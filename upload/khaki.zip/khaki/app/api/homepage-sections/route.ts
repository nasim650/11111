import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserRoleFromRequest, isAdmin } from '@/lib/utils'

export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const isActiveOnly = url.searchParams.get('isActive') !== 'false'

    const sections = await db.homepageSection.findMany({
      where: isActiveOnly ? { isActive: true } : undefined,
      include: { category: { select: { id: true, name: true, slug: true } } },
      orderBy: { sortOrder: 'asc' },
    })

    return NextResponse.json({ success: true, data: sections })
  } catch (error) {
    console.error('Get homepage sections error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const role = await getUserRoleFromRequest(request)
    if (!isAdmin(role)) {
      return NextResponse.json(
        { success: false, error: 'Forbidden: Admin access required' },
        { status: 403 }
      )
    }

    const body = await request.json()
    const {
      title, type, subtitle, description, categoryId, content, image,
      bgColor, sortOrder, isActive, layout, limit,
    } = body

    if (!title) {
      return NextResponse.json(
        { success: false, error: 'Title is required' },
        { status: 400 }
      )
    }

    const section = await db.homepageSection.create({
      data: {
        title,
        type: type || 'product_grid',
        subtitle: subtitle || null,
        description: description || null,
        categoryId: categoryId || null,
        content: content || null,
        image: image || null,
        bgColor: bgColor || null,
        sortOrder: sortOrder ?? 0,
        isActive: isActive ?? true,
        layout: layout || 'grid',
        limit: limit ?? 8,
      },
      include: { category: true },
    })

    return NextResponse.json({ success: true, data: section }, { status: 201 })
  } catch (error) {
    console.error('Create homepage section error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
