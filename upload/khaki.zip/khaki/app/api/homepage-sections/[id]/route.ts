import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserRoleFromRequest, isAdmin } from '@/lib/utils'
import { deleteManagedMedia } from '@/lib/media'

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const role = await getUserRoleFromRequest(request)
    if (!isAdmin(role)) {
      return NextResponse.json(
        { success: false, error: 'Forbidden: Admin access required' },
        { status: 403 }
      )
    }

    const { id } = await params
    const body = await request.json()

    const data: Record<string, unknown> = {}
    const fields = [
      'title', 'type', 'subtitle', 'description', 'categoryId',
      'content', 'image', 'bgColor', 'layout',
    ]
    for (const field of fields) {
      if (body[field] !== undefined) data[field] = body[field]
    }
    if (body.sortOrder !== undefined) data.sortOrder = body.sortOrder
    if (body.isActive !== undefined) data.isActive = body.isActive
    if (body.limit !== undefined) data.limit = body.limit

    const section = await db.homepageSection.update({
      where: { id },
      data,
      include: { category: true },
    })

    return NextResponse.json({ success: true, data: section })
  } catch (error) {
    console.error('Update homepage section error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const role = await getUserRoleFromRequest(request)
    if (!isAdmin(role)) {
      return NextResponse.json(
        { success: false, error: 'Forbidden: Admin access required' },
        { status: 403 }
      )
    }

    const { id } = await params
    const section = await db.homepageSection.findUnique({
      where: { id },
      select: { image: true },
    })
    await db.homepageSection.delete({ where: { id } })
    await deleteManagedMedia([section?.image])

    return NextResponse.json({ success: true, data: null })
  } catch (error) {
    console.error('Delete homepage section error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
