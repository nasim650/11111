import { db } from '@/lib/db'
import { getUserFromRequest } from '@/lib/utils'

export async function GET(request: Request) {
  const user = await getUserFromRequest(request)
  if (!user || (user.role !== 'admin' && user.role !== 'manager')) {
    return Response.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { searchParams } = new URL(request.url)
  const page = Math.max(1, Number(searchParams.get('page')) || 1)
  const limit = Math.min(100, Math.max(1, Number(searchParams.get('limit')) || 20))
  const moduleFilter = searchParams.get('module')
  const action = searchParams.get('action')
  const startDate = searchParams.get('startDate')
  const endDate = searchParams.get('endDate')

  const where: Record<string, unknown> = {}
  if (moduleFilter) where.module = moduleFilter
  if (action) where.action = { contains: action }

  if (startDate || endDate) {
    const dateFilter: Record<string, unknown> = {}
    if (startDate) dateFilter.gte = new Date(startDate)
    if (endDate) dateFilter.lte = new Date(endDate)
    where.createdAt = dateFilter
  }

  const [logs, total] = await Promise.all([
    db.auditLog.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * limit,
      take: limit,
    }),
    db.auditLog.count({ where }),
  ])

  return Response.json({
    success: true,
    data: { data: logs, pagination: { page, limit, total, totalPages: Math.ceil(total / limit) } },
  })
}
