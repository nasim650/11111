import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserFromRequest } from '@/lib/utils'

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authUser = await getUserFromRequest(request)
    if (!authUser) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      )
    }

    const { id } = await params
    const body = await request.json()
    const { isRead, markAllRead, userId } = body

    // Ownership check: non-admin users can only modify their own notifications
    if (authUser.role !== 'admin' && authUser.role !== 'manager') {
      if (markAllRead && userId && userId !== authUser.userId) {
        return NextResponse.json(
          { success: false, error: 'Unauthorized: you can only modify your own notifications' },
          { status: 403 }
        )
      }
      const notification = await db.notification.findUnique({ where: { id }, select: { userId: true } })
      if (notification && notification.userId !== authUser.userId) {
        return NextResponse.json(
          { success: false, error: 'Unauthorized: you can only modify your own notifications' },
          { status: 403 }
        )
      }
    }

    if (markAllRead && userId) {
      await db.notification.updateMany({
        where: { userId, isRead: false },
        data: { isRead: true },
      })
      return NextResponse.json({ success: true, message: 'All notifications marked as read' })
    }

    const notification = await db.notification.update({
      where: { id },
      data: { isRead: isRead ?? true },
    })

    return NextResponse.json({ success: true, data: notification })
  } catch (error) {
    console.error('Update notification error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authUser = await getUserFromRequest(request)
    if (!authUser) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      )
    }

    const { id } = await params

    // Ownership check: non-admin users can only delete their own notifications
    if (authUser.role !== 'admin' && authUser.role !== 'manager') {
      const notification = await db.notification.findUnique({ where: { id }, select: { userId: true } })
      if (notification && notification.userId !== authUser.userId) {
        return NextResponse.json(
          { success: false, error: 'Unauthorized: you can only delete your own notifications' },
          { status: 403 }
        )
      }
    }

    await db.notification.delete({ where: { id } })
    return NextResponse.json({ success: true, message: 'Notification deleted' })
  } catch (error) {
    console.error('Delete notification error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
