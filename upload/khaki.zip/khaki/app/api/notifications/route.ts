import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserFromRequest, getPaginationParams, paginatedResponse } from '@/lib/utils'

export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const authUser = await getUserFromRequest(request)
    const userId = authUser?.userId || url.searchParams.get('userId')
    const { page, limit, skip } = getPaginationParams(url)

    if (!userId) {
      return NextResponse.json(
        { success: false, error: 'User ID is required' },
        { status: 400 }
      )
    }

    // Ownership check: non-admin users can only see their own notifications
    if (authUser && authUser.role !== 'admin' && authUser.role !== 'manager') {
      const queryUserId = url.searchParams.get('userId')
      if (queryUserId && queryUserId !== authUser.userId) {
        return NextResponse.json(
          { success: false, error: 'Unauthorized: you can only view your own notifications' },
          { status: 403 }
        )
      }
    }

    const where: Record<string, unknown> = {}
    if (userId) where.userId = userId

    const [notifications, total] = await Promise.all([
      db.notification.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      db.notification.count({ where }),
    ])

    return NextResponse.json({
      success: true,
      data: paginatedResponse(notifications, total, page, limit),
    })
  } catch (error) {
    console.error('Get notifications error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { userId, title, message, type } = body

    if (!title || !message) {
      return NextResponse.json(
        { success: false, error: 'Title and message are required' },
        { status: 400 }
      )
    }

    const notification = await db.notification.create({
      data: {
        userId: userId || null,
        title,
        message,
        type: type || 'info',
      },
    })

    return NextResponse.json({ success: true, data: notification }, { status: 201 })
  } catch (error) {
    console.error('Create notification error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
