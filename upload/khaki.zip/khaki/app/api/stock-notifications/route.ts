import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// Email validation
const EMAIL_REGEX = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/

export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const productId = url.searchParams.get('productId')

    if (!productId) {
      return NextResponse.json(
        { success: false, error: 'productId query parameter is required' },
        { status: 400 }
      )
    }

    // Check if product exists
    const product = await db.product.findUnique({
      where: { id: productId },
      select: { id: true, name: true, stock: true, status: true },
    })

    if (!product) {
      return NextResponse.json(
        { success: false, error: 'Product not found' },
        { status: 404 }
      )
    }

    // Get notification requests for this product
    const notifications = await db.stockNotification.findMany({
      where: { productId },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json({
      success: true,
      data: {
        product: {
          id: product.id,
          name: product.name,
          stock: product.stock,
          status: product.status,
          isOutOfStock: product.stock <= 0,
        },
        notifications: {
          total: notifications.length,
          pending: notifications.filter((n) => !n.notified).length,
          notified: notifications.filter((n) => n.notified).length,
        },
        // Don't expose individual email addresses for privacy
      },
    })
  } catch (error) {
    console.error('Get stock notification status error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { productId, email } = body

    // Validate required fields
    if (!productId) {
      return NextResponse.json(
        { success: false, error: 'Product ID is required' },
        { status: 400 }
      )
    }

    if (!email) {
      return NextResponse.json(
        { success: false, error: 'Email is required' },
        { status: 400 }
      )
    }

    if (!EMAIL_REGEX.test(email)) {
      return NextResponse.json(
        { success: false, error: 'Please provide a valid email address' },
        { status: 400 }
      )
    }

    // Check if product exists
    const product = await db.product.findUnique({
      where: { id: productId },
      select: { id: true, name: true, stock: true, status: true },
    })

    if (!product) {
      return NextResponse.json(
        { success: false, error: 'Product not found' },
        { status: 404 }
      )
    }

    // Check if product is actually out of stock
    if (product.stock > 0) {
      return NextResponse.json(
        {
          success: false,
          error: 'This product is currently in stock. You can purchase it now!',
          data: { productName: product.name, stock: product.stock },
        },
        { status: 400 }
      )
    }

    // Check if email already registered for this product
    const existingNotification = await db.stockNotification.findUnique({
      where: {
        productId_email: { productId, email },
      },
    })

    if (existingNotification) {
      if (existingNotification.notified) {
        // Already notified - product was back in stock
        return NextResponse.json({
          success: true,
          data: existingNotification,
          message: 'You have already been notified about this product\'s availability. The product may be back in stock!',
        })
      }

      // Already registered but not yet notified
      return NextResponse.json({
        success: true,
        data: existingNotification,
        message: 'You are already registered to receive a notification when this product is back in stock.',
      })
    }

    // Create new stock notification
    const notification = await db.stockNotification.create({
      data: {
        productId,
        email,
        notified: false,
      },
    })

    console.log(`[Stock Notification] New registration:`)
    console.log(`  Product: ${product.name} (ID: ${productId})`)
    console.log(`  Email: ${email}`)
    console.log(`  Current stock: ${product.stock}`)

    return NextResponse.json(
      {
        success: true,
        data: notification,
        message: `You will be notified at ${email} when "${product.name}" is back in stock.`,
      },
      { status: 201 }
    )
  } catch (error) {
    console.error('Create stock notification error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
