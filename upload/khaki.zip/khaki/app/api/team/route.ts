import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserRoleFromRequest, isAdmin } from '@/lib/utils'

export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const isActiveOnly = url.searchParams.get('isActive') !== 'false'

    const members = await db.teamMember.findMany({
      where: isActiveOnly ? { isActive: true } : undefined,
      orderBy: { sortOrder: 'asc' },
    })

    return NextResponse.json({ success: true, data: members })
  } catch (error) {
    console.error('Get team members error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const role = await getUserRoleFromRequest(request)
    if (!isAdmin(role)) {
      return NextResponse.json(
        { success: false, error: 'Forbidden: Admin access required' },
        { status: 403 }
      )
    }

    const body = await request.json()
    const { name, role: memberRole, bio, image, email, phone, isActive, sortOrder } = body

    if (!name || !memberRole) {
      return NextResponse.json(
        { success: false, error: 'Name and role are required' },
        { status: 400 }
      )
    }

    const member = await db.teamMember.create({
      data: {
        name,
        role: memberRole,
        bio: bio || null,
        image: image || null,
        email: email || null,
        phone: phone || null,
        isActive: isActive ?? true,
        sortOrder: sortOrder ?? 0,
      },
    })

    return NextResponse.json({ success: true, data: member }, { status: 201 })
  } catch (error) {
    console.error('Create team member error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
