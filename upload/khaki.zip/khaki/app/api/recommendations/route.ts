import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const productId = url.searchParams.get('productId')
    const limitParam = url.searchParams.get('limit')
    const limit = Math.min(8, Math.max(1, parseInt(limitParam || '4')))

    if (!productId) {
      return NextResponse.json(
        { success: false, error: 'productId query parameter is required' },
        { status: 400 }
      )
    }

    // Get the source product
    const sourceProduct = await db.product.findUnique({
      where: { id: productId },
      include: {
        images: { where: { isFeatured: true }, take: 1 },
        category: { select: { id: true, name: true } },
      },
    })

    if (!sourceProduct) {
      return NextResponse.json(
        { success: false, error: 'Product not found' },
        { status: 404 }
      )
    }

    const sourcePrice = sourceProduct.discountPrice ?? sourceProduct.price
    const priceMin = sourcePrice * 0.7  // 30% below
    const priceMax = sourcePrice * 1.3  // 30% above

    // Strategy 1: Products from same category with similar price range
    const sameCategorySimilarPrice = await db.product.findMany({
      where: {
        categoryId: sourceProduct.categoryId,
        id: { not: productId },
        status: 'active',
        stock: { gt: 0 },
        OR: [
          { discountPrice: { gte: priceMin, lte: priceMax } },
          { discountPrice: null, price: { gte: priceMin, lte: priceMax } },
        ],
      },
      include: {
        images: { where: { isFeatured: true }, take: 1 },
        category: { select: { id: true, name: true, slug: true } },
      },
      take: limit,
      orderBy: { isBestSeller: 'desc' },
    })

    // If we have enough from same category + similar price, return them
    if (sameCategorySimilarPrice.length >= limit) {
      return NextResponse.json({
        success: true,
        data: sameCategorySimilarPrice.map(formatProduct),
      })
    }

    // Strategy 2: Products from same category (any price)
    const sameCategoryAnyPrice = await db.product.findMany({
      where: {
        categoryId: sourceProduct.categoryId,
        id: { not: productId },
        status: 'active',
        stock: { gt: 0 },
      },
      include: {
        images: { where: { isFeatured: true }, take: 1 },
        category: { select: { id: true, name: true, slug: true } },
      },
      take: limit,
      orderBy: { isBestSeller: 'desc' },
    })

    // Combine unique results from same category strategies
    const seenIds = new Set<string>()
    const combined: typeof sameCategoryAnyPrice = []

    for (const p of [...sameCategorySimilarPrice, ...sameCategoryAnyPrice]) {
      if (!seenIds.has(p.id) && combined.length < limit) {
        seenIds.add(p.id)
        combined.push(p)
      }
    }

    if (combined.length >= limit) {
      return NextResponse.json({
        success: true,
        data: combined.map(formatProduct),
      })
    }

    // Strategy 3: Best sellers as fallback
    const bestSellers = await db.product.findMany({
      where: {
        id: { not: productId },
        status: 'active',
        stock: { gt: 0 },
        isBestSeller: true,
      },
      include: {
        images: { where: { isFeatured: true }, take: 1 },
        category: { select: { id: true, name: true, slug: true } },
      },
      take: limit,
    })

    for (const p of bestSellers) {
      if (!seenIds.has(p.id) && combined.length < limit) {
        seenIds.add(p.id)
        combined.push(p)
      }
    }

    // If still not enough, get any active products
    if (combined.length < limit) {
      const moreProducts = await db.product.findMany({
        where: {
          id: { not: productId },
          status: 'active',
          stock: { gt: 0 },
        },
        include: {
          images: { where: { isFeatured: true }, take: 1 },
          category: { select: { id: true, name: true, slug: true } },
        },
        take: limit - combined.length,
        orderBy: { createdAt: 'desc' },
      })

      for (const p of moreProducts) {
        if (!seenIds.has(p.id) && combined.length < limit) {
          seenIds.add(p.id)
          combined.push(p)
        }
      }
    }

    return NextResponse.json({
      success: true,
      data: combined.map(formatProduct),
    })
  } catch (error) {
    console.error('Get recommendations error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

function formatProduct(product: {
  id: string
  name: string
  slug: string
  shortDescription: string | null
  price: number
  discountPrice: number | null
  unit: string
  stock: number
  isFeatured: boolean
  isBestSeller: boolean
  isNewArrival: boolean
  images: { url: string; alt: string | null }[]
  category: { id: string; name: string; slug: string }
}) {
  return {
    id: product.id,
    name: product.name,
    slug: product.slug,
    shortDescription: product.shortDescription,
    price: product.price,
    discountPrice: product.discountPrice,
    unit: product.unit,
    stock: product.stock,
    isFeatured: product.isFeatured,
    isBestSeller: product.isBestSeller,
    isNewArrival: product.isNewArrival,
    image: product.images[0]?.url || null,
    imageAlt: product.images[0]?.alt || product.name,
    category: product.category,
  }
}
