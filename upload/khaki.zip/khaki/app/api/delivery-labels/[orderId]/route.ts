import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserRoleFromRequest, isAdmin } from '@/lib/utils'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ orderId: string }> }
) {
  try {
    const role = await getUserRoleFromRequest(request)
    if (!isAdmin(role)) {
      return NextResponse.json(
        { success: false, error: 'Forbidden: Admin access required' },
        { status: 403 }
      )
    }

    const { orderId } = await params

    let label = await db.deliveryLabel.findUnique({
      where: { orderId },
    })

    // If label doesn't exist, generate it
    if (!label) {
      const order = await db.order.findUnique({
        where: { id: orderId },
        include: { items: true },
      })

      if (!order) {
        return NextResponse.json(
          { success: false, error: 'Order not found' },
          { status: 404 }
        )
      }

      label = await db.deliveryLabel.create({
        data: {
          orderId,
          customerName: order.guestName || '',
          phone: order.guestPhone || '',
          address: order.guestAddress || '',
          productSummary: order.items.map((i) => `${i.productName} x${i.quantity}`).join(', '),
          totalAmount: order.totalAmount,
          paymentMethod: order.paymentMethod,
          paymentStatus: order.paymentStatus,
          deliveryNote: order.orderNote,
        },
      })
    }

    return NextResponse.json({ success: true, data: label })
  } catch (error) {
    console.error('Get delivery label error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
