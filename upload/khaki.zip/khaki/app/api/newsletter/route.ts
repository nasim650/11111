import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserRoleFromRequest, isAdmin } from '@/lib/utils'
import { rateLimit, getClientIp } from '@/lib/rate-limit'

// Email validation regex
const EMAIL_REGEX = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/

function isValidEmail(email: string): boolean {
  return EMAIL_REGEX.test(email)
}

export async function GET(request: NextRequest) {
  try {
    const role = await getUserRoleFromRequest(request)
    if (!isAdmin(role)) {
      return NextResponse.json(
        { success: false, error: 'Forbidden: Admin access required' },
        { status: 403 }
      )
    }

    const subscribers = await db.newsletterSubscriber.findMany({
      orderBy: { subscribedAt: 'desc' },
    })

    return NextResponse.json({ success: true, data: subscribers })
  } catch (error) {
    console.error('Get newsletter subscribers error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    // Rate limiting: 5 subscriptions per minute per IP
    const clientIp = getClientIp(request)
    const rateLimitResult = rateLimit(`newsletter:${clientIp}`, 5, 60 * 1000)
    if (!rateLimitResult.success) {
      return NextResponse.json(
        { success: false, error: 'Too many requests. Please try again later.' },
        { status: 429, headers: { 'Retry-After': String(Math.ceil((rateLimitResult.reset - Date.now()) / 1000)) } }
      )
    }

    const body = await request.json()
    const { email, name, source } = body

    // Validate email presence and format
    if (!email) {
      return NextResponse.json(
        { success: false, error: 'Email is required' },
        { status: 400 }
      )
    }

    if (!isValidEmail(email)) {
      return NextResponse.json(
        { success: false, error: 'Please provide a valid email address' },
        { status: 400 }
      )
    }

    // Check for duplicate email
    const existing = await db.newsletterSubscriber.findUnique({
      where: { email },
    })

    if (existing) {
      if (!existing.isActive) {
        // Reactivate unsubscribed email
        const reactivated = await db.newsletterSubscriber.update({
          where: { email },
          data: {
            isActive: true,
            unsubscribedAt: null,
            subscribedAt: new Date(),
          },
        })

        // Simulate welcome email
        console.log(`[Newsletter] Welcome back! Sending re-subscription email to: ${email}`)

        return NextResponse.json({
          success: true,
          data: reactivated,
          message: 'Welcome back! You have been re-subscribed to our newsletter.',
        })
      }

      // Already subscribed - return friendly message instead of error
      return NextResponse.json({
        success: true,
        data: existing,
        message: 'You are already subscribed to our newsletter. Thank you for your interest!',
      })
    }

    // Create new subscription with subscription date
    const subscriber = await db.newsletterSubscriber.create({
      data: {
        email,
        name: name || null,
        source: source || 'footer',
        subscribedAt: new Date(),
      },
    })

    // Simulate welcome email
    console.log(`[Newsletter] Welcome! Sending subscription confirmation email to: ${email}`)
    console.log(`[Newsletter] Subscription details: { email: "${email}", name: "${name || 'N/A'}", source: "${source || 'footer'}", subscribedAt: "${subscriber.subscribedAt.toISOString()}" }`)

    return NextResponse.json(
      {
        success: true,
        data: subscriber,
        message: 'Thank you for subscribing! You will receive our latest updates and offers.',
      },
      { status: 201 }
    )
  } catch (error) {
    console.error('Subscribe newsletter error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// Unsubscribe endpoint
export async function DELETE(request: NextRequest) {
  try {
    const body = await request.json()
    const { email } = body

    if (!email) {
      return NextResponse.json(
        { success: false, error: 'Email is required' },
        { status: 400 }
      )
    }

    if (!isValidEmail(email)) {
      return NextResponse.json(
        { success: false, error: 'Please provide a valid email address' },
        { status: 400 }
      )
    }

    const existing = await db.newsletterSubscriber.findUnique({
      where: { email },
    })

    if (!existing) {
      return NextResponse.json({
        success: true,
        message: 'This email is not subscribed to our newsletter.',
      })
    }

    if (!existing.isActive) {
      return NextResponse.json({
        success: true,
        message: 'This email has already been unsubscribed.',
      })
    }

    // Mark as unsubscribed with timestamp
    const updated = await db.newsletterSubscriber.update({
      where: { email },
      data: {
        isActive: false,
        unsubscribedAt: new Date(),
      },
    })

    console.log(`[Newsletter] Unsubscribe request processed for: ${email}`)

    return NextResponse.json({
      success: true,
      data: updated,
      message: 'You have been successfully unsubscribed from our newsletter. We\'re sorry to see you go!',
    })
  } catch (error) {
    console.error('Unsubscribe newsletter error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
