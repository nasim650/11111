import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserRoleFromRequest, isAdmin } from '@/lib/utils'
import { deleteManagedMedia } from '@/lib/media'

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const role = await getUserRoleFromRequest(request)
    if (!isAdmin(role)) {
      return NextResponse.json(
        { success: false, error: 'Forbidden: Admin access required' },
        { status: 403 }
      )
    }

    const { id } = await params
    const body = await request.json()

    const data: Record<string, unknown> = {}
    if (body.name !== undefined) data.name = body.name
    if (body.role !== undefined) data.role = body.role
    if (body.content !== undefined) data.content = body.content
    if (body.rating !== undefined) data.rating = body.rating
    if (body.image !== undefined) data.image = body.image
    if (body.isActive !== undefined) data.isActive = body.isActive
    if (body.sortOrder !== undefined) data.sortOrder = body.sortOrder

    const testimonial = await db.testimonial.update({ where: { id }, data })

    return NextResponse.json({ success: true, data: testimonial })
  } catch (error) {
    console.error('Update testimonial error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const role = await getUserRoleFromRequest(request)
    if (!isAdmin(role)) {
      return NextResponse.json(
        { success: false, error: 'Forbidden: Admin access required' },
        { status: 403 }
      )
    }

    const { id } = await params
    const testimonial = await db.testimonial.findUnique({
      where: { id },
      select: { image: true },
    })
    await db.testimonial.delete({ where: { id } })
    await deleteManagedMedia([testimonial?.image])

    return NextResponse.json({ success: true, data: null })
  } catch (error) {
    console.error('Delete testimonial error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
