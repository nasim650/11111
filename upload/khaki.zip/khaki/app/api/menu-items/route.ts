import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserRoleFromRequest, isAdmin } from '@/lib/utils'
import { cache } from '@/lib/cache'

export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const location = url.searchParams.get('location') || 'main'

    const cacheKey = `menu-items:${location}`
    const cached = cache.get<unknown>(cacheKey)
    if (cached) {
      return NextResponse.json(cached)
    }

    const items = await db.menuItem.findMany({
      where: { isActive: true, location, parentId: null },
      include: { children: { where: { isActive: true }, orderBy: { sortOrder: 'asc' } } },
      orderBy: { sortOrder: 'asc' },
    })

    const responseData = { success: true, data: items }
    cache.set(cacheKey, responseData, 10 * 60 * 1000) // 10 min TTL
    return NextResponse.json(responseData)
  } catch (error) {
    console.error('Get menu items error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const role = await getUserRoleFromRequest(request)
    if (!isAdmin(role)) {
      return NextResponse.json(
        { success: false, error: 'Forbidden: Admin access required' },
        { status: 403 }
      )
    }

    const body = await request.json()
    const { label, url, icon, parentId, sortOrder, isActive, openInNew, location } = body

    if (!label || !url) {
      return NextResponse.json(
        { success: false, error: 'Label and URL are required' },
        { status: 400 }
      )
    }

    const menuItem = await db.menuItem.create({
      data: {
        label,
        url,
        icon: icon || null,
        parentId: parentId || null,
        sortOrder: sortOrder ?? 0,
        isActive: isActive ?? true,
        openInNew: openInNew ?? false,
        location: location || 'main',
      },
    })

    // Invalidate menu-items cache on mutation
    cache.invalidatePattern('menu-items')

    return NextResponse.json({ success: true, data: menuItem }, { status: 201 })
  } catch (error) {
    console.error('Create menu item error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
