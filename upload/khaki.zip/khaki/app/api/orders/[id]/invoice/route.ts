import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserIdFromRequest, getUserRoleFromRequest, isAdmin } from '@/lib/utils'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const userId = await getUserIdFromRequest(request)
    const role = await getUserRoleFromRequest(request)

    const order = await db.order.findUnique({
      where: { id },
      include: {
        items: {
          include: {
            product: {
              select: {
                id: true,
                name: true,
                slug: true,
                images: {
                  where: { isFeatured: true },
                  take: 1,
                  select: { url: true, alt: true },
                },
              },
            },
          },
        },
        payment: true,
        user: { select: { id: true, name: true, email: true, phone: true } },
      },
    })

    if (!order) {
      return NextResponse.json(
        { success: false, error: 'Order not found' },
        { status: 404 }
      )
    }

    // Non-admin users can only view their own invoices
    if (!isAdmin(role) && order.userId !== userId) {
      return NextResponse.json(
        { success: false, error: 'Forbidden' },
        { status: 403 }
      )
    }

    // Get company info from site config
    const siteConfigs = await db.siteConfig.findMany({
      where: {
        key: { in: ['siteName', 'siteTagline', 'phone', 'email', 'address', 'logo'] },
      },
    })
    const configMap: Record<string, string> = {}
    for (const config of siteConfigs) {
      configMap[config.key] = config.value
    }

    // Build invoice data
    const invoiceNumber = `INV-${order.orderNumber}`
    const invoiceDate = order.createdAt

    // Customer info
    const customerInfo = order.user
      ? {
          name: order.user.name,
          email: order.user.email,
          phone: order.user.phone,
        }
      : {
          name: order.guestName,
          email: order.guestEmail,
          phone: order.guestPhone,
          address: order.guestAddress,
        }

    // Invoice items with product images
    const invoiceItems = order.items.map((item) => ({
      id: item.id,
      productName: item.productName,
      productImage: item.product?.images[0]?.url || item.image || null,
      quantity: item.quantity,
      unit: item.unit,
      price: item.price,
      totalPrice: Math.round(item.price * item.quantity * 100) / 100,
    }))

    // Totals
    const subtotal = order.items.reduce(
      (sum, item) => sum + item.price * item.quantity,
      0
    )
    const discount = order.discountAmount
    const deliveryCharge = order.deliveryCharge
    const total = order.totalAmount

    // Payment info
    const paymentInfo = order.payment
      ? {
          method: order.paymentMethod,
          status: order.payment.status,
          transactionId: order.payment.transactionId,
          paidAt: order.payment.paidAt,
        }
      : {
          method: order.paymentMethod,
          status: order.paymentStatus,
          transactionId: null,
          paidAt: null,
        }

    const invoice = {
      invoiceNumber,
      invoiceDate,
      orderNumber: order.orderNumber,
      orderStatus: order.orderStatus,
      companyInfo: {
        name: configMap.siteName || 'Khati Khadyo',
        tagline: configMap.siteTagline || '',
        phone: configMap.phone || '',
        email: configMap.email || '',
        address: configMap.address || '',
        logo: configMap.logo || '',
      },
      customer: customerInfo,
      items: invoiceItems,
      totals: {
        subtotal: Math.round(subtotal * 100) / 100,
        discount: Math.round(discount * 100) / 100,
        deliveryCharge: Math.round(deliveryCharge * 100) / 100,
        total: Math.round(total * 100) / 100,
        currency: 'BDT',
      },
      payment: paymentInfo,
      couponCode: order.couponCode || null,
      orderNote: order.orderNote || null,
    }

    return NextResponse.json({
      success: true,
      data: invoice,
    })
  } catch (error) {
    console.error('Get invoice error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
