import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserRoleFromRequest, getUserIdFromRequest, getUserFromRequest, isAdmin, getPaginationParams, paginatedResponse, generateOrderNumber } from '@/lib/utils'
import { validateCheckout, validationError } from '@/lib/validation'
import { appendPaymentLog } from '@/lib/sslcommerz'

export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const role = await getUserRoleFromRequest(request)
    const userId = await getUserIdFromRequest(request)
    const { page, limit, skip } = getPaginationParams(url)

    const orderStatus = url.searchParams.get('orderStatus')
    const paymentStatus = url.searchParams.get('paymentStatus')

    const where: Record<string, unknown> = {}

    // Non-admin users can only see their own orders
    if (!isAdmin(role) && userId) {
      where.userId = userId
    } else if (!isAdmin(role)) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      )
    }

    if (orderStatus) where.orderStatus = orderStatus
    if (paymentStatus) where.paymentStatus = paymentStatus

    const [orders, total] = await Promise.all([
      db.order.findMany({
        where,
        include: {
          items: true,
          payment: true,
          deliveryLabel: true,
          user: { select: { id: true, name: true, email: true, phone: true } },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      db.order.count({ where }),
    ])

    return NextResponse.json({
      success: true,
      data: paginatedResponse(orders, total, page, limit),
    })
  } catch (error) {
    console.error('Get orders error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const validated = validateCheckout(body)
    if (!validated.ok) {
      return NextResponse.json(
        validationError(validated.errors),
        { status: 400 }
      )
    }
    const {
      userId, guestName, guestPhone, guestEmail, guestAddress,
      items,
      paymentMethod, orderNote, couponCode,
      addressId, shippingMethod,
    } = validated.data

    if (userId) {
      const authUser = await getUserFromRequest(request)
      if (!authUser) {
        return NextResponse.json(
          { success: false, error: 'Authentication required for user checkout' },
          { status: 401 }
        )
      }
      if (authUser.role !== 'admin' && authUser.role !== 'manager' && authUser.userId !== userId) {
        return NextResponse.json(
          { success: false, error: 'Unauthorized: you can only create orders for yourself' },
          { status: 403 }
        )
      }
    }

    // Get address if addressId provided
    let shippingAddress: Record<string, unknown> | null = null
    if (addressId && userId) {
      const address = await db.address.findFirst({ where: { id: addressId, userId } })
      if (!address) {
        return NextResponse.json(
          { success: false, error: 'Delivery address not found' },
          { status: 400 }
        )
      }
      shippingAddress = {
        name: address.name,
        phone: address.phone,
        address: address.address,
        city: address.city,
        district: address.district,
        postalCode: address.postalCode,
      }
    }

    // Verify prices server-side
    let subtotal = 0
    const verifiedItems: Array<{
      productId: string
      productName: string
      quantity: number
      unit: string
      price: number
      image: string | null
    }> = []

    for (const item of items) {
      const product = await db.product.findUnique({
        where: { id: item.productId },
        select: { id: true, name: true, price: true, discountPrice: true, stock: true, unit: true, status: true }
      })

      if (!product || product.status !== 'active') {
        return NextResponse.json(
          { success: false, error: `Product ${item.productId} not available` },
          { status: 400 }
        )
      }

      if (product.stock < item.quantity) {
        return NextResponse.json(
          { success: false, error: `Insufficient stock for ${product.name}` },
          { status: 400 }
        )
      }

      const itemPrice = product.discountPrice != null ? product.discountPrice : product.price
      const itemTotal = itemPrice * item.quantity
      subtotal += itemTotal

      verifiedItems.push({
        productId: product.id,
        productName: product.name,
        quantity: item.quantity,
        unit: product.unit,
        price: itemPrice,
        image: item.image,
      })

      // Deduct stock
      await db.product.update({
        where: { id: product.id },
        data: { stock: { decrement: item.quantity } }
      })
    }

    // ─── Calculate delivery charge server-side ────────────────────────────
    const shippingConfigs = await db.siteConfig.findMany({
      where: { group: { in: ['shipping', 'payment'] } }
    })
    const shippingConfig: Record<string, string> = {}
    for (const config of shippingConfigs) {
      shippingConfig[config.key] = config.value
    }

    const freeShippingThreshold = Number(shippingConfig.free_shipping_threshold || shippingConfig.free_delivery_min) || 500
    const standardDeliveryCharge = Number(shippingConfig.standard_delivery_charge || shippingConfig.delivery_charge) || 60
    const expressDeliveryCharge = Number(shippingConfig.express_delivery_charge) || 120

    let deliveryCharge = standardDeliveryCharge
    if (subtotal >= freeShippingThreshold) {
      deliveryCharge = 0
    }
    // If express delivery selected
    if (shippingMethod === 'express') {
      deliveryCharge = expressDeliveryCharge
      if (subtotal >= freeShippingThreshold) {
        deliveryCharge = expressDeliveryCharge - standardDeliveryCharge // only pay difference
      }
    }

    // ─── Calculate discount server-side from coupon ──────────────────────
    let discountAmount = 0
    let validatedCouponCode: string | null = null
    if (couponCode) {
      const coupon = await db.coupon.findFirst({
        where: {
          code: couponCode,
          isActive: true,
          validFrom: { lte: new Date() },
          validTo: { gte: new Date() },
        }
      })
      if (coupon) {
        if (coupon.minOrder && subtotal < coupon.minOrder) {
          return NextResponse.json(
            { success: false, error: `Coupon requires minimum order of ৳${coupon.minOrder}` },
            { status: 400 }
          )
        } else if (coupon.usageLimit && coupon.usedCount >= coupon.usageLimit) {
          return NextResponse.json(
            { success: false, error: 'Coupon usage limit has been reached' },
            { status: 400 }
          )
        } else {
          if (coupon.type === 'percentage') {
            discountAmount = Math.round((subtotal * coupon.value) / 100)
            if (coupon.maxDiscount) {
              discountAmount = Math.min(discountAmount, coupon.maxDiscount)
            }
          } else {
            discountAmount = coupon.value
          }
          validatedCouponCode = coupon.code
          // Increment coupon usage
          await db.coupon.update({
            where: { id: coupon.id },
            data: { usedCount: { increment: 1 } }
          })
        }
      } else {
        return NextResponse.json(
          { success: false, error: 'Invalid or expired coupon code' },
          { status: 400 }
        )
      }
    }

    // ─── Recalculate total with server-side values ──────────────────────
    const totalAmount = subtotal + deliveryCharge - discountAmount

    const orderNumber = generateOrderNumber()

    const order = await db.order.create({
      data: {
        orderNumber,
        userId: userId || null,
        guestName: guestName || (shippingAddress?.name as string) || null,
        guestPhone: guestPhone || (shippingAddress?.phone as string) || null,
        guestEmail,
        guestAddress: guestAddress || (shippingAddress ? `${(shippingAddress as Record<string, string>).address}, ${(shippingAddress as Record<string, string>).city}` : null),
        totalAmount,
        discountAmount,
        deliveryCharge,
        paymentMethod,
        paymentStatus: paymentMethod === 'online' ? 'pending' : 'pending',
        orderNote,
        couponCode: validatedCouponCode,
        items: {
          create: verifiedItems.map((item) => ({
            productId: item.productId,
            productName: item.productName,
            quantity: item.quantity,
            unit: item.unit,
            price: parseFloat(String(item.price)),
            image: item.image || null,
          })),
        },
      },
      include: { items: true },
    })

    if (paymentMethod === 'online') {
      await db.payment.create({
        data: {
          orderId: order.id,
          userId: userId || null,
          method: 'online',
          gateway: 'sslcommerz',
          status: 'pending',
          amount: totalAmount,
          gatewayResponse: appendPaymentLog(null, {
            event: 'order_created',
            status: 'pending',
            message: 'Awaiting SSLCOMMERZ session initiation',
          }),
        },
      })
    }

    // Clear cart for this user after order
    if (userId) {
      await db.cartItem.deleteMany({ where: { userId } })
    }

    // Create delivery label
    await db.deliveryLabel.create({
      data: {
        orderId: order.id,
        customerName: order.guestName || '',
        phone: order.guestPhone || '',
        address: order.guestAddress || '',
        productSummary: order.items.map((i) => `${i.productName} x${i.quantity}`).join(', '),
        totalAmount: order.totalAmount,
        paymentMethod: order.paymentMethod,
        paymentStatus: order.paymentStatus,
      },
    })

    return NextResponse.json({ success: true, data: order, ...order }, { status: 201 })
  } catch (error) {
    console.error('Create order error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
