import { NextRequest, NextResponse } from 'next/server'
import path from 'path'
import { db } from '@/lib/db'
import { uploadImageToCloudinary } from '@/lib/cloudinary'
import { csrfGuard, rateLimitOrResponse, requireAdmin } from '@/lib/security'
import { createAuditLog } from '@/lib/audit'

const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif']
const MAX_FILE_SIZE = 5 * 1024 * 1024 // 5MB
const MAX_FILES = 5
const ALLOWED_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.gif', '.webp']

function sanitizeFilename(name: string): string {
  // Remove path traversal attempts and dangerous characters
  const base = path.basename(name)
  // Replace any non-alphanumeric, non-dot, non-dash, non-underscore characters
  return base.replace(/[^a-zA-Z0-9.\-_]/g, '_')
}

export async function POST(request: NextRequest) {
  try {
    const csrf = csrfGuard(request)
    if (csrf) return csrf
    const limited = rateLimitOrResponse(request, 'uploads', 20, 60 * 1000)
    if (limited) return limited
    const admin = await requireAdmin(request)
    if (!admin.ok) return admin.response

    const formData = await request.formData()
    const folder = sanitizeFilename((formData.get('folder') as string) || 'general')

    // Support both single file and multiple files
    const files: File[] = []
    const singleFile = formData.get('file') as File | null
    if (singleFile) {
      files.push(singleFile)
    }
    // Also check for multiple files under 'files' key
    const multiFiles = formData.getAll('files') as File[]
    if (multiFiles.length > 0) {
      files.push(...multiFiles)
    }

    if (files.length === 0) {
      return NextResponse.json(
        { success: false, error: 'File is required' },
        { status: 400 }
      )
    }

    // Validate maximum files per request
    if (files.length > MAX_FILES) {
      return NextResponse.json(
        { success: false, error: `Maximum ${MAX_FILES} files allowed per request` },
        { status: 400 }
      )
    }

    const uploadedFiles: Array<{ url: string; filename: string; originalName: string; size: number; type: string }> = []

    for (const file of files) {
      // Validate file type
      if (!ALLOWED_TYPES.includes(file.type)) {
        return NextResponse.json(
          { success: false, error: `File type ${file.type} is not allowed. Allowed types: ${ALLOWED_TYPES.join(', ')}` },
          { status: 400 }
        )
      }

      // Validate file extension (double-check even if MIME type is valid)
      const ext = path.extname(file.name).toLowerCase()
      if (!ALLOWED_EXTENSIONS.includes(ext)) {
        return NextResponse.json(
          { success: false, error: `File extension ${ext} is not allowed. Allowed extensions: ${ALLOWED_EXTENSIONS.join(', ')}` },
          { status: 400 }
        )
      }

      // Validate file size
      if (file.size > MAX_FILE_SIZE) {
        return NextResponse.json(
          { success: false, error: `File "${file.name}" exceeds maximum allowed size of 5MB` },
          { status: 400 }
        )
      }

      const safeExt = ext || '.jpg'
      const upload = await uploadImageToCloudinary(file, folder)
      const filename = `${upload.publicId}${safeExt}`

      uploadedFiles.push({
        url: upload.url,
        filename,
        originalName: file.name,
        size: upload.bytes || file.size,
        type: file.type,
      })

      await db.mediaFile.create({
        data: {
          name: sanitizeFilename(file.name),
          url: upload.url,
          type: 'image',
          mimeType: file.type,
          size: upload.bytes || file.size,
          folder,
          alt: null,
        },
      })
    }

    await createAuditLog({
      adminId: admin.userId,
      action: 'upload',
      module: 'media',
      newData: uploadedFiles.map((file) => ({ url: file.url, type: file.type, size: file.size })),
    })

    return NextResponse.json({
      success: true,
      data: uploadedFiles.length === 1 ? uploadedFiles[0] : uploadedFiles,
      files: uploadedFiles,
    }, { status: 201 })
  } catch (error) {
    console.error('Upload file error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
