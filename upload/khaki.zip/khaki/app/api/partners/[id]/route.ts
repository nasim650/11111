import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserRoleFromRequest, isAdmin } from '@/lib/utils'
import { deleteManagedMedia } from '@/lib/media'

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const role = await getUserRoleFromRequest(request)
    if (!isAdmin(role)) {
      return NextResponse.json(
        { success: false, error: 'Forbidden: Admin access required' },
        { status: 403 }
      )
    }

    const { id } = await params
    const body = await request.json()

    const data: Record<string, unknown> = {}
    if (body.name !== undefined) data.name = body.name
    if (body.logo !== undefined) data.logo = body.logo
    if (body.url !== undefined) data.url = body.url
    if (body.isActive !== undefined) data.isActive = body.isActive
    if (body.sortOrder !== undefined) data.sortOrder = body.sortOrder

    const partner = await db.partner.update({ where: { id }, data })

    return NextResponse.json({ success: true, data: partner })
  } catch (error) {
    console.error('Update partner error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const role = await getUserRoleFromRequest(request)
    if (!isAdmin(role)) {
      return NextResponse.json(
        { success: false, error: 'Forbidden: Admin access required' },
        { status: 403 }
      )
    }

    const { id } = await params
    const partner = await db.partner.findUnique({
      where: { id },
      select: { logo: true },
    })
    await db.partner.delete({ where: { id } })
    await deleteManagedMedia([partner?.logo])

    return NextResponse.json({ success: true, data: null })
  } catch (error) {
    console.error('Delete partner error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
