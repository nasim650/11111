import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserRoleFromRequest, isAdmin } from '@/lib/utils'

export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const isActiveOnly = url.searchParams.get('isActive') !== 'false'

    const partners = await db.partner.findMany({
      where: isActiveOnly ? { isActive: true } : undefined,
      orderBy: { sortOrder: 'asc' },
    })

    return NextResponse.json({ success: true, data: partners })
  } catch (error) {
    console.error('Get partners error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const role = await getUserRoleFromRequest(request)
    if (!isAdmin(role)) {
      return NextResponse.json(
        { success: false, error: 'Forbidden: Admin access required' },
        { status: 403 }
      )
    }

    const body = await request.json()
    const { name, logo, url, isActive, sortOrder } = body

    if (!name) {
      return NextResponse.json(
        { success: false, error: 'Name is required' },
        { status: 400 }
      )
    }

    const partner = await db.partner.create({
      data: {
        name,
        logo: logo || null,
        url: url || null,
        isActive: isActive ?? true,
        sortOrder: sortOrder ?? 0,
      },
    })

    return NextResponse.json({ success: true, data: partner }, { status: 201 })
  } catch (error) {
    console.error('Create partner error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
