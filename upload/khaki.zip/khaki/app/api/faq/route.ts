import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserRoleFromRequest, isAdmin } from '@/lib/utils'

export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const isActiveOnly = url.searchParams.get('isActive') !== 'false'
    const category = url.searchParams.get('category')

    const where: Record<string, unknown> = {}
    if (isActiveOnly) where.isActive = true
    if (category) where.category = category

    const faqItems = await db.fAQItem.findMany({
      where,
      orderBy: { sortOrder: 'asc' },
    })

    return NextResponse.json({ success: true, data: faqItems })
  } catch (error) {
    console.error('Get FAQ items error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const role = await getUserRoleFromRequest(request)
    if (!isAdmin(role)) {
      return NextResponse.json(
        { success: false, error: 'Forbidden: Admin access required' },
        { status: 403 }
      )
    }

    const body = await request.json()
    const { question, answer, category, isActive, sortOrder } = body

    if (!question || !answer) {
      return NextResponse.json(
        { success: false, error: 'Question and answer are required' },
        { status: 400 }
      )
    }

    const faqItem = await db.fAQItem.create({
      data: {
        question,
        answer,
        category: category || null,
        isActive: isActive ?? true,
        sortOrder: sortOrder ?? 0,
      },
    })

    return NextResponse.json({ success: true, data: faqItem }, { status: 201 })
  } catch (error) {
    console.error('Create FAQ item error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
