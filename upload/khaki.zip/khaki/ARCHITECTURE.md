# ARCHITECTURE.md

> System architecture of the **Khati Khadyo** e-commerce platform,
> derived from a one-time analysis of the uploaded `v2.zip` source tree.

---

## 1. Architectural Style

Khati Khadyo is a **monolithic Next.js 16 App-Router application** that hosts
three concerns in one deployable unit:

1. **Customer storefront** — a single-page-app (SPA) experience.
2. **Admin CMS** — same app, role-gated client view.
3. **REST API** — Next.js Route Handlers under `/api/*`.

The most distinctive design choice is that **the customer + admin UIs live on a
single route (`/`)** and switch views via a client-side state machine in a
Zustand store, rather than using Next.js file-based routing. Only `/` and
`/api/*` are real routes; everything else is virtual navigation.

---

## 2. Directory Layout

```
.
├── src/
│   ├── app/
│   │   ├── layout.tsx          # Root layout + metadata + Toaster
│   │   ├── page.tsx            # SPA renderer (switches on currentPage)
│   │   ├── globals.css
│   │   └── api/                # 60+ REST Route Handlers (see §5)
│   ├── components/
│   │   ├── layout/             # Navbar, Footer
│   │   ├── pages/              # Customer page components (28)
│   │   │   └── admin/          # Admin page components (19)
│   │   ├── shared/             # Cross-cutting widgets (ProductCard, CartSidebar, AIChatWidget…)
│   │   └── ui/                 # shadcn/ui primitives (47 components)
│   ├── hooks/                  # use-mobile, use-toast
│   ├── lib/                    # Cross-cutting logic (see §4)
│   └── middleware.ts           # Security response headers
├── prisma/
│   ├── schema.prisma           # 30+ models
│   ├── seed.ts                 # Demo data
│   ├── migrations/
│   └── dev.db                  # SQLite database (the real one)
├── public/                     # Logos, favicons, images
├── examples/websocket/         # Reference socket.io demo (not wired into app)
├── agent-ctx/                  # Per-phase agent handover notes
├── Caddyfile                   # Gateway config (:81 → :3000, XTransformPort)
├── middleware.ts (root)        # (duplicate of src/middleware.ts)
├── worklog.md                  # Running dev log
└── package.json
```

> Note: a parallel (older) `app/` and `components/` tree exists at the repo
> root alongside `src/`. The **active** code is under `src/` (per
> `tsconfig.json` paths and `@/` alias). The root-level duplicates appear to
> be legacy and are not the source of truth.

---

## 3. Frontend Architecture

### 3.1 Single-route SPA model
`src/app/page.tsx` is a client component (`'use client'`). On mount it:

1. Rehydrates persisted Zustand state (auth token, cart, wishlist).
2. Calls `loadUser()`, `loadSiteConfig()`, `loadCart()`, `loadWishlist()`.
3. Inspects URL search params for SSLCommerz payment returns
   (`?payment=success&orderId=…`) and routes accordingly.
4. Guards admin pages: if `currentPage` is an `admin-*` view but the user
   isn't an admin, it redirects to `login`.

It then renders either:
- The **admin shell** (`AdminDashboardPage`, no Navbar/Footer) — for `admin-*` pages.
- The **customer shell** (`Navbar` + `main` + `Footer` + global overlays) — otherwise.

A `CustomerPageRenderer` switch maps `currentPage` → the matching lazily-imported
page component. Heavy pages (admin) are `React.lazy` + `Suspense` code-split.

### 3.2 State management — Zustand
`src/lib/store.ts` (~1000 lines) is the single source of client truth. It is
**persisted to localStorage** (`zustand/middleware` `persist`) and exposes:

- **Navigation**: `currentPage`, `pageParams`, `navigate(page, params)`.
- **Auth**: `user`, `accessToken`, `login()`, `register()`, `logout()`,
  `loadUser()`. Token stored both in store and an httpOnly cookie.
- **Cart & Wishlist**: server-backed via `/api/cart` and `/api/wishlist`;
  guest carts keyed by a `kk_session_id` in localStorage.
- **UI**: mobile menu, cart sidebar, quick-view modal, compare drawer,
  order-tracking modal, language toggle (en/bn), search.
- **Notifications**, **recently viewed**, **product comparison**.

### 3.3 UI component system
- **shadcn/ui (New York variant)** — 47 primitives in `src/components/ui/`
  built on Radix UI slots.
- **`cn()`** utility (`src/lib/utils.ts`) merges Tailwind classes via
  `tailwind-merge` + `clsx`.
- **Theme**: light/dark via `next-themes`; Tailwind 4 CSS variables.
- Brand accent leans emerald/teal (food/freshness), deliberately avoiding
  indigo/blue per house style.

### 3.4 Data fetching
No TanStack Query. Pages fetch directly via a thin `src/lib/api.ts` wrapper
around `fetch`, which extracts a normalised `items` array from the
`{ success, data }` envelope. Mutations call API routes and then update the
Zustand store.

---

## 4. Cross-Cutting Library (`src/lib/`)

| File | Responsibility |
|------|----------------|
| `db.ts` | Prisma client singleton |
| `auth.ts` | `hashPassword`, `verifyPassword`, `generateToken`, `verifyToken`, `getUserFromToken` (jose HS256, 7-day JWT) |
| `api.ts` | `fetch` wrapper + `extractItems` normaliser |
| `validation.ts` | zod schemas (checkout, products, coupons, loyalty…); `validateCheckout`, `validationError` |
| `sslcommerz.ts` | SSLCommerz session init, IPN handler, success/fail/cancel routes, payment log |
| `payment-sync.ts` | Reconcile payment status with gateway |
| `cloudinary.ts` | Image upload/destroy |
| `media.ts` | Media helpers |
| `print-utils.ts` | PDFKit invoices/packing slips, bwip-js CODE128, qrcode, thermal receipts, courier labels, `generateAllOrderDocuments` |
| `audit.ts` | AuditLog writer |
| `cache.ts` | In-memory cache helpers |
| `rate-limit.ts` | Per-IP rate limiting (used by auth + chat) |
| `security.ts` | CSRF guard + helpers |
| `store.ts` | Zustand client store |
| `utils.ts` | `cn`, `generateOrderNumber` (`KK-YYYYMMDD-NNNNN`), pagination helpers, role helpers (`isAdmin`, `getUserIdFromRequest`) |

---

## 5. API Layer

### 5.1 Design conventions
- All handlers are Next.js Route Handlers (`app/api/.../route.ts`).
- Every response uses an envelope: `{ success: boolean, data?: …, error?: string }`.
- List endpoints support `?page` & `?limit` via `getPaginationParams` →
  `paginatedResponse`.
- Auth: `getUserFromRequest` / `getUserIdFromRequest` / `getUserRoleFromRequest`
  extract the Bearer JWT; `isAdmin(role)` gates admin endpoints.
- Ownership checks: non-admin users can only read/mutate their own resources
  (orders, addresses, cart, wishlist).
- Input validation via zod schemas → `validationError` on failure.
- Rate limiting on sensitive endpoints (auth: 3–5/min, chat: 20/min).

### 5.2 Endpoint surface (≈60 resources)

| Domain | Routes |
|--------|--------|
| Auth | `auth/login`, `auth/register`, `auth/me` |
| Users/Addresses | `users`, `users/[id]`, `users/[id]/addresses`, `addresses`, `addresses/[id]` |
| Catalog | `products`, `products/[id]`, `products/suggestions`, `recommendations`, `categories`, `categories/[id]`, `subcategories`, `subcategories/[id]` |
| Cart | `cart`, `cart/[id]`, `cart/apply-coupon`, `cart/remove-coupon` |
| Orders | `orders`, `orders/[id]`, `orders/[id]/cancel`, `orders/[id]/status-history`, `orders/[id]/invoice`, `orders/[id]/packing-slip`, `orders/[id]/delivery-label`, `orders/[id]/thermal-receipt`, `orders/[id]/courier-label`, `orders/[id]/barcode`, `orders/[id]/qr-code`, `orders/bulk-print` |
| Payments | `payments`, `payments/[orderId]`, `payments/sslcommerz/{initiate,success,fail,cancel,ipn}` |
| Engagement | `reviews`, `wishlist`, `wishlist/add-all-to-cart`, `coupons`, `coupons/validate`, `loyalty`, `notifications`, `newsletter`, `stock-notifications`, `contact` |
| Content/CMS | `banners`, `homepage-sections`, `menu-items`, `policy-pages`, `policy-pages/slug/[slug]`, `testimonials`, `faq`, `team`, `partners`, `media`, `uploads`, `site-config`, `site-config/[key]` |
| Admin/Ops | `admin/dashboard`, `audit-logs`, `delivery-labels/[orderId]`, `print-queue`, `print-queue/[id]`, `chat` |

### 5.3 Example handler shape (`orders` GET)
```ts
GET /api/orders
  → getUserRoleFromRequest, getUserIdFromRequest
  → non-admin: where.userId = userId (else 401)
  → filter by ?orderStatus / ?paymentStatus
  → db.order.findMany({ include: items, payment, deliveryLabel, user })
  → paginatedResponse(orders, total, page, limit)
```

---

## 6. Data Layer (Prisma + SQLite)

### 6.1 Datasource
- Provider: `sqlite`, URL from `DATABASE_URL` env.
- The **active** DB is `prisma/dev.db`. A stale `db/custom.db` exists and must
  not be treated as canonical (see `DECISIONS.md`).
- The dev script hard-codes `DATABASE_URL=file:/home/z/my-project/prisma/dev.db`,
  overriding the `.env` value.

### 6.2 Model inventory (30+)
**Identity & auth**: `User` (roles: customer/admin/manager, `loyaltyBalance`),
`Address`.
**Catalog**: `Category`, `Subcategory`, `Product`, `ProductImage`,
`ProductVideo`, `Banner`, `HomepageSection`, `MenuItem` (self-referential
hierarchy).
**Commerce**: `CartItem` (userId or sessionId), `Order`, `OrderItem`,
`Payment`, `DeliveryLabel`, `Coupon`.
**Lifecycle/print**: `OrderStatusHistory`, `PrintQueue`, `LoyaltyPoint`.
**Engagement**: `Review`, `Wishlist`, `Notification`, `NewsletterSubscriber`,
`StockNotification`, `ContactMessage`.
**CMS content**: `PolicyPage`, `Testimonial`, `FAQItem`, `TeamMember`,
`Partner`, `MediaFile`.
**Ops**: `AuditLog`, `SiteConfig` (key/value settings store, grouped).

### 6.3 Conventions
- IDs: `cuid()`.
- Timestamps: `createdAt @default(now())`, `updatedAt @updatedAt`.
- Soft flags: `isActive`, `isFeatured`, `isBestSeller`, `isNewArrival`,
  `isVerified`, `isApproved`, `isDefault`, `isRead`.
- Denormalised snapshots on `OrderItem` (`productName`, `price`, `image`) so
  historical orders survive product edits/deletes.
- JSON-as-string columns where Prisma SQLite can't model arrays/lists
  (`specifications`, `tags`, `content`, `deliveryZones`).

---

## 7. Authentication & Security

| Concern | Implementation |
|---------|----------------|
| Password hashing | bcryptjs, cost factor 12 |
| Tokens | JWT HS256 via `jose`, 7-day expiry, no refresh |
| Token transport | `Authorization: Bearer <jwt>` + httpOnly cookie |
| Admin guard | API: `isAdmin(role)` per handler. UI: client-side `user.role === 'admin'` check in `page.tsx` (not middleware-enforced) |
| CSRF | `src/lib/security.ts` origin/host mismatch guard |
| Rate limiting | `src/lib/rate-limit.ts` — auth & chat endpoints |
| Security headers | `middleware.ts` sets CSP, X-Frame-Options DENY, X-Content-Type-Options, Referrer-Policy, Permissions-Policy, HSTS (HTTPS only) |
| Secrets | `JWT_SECRET` env required in production; dev fallback throws if missing |

---

## 8. Payments

- **SSLCommerz** (Bangladesh gateway): `src/lib/sslcommerz.ts` initiates a
  session; the user is redirected to the gateway; callbacks land on
  `payments/sslcommerz/{success,fail,cancel}`; `ipn` route handles async IPN.
  `payment-sync.ts` reconciles final state.
- **COD** (`paymentMethod = "cod"`) creates an order with `paymentStatus = pending`.
- On return, `page.tsx` reads `?payment=success|fail&orderId=` and routes to
  `order-confirmation` or back to `orders`.

---

## 9. Print & Fulfilment Subsystem

`src/lib/print-utils.ts` (`generateAllOrderDocuments`) is invoked after order
creation to generate:
- Invoice PDF, packing slip, delivery label (HTML), thermal receipt,
  courier label (Pathao/Steadfast/RedX/Paperfly), QR code, CODE128 barcode.

Each generated artefact is enqueued in the `PrintQueue` model (status
`PENDING → PRINTING → PRINTED | FAILED`). `AdminPrintQueuePage` monitors the
queue with auto-refresh and a completion progress bar.

> Known limitation: in the dev container, async PDF generation is sometimes
> killed by OOM before `PrintQueue`/`OrderStatusHistory` rows commit. The code
  is correct; production (non-dev) is unaffected.

---

## 10. Gateway & Networking

A **Caddy** gateway on port `:81` is the only externally exposed port:
- Requests with `?XTransformPort=<port>` are reverse-proxied to
  `localhost:<port>` (used for mini-services / socket.io).
- All other requests go to the Next.js dev server on `:3000`.
- Frontend code must use **relative paths only** (e.g. `fetch('/api/orders')`,
  `io('/?XTransformPort=3003')`) — never hard-code `localhost:<port>`.

The `mini-services/` directory is reserved for independent Bun services
(e.g. a socket.io realtime service). Currently only `.gitkeep` is present;
the `examples/websocket/` folder holds a reference implementation.

---

## 11. Build, Tooling & Conventions

- **Lint**: `eslint .` (flat config, `eslint-config-next`).
- **DB scripts**: `db:push`, `db:generate`, `db:migrate`, `db:reset`, `db:seed`.
- **TypeScript**: strict; `@/*` path alias → `./src/*`.
- **Server vs client**: route handlers default to server; page components in
  `components/pages/` opt into `'use client'` when they need hooks/state.
- **No new Prisma clients** may be instantiated in components — always import
  from `src/lib/db.ts`.
- **Styling rule**: prefer shadcn/ui over custom; avoid indigo/blue.

---

## 12. Cross-Cutting Concerns Map

```
Request ──► middleware.ts (security headers)
        ──► Route Handler
              ├─ lib/auth.ts        (who is this?)
              ├─ lib/rate-limit.ts  (are they flooding?)
              ├─ lib/security.ts    (CSRF origin check)
              ├─ lib/validation.ts  (zod input check)
              ├─ lib/db.ts          (Prisma) ──► SQLite
              ├─ lib/audit.ts       (write AuditLog)
              └─ lib/{sslcommerz,cloudinary,print-utils,…} (side-effects)
        ──► { success, data } envelope ──► frontend store update
```
