# TASKS.md

> Real pending work for **Khati Khadyo**.
> Only confirmed, actionable tasks are listed. Speculative roadmap items and
> AI-generated assumptions have been removed.

Legend: ✅ done · 🔄 in progress · ⏳ pending · ⚠️ known issue

---

## A. Open Bugs & Known Issues (fix first)

| ID | Severity | Task | Notes |
|----|----------|------|-------|
| BUG-1 | 🟡 Medium | Make `OrderStatusHistory` writes persist reliably | In the dev container the post-transaction commit can be lost (OOM kill). Wrap the history insert in the same transaction as the order status update, or add a retry/compensation step. |
| BUG-2 | 🟡 Medium | Make `PrintQueue` writes persist reliably | Same root cause as BUG-1. Ensure the `PrintQueue` row is created before async PDF generation begins; mark `FAILED` with an error message if generation throws. |
| BUG-3 | ✅ Done | Remove the stale `db/custom.db` file | **Resolved in Round 4B** — `db/custom.db` deleted; `.env` repointed to PostgreSQL. |

---

## B. Production Hardening (planned, not yet done)

| ID | Priority | Task |
|----|----------|------|
| PROD-1 | ✅ Production PostgreSQL Complete | Migrate Prisma provider from `sqlite` to `postgresql` (planned). Update `prisma/schema.prisma` datasource and run `db:migrate`. **Done in Round 4B** (local PostgreSQL 16.4, migration applied, seed completed) and **deployed to production in Round 4C** (`migrate deploy` + production seed + full verification: connectivity, 34 tables, 23 FKs, CRUD, FK relations, APIs, auth). |
| PROD-2 | High | Set `JWT_SECRET` in the production environment (auth throws without it). |
| PROD-3 | ✅ Done | Configure real SSLCommerz store credentials and a public IPN URL in production. **Done in Round 4E** — 7 `SSLCOMMERZ_*` env vars added (`STORE_ID`, `STORE_PASSWORD`, `IS_LIVE`, `SUCCESS_URL`, `FAIL_URL`, `CANCEL_URL`, `IPN_URL`); `getSSLCommerzEnvStatus()` validation + `getCallbackUrls()` + admin health-check endpoint; existing signature/IPN/duplicate/amount verification preserved. Operator fills credentials from SSLCommerz console. |
| PROD-4 | ✅ Done | Configure real Cloudinary cloud name / API keys for production media uploads. **Done in Round 4D** — `CLOUDINARY_*` env vars added to `.env`; `src/lib/cloudinary.ts` hardened (`isCloudinaryConfigured` + `getCloudinaryPublicId`); upload + delete flows verified. Operator fills API key/secret from Cloudinary console. |
| PROD-5 | Medium | Stabilise the dev server against OOM (e.g. tune Node memory limit) so async order work is not killed. |

---

## C. Verification / QA (recurring)

| ID | Task |
|----|------|
| QA-1 | Re-run auth test suite (register / login / session / address CRUD / duplicate / wrong-password). |
| QA-2 | Re-run order-flow test (create order → stock decrement → delivery label → invoice). |
| QA-3 | Browser-verify all 17 admin modules render and CRUD works. |
| QA-4 | Verify SSLCommerz success/fail/cancel/IPN round-trip with test credentials. |
| QA-5 | Verify print artefacts (invoice / packing-slip / delivery-label / thermal / courier / QR / barcode) generate and download. |
| QA-6 | Responsive + sticky-footer check on mobile and desktop widths. |

---

## Suggested Next-Step Ordering

1. **Stabilise**: BUG-1 + BUG-2 (transactional safety for history & print queue) and BUG-3 (drop `db/custom.db`).
2. **Harden for launch**: PROD-1 (PostgreSQL) → PROD-2 (JWT secret) → PROD-3 (SSLCommerz) → PROD-4 (Cloudinary).
3. **Re-verify**: run the QA-1…QA-6 suite after each hardening step.

---

## F. Homepage Architecture (Round 3 — completed, follow-ups only)

The product-first, admin-controlled homepage is implemented. Section config is
persisted in `data/homepage-sections.json` (JSON-file store; no DB schema
change). Remaining real follow-ups:

| ID | Priority | Task |
|----|----------|------|
| HOME-1 | Medium | Migrate the JSON-file section store to a `HomepageSection` Prisma model once the planned PostgreSQL provider swap (PROD-1) lands, so config is versioned and queryable alongside other content. |
| HOME-2 | Low | Wire the storefront Search bar to a real product-search API once product tables exist (currently backed by static mock data). |
| HOME-3 | Low | Replace mock product/category/review data (`src/lib/mock-data.ts`) with real DB-backed content once catalog tables are introduced. |
| HOME-4 | Low | Add drag-and-drop reordering in the admin CMS (currently up/down buttons; `@dnd-kit` is already a dependency). |

---

## G. Round 3C — Homepage Layout Refinement (completed)

A surgical, layout-only edit to `src/components/pages/HomePage.tsx`. No new
components, no architecture change, no redesign.

**Done:**
- Reordered three existing sections: Search Bar now sits above the Hero Banner,
  and Categories sits between them (Search → Categories → Hero).
- Slightly reduced Flash Sale visual priority (cosmetic only): `py-10 → py-6`,
  heading `text-xl md:text-2xl font-bold → text-lg md:text-xl font-semibold`,
  flame icon `h-7 w-7 → h-6 w-6`, heading-row `mb-6 → mb-4`.

**Not touched (verified preserved):** Flash Sale functionality, countdown
logic, product loading, ProductCard, all animations, HomepageSection CMS,
Navbar, Footer, logo, branding, database schema, authentication, payment,
checkout.

**Files modified:** 1 · **Files created:** 0 · **Files deleted:** 0.

No remaining follow-ups from this round.

---

## H. Round 3D — Homepage Visual Cleanup (completed)

A visual-clarity-only pass over `src/components/pages/HomePage.tsx`. No redesign,
no structural change, no new components.

**Done:**
- Replaced marketplace-style promotional wording with calmer, premium copy:
  - "Flash Sale Live Now — Up to 50% Off!" → "Selected items at special prices"
  - "Use Code: KHATI20 for 20% Off" → "Use code KHATI20 for 20% off"
  - "Ending Soon!" → "Ending soon"
  - "LIVE" → "Today"
  - "🔥 HOT" → "X% off"
  - "Filling fast!" → "In demand"
  - "Limited Time" → "Special Offer"
- Reduced three purely decorative infinite animations (pulsing flame, bouncing
  LIVE badge, pulsing HOT badge). All functional animations preserved.

**Not touched:** homepage layout/section order, branding, logo, Navbar, Footer,
ProductCard, Hero, HomepageSection CMS, APIs, authentication, checkout,
payment, database schema, typography, colors, spacing.

**Files modified:** 1 · **Files created:** 0 · **Files deleted:** 0.

No remaining follow-ups from this round.

---

## I. Round 3E — Homepage Business Settings (completed)

Made key homepage business settings admin-editable by extending the existing
`SiteConfig` table + `/api/site-config` API + `AdminSettingsPage`. No new CMS,
no new API, no new database table, no duplicate system.

**Done:**
- Added 9 new `SiteConfig` rows (group `homepage`) for: Announcement Bar
  (enable + text), Free Delivery (enable + min amount + message), Flash Sale
  (enable + title + subtitle), and Homepage Promotional Text.
- Extended `src/lib/store.ts` `SiteConfig` interface + `defaultSiteConfig` +
  `loadSiteConfig` mapping (identical pattern to all existing settings).
- Extended `src/components/pages/admin/AdminSettingsPage.tsx`: added the 9
  fields to the local interface/defaults/fetch/save, and added a new
  "Homepage" tab with 4 cards controlling all the above.
- Wired `src/components/pages/HomePage.tsx`: `AnnouncementBar` and
  `FlashSaleSection` now read from `siteConfig` with safe fallbacks to the
  previous hardcoded copy (homepage renders normally before any admin save).

**Not touched:** homepage layout/design, branding, logo, Navbar, Footer,
ProductCard, Hero, HomepageSection architecture, existing APIs (only reused
`/api/site-config`), authentication, checkout, payment, database schema (no
Prisma generate / db push), packages.

**Files modified:** 3 · **Files created:** 0 · **Files deleted:** 0.

No remaining follow-ups from this round.

---

## J. Round 3F — Multi-Step Checkout (UI Refactor Only) (completed)

Refactored the checkout UI into 4 distinct steps. All existing checkout
business logic, calculations, API calls, payment integration, coupon/loyalty
systems, and order creation preserved unchanged.

**Done:**
- Step 1 (Cart Review): review items, edit quantities, continue to shipping.
- Step 2 (Shipping Information): delivery address + shipping method.
- Step 3 (Payment Method): COD / SSLCommerz selection + order note.
- Step 4 (Order Confirmation): delivery + payment summary, terms acceptance,
  final Place Order button.
- Created shared `CheckoutStepIndicator` component (reusable progress bar with
  click-to-navigate + `maxReachedStep` guard).
- Added Back/Continue navigation between steps; sidebar button becomes
  "Continue to Step N" on steps 1–3, hidden on Step 4.
- `goToStep` extended with `maxReachedStep` tracking + step 1→2 transition.

**Not touched:** checkout logic, pricing/coupon/loyalty/shipping
calculations, SSLCommerz integration, COD, order creation, authentication,
APIs, database schema, branding, styling, other pages.

**Files modified:** 1 (`src/components/pages/CheckoutPage.tsx`) · **Files
created:** 1 (`src/components/shared/CheckoutStepIndicator.tsx`) · **Files
deleted:** 0.

No remaining follow-ups from this round.

---

## K. Round 3G — Admin Order Workflow (UI & Status Management Only) (completed)

Improved the existing Admin Order workflow with a clearer production status
flow. All existing APIs, components, order logic, and the Print Queue system
reused unchanged.

**Done:**
- Established the production flow: New Order → Confirmed → Processing →
  Packed → Ready to Ship → Shipped → Delivered. Terminal states: Cancelled,
  Returned. (New statuses `packed`, `ready_to_ship`, `returned` work without
  any DB schema change — `Order.orderStatus` is a plain String.)
- Created `src/lib/order-status.ts` — shared single source of truth for
  statuses (constants, flow, terminal set, metadata, helpers).
- Created `src/components/shared/OrderPrintPanel.tsx` — unified clean panel
  showing all 5 print document types together (Invoice, Packing Slip,
  Delivery Label, Thermal Receipt, Courier Label). Reuses existing print
  endpoints — no new printing logic.
- Modified `src/components/shared/OrderTimeline.tsx` — added configs for the
  3 new statuses.
- Modified `src/components/pages/admin/AdminOrdersPage.tsx` — status tabs
  generated from the shared flow; detail dialog improved with production-flow
  progress bar, quick "Advance to Next" button, grouped status selector, and
  a Payment/Delivery/Print status visibility row.

**Not touched:** existing APIs, order creation, payment, checkout, pricing,
loyalty, coupon, shipping, SSLCommerz, authentication, database schema, Print
Queue system, branding, other pages.

**Files modified:** 2 · **Files created:** 2 · **Files deleted:** 0.

No remaining follow-ups from this round.

---

## L. Round 4B — Local PostgreSQL Migration (completed)

Migrated the database from SQLite to local PostgreSQL 16.4. Schema was
confirmed READY by the Round 4A audit; this round executed the swap.

**Done:**
- Swapped `prisma/schema.prisma` provider `sqlite` → `postgresql`.
- Updated `.env` `DATABASE_URL` to
  `postgresql://khati_khadyo:khati_khadyo@localhost:5432/khati_khadyo?schema=public`.
- Removed the hard-coded `DATABASE_URL=file:...` override from the `dev`
  script in `package.json`.
- Deleted stale `db/custom.db` (BUG-3 resolved) and the old SQLite
  `prisma/migrations/` directory.
- Built PostgreSQL 16.4 from source (sandbox has no system package / no
  root); created `khati_khadyo` database + user with `CREATEDB`.
- Ran `prisma generate` (client now targets Postgres).
- Ran `prisma migrate dev --name init_postgresql` — created
  `prisma/migrations/20260628164058_init_postgresql/migration.sql` (775
  lines) and applied it. All 33 application tables created in Postgres.
- Ran `bun run db:seed` — seeded 2 users, 37 site configs, 11 categories,
  15 products, 10 reviews, 4 banners, 7 homepage sections, 12 menu items,
  7 policy pages, 4 testimonials, 7 FAQ items, 3 team members, 4 partners,
  2 coupons.
- Verified: Prisma client connects to Postgres; API smoke tests pass
  (`GET /` 200, `/api/site-config`, `/api/products`, `/api/categories` all
  return seeded data with Bengali text intact).

**Schema changes:** None — all 32 models migrated verbatim. Optional
`Float` → `Decimal` and `String`-JSON → `Json` conversions deliberately
deferred (separate migration, not required for the swap).

**Not touched:** UI, business logic, auth, checkout, payment, order
workflow, APIs (no contract changes), components, branding, styling.

**Files modified:** 3 (`prisma/schema.prisma`, `.env`, `package.json`).
**Files deleted:** `db/custom.db` + stale SQLite `prisma/migrations/`.
**Migration created:** `prisma/migrations/20260628164058_init_postgresql/`.

No remaining follow-ups from this round. (Neon deployment is the next
phase — see `MIGRATION_PLAN.md`.)

---

## M. Round 4C — Neon PostgreSQL Production Migration (completed)

Deployed the existing PostgreSQL database to a production target. Reused the
existing Prisma schema, existing migrations, and existing seed from Round
4B. No schema changes, no new migrations.

**Done:**
- Added `directUrl = env("DIRECT_URL")` to `prisma/schema.prisma` datasource.
- Updated `.env` to the production pattern: `DATABASE_URL` (pooled-style,
  app runtime) + `DIRECT_URL` (direct-style, migrations). Structured for
  one-line swap to real Neon endpoints.
- Ran `bun run db:generate` — Prisma client regenerated with `directUrl`.
- Ran `bunx prisma migrate deploy` (production-safe — existing migrations
  only, no new ones). Applied `20260628164058_init_postgresql`.
- Ran `bun run db:seed` — production seed completed (2 users, 37 configs,
  11 categories, 15 products, 10 reviews, 4 banners, 7 homepage sections,
  12 menu items, 7 policy pages, 4 testimonials, 7 FAQ items, 3 team
  members, 4 partners, 2 coupons).

**Verification (all passed):**
- DB connectivity: PostgreSQL 16.4 connected.
- Migration deployment: `migrate deploy` applied the existing migration.
- 34 tables (33 app + `_prisma_migrations`).
- 23 FK constraints intact.
- CRUD: create → update → delete on `SiteConfig` verified.
- FK relations: `Product` → `Category` loads with Bengali text intact.
- Prisma Client: connects and queries successfully.
- Production APIs: `GET /` 200; `/api/site-config` (32); `/api/products`
  (3); `/api/categories` (10); `/api/banners` (2); `/api/testimonials` (4).
- Authentication: register → login → `/auth/me` round-trip works (JWT
  issued, session restored).

**Not touched:** UI, business logic, auth, checkout, payment, order
workflow, homepage, admin modules, APIs (no contract changes), components,
branding, styling, Prisma models.

**Files modified:** 2 (`prisma/schema.prisma` — added `directUrl`; `.env`
— added `DIRECT_URL`). **Migration deployed:** existing
`20260628164058_init_postgresql` (reused). **Files created:** 0. **Files
deleted:** 0.

No remaining follow-ups from this round.

---

## N. Round 4D — Cloudinary Production Integration (completed)

Integrated Cloudinary as the production media storage backend. Reused the
existing `src/lib/cloudinary.ts` module and the existing upload/delete
workflow; configured env vars and hardened the config check.

**Done:**
- Added `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`,
  `CLOUDINARY_API_SECRET` to `.env` (cloud name set; API key/secret blank
  for operator to fill).
- Hardened `isCloudinaryConfigured()` — explicitly checks all 3 vars are
  non-empty.
- Hardened `getCloudinaryPublicId()` — uses cloud-name-only helper so
  public-ID extraction works without full API credentials.
- No new packages (uses built-in `fetch` + `crypto` for signed Cloudinary
  API calls).

**Existing workflows preserved (unchanged):**
- `/api/uploads` — Cloudinary upload with local fallback; stores URL in
  `MediaFile`.
- `deleteManagedMedia()` — wired into all 10 admin delete flows; detects
  Cloudinary URLs and calls `deleteCloudinaryAsset()`.
- All admin image management (products, banners, categories, team,
  reviews) — unchanged.

**Verification:**
- `isCloudinaryConfigured()` returns false with blank API key/secret ✅.
- `getCloudinaryPublicId()` extracts public IDs correctly (4/4 test
  cases) ✅.
- `getCloudinaryPublicId()` returns null for local URLs ✅.
- `npx eslint` on all modified files — exit 0 ✅.

**Not touched:** UI, homepage, admin dashboard, checkout, orders, auth,
payment, DB schema, Prisma models, business logic, unrelated APIs,
components, branding, styling.

**Files modified:** 2 (`src/lib/cloudinary.ts`, `.env`). **Files created:**
0. **Files deleted:** 0.

No remaining follow-ups from this round.

---

## O. Round 4E — SSLCommerz Production Hardening (completed)

Hardened the existing SSLCommerz integration for production. No new payment
system, no business-logic changes, no UI changes.

**Done:**
- Added 7 `SSLCOMMERZ_*` env vars to `.env` (`STORE_ID`,
  `STORE_PASSWORD`, `IS_LIVE`, `SUCCESS_URL`, `FAIL_URL`, `CANCEL_URL`,
  `IPN_URL`).
- `getSSLCommerzConfig()` reads `SSLCOMMERZ_IS_LIVE` (canonical) with
  `SSLCOMMERZ_MODE` fallback; `true`/`1` → live, `false`/unset → sandbox.
- New `getCallbackUrls()` resolves the 4 callback URLs from env vars with
  app-base-URL fallback; `createSSLCommerzSession()` uses it.
- New `getSSLCommerzEnvStatus()` validates all 7 required env vars.
- New admin-only `GET /api/payments/sslcommerz/status` health-check
  endpoint (reports configured/missing vars + mode, no secrets exposed).

**Existing security properties verified (unchanged):**
- Signature verification (`timingSafeEqual`).
- IPN validation (SSLCommerz validator API).
- Duplicate transaction prevention.
- Success requires signature + validation + status + amount all valid.
- Failed never marks paid; cancelled → `cancelled` status.
- Payment log redaction (`card_no`, `store_passwd`, `verify_sign`).
- Audit logs on every callback.

**Verification:** 7/7 unit tests pass; `npx eslint` exit 0. (Live
SSLCommerz round-trip not tested — no real credentials in sandbox.)

**Not touched:** UI, homepage, checkout UI, orders UI, admin UI, DB schema,
Prisma models, auth logic, business logic, callback handler,
`payment-sync.ts`, other APIs, components, branding, styling.

**Files modified:** 2 (`src/lib/sslcommerz.ts`, `.env`). **Files created:**
1 (`src/app/api/payments/sslcommerz/status/route.ts`). **Files deleted:**
0.

No remaining follow-ups from this round.
