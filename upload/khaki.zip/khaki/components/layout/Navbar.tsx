'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import {
  Search,
  ShoppingCart,
  Heart,
  User,
  Menu,
  X,
  Globe,
  ChevronDown,
  ShieldCheck,
  Package,
  LogOut,
  LayoutDashboard,
  Megaphone,
  Phone,
  Mail,
  Minus,
  Plus,
  Trash2,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from '@/components/ui/sheet'
import { Badge } from '@/components/ui/badge'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from '@/components/ui/dropdown-menu'
import { useAppStore, type PageName } from '@/lib/store'
import { extractItems } from '@/lib/api'
import NotificationBell from '@/components/shared/NotificationBell'

// ─── Types ────────────────────────────────────────────────────────────────────

interface MenuItemChild {
  id: string
  label: string
  url: string
  icon?: string | null
  sortOrder: number
}

interface MenuItemData {
  id: string
  label: string
  url: string
  icon?: string | null
  sortOrder: number
  openInNew?: boolean
  children?: MenuItemChild[]
}

interface CategoryData {
  id: string
  name: string
  slug: string
  image?: string
}

interface AnnouncementBanner {
  id: string
  title: string
  subtitle?: string
  ctaText?: string
  ctaLink?: string
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function mapUrlToPage(url: string): { page: PageName; params?: Record<string, unknown> } {
  const clean = url.replace(/^\/#?/, '').replace(/\/$/, '')
  const pageMap: Record<string, PageName> = {
    '': 'home',
    home: 'home',
    products: 'products',
    categories: 'products',
    offers: 'offers',
    about: 'about',
    contact: 'contact',
    cart: 'cart',
    checkout: 'checkout',
    login: 'login',
    register: 'register',
    wishlist: 'wishlist',
    profile: 'profile',
    orders: 'orders',
    faq: 'faq',
    'quality-promise': 'quality-promise',
    'delivery-policy': 'delivery-policy',
    'return-policy': 'return-policy',
    terms: 'terms',
    privacy: 'privacy',
    compare: 'compare',
  }

  if (clean.startsWith('product/')) {
    return { page: 'product-detail', params: { slug: clean.split('/')[1] } }
  }
  if (clean.startsWith('category/')) {
    return { page: 'products', params: { category: clean.split('/')[1] } }
  }
  if (clean.startsWith('order/')) {
    return { page: 'order-detail', params: { id: clean.split('/')[1] } }
  }

  return { page: pageMap[clean] || 'home' }
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function Navbar() {
  const {
    siteConfig,
    loadSiteConfig,
    currentPage,
    navigate,
    user,
    isAuthenticated,
    cartItems,
    totalItems,
    subtotal,
    wishlistItems,
    language,
    setLanguage,
    isMobileMenuOpen,
    setMobileMenuOpen,
    toggleCart,
    searchQuery,
    setSearchQuery,
    logout,
  } = useAppStore()

  const [scrolled, setScrolled] = useState(false)
  const [menuItems, setMenuItems] = useState<MenuItemData[]>([])
  const [categories, setCategories] = useState<CategoryData[]>([])
  const [announcementBanner, setAnnouncementBanner] =
    useState<AnnouncementBanner | null>(null)
  const [searchOpen, setSearchOpen] = useState(false)
  const [categoriesOpen, setCategoriesOpen] = useState(false)
  const [searchSuggestions, setSearchSuggestions] = useState<string[]>([])
  const [showSuggestions, setShowSuggestions] = useState(false)
  const [miniCartHover, setMiniCartHover] = useState(false)
  const searchRef = useRef<HTMLDivElement>(null)

  // ── Scroll listener with shadow animation ──
  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 10)
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  // ── Close suggestions on click outside ──
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setShowSuggestions(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  // ── Load site config ──
  useEffect(() => {
    if (!siteConfig) loadSiteConfig()
  }, [siteConfig, loadSiteConfig])

  // ── Load menu items from API ──
  useEffect(() => {
    async function fetchMenu() {
      try {
        const res = await fetch('/api/menu-items?location=main')
        if (res.ok) {
          const json = await res.json()
          const items = extractItems<MenuItemData>(json)
          setMenuItems(items.length > 0 ? items : defaultMenuItems)
        }
      } catch {
        setMenuItems(defaultMenuItems)
      }
    }
    fetchMenu()
  }, [])

  // ── Load categories ──
  useEffect(() => {
    async function fetchCategories() {
      try {
        const res = await fetch('/api/categories?isActive=true&showInMenu=true&limit=20')
        if (res.ok) {
          const json = await res.json()
          const cats = extractItems<CategoryData>(json)
          setCategories(cats)
        }
      } catch {
        // Use defaults
      }
    }
    fetchCategories()
  }, [])

  // ── Load announcement banners ──
  useEffect(() => {
    async function fetchAnnouncements() {
      try {
        const res = await fetch('/api/banners?status=active&location=announcement')
        if (res.ok) {
          const json = await res.json()
          const banners = extractItems<AnnouncementBanner>(json)
          if (banners.length > 0) setAnnouncementBanner(banners[0])
        }
      } catch {
        // No announcement
      }
    }
    fetchAnnouncements()
  }, [])

  const handleSearch = useCallback(
    (e: React.FormEvent) => {
      e.preventDefault()
      if (searchQuery.trim()) {
        navigate('products', { search: searchQuery.trim() })
        setSearchOpen(false)
        setShowSuggestions(false)
      }
    },
    [searchQuery, navigate]
  )

  const handleSearchInputChange = useCallback((value: string) => {
    setSearchQuery(value)
    // Simulate autocomplete suggestions
    if (value.trim().length > 1) {
      const allSuggestions = ['Honey', 'Ghee', 'Spices', 'Rice', 'Tea', 'Jaggery', 'Pickles', 'Sweets', 'Mustard Oil', 'Basmati Rice', 'Cashew Nuts', 'Mango Pickle']
      const filtered = allSuggestions.filter(s =>
        s.toLowerCase().includes(value.toLowerCase())
      ).slice(0, 5)
      setSearchSuggestions(filtered)
      setShowSuggestions(filtered.length > 0)
    } else {
      setSearchSuggestions([])
      setShowSuggestions(false)
    }
  }, [setSearchQuery])

  const handleSuggestionClick = useCallback((suggestion: string) => {
    setSearchQuery(suggestion)
    navigate('products', { search: suggestion })
    setShowSuggestions(false)
    setSearchOpen(false)
  }, [setSearchQuery, navigate])

  const handleNavClick = (url: string) => {
    const { page, params } = mapUrlToPage(url)
    navigate(page, params)
    setMobileMenuOpen(false)
    setCategoriesOpen(false)
  }

  const itemCount = totalItems()
  const wishlistCount = wishlistItems.length
  const cartSubtotal = subtotal()
  const siteName = siteConfig?.siteName || 'Khati Khadyo'

  return (
    <header
      className={`sticky top-0 z-50 w-full transition-all duration-500 bg-background/95 backdrop-blur-md ${
        scrolled ? 'shadow-lg shadow-black/5' : 'shadow-none'
      }`}
    >
      {/* ── Announcement Bar ── */}
      {announcementBanner && (
        <div className="bg-gradient-to-r from-secondary via-amber-500 to-secondary text-white overflow-hidden">
          <div className="container mx-auto flex items-center justify-center px-4 py-1.5 text-xs gap-2">
            <Megaphone className="h-3.5 w-3.5 shrink-0" />
            <span className="truncate">
              {announcementBanner.title}
              {announcementBanner.subtitle && ` — ${announcementBanner.subtitle}`}
            </span>
            {announcementBanner.ctaText && (
              <button
                onClick={() => {
                  if (announcementBanner.ctaLink) navigate('products')
                }}
                className="underline font-semibold shrink-0 hover:opacity-80 transition-opacity"
              >
                {announcementBanner.ctaText}
              </button>
            )}
          </div>
        </div>
      )}

      {/* ── Top Bar ── */}
      <div className="hidden md:block border-b bg-primary text-primary-foreground">
        <div className="container mx-auto flex items-center justify-between px-4 py-1.5 text-xs">
          <div className="flex items-center gap-4">
            {siteConfig?.phone && (
              <a
                href={`tel:${siteConfig.phone.replace(/\s/g, '')}`}
                className="flex items-center gap-1.5 hover:opacity-80 transition-opacity"
              >
                <Phone className="size-3" />
                {siteConfig.phone}
              </a>
            )}
            {siteConfig?.email && (
              <a
                href={`mailto:${siteConfig.email}`}
                className="flex items-center gap-1.5 hover:opacity-80 transition-opacity"
              >
                <Mail className="size-3" />
                {siteConfig.email}
              </a>
            )}
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
              className="flex items-center gap-1 hover:opacity-80 transition-opacity"
              aria-label="Toggle language"
            >
              <Globe className="size-3.5" />
              {language === 'en' ? 'বাংলা' : 'English'}
            </button>
            {isAuthenticated && user?.role === 'admin' && (
              <button
                onClick={() => navigate('admin-dashboard')}
                className="flex items-center gap-1 hover:opacity-80 transition-opacity"
              >
                <ShieldCheck className="size-3.5" />
                Admin
              </button>
            )}
          </div>
        </div>
      </div>

      {/* ── Main Navbar ── */}
      <div className="container mx-auto flex items-center justify-between px-4 py-3 gap-4">
        {/* Logo with hover animation */}
        <button
          onClick={() => navigate('home')}
          className="flex items-center gap-2 shrink-0 group"
          aria-label={`${siteName} - Go to homepage`}
        >
          {siteConfig?.logo ? (
            <img
              src={siteConfig.logo}
              alt={siteName}
              className="h-8 w-auto object-contain transition-transform duration-300 group-hover:scale-105"
            />
          ) : (
            <div className="h-9 w-9 rounded-lg bg-primary flex items-center justify-center text-primary-foreground font-bold text-lg transition-transform duration-300 group-hover:scale-110 group-hover:shadow-lg">
              K
            </div>
          )}
          <span className="hidden sm:block font-bold text-lg text-foreground group-hover:text-primary transition-colors duration-300">
            {siteName}
          </span>
        </button>

        {/* Desktop Navigation */}
        <nav
          className="hidden lg:flex items-center gap-1"
          aria-label="Main navigation"
        >
          {menuItems.map((item) =>
            item.children && item.children.length > 0 ? (
              <DropdownMenu key={item.id}>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="gap-1 text-sm font-medium"
                  >
                    {item.label}
                    <ChevronDown className="size-3.5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="w-48">
                  <DropdownMenuLabel className="font-semibold">
                    {item.label}
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  {item.children.map((child) => (
                    <DropdownMenuItem
                      key={child.id}
                      onClick={() => handleNavClick(child.url)}
                      className="cursor-pointer"
                    >
                      {child.label}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button
                key={item.id}
                variant="ghost"
                size="sm"
                onClick={() => handleNavClick(item.url)}
                className={`text-sm font-medium transition-colors duration-200 ${
                  currentPage === mapUrlToPage(item.url).page
                    ? 'text-primary'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                {item.label}
              </Button>
            )
          )}

          {/* Categories dropdown */}
          {categories.length > 0 && (
            <DropdownMenu
              open={categoriesOpen}
              onOpenChange={setCategoriesOpen}
            >
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="gap-1 text-sm font-medium">
                  Categories
                  <ChevronDown className="size-3.5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-56">
                <DropdownMenuLabel className="font-semibold">
                  Shop by Category
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                {categories.slice(0, 10).map((cat) => (
                  <DropdownMenuItem
                    key={cat.id}
                    onClick={() => {
                      navigate('products', { category: cat.slug })
                      setCategoriesOpen(false)
                    }}
                    className="cursor-pointer"
                  >
                    {cat.name}
                  </DropdownMenuItem>
                ))}
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={() => {
                    navigate('products')
                    setCategoriesOpen(false)
                  }}
                  className="cursor-pointer font-medium text-primary"
                >
                  View All Categories
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </nav>

        {/* Right Actions */}
        <div className="flex items-center gap-1 sm:gap-2">
          {/* Search with autocomplete */}
          <div className="hidden md:flex items-center relative" ref={searchRef}>
            {searchOpen ? (
              <form onSubmit={handleSearch} className="flex items-center gap-1 relative">
                <div className="relative">
                  <Input
                    type="search"
                    placeholder="Search products..."
                    value={searchQuery}
                    onChange={(e) => handleSearchInputChange(e.target.value)}
                    className="w-52 h-9 text-sm pr-8"
                    autoFocus
                    onFocus={() => searchQuery.length > 1 && setShowSuggestions(true)}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="absolute right-0 top-0 size-9"
                    onClick={() => { setSearchOpen(false); setShowSuggestions(false); setSearchQuery('') }}
                    aria-label="Close search"
                  >
                    <X className="size-4" />
                  </Button>
                  {/* Autocomplete Dropdown */}
                  {showSuggestions && searchSuggestions.length > 0 && (
                    <div className="absolute top-full left-0 right-0 mt-1 bg-background border rounded-lg shadow-lg z-50 overflow-hidden">
                      {searchSuggestions.map((suggestion) => (
                        <button
                          key={suggestion}
                          type="button"
                          className="w-full text-left px-3 py-2 text-sm hover:bg-primary/5 transition-colors flex items-center gap-2"
                          onClick={() => handleSuggestionClick(suggestion)}
                        >
                          <Search className="size-3.5 text-muted-foreground" />
                          {suggestion}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </form>
            ) : (
              <Button
                variant="ghost"
                size="icon"
                className="size-9"
                onClick={() => setSearchOpen(true)}
                aria-label="Open search"
              >
                <Search className="size-4" />
              </Button>
            )}
          </div>

          {/* Mobile search button */}
          <Button
            variant="ghost"
            size="icon"
            className="size-9 md:hidden"
            onClick={() => setSearchOpen(!searchOpen)}
            aria-label="Search"
          >
            <Search className="size-4" />
          </Button>

          {/* Language toggle (mobile) */}
          <Button
            variant="ghost"
            size="icon"
            className="size-9 md:hidden"
            onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
            aria-label="Toggle language"
          >
            <Globe className="size-4" />
          </Button>

          {/* Notification Bell */}
          <NotificationBell />

          {/* Wishlist with animated badge */}
          <Button
            variant="ghost"
            size="icon"
            className="size-9 relative"
            onClick={() => navigate('wishlist')}
            aria-label={`Wishlist (${wishlistCount} items)`}
          >
            <Heart className="size-4" />
            {wishlistCount > 0 && (
              <Badge className="absolute -top-1 -right-1 min-w-[18px] h-[18px] p-0 flex items-center justify-center text-[10px] bg-secondary text-secondary-foreground animate-in zoom-in-50 duration-200 border-0">
                {wishlistCount}
              </Badge>
            )}
          </Button>

          {/* Cart with mini preview on hover */}
          <div
            className="relative"
            onMouseEnter={() => setMiniCartHover(true)}
            onMouseLeave={() => setMiniCartHover(false)}
          >
            <Button
              variant="ghost"
              size="icon"
              className="size-9 relative"
              onClick={toggleCart}
              aria-label={`Shopping cart (${itemCount} items)`}
            >
              <ShoppingCart className="size-4" />
              {itemCount > 0 && (
                <Badge className="absolute -top-1 -right-1 min-w-[18px] h-[18px] p-0 flex items-center justify-center text-[10px] bg-primary text-primary-foreground animate-in zoom-in-50 duration-200 border-0">
                  {itemCount}
                </Badge>
              )}
            </Button>

            {/* Mini Cart Preview */}
            {miniCartHover && cartItems.length > 0 && (
              <div className="absolute right-0 top-full mt-2 w-64 bg-background border rounded-xl shadow-xl z-50 overflow-hidden">
                <div className="p-3 border-b bg-primary/5">
                  <p className="text-xs font-semibold">{itemCount} items in cart</p>
                  <p className="text-sm font-bold text-primary">৳{cartSubtotal.toLocaleString()}</p>
                </div>
                <div className="p-2 max-h-40 overflow-y-auto">
                  {cartItems.slice(0, 3).map((item, index) => (
                    <div key={`cart-item-${item.productId}-${index}`} className="flex items-center gap-2 p-1.5 text-xs">
                      <span className="flex-1 truncate">{item.productName}</span>
                      <span className="text-muted-foreground">×{item.quantity}</span>
                    </div>
                  ))}
                  {cartItems.length > 3 && (
                    <p className="text-xs text-muted-foreground text-center py-1">
                      +{cartItems.length - 3} more items
                    </p>
                  )}
                </div>
                <div className="p-2 border-t">
                  <Button size="sm" className="w-full h-8 text-xs" onClick={toggleCart}>
                    View Cart
                  </Button>
                </div>
              </div>
            )}
          </div>

          {/* User dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="size-9"
                aria-label="User menu"
              >
                <User className="size-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              {isAuthenticated && user ? (
                <>
                  <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium">{user.name || 'User'}</p>
                      <p className="text-xs text-muted-foreground">
                        {user.email || user.phone}
                      </p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    onClick={() => navigate('profile')}
                    className="cursor-pointer"
                  >
                    <User className="size-4 mr-2" />
                    Profile
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={() => navigate('orders')}
                    className="cursor-pointer"
                  >
                    <Package className="size-4 mr-2" />
                    My Orders
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={() => navigate('wishlist')}
                    className="cursor-pointer"
                  >
                    <Heart className="size-4 mr-2" />
                    Wishlist
                  </DropdownMenuItem>
                  {user.role === 'admin' && (
                    <>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem
                        onClick={() => navigate('admin-dashboard')}
                        className="cursor-pointer"
                      >
                        <LayoutDashboard className="size-4 mr-2" />
                        Admin Dashboard
                      </DropdownMenuItem>
                    </>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    onClick={() => {
                      logout()
                      navigate('home')
                    }}
                    className="cursor-pointer text-destructive focus:text-destructive"
                  >
                    <LogOut className="size-4 mr-2" />
                    Logout
                  </DropdownMenuItem>
                </>
              ) : (
                <>
                  <DropdownMenuItem
                    onClick={() => navigate('login')}
                    className="cursor-pointer"
                  >
                    <User className="size-4 mr-2" />
                    Login
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={() => navigate('register')}
                    className="cursor-pointer"
                  >
                    <ShieldCheck className="size-4 mr-2" />
                    Register
                  </DropdownMenuItem>
                </>
              )}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Mobile menu toggle with animated hamburger */}
          <Sheet open={isMobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="size-9 lg:hidden"
                aria-label="Open menu"
              >
                <div className="relative w-5 h-4 flex flex-col justify-between">
                  <span className={`block h-0.5 w-5 bg-current transition-all duration-300 origin-center ${isMobileMenuOpen ? 'rotate-45 translate-y-[7px]' : ''}`} />
                  <span className={`block h-0.5 w-5 bg-current transition-all duration-300 ${isMobileMenuOpen ? 'opacity-0 scale-0' : ''}`} />
                  <span className={`block h-0.5 w-5 bg-current transition-all duration-300 origin-center ${isMobileMenuOpen ? '-rotate-45 -translate-y-[7px]' : ''}`} />
                </div>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-80 p-0">
              <SheetTitle className="sr-only">Navigation Menu</SheetTitle>
              <div className="flex flex-col h-full">
                {/* Mobile header */}
                <div className="flex items-center gap-2 p-4 border-b bg-primary/5">
                  {siteConfig?.logo ? (
                    <img
                      src={siteConfig.logo}
                      alt={siteName}
                      className="h-8 w-auto object-contain"
                    />
                  ) : (
                    <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center text-primary-foreground font-bold">
                      K
                    </div>
                  )}
                  <span className="font-bold text-lg">{siteName}</span>
                </div>

                {/* Mobile search */}
                <div className="p-4 border-b">
                  <form onSubmit={handleSearch} className="flex items-center gap-2">
                    <Input
                      type="search"
                      placeholder="Search products..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="h-9 text-sm"
                    />
                    <Button type="submit" size="sm" className="shrink-0">
                      <Search className="size-4" />
                    </Button>
                  </form>
                </div>

                {/* Mobile nav links with slide animation */}
                <nav
                  className="flex-1 overflow-y-auto py-2"
                  aria-label="Mobile navigation"
                >
                  {menuItems.map((item, index) => (
                    <div key={item.id} style={{ animationDelay: `${index * 30}ms` }}>
                      <button
                        onClick={() => {
                          handleNavClick(item.url)
                        }}
                        className="flex items-center justify-between w-full px-4 py-3 text-sm font-medium hover:bg-accent transition-all duration-200"
                      >
                        {item.label}
                        {item.children && item.children.length > 0 && (
                          <ChevronDown className="size-4 text-muted-foreground" />
                        )}
                      </button>
                      {item.children && item.children.length > 0 && (
                        <div className="bg-muted/50">
                          {item.children.map((child) => (
                            <button
                              key={child.id}
                              onClick={() => handleNavClick(child.url)}
                              className="flex items-center w-full px-8 py-2.5 text-sm text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
                            >
                              {child.label}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}

                  {/* Mobile categories with images */}
                  {categories.length > 0 && (
                    <>
                      <div className="px-4 py-2 mt-2 border-t">
                        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                          Categories
                        </p>
                      </div>
                      <div className="grid grid-cols-2 gap-2 px-4 pb-2">
                        {categories.slice(0, 10).map((cat) => (
                          <button
                            key={cat.id}
                            onClick={() => {
                              navigate('products', { category: cat.slug })
                              setMobileMenuOpen(false)
                            }}
                            className="flex items-center gap-2 p-2 rounded-lg hover:bg-accent transition-all text-left group"
                          >
                            <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0 group-hover:bg-primary/20 transition-colors overflow-hidden">
                              {cat.image ? (
                                <img src={cat.image} alt="" className="h-full w-full object-cover" />
                              ) : (
                                <span className="text-xs">🍽️</span>
                              )}
                            </div>
                            <span className="text-xs text-muted-foreground group-hover:text-foreground transition-colors line-clamp-1">
                              {cat.name}
                            </span>
                          </button>
                        ))}
                      </div>
                    </>
                  )}
                </nav>

                {/* Mobile footer actions */}
                <div className="border-t p-4 space-y-2">
                  {isAuthenticated && user?.role === 'admin' && (
                    <Button
                      variant="outline"
                      className="w-full justify-start"
                      onClick={() => {
                        navigate('admin-dashboard')
                        setMobileMenuOpen(false)
                      }}
                    >
                      <LayoutDashboard className="size-4 mr-2" />
                      Admin Dashboard
                    </Button>
                  )}
                  {isAuthenticated ? (
                    <Button
                      variant="outline"
                      className="w-full justify-start text-destructive hover:text-destructive"
                      onClick={() => {
                        logout()
                        navigate('home')
                        setMobileMenuOpen(false)
                      }}
                    >
                      <LogOut className="size-4 mr-2" />
                      Logout
                    </Button>
                  ) : (
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        className="flex-1"
                        onClick={() => {
                          navigate('login')
                          setMobileMenuOpen(false)
                        }}
                      >
                        Login
                      </Button>
                      <Button
                        className="flex-1"
                        onClick={() => {
                          navigate('register')
                          setMobileMenuOpen(false)
                        }}
                      >
                        Register
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>

      {/* Mobile search bar (when toggled on mobile) */}
      {searchOpen && (
        <div className="md:hidden border-t px-4 py-2 bg-background animate-in slide-in-from-top duration-200">
          <form onSubmit={handleSearch} className="flex items-center gap-2">
            <Input
              type="search"
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="h-9 text-sm"
              autoFocus
            />
            <Button type="submit" size="sm" className="shrink-0">
              <Search className="size-4" />
            </Button>
          </form>
        </div>
      )}
    </header>
  )
}

// ─── Default Menu Items (fallback) ───────────────────────────────────────────

const defaultMenuItems: MenuItemData[] = [
  { id: 'home', label: 'Home', url: '/', sortOrder: 0 },
  { id: 'products', label: 'Products', url: '/products', sortOrder: 1 },
  {
    id: 'categories',
    label: 'Categories',
    url: '/products',
    sortOrder: 2,
    children: [
      { id: 'cat-honey', label: 'Honey & Jaggery', url: '/category/honey-jaggery', sortOrder: 0 },
      { id: 'cat-ghee', label: 'Ghee & Oils', url: '/category/ghee-oils', sortOrder: 1 },
      { id: 'cat-rice', label: 'Rice & Grains', url: '/category/rice-grains', sortOrder: 2 },
      { id: 'cat-spices', label: 'Spices & Masala', url: '/category/spices-masala', sortOrder: 3 },
      { id: 'cat-sweets', label: 'Sweets & Snacks', url: '/category/sweets-snacks', sortOrder: 4 },
      { id: 'cat-tea', label: 'Tea & Beverages', url: '/category/tea-beverages', sortOrder: 5 },
    ],
  },
  { id: 'offers', label: 'Offers', url: '/offers', sortOrder: 3 },
  { id: 'about', label: 'About', url: '/about', sortOrder: 4 },
  { id: 'contact', label: 'Contact', url: '/contact', sortOrder: 5 },
]
