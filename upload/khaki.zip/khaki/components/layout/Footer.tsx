'use client'

import { useState, useEffect } from 'react'
import {
  Facebook,
  Instagram,
  Twitter,
  Youtube,
  MapPin,
  Phone,
  Mail,
  MessageCircle,
  Send,
  ChevronRight,
  ArrowUp,
  CreditCard,
  Smartphone,
  Banknote,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Separator } from '@/components/ui/separator'
import { useAppStore, type PageName } from '@/lib/store'
import { extractItems } from '@/lib/api'

// ─── Types ────────────────────────────────────────────────────────────────────

interface FooterMenuItem {
  id: string
  label: string
  url: string
  children?: { id: string; label: string; url: string }[]
}

interface CategoryItem {
  id: string
  name: string
  slug: string
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function Footer() {
  const { siteConfig, navigate, language } = useAppStore()

  const [footerMenuItems, setFooterMenuItems] = useState<FooterMenuItem[]>([])
  const [categories, setCategories] = useState<CategoryItem[]>([])
  const [newsletterEmail, setNewsletterEmail] = useState('')
  const [newsletterLoading, setNewsletterLoading] = useState(false)
  const [newsletterSuccess, setNewsletterSuccess] = useState(false)
  const [showBackToTop, setShowBackToTop] = useState(false)

  // ── Scroll listener for back to top button ──
  useEffect(() => {
    const handleScroll = () => setShowBackToTop(window.scrollY > 400)
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  // ── Load footer menu items ──
  useEffect(() => {
    async function fetchFooterMenu() {
      try {
        const res = await fetch('/api/menu-items?location=footer')
        if (res.ok) {
          const json = await res.json()
          const items = extractItems<FooterMenuItem>(json)
          setFooterMenuItems(items)
        }
      } catch {
        // Use defaults
      }
    }
    fetchFooterMenu()
  }, [])

  // ── Load categories ──
  useEffect(() => {
    async function fetchCategories() {
      try {
        const res = await fetch('/api/categories?isActive=true&showInMenu=true&limit=20')
        if (res.ok) {
          const json = await res.json()
          const cats = extractItems<CategoryItem>(json)
          setCategories(cats)
        }
      } catch {
        // Use defaults
      }
    }
    fetchCategories()
  }, [])

  const handleNavClick = (url: string) => {
    const clean = url.replace(/^\/#?/, '').replace(/\/$/, '')
    const pageMap: Record<string, PageName> = {
      '': 'home',
      home: 'home',
      products: 'products',
      offers: 'offers',
      about: 'about',
      contact: 'contact',
      faq: 'faq',
      'quality-promise': 'quality-promise',
      'delivery-policy': 'delivery-policy',
      'return-policy': 'return-policy',
      terms: 'terms',
      privacy: 'privacy',
    }
    const page = pageMap[clean] || 'home'
    navigate(page)
  }

  const handleNewsletterSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newsletterEmail.trim()) return

    setNewsletterLoading(true)
    try {
      const res = await fetch('/api/newsletter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: newsletterEmail, source: 'footer' }),
      })
      if (res.ok) {
        setNewsletterSuccess(true)
        setNewsletterEmail('')
        setTimeout(() => setNewsletterSuccess(false), 4000)
      }
    } catch {
      // Silently fail
    } finally {
      setNewsletterLoading(false)
    }
  }

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const siteName = siteConfig?.siteName || 'Khati Khadyo'
  const tagline = siteConfig?.tagline || 'Authentic Bangladeshi Food Products'
  const description =
    siteConfig?.description ||
    'Premium authentic Bangladeshi food products delivered fresh to your doorstep.'
  const phone = siteConfig?.phone || '+880 1XXX-XXXXXX'
  const email = siteConfig?.email || 'info@khatikhadyo.com'
  const address = siteConfig?.address || 'Dhaka, Bangladesh'
  const socialLinks = siteConfig?.socialLinks || {}
  const currentYear = new Date().getFullYear()

  const quickLinks: { label: string; page: PageName }[] = [
    { label: 'Home', page: 'home' },
    { label: 'Products', page: 'products' },
    { label: 'Offers', page: 'offers' },
    { label: 'About Us', page: 'about' },
    { label: 'Contact', page: 'contact' },
  ]

  const policyLinks: { label: string; page: PageName }[] = [
    { label: 'Quality Promise', page: 'quality-promise' },
    { label: 'Delivery Policy', page: 'delivery-policy' },
    { label: 'Return Policy', page: 'return-policy' },
    { label: 'Terms & Conditions', page: 'terms' },
    { label: 'Privacy Policy', page: 'privacy' },
    { label: 'FAQ', page: 'faq' },
  ]

  // Payment methods
  const paymentMethods = [
    { name: 'bKash', icon: Smartphone, color: 'text-pink-500' },
    { name: 'Nagad', icon: Smartphone, color: 'text-orange-500' },
    { name: 'COD', icon: Banknote, color: 'text-emerald-500' },
    { name: 'Visa', icon: CreditCard, color: 'text-blue-600' },
  ]

  // Social links config
  const socialButtons = [
    { key: 'facebook', href: socialLinks.facebook || '#', icon: Facebook, label: 'Facebook', alwaysShow: true, hoverColor: 'hover:bg-blue-600 hover:text-white' },
    { key: 'instagram', href: socialLinks.instagram, icon: Instagram, label: 'Instagram', alwaysShow: false, hoverColor: 'hover:bg-gradient-to-br hover:from-purple-600 hover:to-pink-500 hover:text-white' },
    { key: 'twitter', href: socialLinks.twitter, icon: Twitter, label: 'Twitter', alwaysShow: false, hoverColor: 'hover:bg-sky-500 hover:text-white' },
    { key: 'youtube', href: socialLinks.youtube, icon: Youtube, label: 'YouTube', alwaysShow: false, hoverColor: 'hover:bg-red-600 hover:text-white' },
    { key: 'whatsapp', href: `https://wa.me/${phone.replace(/[^0-9]/g, '')}`, icon: MessageCircle, label: 'WhatsApp', alwaysShow: true, hoverColor: 'hover:bg-emerald-500 hover:text-white' },
  ]

  return (
    <footer className="mt-auto bg-primary text-primary-foreground relative">
      {/* ── Newsletter Section with Gradient ── */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-secondary/90 via-secondary to-secondary/90" />
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-1/4 w-32 h-32 bg-white rounded-full -translate-y-1/2" />
          <div className="absolute bottom-0 right-1/4 w-48 h-48 bg-white rounded-full translate-y-1/3" />
        </div>
        <div className="container mx-auto px-4 py-10 relative z-10">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="text-center md:text-left">
              <div className="flex items-center gap-2 mb-2">
                <Send className="h-5 w-5 text-white" />
                <h3 className="font-bold text-xl text-white">
                  {language === 'bn'
                    ? 'নিউজলেটার সাবস্ক্রাইব করুন'
                    : 'Subscribe to Our Newsletter'}
                </h3>
              </div>
              <p className="text-white/80 text-sm max-w-md">
                {language === 'bn'
                  ? 'সর্বশেষ অফার এবং পণ্য সম্পর্কে আপডেট পান'
                  : 'Get exclusive offers, new product alerts, and authentic Bangladeshi food updates delivered to your inbox.'}
              </p>
            </div>
            <form
              onSubmit={handleNewsletterSubmit}
              className="flex w-full max-w-md gap-2"
            >
              <Input
                type="email"
                placeholder="Enter your email address"
                value={newsletterEmail}
                onChange={(e) => setNewsletterEmail(e.target.value)}
                className="bg-white/15 border-white/30 text-white placeholder:text-white/50 h-11 backdrop-blur-sm focus:bg-white/20"
                required
              />
              <Button
                type="submit"
                className="shrink-0 bg-white text-secondary hover:bg-white/90 font-semibold h-11 px-6 transition-all hover:scale-105 active:scale-95"
                disabled={newsletterLoading}
              >
                {newsletterLoading ? (
                  <span className="flex items-center gap-1">
                    <span className="h-4 w-4 border-2 border-secondary/30 border-t-secondary rounded-full animate-spin" />
                    ...
                  </span>
                ) : newsletterSuccess ? (
                  <span className="flex items-center gap-1">
                    ✓ Subscribed!
                  </span>
                ) : (
                  <>
                    <Send className="size-4 mr-1.5" />
                    Subscribe
                  </>
                )}
              </Button>
            </form>
          </div>
        </div>
      </div>

      {/* ── Main Footer Content ── */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* About Column */}
          <div className="space-y-5">
            <div className="flex items-center gap-2">
              {siteConfig?.logo ? (
                <img
                  src={siteConfig.logo}
                  alt={siteName}
                  className="h-9 w-auto object-contain brightness-0 invert"
                />
              ) : (
                <div className="h-10 w-10 rounded-xl bg-primary-foreground flex items-center justify-center text-primary font-bold text-lg shadow-lg">
                  K
                </div>
              )}
              <span className="font-bold text-xl">{siteName}</span>
            </div>
            <p className="text-primary-foreground/70 text-sm leading-relaxed">
              {description}
            </p>
            <p className="text-secondary font-medium text-sm italic border-l-2 border-secondary/50 pl-3">
              {tagline}
            </p>

            {/* Animated Social Links */}
            <div className="flex items-center gap-2.5">
              {socialButtons.map((social) => {
                if (!social.alwaysShow && !socialLinks[social.key as keyof typeof socialLinks]) return null
                return (
                  <a
                    key={social.key}
                    href={social.href || '#'}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`size-10 rounded-full bg-primary-foreground/10 flex items-center justify-center transition-all duration-300 hover:scale-110 hover:shadow-lg ${social.hoverColor}`}
                    aria-label={social.label}
                  >
                    <social.icon className="size-4" />
                  </a>
                )
              })}
            </div>
          </div>

          {/* Quick Links Column */}
          <div className="space-y-5">
            <h4 className="font-semibold text-base flex items-center gap-2">
              <div className="h-1 w-6 bg-secondary rounded-full" />
              Quick Links
            </h4>
            <ul className="space-y-2.5">
              {footerMenuItems.length > 0
                ? footerMenuItems.map((item) => (
                    <li key={item.id}>
                      <button
                        onClick={() => handleNavClick(item.url)}
                        className="text-primary-foreground/70 hover:text-primary-foreground text-sm transition-all duration-200 flex items-center gap-2 group"
                      >
                        <ChevronRight className="h-3 w-3 opacity-0 -ml-5 group-hover:opacity-100 group-hover:ml-0 transition-all duration-200 text-secondary" />
                        {item.label}
                      </button>
                    </li>
                  ))
                : quickLinks.map((link) => (
                    <li key={link.label}>
                      <button
                        onClick={() => navigate(link.page)}
                        className="text-primary-foreground/70 hover:text-primary-foreground text-sm transition-all duration-200 flex items-center gap-2 group"
                      >
                        <ChevronRight className="h-3 w-3 opacity-0 -ml-5 group-hover:opacity-100 group-hover:ml-0 transition-all duration-200 text-secondary" />
                        {link.label}
                      </button>
                    </li>
                  ))}
            </ul>
          </div>

          {/* Categories Column */}
          <div className="space-y-5">
            <h4 className="font-semibold text-base flex items-center gap-2">
              <div className="h-1 w-6 bg-secondary rounded-full" />
              Categories
            </h4>
            <ul className="space-y-2.5">
              {categories.length > 0
                ? categories.slice(0, 8).map((cat) => (
                    <li key={cat.id}>
                      <button
                        onClick={() =>
                          navigate('products', { category: cat.slug })
                        }
                        className="text-primary-foreground/70 hover:text-primary-foreground text-sm transition-all duration-200 flex items-center gap-2 group"
                      >
                        <ChevronRight className="h-3 w-3 opacity-0 -ml-5 group-hover:opacity-100 group-hover:ml-0 transition-all duration-200 text-secondary" />
                        {cat.name}
                      </button>
                    </li>
                  ))
                : defaultCategories.map((cat) => (
                    <li key={cat.slug}>
                      <button
                        onClick={() =>
                          navigate('products', { category: cat.slug })
                        }
                        className="text-primary-foreground/70 hover:text-primary-foreground text-sm transition-all duration-200 flex items-center gap-2 group"
                      >
                        <ChevronRight className="h-3 w-3 opacity-0 -ml-5 group-hover:opacity-100 group-hover:ml-0 transition-all duration-200 text-secondary" />
                        {cat.name}
                      </button>
                    </li>
                  ))}
            </ul>
          </div>

          {/* Contact & Policies Column */}
          <div className="space-y-5">
            <h4 className="font-semibold text-base flex items-center gap-2">
              <div className="h-1 w-6 bg-secondary rounded-full" />
              Contact Us
            </h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-2.5 text-sm text-primary-foreground/70">
                <MapPin className="size-4 mt-0.5 shrink-0 text-secondary" />
                <span>{address}</span>
              </li>
              <li>
                <a
                  href={`tel:${phone.replace(/\s/g, '')}`}
                  className="flex items-center gap-2.5 text-sm text-primary-foreground/70 hover:text-primary-foreground transition-colors"
                >
                  <Phone className="size-4 shrink-0 text-secondary" />
                  {phone}
                </a>
              </li>
              <li>
                <a
                  href={`mailto:${email}`}
                  className="flex items-center gap-2.5 text-sm text-primary-foreground/70 hover:text-primary-foreground transition-colors"
                >
                  <Mail className="size-4 shrink-0 text-secondary" />
                  {email}
                </a>
              </li>
            </ul>

            <Separator className="bg-primary-foreground/10" />

            <h4 className="font-semibold text-sm">Policies</h4>
            <ul className="space-y-1.5">
              {policyLinks.map((link) => (
                <li key={link.page}>
                  <button
                    onClick={() => navigate(link.page)}
                    className="text-primary-foreground/60 hover:text-primary-foreground text-xs transition-colors flex items-center gap-1.5 group"
                  >
                    <ChevronRight className="h-2.5 w-2.5 text-secondary/60 group-hover:text-secondary transition-colors" />
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* ── Payment & App Section ── */}
      <div className="border-t border-primary-foreground/10">
        <div className="container mx-auto px-4 py-5">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            {/* Payment Methods */}
            <div className="flex items-center gap-3">
              <span className="text-xs text-primary-foreground/50">We accept:</span>
              <div className="flex items-center gap-2">
                {paymentMethods.map((method) => (
                  <div
                    key={method.name}
                    className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-md bg-primary-foreground/10 text-xs text-primary-foreground/80 font-medium"
                  >
                    <method.icon className={`h-3.5 w-3.5 ${method.color}`} />
                    {method.name}
                  </div>
                ))}
              </div>
            </div>

            {/* App Download Badges (Placeholder) */}
            <div className="flex items-center gap-3">
              <span className="text-xs text-primary-foreground/50">Download App:</span>
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary-foreground/10 text-xs text-primary-foreground/70 cursor-pointer hover:bg-primary-foreground/15 transition-colors">
                  <svg className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor"><path d="M17.523 2.237l-5.807 3.345L6.91 2.237a.5.5 0 00-.754.431v7.495a.5.5 0 00.754.431l4.806-2.77 5.807 3.345a.5.5 0 00.754-.431V2.668a.5.5 0 00-.754-.431z"/><path d="M3.5 6.5v11a.5.5 0 00.25.433l5 2.887a.5.5 0 00.75-.433V9.117a.5.5 0 00-.25-.433l-5-2.887A.5.5 0 003.5 6.5z"/><path d="M20.5 6.5v11a.5.5 0 01-.25.433l-5 2.887a.5.5 0 01-.75-.433V9.117a.5.5 0 01.25-.433l5-2.887A.5.5 0 0120.5 6.5z"/></svg>
                  App Store
                </div>
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary-foreground/10 text-xs text-primary-foreground/70 cursor-pointer hover:bg-primary-foreground/15 transition-colors">
                  <svg className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor"><path d="M3.609 1.814L13.792 12 3.61 22.186a.996.996 0 01-.61-.92V2.734a1 1 0 01.609-.92zm10.89 10.893l2.302 2.302-10.937 6.333 8.635-8.635zm3.199-3.198l2.302 2.302a1 1 0 010 1.38l-2.302 2.302L15.396 13l2.302-2.491zM5.864 2.658L16.8 8.99l-2.302 2.302L5.864 2.658z"/></svg>
                  Google Play
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ── Copyright Bar ── */}
      <div className="border-t border-primary-foreground/10 bg-primary-foreground/5">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-primary-foreground/50">
            <p>
              &copy; {currentYear} {siteName}. All rights reserved.
            </p>
            <div className="flex items-center gap-3">
              <button onClick={() => navigate('terms')} className="hover:text-primary-foreground/80 transition-colors">Terms</button>
              <span>•</span>
              <button onClick={() => navigate('privacy')} className="hover:text-primary-foreground/80 transition-colors">Privacy</button>
              <span>•</span>
              <button onClick={() => navigate('contact')} className="hover:text-primary-foreground/80 transition-colors">Support</button>
            </div>
            <p className="flex items-center gap-1">
              Crafted with <span className="text-red-400">❤️</span> in Bangladesh
            </p>
          </div>
        </div>
      </div>

      {/* ── Back to Top Button ── */}
      <button
        onClick={scrollToTop}
        className={`fixed bottom-6 right-6 z-50 h-11 w-11 rounded-full bg-primary text-primary-foreground shadow-lg flex items-center justify-center transition-all duration-300 hover:bg-secondary hover:shadow-xl hover:scale-110 active:scale-95 ${
          showBackToTop ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'
        }`}
        aria-label="Back to top"
      >
        <ArrowUp className="h-5 w-5" />
      </button>
    </footer>
  )
}

// ─── Default Data ─────────────────────────────────────────────────────────────

const defaultCategories = [
  { name: 'Honey & Jaggery', slug: 'honey-jaggery' },
  { name: 'Ghee & Oils', slug: 'ghee-oils' },
  { name: 'Rice & Grains', slug: 'rice-grains' },
  { name: 'Spices & Masala', slug: 'spices-masala' },
  { name: 'Sweets & Snacks', slug: 'sweets-snacks' },
  { name: 'Tea & Beverages', slug: 'tea-beverages' },
  { name: 'Pickles & Chutney', slug: 'pickles-chutney' },
  { name: 'Dry Fruits & Nuts', slug: 'dry-fruits-nuts' },
]
