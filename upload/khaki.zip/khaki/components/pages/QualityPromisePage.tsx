'use client'

import PolicyPage from './PolicyPage'

export default function QualityPromisePage() {
  return <PolicyPage slug="quality-promise" />
}
