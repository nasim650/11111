'use client'

import { useEffect, useState, useMemo, useRef } from 'react'
import Image from 'next/image'
import {
  Minus,
  Plus,
  ShoppingCart,
  Heart,
  Share2,
  Star,
  Truck,
  ShieldCheck,
  RefreshCw,
  ChevronRight,
  Copy,
  Check,
  GitCompareArrows,
  Facebook,
  MessageCircle,
  Package,
  Users,
  Sparkles,
  Home,
  ArrowRight,
  Clock,
  BadgeCheck,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Card, CardContent } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { Skeleton } from '@/components/ui/skeleton'
import { Textarea } from '@/components/ui/textarea'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Progress } from '@/components/ui/progress'
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbSeparator } from '@/components/ui/breadcrumb'
import { useAppStore, type CartItem, type WishlistItem } from '@/lib/store'
import { extractItems } from '@/lib/api'
import ProductCard from '@/components/shared/ProductCard'
import StockNotificationButton from '@/components/shared/StockNotificationButton'
import { toast } from 'sonner'

// ─── Types ────────────────────────────────────────────────────────────────────

interface Review {
  id: string
  rating: number
  comment?: string
  createdAt: string
  user?: { name?: string }
}

interface ProductDetail {
  id: string
  name: string
  slug: string
  shortDescription?: string
  description?: string
  price: number
  discountPrice?: number | null
  unit: string
  stock: number
  origin?: string
  qualityNote?: string
  ingredients?: string
  storageInstruction?: string
  deliveryNote?: string
  specifications?: string
  tags?: string
  category?: { id: string; name: string; slug: string }
  subcategory?: { id: string; name: string; slug: string }
  images?: Array<{ id: string; url: string; alt?: string }>
  videos?: Array<{ id: string; url: string; title?: string; thumbnail?: string }>
  reviews?: Review[]
  isNewArrival?: boolean
  isBestSeller?: boolean
  isFeatured?: boolean
  status: string
}

interface RelatedProduct {
  id: string
  name: string
  slug: string
  price: number
  discountPrice?: number | null
  unit: string
  stock: number
  images?: Array<{ url: string; alt?: string }>
  category?: { name: string; slug: string }
  status?: string
  isNewArrival?: boolean
  isBestSeller?: boolean
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function ProductDetailPage() {
  const {
    pageParams,
    navigate,
    addToCart,
    isInWishlist,
    toggleWishlist,
    addRecentlyViewed,
    addToCompare,
    isInCompare,
    compareProducts,
    isAuthenticated,
    user,
    siteConfig,
  } = useAppStore()

  const [product, setProduct] = useState<ProductDetail | null>(null)
  const [relatedProducts, setRelatedProducts] = useState<RelatedProduct[]>([])
  const [alsoViewedProducts, setAlsoViewedProducts] = useState<RelatedProduct[]>([])
  const [frequentlyBoughtTogether, setFrequentlyBoughtTogether] = useState<RelatedProduct[]>([])
  const [reviews, setReviews] = useState<Review[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedImage, setSelectedImage] = useState(0)
  const [quantity, setQuantity] = useState(1)
  const [adding, setAdding] = useState(false)
  const [copied, setCopied] = useState(false)
  const [imageZoomed, setImageZoomed] = useState(false)
  const [showStickyBar, setShowStickyBar] = useState(false)

  // Review form
  const [reviewRating, setReviewRating] = useState(5)
  const [reviewComment, setReviewComment] = useState('')
  const [submittingReview, setSubmittingReview] = useState(false)

  const mainCtaRef = useRef<HTMLDivElement>(null)
  const productId = String(pageParams?.id || '')

  // Sticky bar visibility on mobile
  useEffect(() => {
    const handleScroll = () => {
      if (mainCtaRef.current) {
        const rect = mainCtaRef.current.getBoundingClientRect()
        setShowStickyBar(rect.bottom < 0)
      }
    }
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    if (!productId) return
    setLoading(true)
    setSelectedImage(0)
    setQuantity(1)

    Promise.all([
      fetch(`/api/products/${productId}`).then((r) => r.json()),
      fetch(`/api/reviews?productId=${productId}`).then((r) => r.json()).catch(() => []),
    ])
      .then(([productResponse, reviewsData]) => {
        const productData = productResponse?.data || productResponse
        setProduct(productData)
        setReviews(extractItems<Review>(reviewsData))
        addRecentlyViewed(productData.id)

        if (productData.category?.id) {
          fetch(`/api/products?category=${productData.category.slug}&limit=8&status=active`)
            .then((r) => r.json())
            .then((d) => {
              const prods = extractItems<RelatedProduct>(d).filter(
                (p) => p.id !== productData.id
              )
              setRelatedProducts(prods.slice(0, 4))
              setAlsoViewedProducts(prods.slice(0, 6))
            })
            .catch(() => {})
        }

        fetch(`/api/products?status=active&limit=4`)
          .then((r) => r.json())
          .then((d) => {
            const prods = extractItems<RelatedProduct>(d).filter(
              (p) => p.id !== productData.id
            )
            setFrequentlyBoughtTogether(prods.slice(0, 3))
          })
          .catch(() => {})
      })
      .catch(() => setProduct(null))
      .finally(() => setLoading(false))
  }, [productId, addRecentlyViewed])

  const ratingBreakdown = useMemo(() => {
    const breakdown = [0, 0, 0, 0, 0]
    reviews.forEach((r) => {
      if (r.rating >= 1 && r.rating <= 5) {
        breakdown[r.rating - 1]++
      }
    })
    return breakdown
  }, [reviews])

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-6 space-y-6">
        <Skeleton className="h-6 w-48" />
        <div className="grid md:grid-cols-2 gap-8">
          <Skeleton className="h-96 rounded-lg" />
          <div className="space-y-4">
            <Skeleton className="h-8 w-3/4" />
            <Skeleton className="h-6 w-1/3" />
            <Skeleton className="h-12 w-full" />
          </div>
        </div>
      </div>
    )
  }

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <h2 className="text-2xl font-bold mb-2">Product Not Found</h2>
        <p className="text-muted-foreground mb-4">The product you are looking for does not exist.</p>
        <Button onClick={() => navigate('products')}>Browse Products</Button>
      </div>
    )
  }

  const wishlisted = isInWishlist(product.id)
  const compared = isInCompare(product.id)
  const images = product.images || []
  const videos = product.videos || []
  const imageUrl = images[selectedImage]?.url || '/placeholder.png'
  const effectivePrice = product.discountPrice != null && product.discountPrice < (product.price ?? 0) ? product.discountPrice : (product.price ?? 0)
  const hasDiscount = product.discountPrice != null && product.discountPrice < (product.price ?? Infinity)
  const discountPercent = hasDiscount
    ? Math.round(((product.price - product.discountPrice!) / product.price) * 100)
    : 0
  const inStock = product.stock > 0
  const avgRating = reviews.length > 0
    ? reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length
    : 0

  let specs: Array<{ key: string; value: string }> = []
  try {
    if (product.specifications) {
      const parsed = JSON.parse(product.specifications)
      specs = Array.isArray(parsed) ? parsed : Object.entries(parsed).map(([key, value]) => ({ key, value: String(value) }))
    }
  } catch { /* ignore */ }

  let tags: string[] = []
  try {
    if (product.tags) {
      const parsed = JSON.parse(product.tags)
      tags = Array.isArray(parsed) ? parsed : typeof parsed === 'string' ? parsed.split(',').map((t: string) => t.trim()) : []
    }
  } catch { /* ignore */ }

  const handleAddToCart = async () => {
    setAdding(true)
    try {
      const cartItem: Omit<CartItem, 'id'> = {
        productId: product.id,
        productName: product.name,
        price: product.price,
        discountPrice: product.discountPrice,
        quantity,
        unit: product.unit,
        image: images[0]?.url || '/placeholder.png',
        stock: product.stock,
      }
      await addToCart(cartItem)
      toast.success('Added to cart')
    } catch {
      toast.error('Failed to add to cart')
    } finally {
      setAdding(false)
    }
  }

  const handleBuyNow = async () => {
    await handleAddToCart()
    navigate('checkout')
  }

  const handleWishlist = async () => {
    const item: WishlistItem = {
      productId: product.id,
      productName: product.name,
      price: product.price,
      discountPrice: product.discountPrice,
      image: images[0]?.url || '/placeholder.png',
    }
    await toggleWishlist(item)
    toast.success(wishlisted ? 'Removed from wishlist' : 'Added to wishlist')
  }

  const handleCompare = () => {
    if (compared) {
      toast.info('Already in comparison list')
      return
    }
    if (compareProducts.length >= 4) {
      toast.error('Maximum 4 products can be compared')
      return
    }
    addToCompare(product.id)
    toast.success('Added to comparison')
  }

  const handleShare = (platform: string) => {
    const url = typeof window !== 'undefined' ? window.location.href : ''
    const text = `Check out ${product.name} on Khati Khadyo!`

    if (platform === 'whatsapp') {
      window.open(`https://wa.me/?text=${encodeURIComponent(text + ' ' + url)}`)
    } else if (platform === 'facebook') {
      window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`)
    } else if (platform === 'copy') {
      navigator.clipboard.writeText(url)
      setCopied(true)
      toast.success('Link copied!')
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!isAuthenticated) {
      toast.error('Please login to write a review')
      navigate('login')
      return
    }
    setSubmittingReview(true)
    try {
      const res = await fetch('/api/reviews', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productId: product.id,
          userId: user?.id,
          rating: reviewRating,
          comment: reviewComment,
        }),
      })
      if (!res.ok) throw new Error('Failed to submit review')
      toast.success('Review submitted successfully!')
      setReviewComment('')
      setReviewRating(5)
      const reviewsData = await fetch(`/api/reviews?productId=${product.id}`).then((r) => r.json())
      setReviews(extractItems<Review>(reviewsData))
    } catch {
      toast.error('Failed to submit review')
    } finally {
      setSubmittingReview(false)
    }
  }

  return (
    <div className="min-h-screen pb-20 md:pb-0">
      {/* Breadcrumb - Enhanced with Home icon */}
      <div className="bg-muted/30 py-3 border-b">
        <div className="container mx-auto px-4">
          <Breadcrumb>
            <BreadcrumbList>
              <BreadcrumbItem>
                <BreadcrumbLink onClick={() => navigate('home')} className="cursor-pointer flex items-center gap-1">
                  <Home className="h-3.5 w-3.5" />
                  Home
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbLink onClick={() => navigate('products')} className="cursor-pointer">Products</BreadcrumbLink>
              </BreadcrumbItem>
              {product.category && (
                <>
                  <BreadcrumbSeparator />
                  <BreadcrumbItem>
                    <BreadcrumbLink onClick={() => navigate('products', { category: product.category!.slug })} className="cursor-pointer">
                      {product.category.name}
                    </BreadcrumbLink>
                  </BreadcrumbItem>
                </>
              )}
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbLink className="text-foreground font-medium">{product.name}</BreadcrumbLink>
              </BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
          {/* ── Image Gallery ── */}
          <div className="space-y-4">
            <div
              className="relative aspect-square rounded-xl overflow-hidden bg-muted/30 cursor-zoom-in group"
              onClick={() => setImageZoomed(!imageZoomed)}
            >
              <Image
                src={imageUrl}
                alt={product.name}
                fill
                className={`object-cover transition-transform duration-500 ${imageZoomed ? 'scale-150' : 'scale-100 group-hover:scale-105'}`}
                sizes="(max-width: 768px) 100vw, 50vw"
                priority
              />
              {hasDiscount && (
                <Badge className="absolute top-3 left-3 bg-red-500 text-white text-sm px-3 py-1 shadow-md">
                  -{discountPercent}%
                </Badge>
              )}
              {images.length > 1 && (
                <div className="absolute bottom-3 right-3 bg-black/60 text-white text-xs px-2.5 py-1 rounded-full backdrop-blur-sm">
                  {selectedImage + 1} / {images.length}
                </div>
              )}
            </div>

            {images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto pb-2">
                {images.map((img, idx) => (
                  <button
                    key={img.id}
                    className={`relative h-16 w-16 sm:h-20 sm:w-20 rounded-lg overflow-hidden flex-shrink-0 border-2 transition-all duration-200 ${
                      idx === selectedImage
                        ? 'border-primary ring-2 ring-primary/20 shadow-md'
                        : 'border-border hover:border-primary/50'
                    }`}
                    onClick={() => setSelectedImage(idx)}
                  >
                    <Image src={img.url} alt={img.alt || product.name} fill className="object-cover" sizes="80px" />
                  </button>
                ))}
              </div>
            )}

            {videos.length > 0 && (
              <div className="space-y-3">
                <h3 className="font-semibold">Product Videos</h3>
                {videos.map((video) => (
                  <div key={video.id} className="rounded-lg overflow-hidden bg-muted/30">
                    <video src={video.url} controls className="w-full" poster={video.thumbnail || undefined} />
                    {video.title && <p className="text-sm text-muted-foreground p-2">{video.title}</p>}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* ── Product Info ── */}
          <div className="space-y-5">
            {/* Category & Title */}
            <div>
              {product.category && (
                <button
                  onClick={() => navigate('products', { category: product.category!.slug })}
                  className="text-sm text-primary font-medium mb-1 hover:underline inline-flex items-center gap-1"
                >
                  {product.category.name}
                  <ChevronRight className="h-3 w-3" />
                </button>
              )}
              <h1 className="text-2xl md:text-3xl font-bold">{product.name}</h1>
              {product.shortDescription && (
                <p className="text-muted-foreground mt-2">{product.shortDescription}</p>
              )}
              <div className="flex flex-wrap gap-2 mt-2">
                {product.isNewArrival && (
                  <Badge className="bg-emerald-500 text-white text-xs">
                    <Sparkles className="h-3 w-3 mr-1" />New Arrival
                  </Badge>
                )}
                {product.isBestSeller && (
                  <Badge className="bg-amber-500 text-white text-xs">
                    <Star className="h-3 w-3 mr-1 fill-current" />Best Seller
                  </Badge>
                )}
              </div>
            </div>

            {/* Rating */}
            <div className="flex items-center gap-2">
              <div className="flex gap-0.5">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className={`h-4 w-4 ${i < Math.round(avgRating) ? 'fill-amber-400 text-amber-400' : 'text-muted-foreground/30'}`} />
                ))}
              </div>
              <span className="text-sm font-medium">{avgRating.toFixed(1)}</span>
              <span className="text-sm text-muted-foreground">({reviews.length} review{reviews.length !== 1 ? 's' : ''})</span>
            </div>

            {/* Price */}
            <div className="flex items-baseline gap-3">
              <span className="text-3xl font-bold text-primary">৳{(effectivePrice ?? 0).toLocaleString()}</span>
              {hasDiscount && (
                <span className="text-xl text-muted-foreground line-through">৳{(product.price ?? 0).toLocaleString()}</span>
              )}
              <span className="text-muted-foreground">/ {product.unit}</span>
              {hasDiscount && (
                <Badge className="bg-red-100 text-red-700">Save ৳{((product.price ?? 0) - (product.discountPrice ?? 0)).toLocaleString()}</Badge>
              )}
            </div>

            {/* Stock Status */}
            <div>
              {inStock ? (
                product.stock <= 5 ? (
                  <Badge variant="secondary" className="bg-orange-100 text-orange-700">Only {product.stock} left in stock!</Badge>
                ) : (
                  <Badge variant="secondary" className="bg-emerald-100 text-emerald-700">In Stock ({product.stock} available)</Badge>
                )
              ) : (
                <Badge variant="secondary" className="bg-red-100 text-red-700">Out of Stock</Badge>
              )}
            </div>

            {/* Product Details */}
            <div className="space-y-2 text-sm">
              {product.origin && (
                <p><span className="text-muted-foreground">Origin:</span> <span className="font-medium">{product.origin}</span></p>
              )}
              {product.qualityNote && (
                <p><span className="text-muted-foreground">Quality:</span> <span className="font-medium">{product.qualityNote}</span></p>
              )}
              <p><span className="text-muted-foreground">Unit:</span> <span className="font-medium">{product.unit}</span></p>
            </div>

            <Separator />

            {/* Quantity & Add to Cart */}
            <div ref={mainCtaRef}>
              {inStock ? (
                <div className="space-y-3">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center border rounded-lg overflow-hidden shadow-sm">
                      <button
                        className="h-11 w-11 flex items-center justify-center hover:bg-primary/10 transition-colors active:scale-90"
                        onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                        aria-label="Decrease quantity"
                      >
                        <Minus className="h-4 w-4" />
                      </button>
                      <span className="h-11 w-14 flex items-center justify-center font-semibold border-x bg-muted/30">{quantity}</span>
                      <button
                        className="h-11 w-11 flex items-center justify-center hover:bg-primary/10 transition-colors active:scale-90"
                        onClick={() => setQuantity((q) => Math.min(product.stock, q + 1))}
                        disabled={quantity >= product.stock}
                        aria-label="Increase quantity"
                      >
                        <Plus className="h-4 w-4" />
                      </button>
                    </div>
                    <Button className="flex-1 h-11 rounded-lg" size="lg" disabled={adding} onClick={handleAddToCart}>
                      <ShoppingCart className="h-5 w-5 mr-2" />
                      {adding ? 'Adding...' : 'Add to Cart'}
                    </Button>
                  </div>
                  <Button className="w-full h-11 rounded-lg" variant="secondary" size="lg" onClick={handleBuyNow}>
                    Buy Now <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                </div>
              ) : (
                <StockNotificationButton productId={product.id} productName={product.name} />
              )}
            </div>

            {/* Action Buttons Row */}
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1 h-10 rounded-lg" onClick={handleWishlist}>
                <Heart className={`h-4 w-4 mr-1.5 ${wishlisted ? 'fill-red-500 text-red-500' : ''}`} />
                <span className="hidden sm:inline">{wishlisted ? 'Wishlisted' : 'Wishlist'}</span>
              </Button>
              <Button
                variant="outline"
                className={`flex-1 h-10 rounded-lg ${compared ? 'border-primary text-primary' : ''}`}
                onClick={handleCompare}
                disabled={compareProducts.length >= 4 && !compared}
              >
                <GitCompareArrows className="h-4 w-4 mr-1.5" />
                <span className="hidden sm:inline">{compared ? 'In Compare' : 'Compare'}</span>
              </Button>
            </div>

            {/* Share Buttons */}
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground mr-1">Share:</span>
              <Button variant="outline" size="icon" className="h-8 w-8 rounded-full" onClick={() => handleShare('facebook')} aria-label="Share on Facebook">
                <Facebook className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon" className="h-8 w-8 rounded-full text-emerald-600" onClick={() => handleShare('whatsapp')} aria-label="Share on WhatsApp">
                <MessageCircle className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="sm" className="h-8 gap-1 text-xs rounded-full" onClick={() => handleShare('copy')}>
                {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                {copied ? 'Copied!' : 'Copy Link'}
              </Button>
            </div>

            {/* Delivery Info Card - Enhanced */}
            <Card className="border shadow-sm overflow-hidden">
              <CardContent className="p-0">
                <div className="grid grid-cols-1 sm:grid-cols-3 divide-y sm:divide-y-0 sm:divide-x">
                  <div className="flex items-center gap-3 p-4 hover:bg-muted/30 transition-colors">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <Truck className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold">Free Shipping</p>
                      <p className="text-xs text-muted-foreground">
                        Orders over ৳{(siteConfig?.freeShippingThreshold || 1500).toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-4 hover:bg-muted/30 transition-colors">
                    <div className="h-10 w-10 rounded-full bg-emerald-100 flex items-center justify-center flex-shrink-0">
                      <ShieldCheck className="h-5 w-5 text-emerald-600" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold">Quality Guaranteed</p>
                      <p className="text-xs text-muted-foreground">100% authentic products</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-4 hover:bg-muted/30 transition-colors">
                    <div className="h-10 w-10 rounded-full bg-amber-50 flex items-center justify-center flex-shrink-0">
                      <RefreshCw className="h-5 w-5 text-amber-600" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold">Easy Returns</p>
                      <p className="text-xs text-muted-foreground">{siteConfig?.returnWindowDays || 7}-day return policy</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Tags */}
            {tags.length > 0 && (
              <div className="flex flex-wrap gap-1.5">
                {tags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="text-xs">{tag}</Badge>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* ── Frequently Bought Together - Enhanced ── */}
        {frequentlyBoughtTogether.length > 0 && (
          <section className="mt-12">
            <div className="flex items-center gap-2 mb-6">
              <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center">
                <Package className="h-4 w-4 text-primary" />
              </div>
              <h2 className="text-xl md:text-2xl font-bold">Frequently Bought Together</h2>
            </div>
            <Card className="shadow-sm">
              <CardContent className="p-5">
                <div className="flex items-center gap-4 overflow-x-auto pb-2" style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}>
                  {/* Current product */}
                  <div className="flex-shrink-0 w-36 sm:w-40">
                    <div className="relative aspect-square rounded-xl overflow-hidden bg-muted/30 border-2 border-primary shadow-sm">
                      <Image src={images[0]?.url || '/placeholder.png'} alt={product.name} fill className="object-cover" sizes="160px" />
                      <div className="absolute top-1.5 left-1.5">
                        <Badge className="bg-primary text-primary-foreground text-[10px] h-5">This item</Badge>
                      </div>
                    </div>
                    <p className="text-xs font-medium mt-2 line-clamp-1">{product.name}</p>
                    <p className="text-sm font-bold text-primary">৳{(effectivePrice ?? 0).toLocaleString()}</p>
                  </div>

                  {frequentlyBoughtTogether.map((p) => {
                    const pPrice = p.discountPrice != null ? p.discountPrice : (p.price ?? 0)
                    const pImage = p.images?.[0]?.url
                    return (
                      <div key={p.id} className="flex items-center gap-4 flex-shrink-0">
                        <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center">
                          <Plus className="h-4 w-4 text-muted-foreground" />
                        </div>
                        <button className="w-36 sm:w-40 group" onClick={() => navigate('product-detail', { id: p.id })}>
                          <div className="relative aspect-square rounded-xl overflow-hidden bg-muted/30 border border-border/50 group-hover:border-primary/30 group-hover:shadow-md transition-all duration-300">
                            {pImage ? (
                              <Image src={pImage} alt={p.name} fill className="object-cover group-hover:scale-105 transition-transform duration-300" sizes="160px" />
                            ) : (
                              <div className="flex items-center justify-center h-full">
                                <Package className="h-8 w-8 text-muted-foreground/30" />
                              </div>
                            )}
                          </div>
                          <p className="text-xs font-medium mt-2 line-clamp-1 group-hover:text-primary transition-colors">{p.name}</p>
                          <p className="text-sm font-bold text-primary">৳{(pPrice ?? 0).toLocaleString()}</p>
                        </button>
                      </div>
                    )
                  })}
                </div>

                {/* Total price & Add all */}
                <div className="mt-5 pt-5 border-t flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="text-center sm:text-left">
                    <p className="text-sm text-muted-foreground">Bundle total price</p>
                    <p className="text-2xl font-bold text-primary">
                      ৳{((effectivePrice ?? 0) + frequentlyBoughtTogether.reduce((sum, p) => {
                        return sum + (p.discountPrice != null ? (p.discountPrice ?? 0) : (p.price ?? 0))
                      }, 0)).toLocaleString()}
                    </p>
                  </div>
                  <Button
                    className="h-11 px-6 rounded-lg"
                    onClick={async () => {
                      const items = [
                        { productId: product.id, productName: product.name, price: product.price, discountPrice: product.discountPrice, unit: product.unit, image: images[0]?.url || '/placeholder.png', stock: product.stock },
                        ...frequentlyBoughtTogether.map((p) => ({
                          productId: p.id, productName: p.name, price: p.price, discountPrice: p.discountPrice, unit: p.unit, image: p.images?.[0]?.url || '/placeholder.png', stock: p.stock,
                        })),
                      ]
                      for (const item of items) {
                        await addToCart({ ...item, quantity: 1 })
                      }
                      toast.success(`${items.length} items added to cart`)
                    }}
                  >
                    <ShoppingCart className="h-4 w-4 mr-2" />
                    Add All to Cart
                  </Button>
                </div>
              </CardContent>
            </Card>
          </section>
        )}

        {/* ── Description & Specs Tabs ── */}
        <div className="mt-12">
          <Tabs defaultValue="description">
            <TabsList className="w-full justify-start flex-wrap h-auto gap-1 bg-transparent p-0 border-b rounded-none">
              <TabsTrigger
                value="description"
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none px-4 py-2.5"
              >
                Description
              </TabsTrigger>
              <TabsTrigger
                value="specifications"
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none px-4 py-2.5"
              >
                Specifications
              </TabsTrigger>
              <TabsTrigger
                value="reviews"
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none px-4 py-2.5"
              >
                Reviews ({reviews.length})
              </TabsTrigger>
              <TabsTrigger
                value="delivery"
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none px-4 py-2.5"
              >
                Delivery Info
              </TabsTrigger>
            </TabsList>

            <TabsContent value="description" className="mt-6">
              <div className="prose max-w-none">
                {product.description ? (
                  <div dangerouslySetInnerHTML={{ __html: product.description }} />
                ) : (
                  <p className="text-muted-foreground">No detailed description available.</p>
                )}
              </div>
              <div className="mt-8 grid sm:grid-cols-2 gap-6">
                {product.ingredients && (
                  <div className="p-4 rounded-lg bg-muted/30">
                    <h3 className="font-semibold mb-2">Ingredients</h3>
                    <p className="text-sm text-muted-foreground">{product.ingredients}</p>
                  </div>
                )}
                {product.storageInstruction && (
                  <div className="p-4 rounded-lg bg-muted/30">
                    <h3 className="font-semibold mb-2">Storage Instructions</h3>
                    <p className="text-sm text-muted-foreground">{product.storageInstruction}</p>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="specifications" className="mt-6">
              {specs.length > 0 ? (
                <div className="max-w-2xl">
                  {specs.map((spec, idx) => (
                    <div key={idx} className={`flex justify-between py-3 ${idx < specs.length - 1 ? 'border-b' : ''}`}>
                      <span className="text-muted-foreground font-medium">{spec.key}</span>
                      <span className="font-medium">{spec.value}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground">No specifications available.</p>
              )}
            </TabsContent>

            <TabsContent value="reviews" className="mt-6">
              <div className="grid lg:grid-cols-3 gap-8">
                {/* Rating Summary */}
                <div className="space-y-4">
                  <div className="text-center p-6 rounded-xl bg-gradient-to-br from-primary/5 to-primary/10 border">
                    <p className="text-5xl font-bold text-primary">{avgRating.toFixed(1)}</p>
                    <div className="flex gap-0.5 justify-center mt-2">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star key={i} className={`h-5 w-5 ${i < Math.round(avgRating) ? 'fill-amber-400 text-amber-400' : 'text-muted-foreground/30'}`} />
                      ))}
                    </div>
                    <p className="text-sm text-muted-foreground mt-2">
                      Based on {reviews.length} review{reviews.length !== 1 ? 's' : ''}
                    </p>
                  </div>

                  {/* Rating Breakdown with progress bars */}
                  <div className="space-y-2.5 p-4 rounded-xl border bg-background">
                    <h4 className="text-sm font-semibold mb-3">Rating Breakdown</h4>
                    {[5, 4, 3, 2, 1].map((star) => {
                      const count = ratingBreakdown[star - 1]
                      const percentage = reviews.length > 0 ? (count / reviews.length) * 100 : 0
                      return (
                        <div key={star} className="flex items-center gap-2.5 group">
                          <span className="text-sm font-medium w-4 text-right">{star}</span>
                          <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400 flex-shrink-0" />
                          <div className="flex-1 h-2.5 rounded-full bg-muted overflow-hidden">
                            <div
                              className="h-full rounded-full bg-amber-400 transition-all duration-500"
                              style={{ width: `${percentage}%` }}
                            />
                          </div>
                          <span className="text-xs text-muted-foreground w-8 text-right">{count}</span>
                          <span className="text-[10px] text-muted-foreground w-10 text-right opacity-0 group-hover:opacity-100 transition-opacity">
                            {percentage.toFixed(0)}%
                          </span>
                        </div>
                      )
                    })}
                  </div>

                  {isAuthenticated && (
                    <Button
                      variant="outline"
                      className="w-full rounded-lg"
                      onClick={() => document.getElementById('review-form')?.scrollIntoView({ behavior: 'smooth' })}
                    >
                      Write a Review
                    </Button>
                  )}
                </div>

                {/* Reviews List */}
                <div className="lg:col-span-2 space-y-6">
                  {isAuthenticated && (
                    <Card id="review-form" className="shadow-sm">
                      <CardContent className="p-4">
                        <h3 className="font-semibold mb-3">Write a Review</h3>
                        <form onSubmit={handleSubmitReview} className="space-y-3">
                          <div>
                            <Label>Rating</Label>
                            <div className="flex gap-1 mt-1">
                              {Array.from({ length: 5 }).map((_, i) => (
                                <button key={i} type="button" onClick={() => setReviewRating(i + 1)}>
                                  <Star className={`h-6 w-6 transition-colors ${i < reviewRating ? 'fill-amber-400 text-amber-400' : 'text-muted-foreground/30'}`} />
                                </button>
                              ))}
                            </div>
                          </div>
                          <div>
                            <Label htmlFor="review-comment">Comment</Label>
                            <Textarea id="review-comment" value={reviewComment} onChange={(e) => setReviewComment(e.target.value)} placeholder="Share your experience with this product..." className="mt-1" />
                          </div>
                          <Button type="submit" disabled={submittingReview}>{submittingReview ? 'Submitting...' : 'Submit Review'}</Button>
                        </form>
                      </CardContent>
                    </Card>
                  )}

                  {!isAuthenticated && (
                    <div className="text-center py-4 px-6 rounded-lg bg-muted/30">
                      <p className="text-sm text-muted-foreground mb-2">Please login to write a review</p>
                      <Button variant="outline" size="sm" onClick={() => navigate('login')}>Login</Button>
                    </div>
                  )}

                  {reviews.length === 0 ? (
                    <div className="text-center py-12">
                      <Star className="h-12 w-12 text-muted-foreground/20 mx-auto mb-4" />
                      <p className="text-lg font-medium">No reviews yet</p>
                      <p className="text-sm text-muted-foreground mt-1">Be the first to share your experience!</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {reviews.map((review) => (
                        <Card key={review.id} className="shadow-sm">
                          <CardContent className="p-4">
                            <div className="flex items-start justify-between">
                              <div className="flex items-center gap-3">
                                <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center text-primary font-semibold text-sm">
                                  {(review.user?.name || 'A').charAt(0).toUpperCase()}
                                </div>
                                <div>
                                  <p className="text-sm font-medium">{review.user?.name || 'Anonymous'}</p>
                                  <div className="flex items-center gap-1.5">
                                    <div className="flex gap-0.5">
                                      {Array.from({ length: 5 }).map((_, i) => (
                                        <Star key={i} className={`h-3 w-3 ${i < review.rating ? 'fill-amber-400 text-amber-400' : 'text-muted-foreground/30'}`} />
                                      ))}
                                    </div>
                                    <span className="text-xs text-muted-foreground">
                                      {new Date(review.createdAt).toLocaleDateString()}
                                    </span>
                                  </div>
                                </div>
                              </div>
                            </div>
                            {review.comment && (
                              <p className="text-sm mt-3 leading-relaxed">{review.comment}</p>
                            )}
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="delivery" className="mt-6">
              <div className="max-w-2xl space-y-4">
                <div className="flex gap-4 p-5 rounded-xl bg-muted/30 border hover:shadow-sm transition-shadow">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Truck className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Delivery Information</h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      {product.deliveryNote || 'We deliver across Bangladesh. Standard delivery takes 2-5 business days depending on your location.'}
                    </p>
                    <div className="mt-2 space-y-1">
                      <p className="text-sm"><span className="text-muted-foreground">Shipping charge:</span> <span className="font-medium">৳{siteConfig?.shippingCharge || 60}</span></p>
                      <p className="text-sm"><span className="text-muted-foreground">Free shipping on orders over:</span> <span className="font-medium">৳{(siteConfig?.freeShippingThreshold || 1500).toLocaleString()}</span></p>
                    </div>
                  </div>
                </div>
                <div className="flex gap-4 p-5 rounded-xl bg-muted/30 border hover:shadow-sm transition-shadow">
                  <div className="h-10 w-10 rounded-full bg-amber-50 flex items-center justify-center flex-shrink-0">
                    <RefreshCw className="h-5 w-5 text-amber-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Return & Refund Policy</h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      We offer a {siteConfig?.returnWindowDays || 7}-day hassle-free return policy. If you are not satisfied with the product quality, you can initiate a return within {siteConfig?.returnWindowDays || 7} days of delivery.
                    </p>
                  </div>
                </div>
                <div className="flex gap-4 p-5 rounded-xl bg-muted/30 border hover:shadow-sm transition-shadow">
                  <div className="h-10 w-10 rounded-full bg-emerald-100 flex items-center justify-center flex-shrink-0">
                    <ShieldCheck className="h-5 w-5 text-emerald-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Quality Guarantee</h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      All our products are 100% authentic and sourced directly from trusted suppliers. We ensure the highest quality standards for every product we deliver.
                    </p>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* ── Customers Also Viewed ── */}
        {alsoViewedProducts.length > 0 && (
          <section className="mt-12">
            <div className="flex items-center gap-2 mb-6">
              <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center">
                <Users className="h-4 w-4 text-primary" />
              </div>
              <h2 className="text-xl md:text-2xl font-bold">Customers Also Viewed</h2>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {alsoViewedProducts.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </section>
        )}

        {/* ── Related Products ── */}
        {relatedProducts.length > 0 && (
          <section className="mt-12">
            <h2 className="text-xl md:text-2xl font-bold mb-6">Related Products</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {relatedProducts.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </section>
        )}
      </div>

      {/* Sticky Add to Cart Bar - Mobile Only */}
      {showStickyBar && inStock && (
        <div className="fixed bottom-0 left-0 right-0 bg-background/95 backdrop-blur-sm border-t shadow-lg z-50 md:hidden transition-transform duration-300">
          <div className="container mx-auto px-4 py-3 flex items-center gap-3">
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold line-clamp-1">{product.name}</p>
              <div className="flex items-baseline gap-2">
                <span className="text-lg font-bold text-primary">৳{(effectivePrice ?? 0).toLocaleString()}</span>
                {hasDiscount && (
                  <span className="text-xs text-muted-foreground line-through">৳{(product.price ?? 0).toLocaleString()}</span>
                )}
              </div>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <div className="flex items-center border rounded-lg overflow-hidden">
                <button
                  className="h-9 w-8 flex items-center justify-center hover:bg-muted active:scale-90"
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                >
                  <Minus className="h-3.5 w-3.5" />
                </button>
                <span className="h-9 w-8 flex items-center justify-center text-sm font-semibold border-x">{quantity}</span>
                <button
                  className="h-9 w-8 flex items-center justify-center hover:bg-muted active:scale-90"
                  onClick={() => setQuantity((q) => Math.min(product.stock, q + 1))}
                >
                  <Plus className="h-3.5 w-3.5" />
                </button>
              </div>
              <Button
                className="h-9 px-4 rounded-lg"
                size="sm"
                disabled={adding}
                onClick={handleAddToCart}
              >
                <ShoppingCart className="h-4 w-4 mr-1" />
                Add
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
