'use client'

import { useEffect, useState } from 'react'
import { HelpCircle } from 'lucide-react'
import { extractItems } from '@/lib/api'
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { Badge } from '@/components/ui/badge'

interface FAQItem {
  id: string
  question: string
  answer: string
  category?: string
}

export default function FAQPage() {
  const [faqItems, setFaqItems] = useState<FAQItem[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/faq')
      .then((r) => r.json())
      .then((data) => {
        const items = extractItems<FAQItem>(data)
        setFaqItems(items.filter((i: FAQItem) => i.category ? true : true))
      })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  // Group by category
  const categories = faqItems.reduce<Record<string, FAQItem[]>>((acc, item) => {
    const cat = item.category || 'General'
    if (!acc[cat]) acc[cat] = []
    acc[cat].push(item)
    return acc
  }, {})

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-4xl space-y-4">
        <Skeleton className="h-10 w-64" />
        {Array.from({ length: 5 }).map((_, i) => (
          <Skeleton key={i} className="h-16 rounded-lg" />
        ))}
      </div>
    )
  }

  return (
    <div className="min-h-screen">
      <div className="bg-primary text-primary-foreground py-12">
        <div className="container mx-auto px-4 text-center">
          <HelpCircle className="h-12 w-12 mx-auto mb-4 opacity-80" />
          <h1 className="text-3xl md:text-4xl font-bold mb-3">Frequently Asked Questions</h1>
          <p className="text-lg opacity-90">Find answers to common questions about our products and services</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {faqItems.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No FAQ items available yet. Please contact us if you have questions.</p>
          </div>
        ) : (
          <div className="space-y-8">
            {Object.entries(categories).map(([category, items]) => (
              <Card key={category}>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Badge variant="secondary">{category}</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Accordion type="single" collapsible className="w-full">
                    {items.map((item) => (
                      <AccordionItem key={item.id} value={item.id}>
                        <AccordionTrigger className="text-left text-sm">
                          {item.question}
                        </AccordionTrigger>
                        <AccordionContent className="text-muted-foreground text-sm">
                          {item.answer}
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
