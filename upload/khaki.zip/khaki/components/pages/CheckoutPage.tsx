'use client'

import { useEffect, useState } from 'react'
import {
  CreditCard, Truck, MapPin, ChevronRight, Loader2, ShieldCheck,
  Gift, Clock, CheckCircle2, Package, Wallet, Banknote, Smartphone, Lock,
  ArrowLeft, RefreshCw, BadgeCheck, Zap
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Separator } from '@/components/ui/separator'
import { Badge } from '@/components/ui/badge'
import { Checkbox } from '@/components/ui/checkbox'
import { useAppStore } from '@/lib/store'
import { extractItems } from '@/lib/api'
import { toast } from 'sonner'

interface Address {
  id: string
  name: string
  phone: string
  address: string
  city: string
  district?: string
  postalCode?: string
  isDefault: boolean
}

const checkoutSteps = [
  { id: 1, label: 'Cart', icon: Package },
  { id: 2, label: 'Delivery', icon: MapPin },
  { id: 3, label: 'Payment', icon: CreditCard },
  { id: 4, label: 'Confirm', icon: CheckCircle2 },
]

export default function CheckoutPage() {
  const { cartItems, subtotal, totalItems, navigate, isAuthenticated, user, siteConfig, clearCart } = useAppStore()
  const [addresses, setAddresses] = useState<Address[]>([])
  const [selectedAddressId, setSelectedAddressId] = useState('')
  const [shippingMethod, setShippingMethod] = useState('standard')
  const [paymentMethod, setPaymentMethod] = useState('cod')
  const [note, setNote] = useState('')
  const [couponCode, setCouponCode] = useState('')
  const [discount, setDiscount] = useState(0)
  const [placing, setPlacing] = useState(false)
  const [currentStep, setCurrentStep] = useState(2)
  const [giftWrap, setGiftWrap] = useState(false)
  const [couponApplied, setCouponApplied] = useState(false)

  // Guest form
  const [guestName, setGuestName] = useState('')
  const [guestPhone, setGuestPhone] = useState('')
  const [guestEmail, setGuestEmail] = useState('')
  const [guestAddress, setGuestAddress] = useState('')
  const [guestCity, setGuestCity] = useState('')
  const [guestDistrict, setGuestDistrict] = useState('')

  // Add address form
  const [showAddAddress, setShowAddAddress] = useState(false)
  const [newAddr, setNewAddr] = useState({ name: '', phone: '', address: '', city: '', district: '', postalCode: '' })

  useEffect(() => {
    if (isAuthenticated && user?.id) {
      fetch(`/api/addresses?userId=${user.id}`)
        .then((r) => r.json())
        .then((data) => {
          const addrs = extractItems<Address>(data)
          setAddresses(addrs)
          const defaultAddr = addrs.find((a: Address) => a.isDefault)
          if (defaultAddr) setSelectedAddressId(defaultAddr.id)
          else if (addrs.length > 0) setSelectedAddressId(addrs[0].id)
        })
        .catch(() => {})
    }
  }, [isAuthenticated, user?.id])

  const sub = subtotal()
  
  const standardShipping = siteConfig?.shippingCharge || 60
  const expressShipping = 120 // Fallback for express
  const freeThreshold = siteConfig?.freeShippingThreshold || 1500
  
  let shipping = standardShipping
  if (sub >= freeThreshold) {
    shipping = 0
  }
  if (shippingMethod === 'express') {
    shipping = expressShipping
    if (sub >= freeThreshold) {
      shipping = expressShipping - standardShipping
    }
  }

  const giftWrapCharge = giftWrap ? 50 : 0
  const total = sub + shipping + giftWrapCharge - discount

  const handleApplyCoupon = async () => {
    if (!couponCode.trim()) return
    try {
      const res = await fetch('/api/coupons/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: couponCode, totalAmount: sub }),
      })
      const data = await res.json()
      if (!res.ok) {
        toast.error(data.error || 'Invalid coupon')
        return
      }
      const discountAmount = data.type === 'percentage'
        ? Math.min(sub * (data.value / 100), data.maxDiscount || Infinity)
        : data.value
      setDiscount(discountAmount)
      setCouponApplied(true)
      toast.success('Coupon applied!')
    } catch {
      toast.error('Failed to validate coupon')
    }
  }

  const handleAddAddress = async () => {
    if (!user?.id) return
    try {
      const res = await fetch('/api/addresses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id, ...newAddr, isDefault: addresses.length === 0 }),
      })
      if (!res.ok) throw new Error('Failed to add address')
      const saved = await res.json()
      setAddresses((prev) => [...prev, saved])
      setSelectedAddressId(saved.id)
      setShowAddAddress(false)
      setNewAddr({ name: '', phone: '', address: '', city: '', district: '', postalCode: '' })
      toast.success('Address added')
    } catch {
      toast.error('Failed to add address')
    }
  }

  const validatePhone = (p: string) => /^(?:01\d{9}|\+8801\d{9})$/.test(p)

  const handlePlaceOrder = async () => {
    if (cartItems.length === 0) {
      toast.error('Your cart is empty')
      return
    }

    if (isAuthenticated) {
      if (!selectedAddressId) {
        toast.error('Please select a delivery address')
        return
      }
    } else {
      if (!guestName.trim() || !guestPhone.trim() || !guestAddress.trim() || !guestCity.trim()) {
        toast.error('Please fill in all required fields')
        return
      }
      if (!validatePhone(guestPhone)) {
        toast.error('Please enter a valid Bangladesh phone number (e.g. 01XXXXXXXXX)')
        return
      }
    }

    setPlacing(true)
    try {
      const orderData: Record<string, unknown> = {
        paymentMethod,
        shippingMethod,
        orderNote: note,
        couponCode: couponCode || undefined,
        discountAmount: discount,
        deliveryCharge: shipping,
        totalAmount: total,
        giftWrap,
        items: cartItems.map((item) => ({
          productId: item.productId,
          productName: item.productName,
          quantity: item.quantity,
          unit: item.unit,
          price: item.discountPrice != null ? item.discountPrice : item.price,
          image: item.image,
        })),
      }

      if (isAuthenticated && user?.id) {
        orderData.userId = user.id
        orderData.addressId = selectedAddressId
      } else {
        orderData.guestName = guestName
        orderData.guestPhone = guestPhone
        orderData.guestEmail = guestEmail || undefined
        orderData.guestAddress = `${guestAddress}, ${guestCity}${guestDistrict ? `, ${guestDistrict}` : ''}`
      }

      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderData),
      })

      if (!res.ok) {
        const data = await res.json()
        throw new Error(data.error || 'Failed to place order')
      }

      const order = await res.json()
      const orderId = order.data?.id || order.id
      const orderNum = order.data?.orderNumber || order.orderNumber

      if (paymentMethod === 'online') {
        const initRes = await fetch('/api/payments/sslcommerz/initiate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ orderId }),
        })
        const initData = await initRes.json()
        
        if (initData.success && initData.data?.gatewayPageURL) {
          window.location.href = initData.data.gatewayPageURL
          return // Redirecting, so don't clear cart yet
        } else {
          throw new Error(initData.error || 'Failed to initialize payment gateway')
        }
      } else {
        await clearCart()
        toast.success('Order placed successfully!')
        navigate('order-confirmation', { orderId, orderNumber: orderNum })
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Failed to place order')
      setPlacing(false)
    }
  }

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center py-20 px-4">
        <div className="text-center">
          <div className="h-24 w-24 rounded-full bg-muted/50 flex items-center justify-center mx-auto mb-4">
            <Package className="h-10 w-10 text-muted-foreground" />
          </div>
          <h2 className="text-2xl font-bold mb-2">Your cart is empty</h2>
          <p className="text-muted-foreground mb-6">Add products to your cart before checkout</p>
          <Button onClick={() => navigate('products')} className="rounded-full px-6">
            Browse Products
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen">
      {/* Logo Header */}
      <div className="bg-primary text-primary-foreground border-b border-primary/20">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3 cursor-pointer hover:opacity-80 transition-opacity" onClick={() => navigate('home')}>
            {siteConfig?.logo ? (
              <img
                src={siteConfig.logo}
                alt="Khati Khadyo"
                className="h-8 w-auto object-contain invert"
              />
            ) : (
              <div className="h-8 w-8 rounded-lg bg-primary-foreground/20 flex items-center justify-center text-sm font-bold">
                KK
              </div>
            )}
            <span className="font-bold text-lg hidden sm:block">Khati Khadyo</span>
          </div>
          <Button
            variant="ghost"
            className="text-primary-foreground hover:bg-primary-foreground/10"
            onClick={() => navigate('cart')}
          >
            Back to Cart
          </Button>
        </div>
      </div>

      {/* Step Indicator */}
      <div className="bg-gradient-to-r from-[#2D6A4F]/5 via-[#2D6A4F]/10 to-[#2D6A4F]/5 border-b">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-center max-w-xl mx-auto">
            {checkoutSteps.map((step, idx) => (
              <div key={step.id} className="flex items-center">
                <div className="flex flex-col items-center">
                  <div
                    className={`h-11 w-11 rounded-full flex items-center justify-center text-sm font-bold transition-all duration-500 ${
                      currentStep > step.id
                        ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/25 scale-100'
                        : currentStep === step.id
                        ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/25 ring-4 ring-primary/20'
                        : 'bg-muted text-muted-foreground'
                    }`}
                  >
                    {currentStep > step.id ? (
                      <CheckCircle2 className="h-5 w-5" />
                    ) : (
                      <step.icon className="h-4 w-4" />
                    )}
                  </div>
                  <span className={`text-xs mt-1.5 font-medium transition-colors ${currentStep >= step.id ? 'text-primary' : 'text-muted-foreground'}`}>
                    {step.label}
                  </span>
                </div>
                {idx < checkoutSteps.length - 1 && (
                  <div className="relative mx-1 sm:mx-3">
                    <div className="h-0.5 w-10 sm:w-16 bg-muted" />
                    <div
                      className="absolute top-0 left-0 h-0.5 bg-primary transition-all duration-500"
                      style={{ width: currentStep > step.id ? '100%' : currentStep === step.id ? '50%' : '0%' }}
                    />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            {/* Step 1: Delivery Information */}
            <Card className="shadow-sm border">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center">
                    <MapPin className="h-4 w-4 text-primary" />
                  </div>
                  Delivery Information
                  <Badge variant="secondary" className="text-[10px] h-5 ml-2">Step 1</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isAuthenticated ? (
                  <div className="space-y-3">
                    {addresses.length > 0 ? (
                      <RadioGroup value={selectedAddressId} onValueChange={setSelectedAddressId}>
                        {addresses.map((addr) => (
                          <div
                            key={addr.id}
                            className={`flex items-start gap-3 p-4 rounded-xl border-2 cursor-pointer transition-all duration-200 ${
                              selectedAddressId === addr.id
                                ? 'border-primary bg-primary/5 shadow-sm'
                                : 'border-transparent bg-muted/30 hover:bg-muted/50'
                            }`}
                            onClick={() => setSelectedAddressId(addr.id)}
                          >
                            <RadioGroupItem value={addr.id} id={addr.id} className="mt-1" />
                            <Label htmlFor={addr.id} className="flex-1 cursor-pointer">
                              <div className="font-medium">{addr.name}</div>
                              <div className="text-sm text-muted-foreground">{addr.phone}</div>
                              <div className="text-sm text-muted-foreground">
                                {addr.address}, {addr.city}{addr.district ? `, ${addr.district}` : ''} {addr.postalCode || ''}
                              </div>
                              {addr.isDefault && <Badge variant="secondary" className="mt-2 text-xs">Default</Badge>}
                            </Label>
                          </div>
                        ))}
                      </RadioGroup>
                    ) : (
                      <p className="text-muted-foreground text-sm">No saved addresses. Add one below.</p>
                    )}

                    {showAddAddress ? (
                      <div className="border rounded-xl p-4 space-y-3 bg-muted/20 mt-4">
                        <h4 className="font-medium">Add New Address</h4>
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <Label className="text-sm">Full Name *</Label>
                            <Input value={newAddr.name} onChange={(e) => setNewAddr({ ...newAddr, name: e.target.value })} />
                          </div>
                          <div>
                            <Label className="text-sm">Phone *</Label>
                            <Input value={newAddr.phone} onChange={(e) => setNewAddr({ ...newAddr, phone: e.target.value })} />
                          </div>
                        </div>
                        <div>
                          <Label className="text-sm">Address *</Label>
                          <Input value={newAddr.address} onChange={(e) => setNewAddr({ ...newAddr, address: e.target.value })} />
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <Label className="text-sm">City *</Label>
                            <Input value={newAddr.city} onChange={(e) => setNewAddr({ ...newAddr, city: e.target.value })} />
                          </div>
                          <div>
                            <Label className="text-sm">District</Label>
                            <Input value={newAddr.district} onChange={(e) => setNewAddr({ ...newAddr, district: e.target.value })} />
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" onClick={handleAddAddress}>Save Address</Button>
                          <Button size="sm" variant="outline" onClick={() => setShowAddAddress(false)}>Cancel</Button>
                        </div>
                      </div>
                    ) : (
                      <Button variant="outline" size="sm" onClick={() => setShowAddAddress(true)} className="rounded-lg mt-4">
                        + Add New Address
                      </Button>
                    )}
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <Label className="text-sm font-medium">Full Name *</Label>
                        <Input value={guestName} onChange={(e) => setGuestName(e.target.value)} placeholder="Your full name" className="mt-1.5" />
                      </div>
                      <div>
                        <Label className="text-sm font-medium">Phone Number *</Label>
                        <Input value={guestPhone} onChange={(e) => setGuestPhone(e.target.value)} placeholder="01XXXXXXXXX" className="mt-1.5" />
                      </div>
                    </div>
                    <div>
                      <Label className="text-sm font-medium">Email (optional)</Label>
                      <Input type="email" value={guestEmail} onChange={(e) => setGuestEmail(e.target.value)} placeholder="your@email.com" className="mt-1.5" />
                    </div>
                    <div>
                      <Label className="text-sm font-medium">Address *</Label>
                      <Textarea value={guestAddress} onChange={(e) => setGuestAddress(e.target.value)} placeholder="House, Road, Area" className="mt-1.5" rows={2} />
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <Label className="text-sm font-medium">City *</Label>
                        <Input value={guestCity} onChange={(e) => setGuestCity(e.target.value)} placeholder="e.g. Dhaka" className="mt-1.5" />
                      </div>
                      <div>
                        <Label className="text-sm font-medium">District</Label>
                        <Input value={guestDistrict} onChange={(e) => setGuestDistrict(e.target.value)} placeholder="e.g. Dhaka" className="mt-1.5" />
                      </div>
                    </div>
                    <div className="pt-2">
                      <p className="text-xs text-muted-foreground">
                        Have an account?{' '}
                        <button className="text-primary underline font-medium" onClick={() => navigate('login')}>
                          Login
                        </button>{' '}
                        for a faster checkout.
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Step 2: Delivery Method */}
            <Card className="shadow-sm border">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <div className="h-8 w-8 rounded-lg bg-blue-500/10 flex items-center justify-center">
                    <Truck className="h-4 w-4 text-blue-500" />
                  </div>
                  Delivery Method
                  <Badge variant="secondary" className="text-[10px] h-5 ml-2">Step 2</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <RadioGroup value={shippingMethod} onValueChange={setShippingMethod}>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <label
                      htmlFor="ship-standard"
                      className={`relative flex items-center gap-4 p-4 rounded-xl border-2 cursor-pointer transition-all duration-200 group ${
                        shippingMethod === 'standard' ? 'border-primary bg-primary/5 shadow-md' : 'border-border bg-background hover:border-primary/30'
                      }`}
                    >
                      <RadioGroupItem value="standard" id="ship-standard" className="sr-only" />
                      <div className="flex-1 min-w-0">
                        <div className="font-semibold text-sm">Regular Delivery</div>
                        <div className="text-xs text-muted-foreground">3-5 business days</div>
                      </div>
                      <div className="text-right">
                        <span className="font-medium text-primary">৳{sub >= freeThreshold ? 0 : standardShipping}</span>
                      </div>
                      {shippingMethod === 'standard' && <CheckCircle2 className="h-5 w-5 text-primary flex-shrink-0 absolute top-2 right-2 opacity-50" />}
                    </label>
                    
                    <label
                      htmlFor="ship-express"
                      className={`relative flex items-center gap-4 p-4 rounded-xl border-2 cursor-pointer transition-all duration-200 group ${
                        shippingMethod === 'express' ? 'border-primary bg-primary/5 shadow-md' : 'border-border bg-background hover:border-primary/30'
                      }`}
                    >
                      <RadioGroupItem value="express" id="ship-express" className="sr-only" />
                      <div className="flex-1 min-w-0">
                        <div className="font-semibold text-sm flex items-center gap-1">Express Delivery <Zap className="h-3 w-3 text-amber-500" fill="currentColor" /></div>
                        <div className="text-xs text-muted-foreground">Next day delivery</div>
                      </div>
                      <div className="text-right">
                        <span className="font-medium text-primary">৳{sub >= freeThreshold ? expressShipping - standardShipping : expressShipping}</span>
                      </div>
                      {shippingMethod === 'express' && <CheckCircle2 className="h-5 w-5 text-primary flex-shrink-0 absolute top-2 right-2 opacity-50" />}
                    </label>
                  </div>
                </RadioGroup>
              </CardContent>
            </Card>

            {/* Step 3: Payment Method */}
            <Card className="shadow-sm border">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <div className="h-8 w-8 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                    <Wallet className="h-4 w-4 text-emerald-600" />
                  </div>
                  Payment Method
                  <Badge variant="secondary" className="text-[10px] h-5 ml-2">Step 3</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod} className="space-y-4">
                  {/* COD Option */}
                  <label
                    htmlFor="pay-cod"
                    className={`relative flex items-center gap-4 p-4 rounded-xl border-2 cursor-pointer transition-all duration-200 group ${
                      paymentMethod === 'cod' ? 'border-primary bg-primary/5 shadow-md' : 'border-border bg-background hover:border-primary/30'
                    }`}
                  >
                    <RadioGroupItem value="cod" id="pay-cod" className="sr-only" />
                    <div className={`h-11 w-11 rounded-xl bg-gradient-to-br from-emerald-500 to-green-600 flex items-center justify-center flex-shrink-0 shadow-sm`}>
                      <Banknote className="h-5 w-5 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-sm">Cash on Delivery</div>
                      <div className="text-xs text-muted-foreground">Pay when you receive the product</div>
                    </div>
                    {paymentMethod === 'cod' && <CheckCircle2 className="h-5 w-5 text-primary flex-shrink-0" />}
                  </label>

                  {/* Online Payment Option */}
                  <label
                    htmlFor="pay-online"
                    className={`relative flex flex-col gap-3 p-4 rounded-xl border-2 cursor-pointer transition-all duration-200 group ${
                      paymentMethod === 'online' ? 'border-primary bg-primary/5 shadow-md' : 'border-border bg-background hover:border-primary/30'
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <RadioGroupItem value="online" id="pay-online" className="sr-only" />
                      <div className={`h-11 w-11 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center flex-shrink-0 shadow-sm`}>
                        <CreditCard className="h-5 w-5 text-white" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-semibold text-sm">Online Payment</div>
                        <div className="text-xs text-muted-foreground">Pay securely via SSLCommerz</div>
                      </div>
                      {paymentMethod === 'online' && <CheckCircle2 className="h-5 w-5 text-primary flex-shrink-0" />}
                    </div>
                    
                    {/* Supported methods icons */}
                    <div className="ml-[60px] flex flex-wrap gap-2 items-center">
                      <Badge variant="outline" className="bg-white text-pink-600 border-pink-200">bKash</Badge>
                      <Badge variant="outline" className="bg-white text-orange-600 border-orange-200">Nagad</Badge>
                      <Badge variant="outline" className="bg-white text-purple-600 border-purple-200">Rocket</Badge>
                      <Badge variant="outline" className="bg-white text-blue-600 border-blue-200">Visa</Badge>
                      <Badge variant="outline" className="bg-white text-red-600 border-red-200">Mastercard</Badge>
                    </div>
                  </label>
                </RadioGroup>
              </CardContent>
            </Card>

            {/* Gift Wrapping + Order Note */}
            <Card className="shadow-sm border">
              <CardContent className="p-6 space-y-5">
                <div className="flex items-center justify-between p-4 rounded-xl bg-gradient-to-r from-secondary/5 to-secondary/10 border border-secondary/20 cursor-pointer" onClick={() => setGiftWrap(!giftWrap)}>
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-lg bg-secondary/20 flex items-center justify-center">
                      <Gift className="h-5 w-5 text-secondary" />
                    </div>
                    <div>
                      <div className="font-medium text-sm">Gift Wrapping</div>
                      <div className="text-xs text-muted-foreground">Add special gift wrapping for ৳50</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge variant="outline" className="text-secondary border-secondary/30 bg-white">+৳50</Badge>
                    <Checkbox checked={giftWrap} onCheckedChange={(checked) => setGiftWrap(checked === true)} />
                  </div>
                </div>

                <div>
                  <Label className="text-sm font-medium">Order Note (optional)</Label>
                  <Textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="Any special instructions for delivery..." className="mt-1.5 resize-none bg-muted/20" rows={2} />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Step 4: Order Summary Sidebar */}
          <div className="space-y-4">
            <Card className="sticky top-4 shadow-lg border">
              <CardHeader className="pb-3 bg-gradient-to-r from-primary/5 to-transparent rounded-t-lg">
                <CardTitle className="text-lg flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Package className="h-5 w-5 text-primary" />
                    Review Order
                  </span>
                  <Badge variant="secondary" className="text-[10px] h-5">Step 4</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Items */}
                <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                  {cartItems.map((item) => (
                    <div key={item.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted/30 transition-colors">
                      <div className="h-12 w-12 rounded-lg bg-muted/50 flex-shrink-0 overflow-hidden border">
                        <img src={item.image} alt={item.productName} className="h-full w-full object-cover" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{item.productName}</p>
                        <p className="text-xs text-muted-foreground">Qty: {item.quantity}</p>
                      </div>
                      <span className="font-medium text-sm whitespace-nowrap">
                        ৳{((item.discountPrice != null ? item.discountPrice : item.price) * item.quantity).toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>

                <Separator />

                {/* Coupon */}
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Coupon Code</Label>
                  {couponApplied ? (
                    <div className="flex items-center justify-between p-2.5 rounded-lg bg-emerald-50 border border-emerald-200">
                      <div className="flex items-center gap-2">
                        <Badge className="text-sm bg-emerald-100 text-emerald-800 border-emerald-200">
                          <Gift className="h-3 w-3 mr-1" />
                          {couponCode}
                        </Badge>
                      </div>
                      <Button variant="ghost" size="sm" onClick={() => { setCouponCode(''); setDiscount(0); setCouponApplied(false) }} className="text-red-500 h-7 text-xs">
                        Remove
                      </Button>
                    </div>
                  ) : (
                    <div className="flex gap-2">
                      <Input
                        placeholder="Enter coupon code"
                        value={couponCode}
                        onChange={(e) => { setCouponCode(e.target.value); if (couponApplied) { setDiscount(0); setCouponApplied(false) } }}
                        className="h-9 text-sm bg-muted/20"
                        disabled={couponApplied}
                      />
                      <Button variant="outline" size="sm" onClick={handleApplyCoupon} className="h-9">Apply</Button>
                    </div>
                  )}
                </div>

                <Separator />

                {/* Totals */}
                <div className="space-y-2.5">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Products Total ({totalItems()} items)</span>
                    <span className="font-medium">৳{sub.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Delivery Charge</span>
                    <span className={`font-medium ${shipping === 0 ? 'text-emerald-600' : ''}`}>
                      {shipping === 0 ? '✓ Free' : `৳${shipping}`}
                    </span>
                  </div>
                  {giftWrap && (
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Gift Wrapping</span>
                      <span className="font-medium">৳50</span>
                    </div>
                  )}
                  {discount > 0 && (
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Coupon Discount</span>
                      <span className="text-emerald-600 font-medium">-৳{discount.toLocaleString()}</span>
                    </div>
                  )}
                  <Separator />
                  <div className="flex justify-between font-bold text-lg">
                    <span>Grand Total</span>
                    <span className="text-primary">৳{Math.max(0, total).toLocaleString()}</span>
                  </div>
                </div>

                <Button
                  className="w-full h-12 rounded-xl text-base font-semibold shadow-md shadow-primary/20 mt-4"
                  size="lg"
                  onClick={() => {
                    setCurrentStep(4)
                    handlePlaceOrder()
                  }}
                  disabled={placing}
                >
                  {placing ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      {paymentMethod === 'online' ? 'Redirecting...' : 'Placing Order...'}
                    </>
                  ) : (
                    <>
                      {paymentMethod === 'online' ? 'Pay & Place Order' : 'Place Order'}
                      <ChevronRight className="h-4 w-4 ml-1" />
                    </>
                  )}
                </Button>

                <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground pt-1">
                  <Lock className="h-3.5 w-3.5" />
                  <span>Secure 256-bit SSL Encrypted Checkout</span>
                </div>
              </CardContent>
            </Card>

            {/* Trust Badges */}
            <Card className="shadow-sm border bg-gradient-to-r from-primary/5 to-secondary/5">
              <CardContent className="p-4">
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { icon: Lock, label: 'Secure SSL', desc: 'Encrypted' },
                    { icon: RefreshCw, label: 'Money Back', desc: 'Guaranteed' },
                    { icon: ShieldCheck, label: '100% Safe', desc: 'Payments' },
                  ].map((item, idx) => (
                    <div key={idx} className="flex flex-col items-center gap-1.5 p-2 rounded-lg bg-background/50 text-center">
                      <item.icon className="h-5 w-5 text-primary" />
                      <span className="text-[11px] font-semibold leading-tight">{item.label}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
