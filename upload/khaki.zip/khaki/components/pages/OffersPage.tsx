'use client'

import { useEffect, useState, useCallback } from 'react'
import {
  Tag,
  Percent,
  Clock,
  Copy,
  Check,
  Zap,
  Star,
  Gift,
  CalendarClock,
  Share2,
  MessageCircle,
  Facebook,
  ArrowRight,
  Timer,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Separator } from '@/components/ui/separator'
import { useAppStore } from '@/lib/store'
import { extractItems } from '@/lib/api'
import ProductCard from '@/components/shared/ProductCard'
import { toast } from 'sonner'

interface Product {
  id: string
  name: string
  slug: string
  price: number
  discountPrice?: number | null
  unit: string
  stock: number
  images?: Array<{ url: string; alt?: string }>
  category?: { name: string; slug: string }
  status?: string
  isNewArrival?: boolean
  isBestSeller?: boolean
  shortDescription?: string
}

interface Coupon {
  id: string
  code: string
  type: string
  value: number
  minOrder?: number
  maxDiscount?: number
  validFrom: string
  validTo: string
  isActive: boolean
}

interface Category {
  id: string
  name: string
  slug: string
}

// Flash sale countdown timer
function CountdownTimer({ targetDate }: { targetDate: Date }) {
  const [timeLeft, setTimeLeft] = useState({ hours: 0, minutes: 0, seconds: 0 })

  useEffect(() => {
    const update = () => {
      const diff = Math.max(targetDate.getTime() - Date.now(), 0)
      setTimeLeft({
        hours: Math.floor(diff / (1000 * 60 * 60)),
        minutes: Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60)),
        seconds: Math.floor((diff % (1000 * 60)) / 1000),
      })
    }
    update()
    const timer = setInterval(update, 1000)
    return () => clearInterval(timer)
  }, [targetDate])

  const pad = (n: number) => n.toString().padStart(2, '0')

  return (
    <div className="flex items-center gap-1.5">
      <div className="bg-red-600 text-white rounded-md px-2 py-1 min-w-[32px] text-center font-bold text-base tabular-nums">
        {pad(timeLeft.hours)}
      </div>
      <span className="text-red-600 font-bold">:</span>
      <div className="bg-red-600 text-white rounded-md px-2 py-1 min-w-[32px] text-center font-bold text-base tabular-nums">
        {pad(timeLeft.minutes)}
      </div>
      <span className="text-red-600 font-bold">:</span>
      <div className="bg-red-600 text-white rounded-md px-2 py-1 min-w-[32px] text-center font-bold text-base tabular-nums">
        {pad(timeLeft.seconds)}
      </div>
    </div>
  )
}

export default function OffersPage() {
  const { navigate } = useAppStore()
  const [discountProducts, setDiscountProducts] = useState<Product[]>([])
  const [allProducts, setAllProducts] = useState<Product[]>([])
  const [coupons, setCoupons] = useState<Coupon[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)
  const [copiedCode, setCopiedCode] = useState<string | null>(null)
  const [activeCategoryTab, setActiveCategoryTab] = useState('all')
  const [dealOfTheDay, setDealOfTheDay] = useState<Product | null>(null)

  // Flash sale end time = end of today
  const flashSaleEnd = new Date()
  flashSaleEnd.setHours(23, 59, 59, 999)

  useEffect(() => {
    Promise.all([
      fetch('/api/products?status=active&limit=30').then((r) => r.json()).catch(() => []),
      fetch('/api/coupons?isActive=true').then((r) => r.json()).catch(() => []),
      fetch('/api/categories?isActive=true&limit=20').then((r) => r.json()).catch(() => []),
    ])
      .then(([productData, couponData, categoryData]) => {
        const prods = extractItems<Product>(productData)
        setAllProducts(prods)
        const discounted = prods.filter(
          (p: Product) => p.discountPrice != null && p.discountPrice < p.price
        )
        setDiscountProducts(discounted)

        // Deal of the Day: highest discount
        if (discounted.length > 0) {
          const best = discounted.reduce((best: Product, p: Product) => {
            const bestDiscount = ((best.price - (best.discountPrice ?? best.price)) / best.price) * 100
            const pDiscount = ((p.price - (p.discountPrice ?? p.price)) / p.price) * 100
            return pDiscount > bestDiscount ? p : best
          })
          setDealOfTheDay(best)
        }

        setCoupons(extractItems<Coupon>(couponData))
        setCategories(extractItems<Category>(categoryData))
      })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  const handleCopyCode = useCallback((code: string) => {
    navigator.clipboard.writeText(code)
    setCopiedCode(code)
    toast.success(`Coupon code "${code}" copied!`)
    setTimeout(() => setCopiedCode(null), 2000)
  }, [])

  const handleShare = useCallback((platform: string, coupon: Coupon) => {
    const text = `Get ${coupon.type === 'percentage' ? `${coupon.value}% off` : `৳${coupon.value} off`} on Khati Khadyo! Use code: ${coupon.code}`
    const url = typeof window !== 'undefined' ? window.location.href : ''

    if (platform === 'whatsapp') {
      window.open(`https://wa.me/?text=${encodeURIComponent(text + ' ' + url)}`)
    } else if (platform === 'facebook') {
      window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`)
    }
  }, [])

  // Filter products by category
  const filteredProducts = activeCategoryTab === 'all'
    ? discountProducts
    : discountProducts.filter((p) => p.category?.slug === activeCategoryTab)

  // Upcoming coupons (not yet active)
  const now = new Date()
  const upcomingCoupons = coupons.filter((c) => new Date(c.validFrom) > now)
  const activeCoupons = coupons.filter((c) => new Date(c.validFrom) <= now && new Date(c.validTo) >= now)

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <div className="bg-amber-50 py-12">
        <div className="container mx-auto px-4 text-center">
          <Tag className="h-12 w-12 text-amber-500 mx-auto mb-4" />
          <h1 className="text-3xl md:text-4xl font-bold mb-3">Special Offers</h1>
          <p className="text-lg text-muted-foreground">Grab the best deals on authentic Bangladeshi food products</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* ── Flash Sale with Countdown ── */}
        {discountProducts.length > 0 && (
          <section className="mb-10">
            <div className="relative rounded-2xl overflow-hidden bg-gradient-to-r from-red-600 via-red-500 to-red-600 text-white p-6 sm:p-8">
              <div className="absolute inset-0 opacity-10">
                <div className="absolute top-0 left-0 w-32 h-32 bg-white rounded-full -translate-x-1/2 -translate-y-1/2" />
                <div className="absolute bottom-0 right-0 w-40 h-40 bg-white rounded-full translate-x-1/3 translate-y-1/3" />
              </div>
              <div className="relative z-10">
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-6">
                  <div className="flex items-center gap-3">
                    <Zap className="h-7 w-7 text-yellow-300 animate-pulse" />
                    <h2 className="text-2xl md:text-3xl font-bold">Flash Sale</h2>
                    <Badge className="bg-yellow-400 text-red-700 font-bold text-xs px-2.5 py-0.5">
                      LIVE
                    </Badge>
                  </div>
                  <div className="flex items-center gap-3">
                    <Timer className="h-4 w-4 text-white/80" />
                    <span className="text-sm text-white/80">Ends in:</span>
                    <CountdownTimer targetDate={flashSaleEnd} />
                  </div>
                </div>
                <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide snap-x snap-mandatory">
                  {discountProducts.slice(0, 6).map((product) => (
                    <div key={product.id} className="min-w-[200px] sm:min-w-[220px] snap-start">
                      <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3 hover:bg-white/20 transition-colors">
                        <ProductCard product={product} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </section>
        )}

        {/* ── Deal of the Day ── */}
        {dealOfTheDay && (
          <section className="mb-10">
            <Card className="border-2 border-primary/20 overflow-hidden">
              <div className="grid md:grid-cols-2 gap-0">
                <div className="bg-gradient-to-br from-primary/10 to-primary/5 p-6 sm:p-8 flex flex-col items-center justify-center">
                  <Badge className="bg-secondary text-white mb-4">
                    <Star className="size-3 mr-1 fill-current" /> Deal of the Day
                  </Badge>
                  <h3 className="text-xl sm:text-2xl font-bold text-center mb-2">{dealOfTheDay.name}</h3>
                  {dealOfTheDay.shortDescription && (
                    <p className="text-sm text-muted-foreground text-center mb-4">{dealOfTheDay.shortDescription}</p>
                  )}
                  <div className="flex items-baseline gap-3 mb-4">
                    <span className="text-3xl font-bold text-primary">
                      ৳{(dealOfTheDay.discountPrice ?? dealOfTheDay.price).toLocaleString()}
                    </span>
                    {dealOfTheDay.discountPrice && (
                      <span className="text-lg text-muted-foreground line-through">
                        ৳{dealOfTheDay.price.toLocaleString()}
                      </span>
                    )}
                    {dealOfTheDay.discountPrice && (
                      <Badge className="bg-red-100 text-red-700">
                        -{Math.round(((dealOfTheDay.price - dealOfTheDay.discountPrice) / dealOfTheDay.price) * 100)}%
                      </Badge>
                    )}
                  </div>
                  <Button
                    size="lg"
                    className="gap-2"
                    onClick={() => navigate('product-detail', { id: dealOfTheDay.id })}
                  >
                    Shop Now <ArrowRight className="size-4" />
                  </Button>
                </div>
                <div className="p-6 sm:p-8 bg-gradient-to-br from-secondary/5 to-secondary/10 flex items-center justify-center">
                  <div className="text-center">
                    <div className="text-6xl sm:text-7xl mb-3">🔥</div>
                    <p className="font-semibold text-lg">Limited Time Offer</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Don&apos;t miss out on this amazing deal
                    </p>
                    <div className="flex items-center justify-center gap-2 mt-3 text-sm text-muted-foreground">
                      <Clock className="size-4" />
                      <span>Offer valid today only</span>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </section>
        )}

        {/* ── Coupon Cards with Copy Code ── */}
        {activeCoupons.length > 0 && (
          <section className="mb-10">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
              <Percent className="h-6 w-6 text-primary" />
              Active Coupons
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {activeCoupons.map((coupon) => (
                <Card key={coupon.id} className="border-dashed border-2 border-primary/30 hover:border-primary/60 transition-colors relative overflow-hidden">
                  {/* Decorative cutout circles */}
                  <div className="absolute -left-3 top-1/2 -translate-y-1/2 size-6 rounded-full bg-background border border-primary/20" />
                  <div className="absolute -right-3 top-1/2 -translate-y-1/2 size-6 rounded-full bg-background border border-primary/20" />
                  <CardContent className="p-4 sm:p-6">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <Gift className="size-5 text-primary" />
                        <Badge className="bg-primary text-primary-foreground font-mono text-sm px-3 py-1">
                          {coupon.code}
                        </Badge>
                      </div>
                      <span className="font-bold text-primary text-xl">
                        {coupon.type === 'percentage' ? `${coupon.value}%` : `৳${coupon.value}`}
                      </span>
                    </div>
                    <div className="space-y-1 text-xs text-muted-foreground mb-3">
                      {coupon.minOrder && (
                        <p>Min. order ৳{coupon.minOrder.toLocaleString()}</p>
                      )}
                      {coupon.maxDiscount && coupon.type === 'percentage' && (
                        <p>Max discount ৳{coupon.maxDiscount.toLocaleString()}</p>
                      )}
                      <p>Valid until {new Date(coupon.validTo).toLocaleDateString()}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="flex-1 gap-1.5 text-xs"
                        onClick={() => handleCopyCode(coupon.code)}
                      >
                        {copiedCode === coupon.code ? (
                          <><Check className="size-3.5 text-emerald-600" /> Copied!</>
                        ) : (
                          <><Copy className="size-3.5" /> Copy Code</>
                        )}
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="size-8 p-0 text-emerald-600"
                        onClick={() => handleShare('whatsapp', coupon)}
                        aria-label="Share on WhatsApp"
                      >
                        <MessageCircle className="size-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="size-8 p-0"
                        onClick={() => handleShare('facebook', coupon)}
                        aria-label="Share on Facebook"
                      >
                        <Facebook className="size-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>
        )}

        {/* ── Category-wise Offers Tabs ── */}
        <section className="mb-10">
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <Tag className="h-6 w-6 text-primary" />
            Products on Sale
          </h2>
          {categories.length > 1 && (
            <Tabs value={activeCategoryTab} onValueChange={setActiveCategoryTab} className="mb-6">
              <TabsList className="flex-wrap h-auto gap-1">
                <TabsTrigger value="all">All</TabsTrigger>
                {categories.slice(0, 8).map((cat) => (
                  <TabsTrigger key={cat.id} value={cat.slug}>
                    {cat.name}
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>
          )}

          {loading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {Array.from({ length: 8 }).map((_, i) => (
                <Skeleton key={i} className="h-72 rounded-lg" />
              ))}
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="text-center py-16">
              <Tag className="h-16 w-16 text-muted-foreground/20 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">No Offers Available</h3>
              <p className="text-muted-foreground mb-4">
                {activeCategoryTab !== 'all'
                  ? 'No discounted products in this category. Try another category!'
                  : 'Check back later for exciting deals'}
              </p>
              <div className="flex items-center justify-center gap-3">
                <Button onClick={() => setActiveCategoryTab('all')} variant="outline">
                  View All Categories
                </Button>
                <Button onClick={() => navigate('products')}>Browse All Products</Button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {filteredProducts.map((product) => {
                const discountPercent = product.discountPrice
                  ? Math.round(((product.price - product.discountPrice) / product.price) * 100)
                  : 0
                return (
                  <div key={product.id} className="relative">
                    {discountPercent > 0 && (
                      <Badge className="absolute top-2 left-2 z-10 bg-red-500 text-white text-xs">
                        -{discountPercent}%
                      </Badge>
                    )}
                    <ProductCard product={product} />
                  </div>
                )
              })}
            </div>
          )}
        </section>

        {/* ── Upcoming Offers ── */}
        {upcomingCoupons.length > 0 && (
          <section className="mb-10">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
              <CalendarClock className="h-6 w-6 text-amber-600" />
              Upcoming Offers
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {upcomingCoupons.map((coupon) => (
                <Card key={coupon.id} className="border-amber-200 bg-amber-50/50 opacity-90">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <CalendarClock className="size-4 text-amber-600" />
                      <Badge variant="secondary" className="bg-amber-100 text-amber-700 text-xs">
                        Coming Soon
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between mb-2">
                      <Badge className="font-mono bg-amber-600 text-white">{coupon.code}</Badge>
                      <span className="font-bold text-amber-700 text-lg">
                        {coupon.type === 'percentage' ? `${coupon.value}%` : `৳${coupon.value}`}
                      </span>
                    </div>
                    {coupon.minOrder && (
                      <p className="text-xs text-muted-foreground">
                        Min. order ৳{coupon.minOrder.toLocaleString()}
                      </p>
                    )}
                    <p className="text-xs text-amber-600 font-medium mt-1">
                      Starts {new Date(coupon.validFrom).toLocaleDateString()}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Valid until {new Date(coupon.validTo).toLocaleDateString()}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  )
}
