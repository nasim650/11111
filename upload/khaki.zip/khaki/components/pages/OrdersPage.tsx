'use client'

import { useEffect, useState, useMemo } from 'react'
import {
  Package, Eye, ChevronRight, Search, Truck, RotateCcw,
  MapPin, CheckCircle2, Clock, XCircle, AlertCircle, PackageCheck
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Input } from '@/components/ui/input'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useAppStore, type CartItem } from '@/lib/store'
import { extractItems } from '@/lib/api'
import { toast } from 'sonner'

interface Order {
  id: string
  orderNumber: string
  totalAmount: number
  orderStatus: string
  paymentStatus: string
  paymentMethod: string
  createdAt: string
  deliveryCharge?: number
  discountAmount?: number
  items?: Array<{
    productName: string
    quantity: number
    price: number
    image?: string
  }>
}

const statusConfig: Record<string, {
  color: string
  bg: string
  icon: typeof Package
  label: string
}> = {
  pending: { color: 'text-amber-700', bg: 'bg-amber-50 border-amber-200', icon: Clock, label: 'Pending' },
  confirmed: { color: 'text-teal-700', bg: 'bg-teal-50 border-teal-200', icon: CheckCircle2, label: 'Confirmed' },
  processing: { color: 'text-orange-700', bg: 'bg-orange-50 border-orange-200', icon: Package, label: 'Processing' },
  shipped: { color: 'text-purple-700', bg: 'bg-purple-50 border-purple-200', icon: Truck, label: 'Shipped' },
  delivered: { color: 'text-emerald-700', bg: 'bg-emerald-50 border-emerald-200', icon: PackageCheck, label: 'Delivered' },
  cancelled: { color: 'text-red-700', bg: 'bg-red-50 border-red-200', icon: XCircle, label: 'Cancelled' },
  refunded: { color: 'text-gray-700', bg: 'bg-gray-50 border-gray-200', icon: RotateCcw, label: 'Refunded' },
}

const statusSteps = ['pending', 'confirmed', 'processing', 'shipped', 'delivered']

function OrderTimeline({ status }: { status: string }) {
  const currentIdx = statusSteps.indexOf(status)
  const isCancelled = status === 'cancelled'

  return (
    <div className="flex items-center gap-1 my-3">
      {statusSteps.map((step, idx) => {
        const isCompleted = !isCancelled && idx <= currentIdx
        const isCurrent = !isCancelled && idx === currentIdx
        const StatusIcon = statusConfig[step]?.icon || Package

        return (
          <div key={step} className="flex items-center flex-1">
            <div className="flex flex-col items-center flex-1">
              <div
                className={`h-7 w-7 rounded-full flex items-center justify-center transition-all duration-300 ${
                  isCancelled
                    ? 'bg-red-100 text-red-400'
                    : isCompleted
                      ? 'bg-primary text-white shadow-sm'
                      : 'bg-muted text-muted-foreground'
                } ${isCurrent ? 'ring-2 ring-primary/30 ring-offset-1' : ''}`}
              >
                {isCompleted ? (
                  <CheckCircle2 className="h-3.5 w-3.5" />
                ) : (
                  <StatusIcon className="h-3.5 w-3.5" />
                )}
              </div>
              <span className={`text-[10px] mt-1 ${isCompleted ? 'text-primary font-medium' : 'text-muted-foreground'}`}>
                {statusConfig[step]?.label || step}
              </span>
            </div>
            {idx < statusSteps.length - 1 && (
              <div className={`h-0.5 w-full -mt-4 ${
                !isCancelled && idx < currentIdx ? 'bg-primary' : 'bg-muted'
              }`} />
            )}
          </div>
        )
      })}
    </div>
  )
}

function getEstimatedDelivery(createdAt: string, status: string): string | null {
  if (status === 'delivered' || status === 'cancelled') return null
  const created = new Date(createdAt)
  const est = new Date(created.getTime() + 5 * 24 * 60 * 60 * 1000) // 5 days from order
  return est.toLocaleDateString('en-BD', { month: 'short', day: 'numeric' })
}

export default function OrdersPage() {
  const { navigate, isAuthenticated, user, addToCart } = useAppStore()
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [activeTab, setActiveTab] = useState('all')

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('login')
      return
    }
    if (user?.id) {
      fetch(`/api/orders?userId=${user.id}`)
        .then((r) => r.json())
        .then((data) => {
          const ords = extractItems<Order>(data)
          setOrders(ords)
        })
        .catch(() => {})
        .finally(() => setLoading(false))
    }
  }, [isAuthenticated, user?.id, navigate])

  const filteredOrders = useMemo(() => {
    let filtered = orders

    // Filter by tab
    if (activeTab !== 'all') {
      filtered = filtered.filter((o) => o.orderStatus === activeTab)
    }

    // Filter by search
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase()
      filtered = filtered.filter(
        (o) =>
          o.orderNumber.toLowerCase().includes(q) ||
          o.items?.some((i) => i.productName.toLowerCase().includes(q))
      )
    }

    return filtered
  }, [orders, activeTab, searchQuery])

  const handleReorder = async (order: Order) => {
    if (!order.items?.length) return
    let added = 0
    for (const item of order.items) {
      try {
        const cartItem: Omit<CartItem, 'id'> = {
          productId: `reorder-${Date.now()}`,
          productName: item.productName,
          price: item.price,
          quantity: item.quantity,
          unit: 'kg',
          image: item.image || '/placeholder.png',
          stock: 999,
        }
        await addToCart(cartItem)
        added++
      } catch {
        // continue
      }
    }
    toast.success(`${added} item${added !== 1 ? 's' : ''} added to cart`)
  }

  const handleTrack = (orderId: string) => {
    navigate('order-detail', { id: orderId })
  }

  if (!isAuthenticated) return null

  const tabs = [
    { value: 'all', label: 'All Orders' },
    { value: 'processing', label: 'Processing' },
    { value: 'shipped', label: 'Shipped' },
    { value: 'delivered', label: 'Delivered' },
    { value: 'cancelled', label: 'Cancelled' },
  ]

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary/5 via-primary/10 to-primary/5 py-6 border-b">
        <div className="container mx-auto px-4 max-w-4xl">
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Package className="h-6 w-6 text-primary" />
            My Orders
          </h1>
          <p className="text-sm text-muted-foreground mt-1">Track and manage your orders</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6 max-w-4xl">
        {/* Search + Tabs */}
        <div className="space-y-4 mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by order number or product name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 h-10"
            />
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="w-full h-auto flex-wrap gap-1 bg-muted/50 p-1">
              {tabs.map((tab) => {
                const count = tab.value === 'all'
                  ? orders.length
                  : orders.filter((o) => o.orderStatus === tab.value).length
                return (
                  <TabsTrigger
                    key={tab.value}
                    value={tab.value}
                    className="text-xs data-[state=active]:bg-white data-[state=active]:shadow-sm"
                  >
                    {tab.label}
                    {count > 0 && (
                      <Badge variant="secondary" className="ml-1.5 h-5 min-w-[20px] text-[10px] px-1.5">
                        {count}
                      </Badge>
                    )}
                  </TabsTrigger>
                )
              })}
            </TabsList>
          </Tabs>
        </div>

        {loading ? (
          <div className="space-y-4">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-48 rounded-xl" />
            ))}
          </div>
        ) : filteredOrders.length === 0 ? (
          <div className="text-center py-20">
            <div className="h-24 w-24 rounded-full bg-muted/50 flex items-center justify-center mx-auto mb-4">
              <Package className="h-10 w-10 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-semibold mb-2">
              {searchQuery || activeTab !== 'all' ? 'No Orders Found' : 'No Orders Yet'}
            </h3>
            <p className="text-muted-foreground mb-6">
              {searchQuery || activeTab !== 'all'
                ? 'Try adjusting your search or filter criteria'
                : 'Start shopping to see your orders here'}
            </p>
            <Button onClick={() => navigate('products')} className="rounded-full px-6">
              Browse Products
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredOrders.map((order) => {
              const config = statusConfig[order.orderStatus] || statusConfig.pending
              const StatusIcon = config.icon
              const estDelivery = getEstimatedDelivery(order.createdAt, order.orderStatus)

              return (
                <Card
                  key={order.id}
                  className="hover:shadow-lg transition-all duration-300 border-0 shadow-sm overflow-hidden"
                >
                  <CardContent className="p-0">
                    {/* Order header with status */}
                    <div className={`px-5 py-3 border-b ${config.bg} flex items-center justify-between`}>
                      <div className="flex items-center gap-2">
                        <StatusIcon className={`h-4 w-4 ${config.color}`} />
                        <span className={`text-sm font-semibold ${config.color}`}>
                          {config.label}
                        </span>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground">
                        <span>#{order.orderNumber}</span>
                        <span>
                          {new Date(order.createdAt).toLocaleDateString('en-BD', {
                            month: 'short',
                            day: 'numeric',
                            year: 'numeric',
                          })}
                        </span>
                      </div>
                    </div>

                    <div className="p-5">
                      {/* Timeline */}
                      <OrderTimeline status={order.orderStatus} />

                      {/* Items preview */}
                      <div className="flex items-center gap-3 mt-3 mb-3">
                        <div className="flex -space-x-2">
                          {order.items?.slice(0, 4).map((item, idx) => (
                            <div
                              key={idx}
                              className="h-10 w-10 rounded-lg bg-muted/50 border-2 border-white overflow-hidden"
                            >
                              {item.image ? (
                                <img src={item.image} alt={item.productName} className="h-full w-full object-cover" />
                              ) : (
                                <div className="h-full w-full flex items-center justify-center">
                                  <Package className="h-4 w-4 text-muted-foreground" />
                                </div>
                              )}
                            </div>
                          ))}
                          {(order.items?.length || 0) > 4 && (
                            <div className="h-10 w-10 rounded-lg bg-primary/10 border-2 border-white flex items-center justify-center">
                              <span className="text-[10px] font-bold text-primary">
                                +{(order.items?.length || 0) - 4}
                              </span>
                            </div>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">
                            {order.items?.map((i) => i.productName).join(', ') || 'No items'}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {order.items?.length || 0} item{(order.items?.length || 0) !== 1 ? 's' : ''}
                          </p>
                        </div>
                      </div>

                      {/* Estimated delivery */}
                      {estDelivery && (
                        <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-3">
                          <MapPin className="h-3.5 w-3.5" />
                          <span>Estimated delivery: <span className="font-medium text-foreground">{estDelivery}</span></span>
                        </div>
                      )}

                      {/* Bottom row */}
                      <div className="flex items-center justify-between pt-3 border-t">
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="text-[10px] capitalize">
                            {order.paymentMethod}
                          </Badge>
                          <Badge variant="outline" className="text-[10px] capitalize">
                            {order.paymentStatus}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="font-bold text-primary">
                            ৳{(order.totalAmount ?? 0).toLocaleString()}
                          </span>
                          <div className="flex items-center gap-2">
                            {(order.orderStatus === 'shipped' || order.orderStatus === 'processing') && (
                              <Button
                                variant="outline"
                                size="sm"
                                className="h-8 text-xs rounded-lg"
                                onClick={(e) => { e.stopPropagation(); handleTrack(order.id) }}
                              >
                                <Eye className="h-3 w-3 mr-1" />
                                Track
                              </Button>
                            )}
                            {order.orderStatus === 'delivered' && (
                              <Button
                                variant="outline"
                                size="sm"
                                className="h-8 text-xs rounded-lg"
                                onClick={(e) => { e.stopPropagation(); handleReorder(order) }}
                              >
                                <RotateCcw className="h-3 w-3 mr-1" />
                                Reorder
                              </Button>
                            )}
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 text-xs"
                              onClick={() => navigate('order-detail', { id: order.id })}
                            >
                              Details
                              <ChevronRight className="h-3 w-3 ml-0.5" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}
