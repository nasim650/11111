'use client'

import { useEffect, useState } from 'react'
import { CheckCircle2, ArrowRight, Package, Home } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { useAppStore } from '@/lib/store'

export default function OrderConfirmationPage() {
  const { pageParams, navigate, siteConfig } = useAppStore()
  const orderNumber = String(pageParams?.orderNumber || pageParams?.orderId || '')

  return (
    <div className="min-h-screen flex items-center justify-center py-12 px-4">
      <Card className="w-full max-w-lg">
        <CardContent className="p-8 text-center">
          {siteConfig?.logo && (
            <div className="flex justify-center mb-6">
              <img
                src={siteConfig.logo}
                alt="Khati Khadyo"
                className="h-10 w-auto object-contain"
              />
            </div>
          )}

          <div className="h-20 w-20 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 className="h-10 w-10 text-emerald-600" />
          </div>

          <h1 className="text-2xl font-bold mb-2">Order Placed Successfully!</h1>
          <p className="text-muted-foreground mb-6">
            Thank you for your order. We will process it shortly.
          </p>

          {orderNumber && (
            <div className="bg-muted/50 rounded-lg p-4 mb-6">
              <p className="text-sm text-muted-foreground">Order Number</p>
              <p className="text-xl font-bold text-primary">#{orderNumber}</p>
            </div>
          )}

          <div className="space-y-3 text-sm text-muted-foreground mb-8">
            <p>• You will receive a confirmation via email/phone</p>
            <p>• Track your order status from your account</p>
            <p>• For any queries, contact our support team</p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <Button
              variant="outline"
              className="flex-1"
              onClick={() => navigate('orders')}
            >
              <Package className="h-4 w-4 mr-2" />
              View Orders
            </Button>
            <Button
              className="flex-1"
              onClick={() => navigate('home')}
            >
              <Home className="h-4 w-4 mr-2" />
              Continue Shopping
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
