'use client'

import { useEffect, useState, useCallback } from 'react'
import Image from 'next/image'
import {
  ChevronLeft,
  ChevronRight,
  Search,
  ShieldCheck,
  Truck,
  RefreshCw,
  Award,
  Leaf,
  Star,
  Send,
  ArrowRight,
  Sparkles,
  TrendingUp,
  Tag,
  Clock,
  Zap,
  Handshake,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { useAppStore } from '@/lib/store'
import { extractItems } from '@/lib/api'
import ProductCard from '@/components/shared/ProductCard'
import { toast } from 'sonner'

interface Banner {
  id: string
  title: string
  subtitle?: string
  desktopImage?: string
  mobileImage?: string
  ctaText?: string
  ctaLink?: string
  link?: string
  bgColor?: string
  location?: string
}

interface Category {
  id: string
  name: string
  slug: string
  image?: string
  icon?: string
  description?: string
  showInHome?: boolean
  bengaliName?: string
}

interface Product {
  id: string
  name: string
  slug: string
  price: number
  discountPrice?: number | null
  unit: string
  stock: number
  images?: Array<{ url: string; alt?: string }>
  category?: { name: string; slug: string }
  status?: string
  isNewArrival?: boolean
  isBestSeller?: boolean
  shortDescription?: string
}

interface Testimonial {
  id: string
  name: string
  role?: string
  content: string
  rating: number
  image?: string
}

interface HomepageSection {
  id: string
  title: string
  type: string
  subtitle?: string
  description?: string
  content?: string
  image?: string
  bgColor?: string
  layout?: string
  limit?: number
  categoryId?: string
  category?: { id: string; name: string; slug: string; image?: string }
  sortOrder?: number
}

interface Partner {
  id: string
  name: string
  logo?: string
}

interface FeatureContent {
  icon?: string
  title: string
  description: string
}

interface PromoContent {
  title?: string
  description?: string
  ctaText?: string
}

const featureIcons: Record<string, React.ElementType> = {
  'shield-check': ShieldCheck,
  truck: Truck,
  leaf: Leaf,
  award: Award,
  refresh: RefreshCw,
}

function parseSectionContent<T>(content?: string): T | null {
  if (!content) return null
  try {
    return JSON.parse(content) as T
  } catch {
    return null
  }
}

// Bengali category names mapping
const bengaliCategoryNames: Record<string, string> = {
  'Honey & Jaggery': 'মধু ও গুড়',
  'Ghee & Oils': 'ঘি ও তেল',
  'Rice & Grains': 'চাল ও শস্য',
  'Spices & Masala': 'মশলা',
  'Sweets & Snacks': 'মিষ্টি ও স্ন্যাকস',
  'Tea & Beverages': 'চা ও পানীয়',
  'Pickles & Chutney': 'আচার ও চাটনি',
  'Dry Fruits & Nuts': 'শুকনো ফল ও বাদাম',
  'Deshi Gur': 'দেশি গুড়',
  'Organic Products': 'জৈব পণ্য',
  'Special Combos': 'স্পেশাল কম্বো',
}

// ── Flash Sale Countdown ──
function FlashSaleCountdown() {
  const [timeLeft, setTimeLeft] = useState({ hours: 0, minutes: 0, seconds: 0 })

  useEffect(() => {
    const getTargetTime = () => {
      const now = new Date()
      const end = new Date(now)
      end.setHours(23, 59, 59, 999)
      return end.getTime()
    }

    const updateCountdown = () => {
      const target = getTargetTime()
      const now = Date.now()
      const diff = Math.max(target - now, 0)

      setTimeLeft({
        hours: Math.floor(diff / (1000 * 60 * 60)),
        minutes: Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60)),
        seconds: Math.floor((diff % (1000 * 60)) / 1000),
      })
    }

    updateCountdown()
    const timer = setInterval(updateCountdown, 1000)
    return () => clearInterval(timer)
  }, [])

  const pad = (n: number) => n.toString().padStart(2, '0')

  return (
    <div className="flex items-center gap-1.5">
      <div className="bg-red-600 text-white rounded-md px-2 py-1 min-w-[36px] text-center font-bold text-lg tabular-nums">
        {pad(timeLeft.hours)}
      </div>
      <span className="text-red-600 font-bold text-lg">:</span>
      <div className="bg-red-600 text-white rounded-md px-2 py-1 min-w-[36px] text-center font-bold text-lg tabular-nums">
        {pad(timeLeft.minutes)}
      </div>
      <span className="text-red-600 font-bold text-lg">:</span>
      <div className="bg-red-600 text-white rounded-md px-2 py-1 min-w-[36px] text-center font-bold text-lg tabular-nums">
        {pad(timeLeft.seconds)}
      </div>
    </div>
  )
}

// ── Section Heading Component ──
function SectionHeading({ label, labelIcon: LabelIcon, labelColor, title, subtitle }: {
  label: string
  labelIcon: React.ElementType
  labelColor: string
  title: string
  subtitle?: string
}) {
  return (
    <div>
      <div className={`inline-flex items-center gap-2 ${labelColor} mb-1`}>
        <LabelIcon className="h-4 w-4" />
        <span className="text-xs font-semibold uppercase tracking-wider">{label}</span>
        <div className="h-[2px] w-8 bg-current opacity-30" />
      </div>
      <h2 className="text-2xl md:text-3xl font-bold">{title}</h2>
      {subtitle && (
        <p className="text-muted-foreground mt-1">{subtitle}</p>
      )}
    </div>
  )
}

export default function HomePage() {
  const { navigate, setSearchQuery, loadSiteConfig, siteConfig } = useAppStore()
  const [heroBanners, setHeroBanners] = useState<Banner[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [discountProducts, setDiscountProducts] = useState<Product[]>([])
  const [sections, setSections] = useState<HomepageSection[]>([])
  const [sectionProducts, setSectionProducts] = useState<Record<string, Product[]>>({})
  const [testimonials, setTestimonials] = useState<Testimonial[]>([])
  const [partners, setPartners] = useState<Partner[]>([])
  const [currentBanner, setCurrentBanner] = useState(0)
  const [loading, setLoading] = useState(true)
  const [email, setEmail] = useState('')
  const [scrollY, setScrollY] = useState(0)

  useEffect(() => {
    loadSiteConfig()
  }, [loadSiteConfig])

  // Parallax scroll tracking
  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY)
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    const loadAll = async () => {
      setLoading(true)
      try {
        const [
          heroBannersRes,
          catRes,
          discRes,
          sectionsRes,
          testRes,
          partnersRes,
        ] = await Promise.all([
          fetch('/api/banners?status=active&location=hero').catch(() => null),
          fetch('/api/categories').catch(() => null),
          fetch('/api/products?status=active&minPrice=1&sort=discount&limit=8').catch(() => null),
          fetch('/api/homepage-sections?isActive=true').catch(() => null),
          fetch('/api/testimonials').catch(() => null),
          fetch('/api/partners').catch(() => null),
        ])

        if (heroBannersRes?.ok) {
          const data = await heroBannersRes.json()
          setHeroBanners(extractItems<Banner>(data))
        }
        if (catRes?.ok) {
          const data = await catRes.json()
          const cats = extractItems<Category>(data)
          setCategories(cats.filter((c: Category) => c.showInHome !== false))
        }
        if (discRes?.ok) {
          const data = await discRes.json()
          const prods = extractItems<Product>(data)
          setDiscountProducts(
            prods.filter((p: Product) => p.discountPrice != null && p.discountPrice < p.price)
          )
        }
        if (sectionsRes?.ok) {
          const data = await sectionsRes.json()
          const secs = extractItems<HomepageSection>(data)

          // Deduplicate sections by type — keep only the first of each type
          const seenTypes = new Set<string>()
          const uniqueSections = secs
            .sort(
              (a: HomepageSection, b: HomepageSection) =>
                (a.sortOrder ?? 0) - (b.sortOrder ?? 0)
            )
            .filter((s: HomepageSection) => {
              // Allow multiple product_grid sections (they can have different categories)
              // For other types, only keep the first occurrence
              if (s.type === 'product_grid') return true
              if (seenTypes.has(s.type)) return false
              seenTypes.add(s.type)
              return true
            })

          setSections(uniqueSections)

          // Fetch products for product_grid sections
          const productSections = uniqueSections.filter(
            (s: HomepageSection) => s.type === 'product_grid'
          )
          const productMap: Record<string, Product[]> = {}
          await Promise.all(
            productSections.map(async (section: HomepageSection) => {
              try {
                const params = new URLSearchParams({
                  status: 'active',
                  limit: String(section.limit || 8),
                })
                if (section.categoryId) params.set('categoryId', section.categoryId)
                const res = await fetch(`/api/products?${params.toString()}`)
                if (res.ok) {
                  const d = await res.json()
                  productMap[section.id] = extractItems<Product>(d)
                }
              } catch {
                /* skip */
              }
            })
          )
          setSectionProducts(productMap)
        }
        if (testRes?.ok) {
          const data = await testRes.json()
          setTestimonials(extractItems<Testimonial>(data))
        }
        if (partnersRes?.ok) {
          const data = await partnersRes.json()
          setPartners(extractItems<Partner>(data))
        }
      } catch (error) {
        console.error('Failed to load homepage data:', error)
      } finally {
        setLoading(false)
      }
    }
    loadAll()
  }, [])

  // Banner auto-rotate
  useEffect(() => {
    if (heroBanners.length <= 1) return
    const timer = setInterval(() => {
      setCurrentBanner((prev) => (prev + 1) % heroBanners.length)
    }, 5000)
    return () => clearInterval(timer)
  }, [heroBanners.length])

  const handleSearchSubmit = (query: string) => {
    setSearchQuery(query)
    navigate('products')
  }

  const handleNewsletter = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email.trim()) return
    try {
      const res = await fetch('/api/newsletter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      })
      if (res.ok) {
        toast.success('Subscribed successfully!')
        setEmail('')
      } else {
        toast.error('Failed to subscribe')
      }
    } catch {
      toast.error('Failed to subscribe')
    }
  }

  // Horizontal scroll helper for mobile
  const scrollContainer = useCallback((containerId: string, direction: 'left' | 'right') => {
    const container = document.getElementById(containerId)
    if (container) {
      const scrollAmount = 280
      container.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth',
      })
    }
  }, [])

  // Check which section types are present in dynamic sections
  // so we don't render duplicate hardcoded versions
  const hasSectionType = useCallback(
    (type: string) => sections.some((s) => s.type === type),
    [sections]
  )

  if (loading) {
    return (
      <div className="space-y-8 p-4">
        <Skeleton className="h-64 md:h-96 w-full rounded-xl" />
        <Skeleton className="h-12 w-full max-w-md mx-auto" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <Skeleton key={i} className="h-48 rounded-lg" />
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen">
      {/* ── Hero Banner Carousel with Parallax ── */}
      {heroBanners.length > 0 && (
        <div className="relative h-56 sm:h-72 md:h-[420px] lg:h-[500px] overflow-hidden bg-muted">
          <div
            className="flex transition-transform duration-700 ease-in-out h-full"
            style={{ transform: `translateX(-${currentBanner * 100}%)` }}
          >
            {heroBanners.map((banner, idx) => (
              <div key={banner.id} className="min-w-full h-full relative">
                {banner.desktopImage ? (
                  <>
                    <div
                      className="absolute inset-0 w-full h-full"
                      style={{ transform: `translateY(${scrollY * 0.15}px)` }}
                    >
                      <Image
                        src={banner.desktopImage}
                        alt={banner.title}
                        fill
                        className="object-cover scale-110"
                        priority={idx === 0}
                        sizes="100vw"
                      />
                    </div>
                    {/* Gradient overlay */}
                    <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/40 to-transparent" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />
                    {/* Content */}
                    <div className="absolute inset-0 flex items-center">
                      <div className="p-6 md:p-12 lg:p-16 max-w-2xl">
                        <h1 className="text-2xl sm:text-4xl md:text-5xl lg:text-6xl font-extrabold text-white mb-3 leading-tight drop-shadow-lg">
                          {banner.title}
                        </h1>
                        {banner.subtitle && (
                          <p className="text-base sm:text-lg md:text-xl text-white/90 mb-6 drop-shadow">
                            {banner.subtitle}
                          </p>
                        )}
                        {banner.ctaText && (
                          <Button
                            size="lg"
                            className="bg-secondary hover:bg-secondary/90 text-white font-semibold px-8 h-12 text-base shadow-lg hover:shadow-xl transition-all hover:scale-105"
                            onClick={() => {
                              if (banner.ctaLink) {
                                if (banner.ctaLink.startsWith('/')) {
                                  navigate('products')
                                } else {
                                  window.open(banner.ctaLink, '_blank')
                                }
                              } else {
                                navigate('products')
                              }
                            }}
                          >
                            {banner.ctaText}
                            <ArrowRight className="h-5 w-5 ml-2" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </>
                ) : (
                  <div
                    className="w-full h-full flex items-center justify-center"
                    style={{ backgroundColor: banner.bgColor || '#2D6A4F' }}
                  >
                    <div className="text-center text-white px-6">
                      <h1 className="text-2xl sm:text-4xl md:text-5xl font-bold mb-3">
                        {banner.title}
                      </h1>
                      {banner.subtitle && (
                        <p className="text-lg sm:text-xl opacity-90 mb-4">
                          {banner.subtitle}
                        </p>
                      )}
                      {banner.ctaText && (
                        <Button
                          size="lg"
                          className="bg-secondary hover:bg-secondary/90 text-white font-semibold mt-2"
                          onClick={() => {
                            if (banner.ctaLink) {
                              if (banner.ctaLink.startsWith('/')) {
                                navigate('products')
                              } else {
                                window.open(banner.ctaLink, '_blank')
                              }
                            }
                          }}
                        >
                          {banner.ctaText}
                          <ArrowRight className="h-5 w-5 ml-2" />
                        </Button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
          {/* Carousel Controls */}
          {heroBanners.length > 1 && (
            <>
              <button
                className="absolute left-3 md:left-6 top-1/2 -translate-y-1/2 bg-white/20 backdrop-blur-sm hover:bg-white/40 rounded-full p-2 md:p-3 shadow-lg transition-all hover:scale-110"
                onClick={() =>
                  setCurrentBanner(
                    (prev) => (prev - 1 + heroBanners.length) % heroBanners.length
                  )
                }
                aria-label="Previous banner"
              >
                <ChevronLeft className="h-5 w-5 md:h-6 md:w-6 text-white" />
              </button>
              <button
                className="absolute right-3 md:right-6 top-1/2 -translate-y-1/2 bg-white/20 backdrop-blur-sm hover:bg-white/40 rounded-full p-2 md:p-3 shadow-lg transition-all hover:scale-110"
                onClick={() =>
                  setCurrentBanner((prev) => (prev + 1) % heroBanners.length)
                }
                aria-label="Next banner"
              >
                <ChevronRight className="h-5 w-5 md:h-6 md:w-6 text-white" />
              </button>
              {/* Dots */}
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                {heroBanners.map((_, idx) => (
                  <button
                    key={idx}
                    className={`h-2 rounded-full transition-all duration-300 ${
                      idx === currentBanner
                        ? 'w-8 bg-white shadow-md'
                        : 'w-2 bg-white/50 hover:bg-white/70'
                    }`}
                    onClick={() => setCurrentBanner(idx)}
                    aria-label={`Go to slide ${idx + 1}`}
                  />
                ))}
              </div>
            </>
          )}
        </div>
      )}

      {/* ── Search Bar Section ── */}
      <div className="bg-gradient-to-b from-primary/5 to-transparent py-8">
        <div className="container mx-auto px-4 max-w-2xl">
          <form
            onSubmit={(e) => {
              e.preventDefault()
              const form = e.target as HTMLFormElement
              const input = form.querySelector('input') as HTMLInputElement
              if (input.value.trim()) handleSearchSubmit(input.value)
            }}
            className="flex gap-2"
          >
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search for authentic Bangladeshi food products..."
                className="pl-10 h-12 bg-white shadow-sm border-primary/20 focus:border-primary"
              />
            </div>
            <Button type="submit" size="lg" className="h-12 px-6 shadow-sm">
              Search
            </Button>
          </form>
        </div>
      </div>

      {/* ── Category Grid with Bengali Labels & Hover Zoom ── */}
      {categories.length > 0 && (
        <section className="py-12">
          <div className="container mx-auto px-4">
            <div className="text-center mb-10">
              <div className="inline-flex items-center gap-2 text-secondary mb-2">
                <Sparkles className="h-5 w-5" />
                <span className="text-sm font-semibold uppercase tracking-wider">Explore</span>
                <div className="h-[2px] w-8 bg-secondary/30" />
              </div>
              <h2 className="text-2xl md:text-3xl font-bold">Shop by Category</h2>
              <p className="text-muted-foreground mt-2 max-w-md mx-auto">
                Discover our authentic Bangladeshi food categories, sourced directly
                from trusted producers
              </p>
            </div>
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-4 md:gap-6">
              {categories.slice(0, 12).map((cat) => (
                <button
                  key={cat.id}
                  className="group flex flex-col items-center gap-2 p-3 rounded-xl hover:bg-primary/5 transition-all duration-300"
                  onClick={() => navigate('products', { category: cat.slug })}
                >
                  <div className="relative h-20 w-20 md:h-24 md:w-24 rounded-2xl overflow-hidden bg-gradient-to-br from-primary/10 to-primary/5 shadow-md group-hover:shadow-xl group-hover:scale-110 transition-all duration-300 ring-2 ring-transparent group-hover:ring-secondary/50">
                    {cat.image ? (
                      <Image
                        src={cat.image}
                        alt={cat.name}
                        fill
                        className="object-cover transition-transform duration-500 group-hover:scale-125"
                        sizes="96px"
                      />
                    ) : (
                      <div className="flex items-center justify-center h-full text-3xl">
                        🍽️
                      </div>
                    )}
                  </div>
                  <h3 className="font-medium text-sm text-center line-clamp-1 group-hover:text-primary transition-colors">
                    {cat.name}
                  </h3>
                  {bengaliCategoryNames[cat.name] && (
                    <p className="text-[10px] text-muted-foreground/60 text-center -mt-1">
                      {bengaliCategoryNames[cat.name]}
                    </p>
                  )}
                </button>
              ))}
            </div>
            <div className="text-center mt-8">
              <Button
                variant="outline"
                onClick={() => navigate('products')}
                className="gap-2"
              >
                View All Categories
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </section>
      )}

      {/* ── Flash Sale Section ── */}
      {discountProducts.length > 0 && (
        <section className="py-8 bg-gradient-to-r from-red-600 via-red-500 to-red-600 text-white relative overflow-hidden">
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-0 left-0 w-32 h-32 bg-white rounded-full -translate-x-1/2 -translate-y-1/2" />
            <div className="absolute bottom-0 right-0 w-40 h-40 bg-white rounded-full translate-x-1/3 translate-y-1/3" />
          </div>
          <div className="container mx-auto px-4 relative z-10">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-6">
              <div className="flex items-center gap-3">
                <Zap className="h-6 w-6 text-yellow-300 animate-pulse" />
                <h2 className="text-xl md:text-2xl font-bold">Flash Sale</h2>
                <Badge className="bg-yellow-400 text-red-700 font-bold text-xs px-2 py-0.5">
                  LIVE
                </Badge>
              </div>
              <div className="flex items-center gap-3">
                <Clock className="h-4 w-4 text-white/80" />
                <span className="text-sm text-white/80">Ends in:</span>
                <FlashSaleCountdown />
              </div>
              <Button
                variant="secondary"
                size="sm"
                className="bg-white text-red-600 hover:bg-white/90 font-semibold"
                onClick={() => navigate('offers')}
              >
                View All Deals <ArrowRight className="h-4 w-4 ml-1" />
              </Button>
            </div>
            <div
              id="flash-sale-scroll"
              className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide snap-x snap-mandatory"
            >
              {discountProducts.slice(0, 8).map((product) => (
                <div key={product.id} className="min-w-[220px] sm:min-w-[240px] snap-start">
                  <ProductCard product={product} />
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ── Dynamic Homepage Sections (from API) ── */}
      {/* These sections are managed by the admin panel and rendered dynamically.
          Hardcoded sections for New Arrivals, Best Sellers, Quality Promise,
          Customer Reviews, and Testimonials have been removed to avoid duplication. */}
      {sections.map((section) => {
        // ── Product Grid Section ──
        if (section.type === 'product_grid') {
          const products = sectionProducts[section.id] || []
          if (products.length === 0) return null
          return (
            <section
              key={section.id}
              className="py-12"
              style={{ backgroundColor: section.bgColor || undefined }}
            >
              <div className="container mx-auto px-4">
                <div className="flex items-center justify-between mb-8">
                  <SectionHeading
                    label="Featured"
                    labelIcon={TrendingUp}
                    labelColor="text-secondary"
                    title={section.title}
                    subtitle={section.subtitle}
                  />
                  <Button
                    variant="outline"
                    onClick={() => navigate('products', { category: section.categoryId })}
                    className="hidden sm:flex gap-2"
                  >
                    View All <ArrowRight className="h-4 w-4" />
                  </Button>
                </div>
                {/* Desktop: grid, Mobile: horizontal scroll */}
                <div className="hidden sm:grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                  {products.slice(0, section.limit || 8).map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </div>
                <div
                  id={`section-${section.id}-scroll`}
                  className="sm:hidden flex gap-4 overflow-x-auto pb-4 scrollbar-hide snap-x snap-mandatory"
                >
                  {products.slice(0, section.limit || 8).map((product) => (
                    <div key={product.id} className="min-w-[220px] snap-start">
                      <ProductCard product={product} />
                    </div>
                  ))}
                </div>
                <div className="text-center mt-6 sm:hidden">
                  <Button
                    variant="outline"
                    onClick={() => navigate('products', { category: section.categoryId })}
                  >
                    View All <ArrowRight className="h-4 w-4 ml-1" />
                  </Button>
                </div>
              </div>
            </section>
          )
        }

        // ── Banner Section ──
        if (section.type === 'banner') {
          return (
            <section key={section.id} className="py-6">
              <div className="container mx-auto px-4">
                <div className="relative rounded-2xl overflow-hidden h-48 md:h-64 shadow-lg">
                  {section.image ? (
                    <>
                      <Image
                        src={section.image}
                        alt={section.title}
                        fill
                        className="object-cover"
                        sizes="100vw"
                      />
                      <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/30 to-transparent flex items-center">
                        <div className="text-white px-8 md:px-12">
                          <h2 className="text-xl md:text-3xl font-bold mb-2">
                            {section.title}
                          </h2>
                          {section.subtitle && (
                            <p className="text-base md:text-lg opacity-90">
                              {section.subtitle}
                            </p>
                          )}
                        </div>
                      </div>
                    </>
                  ) : (
                    <div
                      className="w-full h-full flex items-center justify-center"
                      style={{ backgroundColor: section.bgColor || '#2D6A4F' }}
                    >
                      <div className="text-white text-center px-6">
                        <h2 className="text-2xl md:text-4xl font-bold mb-2">
                          {section.title}
                        </h2>
                        {section.subtitle && (
                          <p className="text-lg opacity-90">{section.subtitle}</p>
                        )}
                        {section.description && (
                          <p className="text-sm opacity-75 mt-2">{section.description}</p>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </section>
          )
        }

        // ── Category Section ──
        if (section.type === 'category') {
          return (
            <section key={section.id} className="py-12 bg-muted/30">
              <div className="container mx-auto px-4">
                <div className="text-center mb-6">
                  <h2 className="text-2xl md:text-3xl font-bold">{section.title}</h2>
                  {section.subtitle && (
                    <p className="text-muted-foreground mt-1">{section.subtitle}</p>
                  )}
                </div>
                {section.category && (
                  <div className="flex justify-center">
                    <Button
                      onClick={() =>
                        navigate('products', { category: section.category!.slug })
                      }
                      className="bg-secondary hover:bg-secondary/90 text-white"
                    >
                      Browse {section.category.name}{' '}
                      <ArrowRight className="h-4 w-4 ml-1" />
                    </Button>
                  </div>
                )}
              </div>
            </section>
          )
        }

        // ── Testimonial Section ──
        if (section.type === 'testimonial') {
          return (
            <section key={section.id} className="py-12 bg-primary/5">
              <div className="container mx-auto px-4">
                <div className="text-center mb-8">
                  <h2 className="text-2xl md:text-3xl font-bold">{section.title}</h2>
                  {section.subtitle && (
                    <p className="text-muted-foreground mt-1">{section.subtitle}</p>
                  )}
                </div>
                {testimonials.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {testimonials.slice(0, 3).map((t) => (
                      <div
                        key={t.id}
                        className="bg-background rounded-xl border border-border/50 p-6 hover:shadow-lg transition-shadow duration-300"
                      >
                        <div className="flex gap-1 mb-3">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <Star
                              key={i}
                              className={`h-4 w-4 ${
                                i < t.rating
                                  ? 'fill-amber-400 text-amber-400'
                                  : 'text-muted-foreground/30'
                              }`}
                            />
                          ))}
                        </div>
                        <p className="text-sm text-muted-foreground line-clamp-4 mb-4">
                          &ldquo;{t.content}&rdquo;
                        </p>
                        <div className="flex items-center gap-3">
                          <div className="h-10 w-10 rounded-full bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center text-primary font-bold">
                            {t.name.charAt(0)}
                          </div>
                          <div>
                            <p className="font-medium text-sm">{t.name}</p>
                            {t.role && (
                              <p className="text-xs text-muted-foreground">{t.role}</p>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-center text-muted-foreground">No testimonials yet</p>
                )}
              </div>
            </section>
          )
        }

        // ── Features / Quality Promise Section ──
        if (section.type === 'features') {
          const features = parseSectionContent<FeatureContent[]>(section.content) ?? []
          if (features.length === 0) return null
          return (
            <section key={section.id} className="py-12">
              <div className="container mx-auto px-4">
                <div className="text-center mb-8">
                  <h2 className="text-2xl md:text-3xl font-bold">{section.title}</h2>
                  {section.subtitle && (
                    <p className="text-muted-foreground mt-1">{section.subtitle}</p>
                  )}
                </div>
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
                  {features.slice(0, section.limit || features.length).map((feature) => {
                    const FeatureIcon = featureIcons[feature.icon || ''] || ShieldCheck
                    return (
                      <div
                        key={feature.title}
                        className="text-center p-6 rounded-xl border border-border/50 hover:shadow-lg hover:-translate-y-1 transition-all duration-300"
                      >
                        <div className="h-14 w-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                          <FeatureIcon className="h-7 w-7 text-primary" />
                        </div>
                        <h3 className="font-semibold mb-1">{feature.title}</h3>
                        <p className="text-sm text-muted-foreground">{feature.description}</p>
                      </div>
                    )
                  })}
                </div>
              </div>
            </section>
          )
        }

        // ── Promo Section ──
        if (section.type === 'promo') {
          const promo = parseSectionContent<PromoContent>(section.content)
          return (
            <section
              key={section.id}
              className="py-12"
              style={{ backgroundColor: section.bgColor || '#FEF3C7' }}
            >
              <div className="container mx-auto px-4 text-center">
                <div className="inline-flex items-center gap-2 text-secondary mb-2">
                  <Tag className="h-5 w-5" />
                  <span className="text-sm font-bold uppercase tracking-wider">Limited Time</span>
                </div>
                <h2 className="text-2xl md:text-3xl font-bold mb-2">{promo?.title || section.title}</h2>
                {section.subtitle && <p className="text-lg mb-4">{section.subtitle}</p>}
                {(promo?.description || section.description) && (
                  <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                    {promo?.description || section.description}
                  </p>
                )}
                <Button
                  onClick={() => navigate('offers')}
                  size="lg"
                  className="bg-secondary hover:bg-secondary/90 text-white"
                >
                  {promo?.ctaText || 'Shop Offers'} <ArrowRight className="h-4 w-4 ml-1" />
                </Button>
              </div>
            </section>
          )
        }

        // ── Fallback: raw content section ──
        if (section.content) {
          return (
            <section
              key={section.id}
              className="py-12"
              style={{ backgroundColor: section.bgColor || undefined }}
            >
              <div className="container mx-auto px-4">
                <h2 className="text-2xl md:text-3xl font-bold mb-4">{section.title}</h2>
                <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: section.content }} />
              </div>
            </section>
          )
        }

        return null
      })}

      {/* ── Newsletter Section (unique, not duplicated by dynamic sections) ── */}
      {!hasSectionType('newsletter') && (
        <section className="py-16 bg-gradient-to-br from-primary via-primary to-primary/90 text-primary-foreground relative overflow-hidden">
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-0 left-0 w-40 h-40 bg-secondary rounded-full -translate-x-1/2 -translate-y-1/2" />
            <div className="absolute bottom-0 right-0 w-60 h-60 bg-secondary rounded-full translate-x-1/3 translate-y-1/3" />
            <div className="absolute top-1/2 left-1/2 w-32 h-32 bg-white rounded-full -translate-x-1/2 -translate-y-1/2" />
          </div>
          <div className="container mx-auto px-4 text-center relative z-10">
            <div className="inline-flex items-center gap-2 text-secondary mb-3">
              <Send className="h-5 w-5" />
              <span className="text-sm font-semibold uppercase tracking-wider">Newsletter</span>
            </div>
            <h2 className="text-2xl md:text-4xl font-bold mb-2">Stay Updated</h2>
            <p className="opacity-90 mb-8 max-w-lg mx-auto">
              Subscribe to our newsletter for the latest products, offers, and authentic
              Bangladeshi food updates
            </p>
            <form
              onSubmit={handleNewsletter}
              className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto"
            >
              <Input
                placeholder="Enter your email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-white/10 border-white/20 text-white placeholder:text-white/60 h-12 text-base"
              />
              <Button
                type="submit"
                variant="secondary"
                size="lg"
                className="h-12 px-8 font-semibold"
              >
                <Send className="h-4 w-4 mr-2" />
                Subscribe
              </Button>
            </form>
          </div>
        </section>
      )}

      {/* ── Partners / Brands Section ── */}
      <section className="py-12 bg-muted/20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-2 text-muted-foreground mb-2">
              <Handshake className="h-5 w-5" />
              <span className="text-sm font-semibold uppercase tracking-wider">Trusted Partners</span>
              <div className="h-[2px] w-8 bg-muted-foreground/30" />
            </div>
            <h2 className="text-xl md:text-2xl font-bold">Brands We Work With</h2>
          </div>
          <div className="flex items-center justify-center gap-8 md:gap-12 flex-wrap">
            {partners.length > 0 ? (
              partners.map((partner) => (
                <div
                  key={partner.id}
                  className="flex items-center justify-center h-16 w-32 md:h-20 md:w-40 rounded-lg bg-background border border-border/50 p-3 grayscale hover:grayscale-0 opacity-60 hover:opacity-100 transition-all duration-300 hover:shadow-md"
                >
                  {partner.logo ? (
                    <img
                      src={partner.logo}
                      alt={partner.name}
                      className="max-h-full max-w-full object-contain"
                    />
                  ) : (
                    <span className="text-sm font-semibold text-muted-foreground">
                      {partner.name}
                    </span>
                  )}
                </div>
              ))
            ) : null}
          </div>
        </div>
      </section>
    </div>
  )
}
