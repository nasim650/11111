'use client'

import React, { useEffect, useState, useCallback } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { Skeleton } from '@/components/ui/skeleton'
import { toast } from 'sonner'
import { extractItems } from '@/lib/api'
import { Plus, Pencil, Trash2, MessageSquareQuote, Star, Upload } from 'lucide-react'

interface Testimonial {
  id: string
  name: string
  role?: string
  company?: string
  content: string
  rating: number
  image?: string
  isActive: boolean
  sortOrder: number
  createdAt: string
}

const emptyTestimonial: Partial<Testimonial> = {
  name: '',
  role: '',
  company: '',
  content: '',
  rating: 5,
  image: '',
  isActive: true,
  sortOrder: 0,
}

export default function AdminTestimonialsPage() {
  const [items, setItems] = useState<Testimonial[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editing, setEditing] = useState<Partial<Testimonial> | null>(null)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)

  const fetchItems = useCallback(async () => {
    try {
      const res = await fetch('/api/testimonials')
      if (res.ok) {
        const data = await res.json()
        setItems(extractItems(data))
      }
    } catch {
      toast.error('Failed to fetch testimonials')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { fetchItems() }, [fetchItems])

  function openCreate() { setEditing({ ...emptyTestimonial }); setDialogOpen(true) }
  function openEdit(t: Testimonial) { setEditing({ ...t }); setDialogOpen(true) }

  async function handleSave() {
    if (!editing?.name || !editing?.content) { toast.error('Name and content are required'); return }
    setSaving(true)
    try {
      const payload = { ...editing, sortOrder: Number(editing.sortOrder) || 0, rating: Number(editing.rating) || 5 }
      const isEdit = !!editing.id
      const url = isEdit ? `/api/testimonials/${editing.id}` : '/api/testimonials'
      const method = isEdit ? 'PUT' : 'POST'
      const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
      if (!res.ok) { const data = await res.json(); throw new Error(data.error || 'Failed to save') }
      toast.success(isEdit ? 'Testimonial updated' : 'Testimonial created')
      setDialogOpen(false); fetchItems()
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed to save') } finally { setSaving(false) }
  }

  async function handleDelete() {
    if (!deleteId) return
    try {
      const res = await fetch(`/api/testimonials/${deleteId}`, { method: 'DELETE' })
      if (!res.ok) throw new Error('Failed to delete')
      toast.success('Testimonial deleted'); fetchItems()
    } catch { toast.error('Failed to delete') } finally { setDeleteId(null) }
  }

  async function handleImageUpload() {
    const input = document.createElement('input'); input.type = 'file'; input.accept = 'image/*'
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0]; if (!file) return
      const formData = new FormData(); formData.append('files', file)
      try {
        const res = await fetch('/api/uploads', { method: 'POST', body: formData })
        if (!res.ok) throw new Error('Upload failed')
        const data = await res.json(); const files = data.files ?? data ?? []
        if (files.length > 0) setEditing((prev) => ({ ...prev, image: files[0].url }) as Partial<Testimonial>)
      } catch { toast.error('Image upload failed') }
    }
    input.click()
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Testimonials</CardTitle>
          <Button onClick={openCreate} className="gap-2"><Plus className="size-4" /> Add Testimonial</Button>
        </CardHeader>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-6 space-y-3">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}</div>
          ) : items.length === 0 ? (
            <div className="text-center py-12">
              <MessageSquareQuote className="mx-auto size-10 text-muted-foreground mb-2" />
              <p className="text-muted-foreground">No testimonials yet</p>
              <Button variant="outline" size="sm" className="mt-2" onClick={openCreate}>Add your first testimonial</Button>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Content</TableHead>
                  <TableHead>Rating</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Sort</TableHead>
                  <TableHead className="w-10" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.map((t) => (
                  <TableRow key={t.id}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {t.image ? <img src={t.image} alt={t.name} className="size-8 rounded-full object-cover" /> : <div className="size-8 rounded-full bg-muted flex items-center justify-center text-xs">{t.name.charAt(0)}</div>}
                        <div><p className="font-medium text-sm">{t.name}</p><p className="text-xs text-muted-foreground">{t.role}{t.company ? ` @ ${t.company}` : ''}</p></div>
                      </div>
                    </TableCell>
                    <TableCell className="text-sm max-w-xs truncate">{t.content}</TableCell>
                    <TableCell><div className="flex gap-0.5">{[1,2,3,4,5].map((i) => <Star key={i} className={`size-3 ${i <= t.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`} />)}</div></TableCell>
                    <TableCell><Badge variant="secondary" className={t.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>{t.isActive ? 'Active' : 'Inactive'}</Badge></TableCell>
                    <TableCell className="text-sm">{t.sortOrder}</TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon" className="size-7" onClick={() => openEdit(t)}><Pencil className="size-3" /></Button>
                        <Button variant="ghost" size="icon" className="size-7 text-destructive" onClick={() => setDeleteId(t.id)}><Trash2 className="size-3" /></Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editing?.id ? 'Edit Testimonial' : 'Add Testimonial'}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2"><Label>Name *</Label><Input value={editing?.name ?? ''} onChange={(e) => setEditing((prev) => ({ ...prev, name: e.target.value }) as Partial<Testimonial>)} /></div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2"><Label>Role</Label><Input value={editing?.role ?? ''} onChange={(e) => setEditing((prev) => ({ ...prev, role: e.target.value }) as Partial<Testimonial>)} /></div>
              <div className="space-y-2"><Label>Company</Label><Input value={editing?.company ?? ''} onChange={(e) => setEditing((prev) => ({ ...prev, company: e.target.value }) as Partial<Testimonial>)} /></div>
            </div>
            <div className="space-y-2"><Label>Content *</Label><Textarea value={editing?.content ?? ''} onChange={(e) => setEditing((prev) => ({ ...prev, content: e.target.value }) as Partial<Testimonial>)} rows={4} /></div>
            <div className="grid gap-4 sm:grid-cols-3">
              <div className="space-y-2"><Label>Rating</Label><Input type="number" min={1} max={5} value={editing?.rating ?? 5} onChange={(e) => setEditing((prev) => ({ ...prev, rating: Number(e.target.value) }) as Partial<Testimonial>)} /></div>
              <div className="space-y-2"><Label>Sort Order</Label><Input type="number" value={editing?.sortOrder ?? 0} onChange={(e) => setEditing((prev) => ({ ...prev, sortOrder: Number(e.target.value) }) as Partial<Testimonial>)} /></div>
              <div className="flex items-end gap-2"><Switch checked={editing?.isActive ?? true} onCheckedChange={(c) => setEditing((prev) => ({ ...prev, isActive: c }) as Partial<Testimonial>)} /><Label>Active</Label></div>
            </div>
            <div className="space-y-2">
              <Label>Image</Label>
              <div className="flex gap-2">
                <Input value={editing?.image ?? ''} onChange={(e) => setEditing((prev) => ({ ...prev, image: e.target.value }) as Partial<Testimonial>)} placeholder="URL or upload" />
                <Button type="button" variant="outline" size="icon" onClick={handleImageUpload}><Upload className="size-4" /></Button>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving ? 'Saving...' : editing?.id ? 'Update' : 'Create'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Delete Testimonial</AlertDialogTitle><AlertDialogDescription>Are you sure?</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
