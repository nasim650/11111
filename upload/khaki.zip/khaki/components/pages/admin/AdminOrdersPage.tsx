'use client'

import React, { useEffect, useState, useCallback } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Skeleton } from '@/components/ui/skeleton'
import { toast } from 'sonner'
import { extractItems } from '@/lib/api'
import { useAppStore } from '@/lib/store'
import { ShoppingCart, Eye, Truck, Printer, Package } from 'lucide-react'

interface OrderItem {
  id: string
  productId: string
  productName: string
  quantity: number
  unit: string
  price: number
  total: number
  image?: string
}

interface Order {
  id: string
  orderNumber: string
  userId: string
  customerName?: string
  customerEmail?: string
  customerPhone?: string
  items: OrderItem[]
  subtotal: number
  deliveryCharge: number
  discount: number
  total: number
  status: string
  paymentMethod: string
  paymentStatus: string
  shippingAddress?: string
  note?: string
  createdAt: string
  updatedAt: string
}

const statusColors: Record<string, string> = {
  PENDING: 'bg-yellow-100 text-yellow-800',
  PROCESSING: 'bg-blue-100 text-blue-800',
  SHIPPED: 'bg-purple-100 text-purple-800',
  DELIVERED: 'bg-green-100 text-green-800',
  CANCELLED: 'bg-red-100 text-red-800',
}

const statusFlow = ['PENDING', 'PROCESSING', 'SHIPPED', 'DELIVERED', 'CANCELLED']

export default function AdminOrdersPage() {
  const { navigate } = useAppStore()
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [statusFilter, setStatusFilter] = useState('all')
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)
  const [detailOpen, setDetailOpen] = useState(false)
  const [updating, setUpdating] = useState(false)

  const fetchOrders = useCallback(async () => {
    try {
      const params = new URLSearchParams()
      if (statusFilter !== 'all') params.set('status', statusFilter)
      params.set('limit', '50')
      const res = await fetch(`/api/orders?${params.toString()}`)
      if (res.ok) {
        const data = await res.json()
        setOrders(extractItems(data))
      }
    } catch {
      toast.error('Failed to fetch orders')
    } finally {
      setLoading(false)
    }
  }, [statusFilter])

  useEffect(() => { fetchOrders() }, [fetchOrders])

  function openDetail(order: Order) {
    setSelectedOrder(order)
    setDetailOpen(true)
  }

  async function updateStatus(orderId: string, status: string) {
    setUpdating(true)
    try {
      const res = await fetch(`/api/orders/${orderId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      })
      if (!res.ok) throw new Error('Failed to update status')
      toast.success('Order status updated')
      fetchOrders()
      if (selectedOrder?.id === orderId) {
        setSelectedOrder((prev) => prev ? { ...prev, status } : null)
      }
    } catch {
      toast.error('Failed to update order status')
    } finally {
      setUpdating(false)
    }
  }

  async function printLabel(orderId: string) {
    try {
      const res = await fetch(`/api/delivery-labels/${orderId}`)
      if (!res.ok) throw new Error('Failed to get label')
      const data = await res.json()
      // Open print window
      const w = window.open('', '_blank')
      if (w) {
        w.document.write(`<html><head><title>Delivery Label</title></head><body><pre>${JSON.stringify(data, null, 2)}</pre></body></html>`)
        w.document.close()
        w.print()
      }
    } catch {
      toast.error('Failed to print label')
    }
  }

  const counts = {
    all: orders.length,
    PENDING: orders.filter((o) => o.status === 'PENDING').length,
    PROCESSING: orders.filter((o) => o.status === 'PROCESSING').length,
    SHIPPED: orders.filter((o) => o.status === 'SHIPPED').length,
    DELIVERED: orders.filter((o) => o.status === 'DELIVERED').length,
    CANCELLED: orders.filter((o) => o.status === 'CANCELLED').length,
  }

  return (
    <div className="space-y-4">
      <Tabs value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setLoading(true) }}>
        <TabsList className="flex-wrap">
          <TabsTrigger value="all">All ({counts.all})</TabsTrigger>
          <TabsTrigger value="PENDING">Pending ({counts.PENDING})</TabsTrigger>
          <TabsTrigger value="PROCESSING">Processing ({counts.PROCESSING})</TabsTrigger>
          <TabsTrigger value="SHIPPED">Shipped ({counts.SHIPPED})</TabsTrigger>
          <TabsTrigger value="DELIVERED">Delivered ({counts.DELIVERED})</TabsTrigger>
          <TabsTrigger value="CANCELLED">Cancelled ({counts.CANCELLED})</TabsTrigger>
        </TabsList>
      </Tabs>

      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-6 space-y-3">{[...Array(5)].map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}</div>
          ) : orders.length === 0 ? (
            <div className="text-center py-12">
              <ShoppingCart className="mx-auto size-10 text-muted-foreground mb-2" />
              <p className="text-muted-foreground">No orders found</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Order #</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Items</TableHead>
                  <TableHead>Total</TableHead>
                  <TableHead>Payment</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead className="w-10" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {orders.map((order) => (
                  <TableRow key={order.id}>
                    <TableCell className="font-medium text-sm">{order.orderNumber}</TableCell>
                    <TableCell>
                      <div>
                        <p className="text-sm">{order.customerName ?? 'N/A'}</p>
                        <p className="text-xs text-muted-foreground">{order.customerPhone ?? ''}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="text-xs">{order.items?.length ?? 0} items</Badge>
                    </TableCell>
                    <TableCell className="font-medium">৳{order.total.toLocaleString()}</TableCell>
                    <TableCell>
                      <div>
                        <Badge variant={order.paymentStatus === 'PAID' ? 'default' : 'secondary'} className="text-xs">
                          {order.paymentStatus}
                        </Badge>
                        <p className="text-xs text-muted-foreground mt-0.5">{order.paymentMethod}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className={statusColors[order.status] ?? 'bg-gray-100'}>
                        {order.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {new Date(order.createdAt).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      <Button variant="ghost" size="icon" className="size-7" onClick={() => openDetail(order)}>
                        <Eye className="size-3" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Order Detail Dialog */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Package className="size-5" /> Order {selectedOrder?.orderNumber}
            </DialogTitle>
          </DialogHeader>
          {selectedOrder && (
            <div className="space-y-6">
              {/* Status + Actions */}
              <div className="flex flex-wrap items-center gap-3">
                <Badge variant="secondary" className={statusColors[selectedOrder.status] ?? 'bg-gray-100'}>
                  {selectedOrder.status}
                </Badge>
                <Select
                  value={selectedOrder.status}
                  onValueChange={(v) => updateStatus(selectedOrder.id, v)}
                  disabled={updating}
                >
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {statusFlow.map((s) => (
                      <SelectItem key={s} value={s}>{s}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button variant="outline" size="sm" className="gap-1" onClick={() => printLabel(selectedOrder.id)}>
                  <Printer className="size-3" /> Print Label
                </Button>
              </div>

              {/* Customer Info */}
              <div className="grid gap-4 sm:grid-cols-2">
                <Card>
                  <CardContent className="p-4">
                    <h4 className="text-sm font-semibold mb-2">Customer Info</h4>
                    <p className="text-sm">{selectedOrder.customerName ?? 'N/A'}</p>
                    <p className="text-sm text-muted-foreground">{selectedOrder.customerEmail ?? ''}</p>
                    <p className="text-sm text-muted-foreground">{selectedOrder.customerPhone ?? ''}</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <h4 className="text-sm font-semibold mb-2">Shipping Address</h4>
                    <p className="text-sm">{selectedOrder.shippingAddress ?? 'N/A'}</p>
                  </CardContent>
                </Card>
              </div>

              {/* Items */}
              <div>
                <h4 className="text-sm font-semibold mb-2">Order Items</h4>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Product</TableHead>
                      <TableHead>Price</TableHead>
                      <TableHead>Qty</TableHead>
                      <TableHead>Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {(selectedOrder.items ?? []).map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="text-sm">{item.productName}</TableCell>
                        <TableCell className="text-sm">৳{item.price}</TableCell>
                        <TableCell className="text-sm">{item.quantity} {item.unit}</TableCell>
                        <TableCell className="text-sm font-medium">৳{item.total}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {/* Totals */}
              <div className="border-t pt-4 space-y-1 text-sm">
                <div className="flex justify-between"><span>Subtotal</span><span>৳{selectedOrder.subtotal.toLocaleString()}</span></div>
                <div className="flex justify-between"><span>Delivery Charge</span><span>৳{selectedOrder.deliveryCharge.toLocaleString()}</span></div>
                {selectedOrder.discount > 0 && (
                  <div className="flex justify-between text-green-600"><span>Discount</span><span>-৳{selectedOrder.discount.toLocaleString()}</span></div>
                )}
                <div className="flex justify-between font-bold text-base pt-2 border-t"><span>Total</span><span>৳{selectedOrder.total.toLocaleString()}</span></div>
              </div>

              {selectedOrder.note && (
                <div>
                  <h4 className="text-sm font-semibold mb-1">Order Note</h4>
                  <p className="text-sm text-muted-foreground">{selectedOrder.note}</p>
                </div>
              )}

              <div className="text-xs text-muted-foreground">
                <p>Order Date: {new Date(selectedOrder.createdAt).toLocaleString()}</p>
                <p>Last Updated: {new Date(selectedOrder.updatedAt).toLocaleString()}</p>
                <p>Payment: {selectedOrder.paymentMethod} - {selectedOrder.paymentStatus}</p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
