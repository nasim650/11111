'use client'

import React, { useEffect, useState, useCallback } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { Skeleton } from '@/components/ui/skeleton'
import { toast } from 'sonner'
import { extractItems } from '@/lib/api'
import { Plus, Pencil, Trash2, HelpCircle } from 'lucide-react'

interface FAQItem {
  id: string
  question: string
  answer: string
  category?: string
  isActive: boolean
  sortOrder: number
  createdAt: string
}

const emptyFAQ: Partial<FAQItem> = {
  question: '',
  answer: '',
  category: '',
  isActive: true,
  sortOrder: 0,
}

export default function AdminFAQPage() {
  const [items, setItems] = useState<FAQItem[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editing, setEditing] = useState<Partial<FAQItem> | null>(null)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)

  const fetchItems = useCallback(async () => {
    try {
      const res = await fetch('/api/faq')
      if (res.ok) {
        const data = await res.json()
        setItems(extractItems(data))
      }
    } catch {
      toast.error('Failed to fetch FAQ')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { fetchItems() }, [fetchItems])

  function openCreate() { setEditing({ ...emptyFAQ }); setDialogOpen(true) }
  function openEdit(f: FAQItem) { setEditing({ ...f }); setDialogOpen(true) }

  async function handleSave() {
    if (!editing?.question || !editing?.answer) { toast.error('Question and answer are required'); return }
    setSaving(true)
    try {
      const payload = { ...editing, sortOrder: Number(editing.sortOrder) || 0 }
      const isEdit = !!editing.id
      const url = isEdit ? `/api/faq/${editing.id}` : '/api/faq'
      const method = isEdit ? 'PUT' : 'POST'
      const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
      if (!res.ok) { const data = await res.json(); throw new Error(data.error || 'Failed to save') }
      toast.success(isEdit ? 'FAQ updated' : 'FAQ created')
      setDialogOpen(false); fetchItems()
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed to save') } finally { setSaving(false) }
  }

  async function handleDelete() {
    if (!deleteId) return
    try {
      const res = await fetch(`/api/faq/${deleteId}`, { method: 'DELETE' })
      if (!res.ok) throw new Error('Failed to delete')
      toast.success('FAQ deleted'); fetchItems()
    } catch { toast.error('Failed to delete') } finally { setDeleteId(null) }
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>FAQ Management</CardTitle>
          <Button onClick={openCreate} className="gap-2"><Plus className="size-4" /> Add FAQ</Button>
        </CardHeader>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-6 space-y-3">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}</div>
          ) : items.length === 0 ? (
            <div className="text-center py-12">
              <HelpCircle className="mx-auto size-10 text-muted-foreground mb-2" />
              <p className="text-muted-foreground">No FAQs yet</p>
              <Button variant="outline" size="sm" className="mt-2" onClick={openCreate}>Add your first FAQ</Button>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Question</TableHead>
                  <TableHead>Answer</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Sort</TableHead>
                  <TableHead className="w-10" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.map((f) => (
                  <TableRow key={f.id}>
                    <TableCell className="font-medium text-sm max-w-xs">{f.question}</TableCell>
                    <TableCell className="text-sm text-muted-foreground max-w-sm truncate">{f.answer}</TableCell>
                    <TableCell><Badge variant="secondary" className="text-xs">{f.category || 'General'}</Badge></TableCell>
                    <TableCell><Badge variant="secondary" className={f.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>{f.isActive ? 'Active' : 'Inactive'}</Badge></TableCell>
                    <TableCell className="text-sm">{f.sortOrder}</TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon" className="size-7" onClick={() => openEdit(f)}><Pencil className="size-3" /></Button>
                        <Button variant="ghost" size="icon" className="size-7 text-destructive" onClick={() => setDeleteId(f.id)}><Trash2 className="size-3" /></Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editing?.id ? 'Edit FAQ' : 'Add FAQ'}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2"><Label>Question *</Label><Input value={editing?.question ?? ''} onChange={(e) => setEditing((prev) => ({ ...prev, question: e.target.value }) as Partial<FAQItem>)} /></div>
            <div className="space-y-2"><Label>Answer *</Label><Textarea value={editing?.answer ?? ''} onChange={(e) => setEditing((prev) => ({ ...prev, answer: e.target.value }) as Partial<FAQItem>)} rows={4} /></div>
            <div className="grid gap-4 sm:grid-cols-3">
              <div className="space-y-2"><Label>Category</Label><Input value={editing?.category ?? ''} onChange={(e) => setEditing((prev) => ({ ...prev, category: e.target.value }) as Partial<FAQItem>)} placeholder="General" /></div>
              <div className="space-y-2"><Label>Sort Order</Label><Input type="number" value={editing?.sortOrder ?? 0} onChange={(e) => setEditing((prev) => ({ ...prev, sortOrder: Number(e.target.value) }) as Partial<FAQItem>)} /></div>
              <div className="flex items-end gap-2"><Switch checked={editing?.isActive ?? true} onCheckedChange={(c) => setEditing((prev) => ({ ...prev, isActive: c }) as Partial<FAQItem>)} /><Label>Active</Label></div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving ? 'Saving...' : editing?.id ? 'Update' : 'Create'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Delete FAQ</AlertDialogTitle><AlertDialogDescription>Are you sure?</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
