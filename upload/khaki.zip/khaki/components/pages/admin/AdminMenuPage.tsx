'use client'

import React, { useEffect, useState, useCallback } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { Skeleton } from '@/components/ui/skeleton'
import { toast } from 'sonner'
import { extractItems } from '@/lib/api'
import { Plus, Pencil, Trash2, Menu, ChevronDown, ChevronRight } from 'lucide-react'

interface MenuItem {
  id: string
  label: string
  url: string
  icon?: string
  parentId?: string | null
  location: string
  openInNew: boolean
  isActive: boolean
  sortOrder: number
  children?: MenuItem[]
}

const emptyItem: Partial<MenuItem> = {
  label: '',
  url: '',
  icon: '',
  parentId: null,
  location: 'main',
  openInNew: false,
  isActive: true,
  sortOrder: 0,
}

export default function AdminMenuPage() {
  const [items, setItems] = useState<MenuItem[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editing, setEditing] = useState<Partial<MenuItem> | null>(null)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set())

  const fetchItems = useCallback(async () => {
    try {
      const res = await fetch('/api/menu-items')
      if (res.ok) {
        const data = await res.json()
        setItems(extractItems<MenuItem>(data))
      }
    } catch {
      toast.error('Failed to fetch menu items')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { fetchItems() }, [fetchItems])

  function toggleExpand(id: string) {
    setExpandedIds((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  function openCreate(parentId?: string) {
    setEditing({ ...emptyItem, parentId: parentId ?? null })
    setDialogOpen(true)
  }

  function openEdit(item: MenuItem) {
    setEditing({ ...item })
    setDialogOpen(true)
  }

  async function handleSave() {
    if (!editing?.label || !editing?.url) {
      toast.error('Label and URL are required')
      return
    }
    setSaving(true)
    try {
      const payload = { ...editing, sortOrder: Number(editing.sortOrder) || 0, parentId: editing.parentId || null }
      const isEdit = !!editing.id
      const url = isEdit ? `/api/menu-items/${editing.id}` : '/api/menu-items'
      const method = isEdit ? 'PUT' : 'POST'
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      if (!res.ok) {
        const data = await res.json()
        throw new Error(data.error || 'Failed to save')
      }
      toast.success(isEdit ? 'Menu item updated' : 'Menu item created')
      setDialogOpen(false)
      fetchItems()
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to save menu item')
    } finally {
      setSaving(false)
    }
  }

  async function handleDelete() {
    if (!deleteId) return
    try {
      const res = await fetch(`/api/menu-items/${deleteId}`, { method: 'DELETE' })
      if (!res.ok) throw new Error('Failed to delete')
      toast.success('Menu item deleted')
      fetchItems()
    } catch {
      toast.error('Failed to delete menu item')
    } finally {
      setDeleteId(null)
    }
  }

  function renderItems(items: MenuItem[], level: number = 0) {
    return items.map((item) => (
      <React.Fragment key={item.id}>
        <TableRow>
          <TableCell>
            {item.children && item.children.length > 0 && (
              <Button variant="ghost" size="icon" className="size-6" onClick={() => toggleExpand(item.id)}>
                {expandedIds.has(item.id) ? <ChevronDown className="size-3" /> : <ChevronRight className="size-3" />}
              </Button>
            )}
          </TableCell>
          <TableCell>
            <div className="flex items-center gap-1" style={{ paddingLeft: `${level * 24}px` }}>
              {level > 0 && <span className="text-muted-foreground mr-1">↳</span>}
              <span className="font-medium text-sm">{item.label}</span>
            </div>
          </TableCell>
          <TableCell className="text-sm text-muted-foreground">{item.url}</TableCell>
          <TableCell><Badge variant="secondary" className="capitalize text-xs">{item.location}</Badge></TableCell>
          <TableCell>{item.openInNew ? 'Yes' : 'No'}</TableCell>
          <TableCell>
            <Badge variant="secondary" className={item.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
              {item.isActive ? 'Active' : 'Inactive'}
            </Badge>
          </TableCell>
          <TableCell>
            <div className="flex gap-1">
              <Button variant="ghost" size="icon" className="size-7" onClick={() => openCreate(item.id)} title="Add child">
                <Plus className="size-3" />
              </Button>
              <Button variant="ghost" size="icon" className="size-7" onClick={() => openEdit(item)}>
                <Pencil className="size-3" />
              </Button>
              <Button variant="ghost" size="icon" className="size-7 text-destructive" onClick={() => setDeleteId(item.id)}>
                <Trash2 className="size-3" />
              </Button>
            </div>
          </TableCell>
        </TableRow>
        {expandedIds.has(item.id) && item.children && renderItems(item.children, level + 1)}
      </React.Fragment>
    ))
  }

  const topLevelItems = items.filter((i) => !i.parentId)
  const childMap = new Map<string, MenuItem[]>()
  items.forEach((i) => {
    if (i.parentId) {
      const children = childMap.get(i.parentId) ?? []
      children.push(i)
      childMap.set(i.parentId, children)
    }
  })
  function withChildren(list: MenuItem[]): MenuItem[] {
    return list.map((i) => ({ ...i, children: childMap.get(i.id) }))
  }
  const treeItems = withChildren(topLevelItems)

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Menu Items</CardTitle>
          <Button onClick={() => openCreate()} className="gap-2">
            <Plus className="size-4" /> Add Menu Item
          </Button>
        </CardHeader>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-6 space-y-3">{[...Array(4)].map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}</div>
          ) : items.length === 0 ? (
            <div className="text-center py-12">
              <Menu className="mx-auto size-10 text-muted-foreground mb-2" />
              <p className="text-muted-foreground">No menu items yet</p>
              <Button variant="outline" size="sm" className="mt-2" onClick={() => openCreate()}>Add your first menu item</Button>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-8"></TableHead>
                  <TableHead>Label</TableHead>
                  <TableHead>URL</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>New Tab</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="w-10" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {renderItems(treeItems)}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{editing?.id ? 'Edit Menu Item' : 'Add Menu Item'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Label *</Label>
              <Input value={editing?.label ?? ''} onChange={(e) => setEditing((prev) => ({ ...prev, label: e.target.value }) as Partial<MenuItem>)} />
            </div>
            <div className="space-y-2">
              <Label>URL *</Label>
              <Input value={editing?.url ?? ''} onChange={(e) => setEditing((prev) => ({ ...prev, url: e.target.value }) as Partial<MenuItem>)} placeholder="/page or https://..." />
            </div>
            <div className="space-y-2">
              <Label>Icon</Label>
              <Input value={editing?.icon ?? ''} onChange={(e) => setEditing((prev) => ({ ...prev, icon: e.target.value }) as Partial<MenuItem>)} placeholder="Icon name" />
            </div>
            <div className="space-y-2">
              <Label>Location</Label>
              <Select value={editing?.location ?? 'main'} onValueChange={(v) => setEditing((prev) => ({ ...prev, location: v }) as Partial<MenuItem>)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="main">Main</SelectItem>
                  <SelectItem value="footer">Footer</SelectItem>
                  <SelectItem value="sidebar">Sidebar</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Parent</Label>
              <Select value={editing?.parentId ?? 'none'} onValueChange={(v) => setEditing((prev) => ({ ...prev, parentId: v === 'none' ? null : v }) as Partial<MenuItem>)}>
                <SelectTrigger><SelectValue placeholder="None (top level)" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None (top level)</SelectItem>
                  {topLevelItems.filter((i) => i.id).map((i) => (<SelectItem key={i.id} value={i.id}>{i.label}</SelectItem>))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>Sort Order</Label>
                <Input type="number" value={editing?.sortOrder ?? 0} onChange={(e) => setEditing((prev) => ({ ...prev, sortOrder: Number(e.target.value) }) as Partial<MenuItem>)} />
              </div>
              <div className="flex flex-col justify-end gap-3">
                <div className="flex items-center gap-2">
                  <Switch checked={editing?.openInNew ?? false} onCheckedChange={(c) => setEditing((prev) => ({ ...prev, openInNew: c }) as Partial<MenuItem>)} />
                  <Label>Open in New Tab</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Switch checked={editing?.isActive ?? true} onCheckedChange={(c) => setEditing((prev) => ({ ...prev, isActive: c }) as Partial<MenuItem>)} />
                  <Label>Active</Label>
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving ? 'Saving...' : editing?.id ? 'Update' : 'Create'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Delete Menu Item</AlertDialogTitle><AlertDialogDescription>Are you sure? Child items will also be deleted.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
