'use client'

import React, { useEffect, useState, useCallback } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { Skeleton } from '@/components/ui/skeleton'
import { toast } from 'sonner'
import { extractItems } from '@/lib/api'
import { Plus, Pencil, Trash2, Handshake, Upload } from 'lucide-react'

interface Partner {
  id: string
  name: string
  logo?: string
  website?: string
  description?: string
  isActive: boolean
  sortOrder: number
  createdAt: string
}

const emptyPartner: Partial<Partner> = {
  name: '',
  logo: '',
  website: '',
  description: '',
  isActive: true,
  sortOrder: 0,
}

export default function AdminPartnersPage() {
  const [items, setItems] = useState<Partner[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editing, setEditing] = useState<Partial<Partner> | null>(null)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)

  const fetchItems = useCallback(async () => {
    try {
      const res = await fetch('/api/partners')
      if (res.ok) {
        const data = await res.json()
        setItems(extractItems(data))
      }
    } catch {
      toast.error('Failed to fetch partners')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { fetchItems() }, [fetchItems])

  function openCreate() { setEditing({ ...emptyPartner }); setDialogOpen(true) }
  function openEdit(p: Partner) { setEditing({ ...p }); setDialogOpen(true) }

  async function handleSave() {
    if (!editing?.name) { toast.error('Partner name is required'); return }
    setSaving(true)
    try {
      const payload = { ...editing, sortOrder: Number(editing.sortOrder) || 0 }
      const isEdit = !!editing.id
      const url = isEdit ? `/api/partners/${editing.id}` : '/api/partners'
      const method = isEdit ? 'PUT' : 'POST'
      const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
      if (!res.ok) { const data = await res.json(); throw new Error(data.error || 'Failed to save') }
      toast.success(isEdit ? 'Partner updated' : 'Partner created')
      setDialogOpen(false); fetchItems()
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed to save') } finally { setSaving(false) }
  }

  async function handleDelete() {
    if (!deleteId) return
    try {
      const res = await fetch(`/api/partners/${deleteId}`, { method: 'DELETE' })
      if (!res.ok) throw new Error('Failed to delete')
      toast.success('Partner deleted'); fetchItems()
    } catch { toast.error('Failed to delete') } finally { setDeleteId(null) }
  }

  async function handleLogoUpload() {
    const input = document.createElement('input'); input.type = 'file'; input.accept = 'image/*'
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0]; if (!file) return
      const formData = new FormData(); formData.append('files', file)
      try {
        const res = await fetch('/api/uploads', { method: 'POST', body: formData })
        if (!res.ok) throw new Error('Upload failed')
        const data = await res.json(); const files = data.files ?? data ?? []
        if (files.length > 0) setEditing((prev) => ({ ...prev, logo: files[0].url }) as Partial<Partner>)
      } catch { toast.error('Image upload failed') }
    }
    input.click()
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Partners</CardTitle>
          <Button onClick={openCreate} className="gap-2"><Plus className="size-4" /> Add Partner</Button>
        </CardHeader>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-6 space-y-3">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}</div>
          ) : items.length === 0 ? (
            <div className="text-center py-12">
              <Handshake className="mx-auto size-10 text-muted-foreground mb-2" />
              <p className="text-muted-foreground">No partners yet</p>
              <Button variant="outline" size="sm" className="mt-2" onClick={openCreate}>Add your first partner</Button>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Logo</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Website</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Sort</TableHead>
                  <TableHead className="w-10" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.map((p) => (
                  <TableRow key={p.id}>
                    <TableCell>
                      {p.logo ? <img src={p.logo} alt={p.name} className="h-8 object-contain" /> : <div className="h-8 w-16 bg-muted rounded flex items-center justify-center text-xs">No logo</div>}
                    </TableCell>
                    <TableCell className="font-medium text-sm">{p.name}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{p.website ? <a href={p.website} target="_blank" rel="noopener noreferrer" className="hover:underline">{p.website}</a> : '-'}</TableCell>
                    <TableCell><Badge variant="secondary" className={p.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>{p.isActive ? 'Active' : 'Inactive'}</Badge></TableCell>
                    <TableCell className="text-sm">{p.sortOrder}</TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon" className="size-7" onClick={() => openEdit(p)}><Pencil className="size-3" /></Button>
                        <Button variant="ghost" size="icon" className="size-7 text-destructive" onClick={() => setDeleteId(p.id)}><Trash2 className="size-3" /></Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>{editing?.id ? 'Edit Partner' : 'Add Partner'}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2"><Label>Name *</Label><Input value={editing?.name ?? ''} onChange={(e) => setEditing((prev) => ({ ...prev, name: e.target.value }) as Partial<Partner>)} /></div>
            <div className="space-y-2">
              <Label>Logo</Label>
              <div className="flex gap-2">
                <Input value={editing?.logo ?? ''} onChange={(e) => setEditing((prev) => ({ ...prev, logo: e.target.value }) as Partial<Partner>)} placeholder="URL or upload" />
                <Button type="button" variant="outline" size="icon" onClick={handleLogoUpload}><Upload className="size-4" /></Button>
              </div>
            </div>
            <div className="space-y-2"><Label>Website</Label><Input value={editing?.website ?? ''} onChange={(e) => setEditing((prev) => ({ ...prev, website: e.target.value }) as Partial<Partner>)} placeholder="https://..." /></div>
            <div className="space-y-2"><Label>Description</Label><Textarea value={editing?.description ?? ''} onChange={(e) => setEditing((prev) => ({ ...prev, description: e.target.value }) as Partial<Partner>)} rows={3} /></div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2"><Label>Sort Order</Label><Input type="number" value={editing?.sortOrder ?? 0} onChange={(e) => setEditing((prev) => ({ ...prev, sortOrder: Number(e.target.value) }) as Partial<Partner>)} /></div>
              <div className="flex items-end gap-2"><Switch checked={editing?.isActive ?? true} onCheckedChange={(c) => setEditing((prev) => ({ ...prev, isActive: c }) as Partial<Partner>)} /><Label>Active</Label></div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving ? 'Saving...' : editing?.id ? 'Update' : 'Create'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Delete Partner</AlertDialogTitle><AlertDialogDescription>Are you sure?</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
