'use client'

import React, { useEffect, useState, useCallback } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { Skeleton } from '@/components/ui/skeleton'
import { toast } from 'sonner'
import { extractItems } from '@/lib/api'
import { Plus, Pencil, Trash2, LayoutGrid, GripVertical } from 'lucide-react'

interface HomepageSection {
  id: string
  title: string
  subtitle?: string
  type: string
  categoryId?: string
  layout?: string
  limit?: number
  isActive: boolean
  sortOrder: number
  content?: string
  description?: string
  image?: string
  bgColor?: string
}

interface Category {
  id: string
  name: string
}

const emptySection: Partial<HomepageSection> = {
  title: '',
  subtitle: '',
  type: 'product_grid',
  categoryId: '',
  layout: 'grid',
  limit: 8,
  isActive: true,
  sortOrder: 0,
  content: '',
  description: '',
  image: '',
  bgColor: '',
}

export default function AdminHomepagePage() {
  const [sections, setSections] = useState<HomepageSection[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editing, setEditing] = useState<Partial<HomepageSection> | null>(null)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)

  const fetchData = useCallback(async () => {
    try {
      const [secRes, catRes] = await Promise.all([
        fetch('/api/homepage-sections'),
        fetch('/api/categories'),
      ])
      if (secRes.ok) {
        const data = await secRes.json()
        setSections(extractItems(data))
      }
      if (catRes.ok) {
        const data = await catRes.json()
        setCategories(extractItems(data))
      }
    } catch {
      toast.error('Failed to fetch data')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { fetchData() }, [fetchData])

  function openCreate() {
    setEditing({ ...emptySection })
    setDialogOpen(true)
  }

  function openEdit(s: HomepageSection) {
    setEditing({ ...s })
    setDialogOpen(true)
  }

  async function handleSave() {
    if (!editing?.title) {
      toast.error('Section title is required')
      return
    }
    setSaving(true)
    try {
      const payload = { ...editing, sortOrder: Number(editing.sortOrder) || 0, limit: Number(editing.limit) || 8 }
      const isEdit = !!editing.id
      const url = isEdit ? `/api/homepage-sections/${editing.id}` : '/api/homepage-sections'
      const method = isEdit ? 'PUT' : 'POST'
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      if (!res.ok) {
        const data = await res.json()
        throw new Error(data.error || 'Failed to save')
      }
      toast.success(isEdit ? 'Section updated' : 'Section created')
      setDialogOpen(false)
      fetchData()
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to save section')
    } finally {
      setSaving(false)
    }
  }

  async function handleDelete() {
    if (!deleteId) return
    try {
      const res = await fetch(`/api/homepage-sections/${deleteId}`, { method: 'DELETE' })
      if (!res.ok) throw new Error('Failed to delete')
      toast.success('Section deleted')
      fetchData()
    } catch {
      toast.error('Failed to delete section')
    } finally {
      setDeleteId(null)
    }
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Homepage Sections</CardTitle>
          <Button onClick={openCreate} className="gap-2">
            <Plus className="size-4" /> Add Section
          </Button>
        </CardHeader>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-6 space-y-3">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}</div>
          ) : sections.length === 0 ? (
            <div className="text-center py-12">
              <LayoutGrid className="mx-auto size-10 text-muted-foreground mb-2" />
              <p className="text-muted-foreground">No sections yet</p>
              <Button variant="outline" size="sm" className="mt-2" onClick={openCreate}>Add your first section</Button>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-8"></TableHead>
                  <TableHead>Section</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Layout</TableHead>
                  <TableHead>Limit</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="w-10" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {sections.map((s) => (
                  <TableRow key={s.id}>
                    <TableCell><GripVertical className="size-4 text-muted-foreground" /></TableCell>
                    <TableCell>
                      <p className="font-medium text-sm">{s.title}</p>
                      {s.subtitle && <p className="text-xs text-muted-foreground">{s.subtitle}</p>}
                    </TableCell>
                    <TableCell><Badge variant="secondary" className="capitalize text-xs">{s.type.replace('_', ' ')}</Badge></TableCell>
                    <TableCell className="text-sm">{s.categoryId ? categories.find((c) => c.id === s.categoryId)?.name ?? s.categoryId : '-'}</TableCell>
                    <TableCell className="text-sm capitalize">{s.layout ?? 'grid'}</TableCell>
                    <TableCell className="text-sm">{s.limit ?? '-'}</TableCell>
                    <TableCell>
                      <Badge variant="secondary" className={s.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                        {s.isActive ? 'Active' : 'Inactive'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon" className="size-7" onClick={() => openEdit(s)}><Pencil className="size-3" /></Button>
                        <Button variant="ghost" size="icon" className="size-7 text-destructive" onClick={() => setDeleteId(s.id)}><Trash2 className="size-3" /></Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing?.id ? 'Edit Section' : 'Add Section'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Title *</Label>
              <Input value={editing?.title ?? ''} onChange={(e) => setEditing((prev) => ({ ...prev, title: e.target.value }) as Partial<HomepageSection>)} />
            </div>
            <div className="space-y-2">
              <Label>Subtitle</Label>
              <Input value={editing?.subtitle ?? ''} onChange={(e) => setEditing((prev) => ({ ...prev, subtitle: e.target.value }) as Partial<HomepageSection>)} />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>Section Type</Label>
                <Select value={editing?.type ?? 'product_grid'} onValueChange={(v) => setEditing((prev) => ({ ...prev, type: v }) as Partial<HomepageSection>)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="product_grid">Product Grid</SelectItem>
                    <SelectItem value="banner">Banner</SelectItem>
                    <SelectItem value="category">Category</SelectItem>
                    <SelectItem value="custom">Custom</SelectItem>
                    <SelectItem value="testimonial">Testimonial</SelectItem>
                    <SelectItem value="features">Features</SelectItem>
                    <SelectItem value="promo">Promo</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Category</Label>
                <Select value={editing?.categoryId ?? 'none'} onValueChange={(v) => setEditing((prev) => ({ ...prev, categoryId: v === 'none' ? '' : v }) as Partial<HomepageSection>)}>
                  <SelectTrigger><SelectValue placeholder="Select category" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    {categories.filter((c) => c.id).map((c) => (<SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid gap-4 sm:grid-cols-3">
              <div className="space-y-2">
                <Label>Layout</Label>
                <Select value={editing?.layout ?? 'grid'} onValueChange={(v) => setEditing((prev) => ({ ...prev, layout: v }) as Partial<HomepageSection>)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="grid">Grid</SelectItem>
                    <SelectItem value="carousel">Carousel</SelectItem>
                    <SelectItem value="list">List</SelectItem>
                    <SelectItem value="slider">Slider</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Item Limit</Label>
                <Input type="number" value={editing?.limit ?? 8} onChange={(e) => setEditing((prev) => ({ ...prev, limit: Number(e.target.value) }) as Partial<HomepageSection>)} />
              </div>
              <div className="space-y-2">
                <Label>Sort Order</Label>
                <Input type="number" value={editing?.sortOrder ?? 0} onChange={(e) => setEditing((prev) => ({ ...prev, sortOrder: Number(e.target.value) }) as Partial<HomepageSection>)} />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea value={editing?.description ?? ''} onChange={(e) => setEditing((prev) => ({ ...prev, description: e.target.value }) as Partial<HomepageSection>)} rows={3} />
            </div>
            {['custom', 'features', 'promo'].includes(editing?.type ?? '') && (
              <div className="space-y-2">
                <Label>{editing?.type === 'custom' ? 'Custom Content' : 'Content (JSON)'}</Label>
                <Textarea value={editing?.content ?? ''} onChange={(e) => setEditing((prev) => ({ ...prev, content: e.target.value }) as Partial<HomepageSection>)} rows={5} />
              </div>
            )}
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>Image URL</Label>
                <Input value={editing?.image ?? ''} onChange={(e) => setEditing((prev) => ({ ...prev, image: e.target.value }) as Partial<HomepageSection>)} placeholder="/uploads/homepage/..." />
              </div>
              <div className="space-y-2">
                <Label>Background Color</Label>
                <Input value={editing?.bgColor ?? ''} onChange={(e) => setEditing((prev) => ({ ...prev, bgColor: e.target.value }) as Partial<HomepageSection>)} placeholder="#ffffff" />
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Switch checked={editing?.isActive ?? true} onCheckedChange={(c) => setEditing((prev) => ({ ...prev, isActive: c }) as Partial<HomepageSection>)} />
              <Label>Active</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving ? 'Saving...' : editing?.id ? 'Update' : 'Create'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Delete Section</AlertDialogTitle><AlertDialogDescription>Are you sure? This action cannot be undone.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
