'use client'

import React, { useState, useEffect, useReducer, useCallback, useRef } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from '@/components/ui/dialog'
import { Skeleton } from '@/components/ui/skeleton'
import { extractItems, extractPagination } from '@/lib/api'
import {
  ClipboardList, ChevronLeft, ChevronRight, Filter, X, Eye,
} from 'lucide-react'

interface AuditLog {
  id: string
  adminId: string | null
  action: string
  module: string
  referenceId: string | null
  oldData: string | null
  newData: string | null
  ipAddress: string | null
  createdAt: string
}

interface FilterState {
  module: string
  action: string
  startDate: string
  endDate: string
}

type FilterAction =
  | { key: keyof FilterState; value: string }
  | { type: 'reset' }

function filterReducer(state: FilterState, action: FilterAction): FilterState {
  if ('type' in action) {
    return { module: '', action: '', startDate: '', endDate: '' }
  }
  return { ...state, [action.key]: action.value }
}

const MODULES = ['users', 'products', 'orders', 'categories', 'banners', 'coupons', 'policy-pages', 'reviews', 'settings', 'media']
const ACTIONS = ['create', 'update', 'delete']

function JsonDiffView({ oldData, newData }: { oldData: string | null; newData: string | null }) {
  let oldObj: Record<string, unknown> | null = null
  let newObj: Record<string, unknown> | null = null

  try { oldObj = oldData ? JSON.parse(oldData) : null } catch { /* ignore */ }
  try { newObj = newData ? JSON.parse(newData) : null } catch { /* ignore */ }

  if (!oldObj && !newObj) {
    return <p className="text-sm text-muted-foreground">No data available</p>
  }

  // If only new data (e.g., create action)
  if (!oldObj && newObj) {
    return (
      <div className="space-y-1">
        <p className="text-xs font-medium text-green-700 dark:text-green-400 mb-2">New Data</p>
        {Object.entries(newObj).map(([key, value]) => (
          <div key={key} className="flex items-start gap-2 text-sm">
            <span className="text-muted-foreground min-w-[140px] font-mono text-xs">{key}:</span>
            <span className="text-green-700 dark:text-green-400 font-mono text-xs break-all">
              {typeof value === 'object' ? JSON.stringify(value) : String(value ?? '')}
            </span>
          </div>
        ))}
      </div>
    )
  }

  // If only old data (e.g., delete action)
  if (oldObj && !newObj) {
    return (
      <div className="space-y-1">
        <p className="text-xs font-medium text-red-700 dark:text-red-400 mb-2">Deleted Data</p>
        {Object.entries(oldObj).map(([key, value]) => (
          <div key={key} className="flex items-start gap-2 text-sm">
            <span className="text-muted-foreground min-w-[140px] font-mono text-xs">{key}:</span>
            <span className="text-red-700 dark:text-red-400 font-mono text-xs line-through break-all">
              {typeof value === 'object' ? JSON.stringify(value) : String(value ?? '')}
            </span>
          </div>
        ))}
      </div>
    )
  }

  // Diff view for update actions
  const allKeys = Array.from(new Set([...Object.keys(oldObj ?? {}), ...Object.keys(newObj ?? {})])).sort()

  return (
    <div className="space-y-1">
      {allKeys.map((key) => {
        const oldVal = (oldObj as Record<string, unknown>)?.[key]
        const newVal = (newObj as Record<string, unknown>)?.[key]
        const oldStr = typeof oldVal === 'object' ? JSON.stringify(oldVal) : String(oldVal ?? '')
        const newStr = typeof newVal === 'object' ? JSON.stringify(newVal) : String(newVal ?? '')
        const changed = oldStr !== newStr

        return (
          <div key={key} className="flex items-start gap-2 text-sm">
            <span className="text-muted-foreground min-w-[140px] font-mono text-xs">{key}:</span>
            {changed ? (
              <div className="flex flex-col gap-0.5">
                <span className="text-red-700 dark:text-red-400 font-mono text-xs line-through break-all">{oldStr || '(empty)'}</span>
                <span className="text-green-700 dark:text-green-400 font-mono text-xs break-all">{newStr || '(empty)'}</span>
              </div>
            ) : (
              <span className="font-mono text-xs break-all">{oldStr || '(empty)'}</span>
            )}
          </div>
        )
      })}
    </div>
  )
}

export default function AdminAuditLogPage() {
  const [logs, setLogs] = useState<AuditLog[]>([])
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(0)
  const [total, setTotal] = useState(0)
  const [selectedLog, setSelectedLog] = useState<AuditLog | null>(null)
  const [filters, dispatchFilter] = useReducer(filterReducer, {
    module: '', action: '', startDate: '', endDate: '',
  })
  const [showFilters, setShowFilters] = useState(false)
  const isInitialMount = useRef(true)

  const fetchLogs = useCallback(async (pageNum = 1) => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      params.set('page', String(pageNum))
      params.set('limit', '20')
      if (filters.module) params.set('module', filters.module)
      if (filters.action) params.set('action', filters.action)
      if (filters.startDate) params.set('startDate', filters.startDate)
      if (filters.endDate) params.set('endDate', filters.endDate)

      const res = await fetch(`/api/audit-logs?${params.toString()}`)
      if (res.ok) {
        const data = await res.json()
        setLogs(extractItems<AuditLog>(data))
        const pag = extractPagination(data)
        setTotalPages(pag.totalPages)
        setTotal(pag.total)
      }
    } catch {
      // silently fail
    } finally {
      setLoading(false)
    }
  }, [filters])

  useEffect(() => {
    fetchLogs(page)
  }, [fetchLogs, page])

  // Reset to page 1 when filters change
  useEffect(() => {
    if (isInitialMount.current) {
      isInitialMount.current = false
      return
    }
    setPage(1)
  }, [filters])

  function getActionBadgeVariant(action: string) {
    switch (action) {
      case 'create': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300'
      case 'update': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300'
      case 'delete': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  function getModuleLabel(mod: string) {
    const labels: Record<string, string> = {
      users: 'Users',
      products: 'Products',
      orders: 'Orders',
      categories: 'Categories',
      banners: 'Banners',
      coupons: 'Coupons',
      'policy-pages': 'Policy Pages',
      reviews: 'Reviews',
      settings: 'Settings',
      media: 'Media',
    }
    return labels[mod] || mod
  }

  const hasActiveFilters = filters.module || filters.action || filters.startDate || filters.endDate

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <ClipboardList className="size-5" />
            Audit Log
          </CardTitle>
          <div className="flex items-center gap-2">
            {hasActiveFilters && (
              <Badge variant="secondary" className="gap-1">
                Active filters
                <button onClick={() => dispatchFilter({ type: 'reset' })} className="hover:text-destructive">
                  <X className="size-3" />
                </button>
              </Badge>
            )}
            <Button variant="outline" size="sm" onClick={() => setShowFilters(!showFilters)} className="gap-1">
              <Filter className="size-4" />
              Filters
            </Button>
          </div>
        </CardHeader>

        {showFilters && (
          <div className="border-b px-6 py-4 bg-muted/30">
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <div className="space-y-1.5">
                <Label className="text-xs">Module</Label>
                <Select value={filters.module || '_all'} onValueChange={(v) => dispatchFilter({ key: 'module', value: v === '_all' ? '' : v })}>
                  <SelectTrigger className="h-9"><SelectValue placeholder="All modules" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="_all">All modules</SelectItem>
                    {MODULES.map((m) => (
                      <SelectItem key={m} value={m}>{getModuleLabel(m)}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Action</Label>
                <Select value={filters.action || '_all'} onValueChange={(v) => dispatchFilter({ key: 'action', value: v === '_all' ? '' : v })}>
                  <SelectTrigger className="h-9"><SelectValue placeholder="All actions" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="_all">All actions</SelectItem>
                    {ACTIONS.map((a) => (
                      <SelectItem key={a} value={a} className="capitalize">{a}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Start Date</Label>
                <Input
                  type="date"
                  className="h-9"
                  value={filters.startDate}
                  onChange={(e) => dispatchFilter({ key: 'startDate', value: e.target.value })}
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">End Date</Label>
                <Input
                  type="date"
                  className="h-9"
                  value={filters.endDate}
                  onChange={(e) => dispatchFilter({ key: 'endDate', value: e.target.value })}
                />
              </div>
            </div>
          </div>
        )}

        <CardContent className="p-0">
          {loading ? (
            <div className="p-6 space-y-3">
              {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}
            </div>
          ) : logs.length === 0 ? (
            <div className="text-center py-12">
              <ClipboardList className="mx-auto size-10 text-muted-foreground mb-2" />
              <p className="text-muted-foreground">No audit logs found</p>
              {hasActiveFilters && (
                <Button variant="outline" size="sm" className="mt-2" onClick={() => dispatchFilter({ type: 'reset' })}>
                  Clear filters
                </Button>
              )}
            </div>
          ) : (
            <>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Admin</TableHead>
                    <TableHead>Action</TableHead>
                    <TableHead>Module</TableHead>
                    <TableHead className="hidden md:table-cell">Reference ID</TableHead>
                    <TableHead className="hidden lg:table-cell">Details</TableHead>
                    <TableHead className="w-10" />
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {logs.map((log) => (
                    <TableRow key={log.id} className="cursor-pointer hover:bg-muted/50" onClick={() => setSelectedLog(log)}>
                      <TableCell className="text-xs text-muted-foreground whitespace-nowrap">
                        {new Date(log.createdAt).toLocaleString()}
                      </TableCell>
                      <TableCell className="text-xs font-mono">
                        {log.adminId ? log.adminId.slice(0, 8) + '...' : 'System'}
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary" className={`text-xs capitalize ${getActionBadgeVariant(log.action)}`}>
                          {log.action}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-xs">
                        {getModuleLabel(log.module)}
                      </TableCell>
                      <TableCell className="hidden md:table-cell text-xs font-mono text-muted-foreground">
                        {log.referenceId ? log.referenceId.slice(0, 8) + '...' : '-'}
                      </TableCell>
                      <TableCell className="hidden lg:table-cell text-xs text-muted-foreground max-w-[200px] truncate">
                        {log.newData ? log.newData.slice(0, 60) + '...' : '-'}
                      </TableCell>
                      <TableCell>
                        <Button variant="ghost" size="icon" className="size-7" onClick={() => setSelectedLog(log)}>
                          <Eye className="size-3" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between border-t px-4 py-3">
                  <p className="text-xs text-muted-foreground">
                    Showing {((page - 1) * 20) + 1}-{Math.min(page * 20, total)} of {total}
                  </p>
                  <div className="flex items-center gap-1">
                    <Button
                      variant="outline"
                      size="icon"
                      className="size-8"
                      disabled={page <= 1}
                      onClick={() => setPage(page - 1)}
                    >
                      <ChevronLeft className="size-4" />
                    </Button>
                    <span className="text-xs px-2">
                      Page {page} of {totalPages}
                    </span>
                    <Button
                      variant="outline"
                      size="icon"
                      className="size-8"
                      disabled={page >= totalPages}
                      onClick={() => setPage(page + 1)}
                    >
                      <ChevronRight className="size-4" />
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {/* Detail Dialog */}
      <Dialog open={!!selectedLog} onOpenChange={() => setSelectedLog(null)}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              Audit Log Detail
              {selectedLog && (
                <Badge variant="secondary" className={`text-xs capitalize ${getActionBadgeVariant(selectedLog.action)}`}>
                  {selectedLog.action}
                </Badge>
              )}
            </DialogTitle>
            <DialogDescription>
              Detailed view of the audit log entry with data comparison
            </DialogDescription>
          </DialogHeader>

          {selectedLog && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-xs text-muted-foreground">Date</p>
                  <p className="font-medium">{new Date(selectedLog.createdAt).toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Admin ID</p>
                  <p className="font-mono text-xs">{selectedLog.adminId || 'System'}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Module</p>
                  <p className="font-medium">{getModuleLabel(selectedLog.module)}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Reference ID</p>
                  <p className="font-mono text-xs">{selectedLog.referenceId || '-'}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">IP Address</p>
                  <p className="font-mono text-xs">{selectedLog.ipAddress || '-'}</p>
                </div>
              </div>

              <div className="border-t pt-4">
                <h4 className="text-sm font-medium mb-3">Data Changes</h4>
                <div className="bg-muted/50 rounded-lg p-4 max-h-[400px] overflow-y-auto">
                  <JsonDiffView oldData={selectedLog.oldData} newData={selectedLog.newData} />
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
