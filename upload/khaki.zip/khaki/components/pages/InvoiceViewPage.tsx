'use client'

import { useEffect, useState } from 'react'
import Image from 'next/image'
import { Printer, ArrowLeft, Download } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { Skeleton } from '@/components/ui/skeleton'
import { useAppStore } from '@/lib/store'

interface OrderItem {
  id: string
  productName: string
  quantity: number
  unit: string
  price: number
  image?: string
}

interface OrderData {
  id: string
  orderNumber: string
  totalAmount: number
  discountAmount: number
  deliveryCharge: number
  paymentMethod: string
  paymentStatus: string
  orderStatus: string
  couponCode?: string
  createdAt: string
  guestName?: string
  guestPhone?: string
  guestEmail?: string
  guestAddress?: string
  items: OrderItem[]
}

export default function InvoiceViewPage() {
  const { pageParams, navigate, siteConfig } = useAppStore()
  const orderId = String(pageParams?.id || '')
  const [order, setOrder] = useState<OrderData | null>(null)
  const [loading, setLoading] = useState(() => !!orderId)

  useEffect(() => {
    if (!orderId) return
    let cancelled = false
    fetch(`/api/orders/${orderId}`)
      .then((r) => {
        if (!r.ok) throw new Error('Not found')
        return r.json()
      })
      .then((data) => { if (!cancelled) setOrder(data) })
      .catch(() => { if (!cancelled) setOrder(null) })
      .finally(() => { if (!cancelled) setLoading(false) })
    return () => { cancelled = true }
  }, [orderId])

  const handlePrint = () => {
    window.print()
  }

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-3xl space-y-4">
        <Skeleton className="h-8 w-32" />
        <Skeleton className="h-96 rounded-lg" />
      </div>
    )
  }

  if (!order) {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <h2 className="text-2xl font-bold mb-2">Order Not Found</h2>
        <Button onClick={() => navigate('orders')}>View Orders</Button>
      </div>
    )
  }

  const subtotal = order.items.reduce((sum, item) => sum + item.price * item.quantity, 0)

  return (
    <div className="min-h-screen">
      <div className="container mx-auto px-4 py-6 max-w-3xl">
        {/* Action bar - hidden in print */}
        <div className="flex items-center justify-between mb-6 print:hidden">
          <Button variant="outline" onClick={() => navigate('order-detail', { id: order.id })}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Order
          </Button>
          <Button onClick={handlePrint}>
            <Printer className="h-4 w-4 mr-2" />
            Print Invoice
          </Button>
        </div>

        {/* Invoice */}
        <Card className="print:shadow-none print:border-0">
          <CardContent className="p-8">
            {/* Header */}
            <div className="flex items-center justify-between mb-8">
              <div>
                <h1 className="text-2xl font-bold text-primary">{siteConfig?.siteName || 'Khati Khadyo'}</h1>
                <p className="text-sm text-muted-foreground">{siteConfig?.address || 'Dhaka, Bangladesh'}</p>
                <p className="text-sm text-muted-foreground">{siteConfig?.phone}</p>
                <p className="text-sm text-muted-foreground">{siteConfig?.email}</p>
              </div>
              <div className="text-right">
                <h2 className="text-xl font-bold">INVOICE</h2>
                <p className="text-sm text-muted-foreground">#{order.orderNumber}</p>
                <p className="text-sm text-muted-foreground">
                  {new Date(order.createdAt).toLocaleDateString('en-BD', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                  })}
                </p>
              </div>
            </div>

            <Separator className="my-6" />

            {/* Customer Info */}
            <div className="mb-6">
              <h3 className="font-semibold text-sm text-muted-foreground mb-2">BILL TO</h3>
              <p className="font-medium">{order.guestName || 'Customer'}</p>
              {order.guestPhone && <p className="text-sm text-muted-foreground">{order.guestPhone}</p>}
              {order.guestEmail && <p className="text-sm text-muted-foreground">{order.guestEmail}</p>}
              {order.guestAddress && <p className="text-sm text-muted-foreground">{order.guestAddress}</p>}
            </div>

            {/* Items Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-2 font-semibold">Item</th>
                    <th className="text-center py-2 font-semibold">Qty</th>
                    <th className="text-right py-2 font-semibold">Price</th>
                    <th className="text-right py-2 font-semibold">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {order.items.map((item) => (
                    <tr key={item.id} className="border-b">
                      <td className="py-3">{item.productName}</td>
                      <td className="text-center py-3">{item.quantity} {item.unit}</td>
                      <td className="text-right py-3">৳{item.price.toLocaleString()}</td>
                      <td className="text-right py-3">৳{(item.price * item.quantity).toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <Separator className="my-4" />

            {/* Totals */}
            <div className="flex justify-end">
              <div className="w-64 space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span>৳{subtotal.toLocaleString()}</span>
                </div>
                {order.discountAmount > 0 && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Discount {order.couponCode ? `(${order.couponCode})` : ''}</span>
                    <span>-৳{order.discountAmount.toLocaleString()}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Delivery</span>
                  <span>{order.deliveryCharge === 0 ? 'Free' : `৳${order.deliveryCharge.toLocaleString()}`}</span>
                </div>
                <Separator />
                <div className="flex justify-between font-bold text-lg">
                  <span>Total</span>
                  <span className="text-primary">৳{order.totalAmount.toLocaleString()}</span>
                </div>
              </div>
            </div>

            {/* Payment Info */}
            <div className="mt-6 pt-4 border-t">
              <p className="text-sm text-muted-foreground">
                Payment Method: <span className="font-medium capitalize">{order.paymentMethod}</span>
              </p>
              <p className="text-sm text-muted-foreground">
                Payment Status: <span className="font-medium capitalize">{order.paymentStatus}</span>
              </p>
            </div>

            {/* Footer */}
            <div className="mt-8 text-center text-sm text-muted-foreground">
              <p>Thank you for your order!</p>
              <p>{siteConfig?.siteName || 'Khati Khadyo'} - {siteConfig?.tagline || 'Authentic Bangladeshi Food Products'}</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
