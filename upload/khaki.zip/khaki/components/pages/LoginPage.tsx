'use client'

import { useState } from 'react'
import { Eye, EyeOff, LogIn, Mail, Phone, Lock, AlertCircle, Truck, ShieldCheck, Award, Heart, Zap } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Checkbox } from '@/components/ui/checkbox'
import { Separator } from '@/components/ui/separator'
import { useAppStore } from '@/lib/store'
import { toast } from 'sonner'

export default function LoginPage() {
  const { login, navigate, siteConfig } = useAppStore()
  const [email, setEmail] = useState('')
  const [phone, setPhone] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [rememberMe, setRememberMe] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [fieldErrors, setFieldErrors] = useState<Record<string, boolean>>({})

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setFieldErrors({})
    if (!password) {
      setError('Please enter your password')
      setFieldErrors({ password: true })
      return
    }
    if (!email && !phone) {
      setError('Please enter your email or phone number')
      setFieldErrors({ email: true, phone: true })
      return
    }
    setLoading(true)
    try {
      await login({ email: email || undefined, phone: phone || undefined, password })
      toast.success('Login successful!')
      const state = useAppStore.getState()
      if (state.user?.role === 'admin') {
        navigate('admin-dashboard')
      } else {
        navigate('home')
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Login failed'
      setError(message)
      setFieldErrors({ password: true })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex relative">
      {/* Animated Background Pattern - covers entire page */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
        <svg className="absolute inset-0 w-full h-full opacity-[0.03]" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="food-pattern" x="0" y="0" width="60" height="60" patternUnits="userSpaceOnUse">
              <circle cx="30" cy="30" r="8" fill="none" stroke="#2D6A4F" strokeWidth="1.5" />
              <path d="M30 22 L30 38 M22 30 L38 30" stroke="#2D6A4F" strokeWidth="0.5" opacity="0.5" />
            </pattern>
            <pattern id="dot-pattern" x="0" y="0" width="30" height="30" patternUnits="userSpaceOnUse">
              <circle cx="15" cy="15" r="1" fill="#B8860B" opacity="0.4" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#food-pattern)" />
          <rect width="100%" height="100%" fill="url(#dot-pattern)" />
        </svg>
        {/* Floating geometric shapes */}
        <div className="absolute top-[10%] right-[15%] w-64 h-64 rounded-full border border-primary/10 animate-pulse" style={{ animationDuration: '4s' }} />
        <div className="absolute bottom-[20%] left-[5%] w-40 h-40 rounded-full border border-secondary/10 animate-pulse" style={{ animationDuration: '5s', animationDelay: '1s' }} />
        <div className="absolute top-[60%] right-[5%] w-24 h-24 rounded-full bg-primary/5 animate-bounce" style={{ animationDuration: '6s' }} />
      </div>

      {/* Decorative Left Panel - Hidden on mobile */}
      <div className="hidden lg:flex lg:w-[45%] bg-gradient-to-br from-primary via-primary to-emerald-800 relative overflow-hidden z-10">
        {/* Animated background pattern */}
        <div className="absolute inset-0 opacity-10">
          <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="leaf-pattern" x="0" y="0" width="80" height="80" patternUnits="userSpaceOnUse">
                <path d="M40 10 C50 25, 55 40, 40 70 C25 40, 30 25, 40 10Z" fill="none" stroke="white" strokeWidth="1" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#leaf-pattern)" />
          </svg>
          <div className="absolute top-20 left-10 w-32 h-32 rounded-full border-4 border-white animate-pulse" style={{ animationDuration: '3s' }} />
          <div className="absolute bottom-40 right-20 w-48 h-48 rounded-full border-4 border-white animate-pulse" style={{ animationDuration: '4s', animationDelay: '1s' }} />
          <div className="absolute top-1/2 left-1/3 w-20 h-20 rounded-full bg-white/20 animate-bounce" style={{ animationDuration: '5s' }} />
          <div className="absolute bottom-20 left-20 w-16 h-16 rounded-full bg-white/10 animate-bounce" style={{ animationDuration: '3.5s', animationDelay: '0.5s' }} />
        </div>

        {/* Floating food icons */}
        <div className="absolute top-16 right-16 text-5xl opacity-20 animate-bounce" style={{ animationDuration: '3s' }}>🍯</div>
        <div className="absolute top-1/3 right-1/4 text-4xl opacity-20 animate-bounce" style={{ animationDuration: '4s', animationDelay: '1s' }}>🌶️</div>
        <div className="absolute bottom-1/3 left-1/4 text-4xl opacity-20 animate-bounce" style={{ animationDuration: '3.5s', animationDelay: '0.5s' }}>🫒</div>
        <div className="absolute bottom-16 right-1/3 text-5xl opacity-20 animate-bounce" style={{ animationDuration: '4.5s', animationDelay: '1.5s' }}>🍚</div>

        <div className="relative z-10 flex flex-col justify-center items-center px-12 text-white">
          {/* Brand Logo Area */}
          <div className="w-24 h-24 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center mb-8 shadow-2xl ring-1 ring-white/20">
            <span className="text-5xl font-bold text-secondary">KK</span>
          </div>
          <h1 className="text-4xl font-bold mb-2">Khati Khadyo</h1>
          <p className="text-white/80 text-lg mb-10 text-center">
            খাঁটি খাদ্য — Authentic Bangladeshi Food Products
          </p>

          {/* Benefits Section with Lucide Icons */}
          <div className="w-full max-w-sm space-y-5">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-white/50 mb-4">Why shop with us</h3>
            {[
              { icon: Truck, text: 'Free Delivery on orders over ৳1,500', color: 'bg-sky-400/20' },
              { icon: ShieldCheck, text: '100% Authentic Products Guaranteed', color: 'bg-emerald-400/20' },
              { icon: Award, text: 'Premium Quality You Can Trust', color: 'bg-secondary/30' },
              { icon: Heart, text: 'Save Favorites to Your Wishlist', color: 'bg-red-400/20' },
              { icon: Zap, text: 'Lightning-Fast Secure Checkout', color: 'bg-amber-400/20' },
            ].map((benefit) => {
              const Icon = benefit.icon
              return (
                <div key={benefit.text} className="flex items-center gap-4 text-white/90 group">
                  <div className={`w-10 h-10 rounded-xl ${benefit.color} backdrop-blur-sm flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform duration-200`}>
                    <Icon className="h-5 w-5 text-white" />
                  </div>
                  <span className="text-sm leading-snug">{benefit.text}</span>
                </div>
              )
            })}
          </div>
        </div>
      </div>

      {/* Right Panel - Login Form */}
      <div className="w-full lg:w-[55%] flex flex-col relative z-10">
        {/* Mobile Top Banner */}
        <div className="lg:hidden bg-gradient-to-r from-primary to-emerald-700 p-6 text-white text-center relative overflow-hidden">
          <div className="absolute inset-0 opacity-10">
            <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="mobile-food-pattern" x="0" y="0" width="40" height="40" patternUnits="userSpaceOnUse">
                  <circle cx="20" cy="20" r="5" fill="none" stroke="white" strokeWidth="1" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#mobile-food-pattern)" />
            </svg>
          </div>
          <div className="relative">
            <div className="w-14 h-14 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center mx-auto mb-3 shadow-lg">
              <span className="text-2xl font-bold text-secondary">KK</span>
            </div>
            <h1 className="text-xl font-bold">Khati Khadyo</h1>
            <p className="text-white/70 text-sm mt-1">খাঁটি খাদ্য — Authentic Bangladeshi Food</p>
          </div>
        </div>

        {/* Form Container */}
        <div className="flex-1 flex items-center justify-center p-6 sm:p-8">
          <div className="w-full max-w-md">
            {/* Glassmorphism Form Card */}
            <div className="bg-white/70 backdrop-blur-xl rounded-2xl shadow-xl ring-1 ring-white/50 p-8">
              <div className="mb-8 text-center">
                {siteConfig?.logo && (
                  <div className="flex justify-center mb-4">
                    <img
                      src={siteConfig.logo}
                      alt="Khati Khadyo"
                      className="h-12 w-auto object-contain"
                    />
                  </div>
                )}
                <h2 className="text-2xl font-bold text-foreground">Welcome Back</h2>
                <p className="text-muted-foreground mt-1">Sign in to your Khati Khadyo account</p>
              </div>

              {/* Error Message */}
              {error && (
                <div className="mb-6 p-4 rounded-xl bg-red-50 border-2 border-red-200 flex items-start gap-3 animate-in fade-in slide-in-from-top-2 duration-300">
                  <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-semibold text-red-800">Login Failed</p>
                    <p className="text-sm text-red-600 mt-0.5">{error}</p>
                  </div>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-5">
                {/* Email Field */}
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-sm font-medium">Email Address</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="your@email.com"
                      value={email}
                      onChange={(e) => { setEmail(e.target.value); setFieldErrors(prev => ({ ...prev, email: false })) }}
                      className={`pl-10 h-11 transition-colors ${fieldErrors.email ? 'border-red-400 ring-2 ring-red-100 focus-visible:ring-red-200' : 'focus-visible:ring-primary/20'}`}
                    />
                  </div>
                </div>

                {/* Divider */}
                <div className="relative">
                  <Separator />
                  <span className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white/70 backdrop-blur-sm px-3 text-xs text-muted-foreground">
                    or sign in with phone
                  </span>
                </div>

                {/* Phone Field */}
                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-sm font-medium">Phone Number</Label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="01XXXXXXXXX"
                      value={phone}
                      onChange={(e) => { setPhone(e.target.value); setFieldErrors(prev => ({ ...prev, phone: false })) }}
                      className={`pl-10 h-11 transition-colors ${fieldErrors.phone ? 'border-red-400 ring-2 ring-red-100 focus-visible:ring-red-200' : 'focus-visible:ring-primary/20'}`}
                    />
                  </div>
                </div>

                {/* Password Field */}
                <div className="space-y-2">
                  <Label htmlFor="password" className="text-sm font-medium">Password</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="password"
                      type={showPassword ? 'text' : 'password'}
                      placeholder="Enter your password"
                      value={password}
                      onChange={(e) => { setPassword(e.target.value); setFieldErrors(prev => ({ ...prev, password: false })) }}
                      className={`pl-10 pr-10 h-11 transition-colors ${fieldErrors.password ? 'border-red-400 ring-2 ring-red-100 focus-visible:ring-red-200' : 'focus-visible:ring-primary/20'}`}
                    />
                    <button
                      type="button"
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>

                {/* Remember Me & Forgot Password */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Checkbox
                      id="remember"
                      checked={rememberMe}
                      onCheckedChange={(checked) => setRememberMe(checked === true)}
                      className="data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                    />
                    <Label htmlFor="remember" className="text-sm text-muted-foreground cursor-pointer">
                      Remember me
                    </Label>
                  </div>
                  <button
                    type="button"
                    className="text-sm text-primary hover:underline font-medium"
                    onClick={() => navigate('forgot-password')}
                  >
                    Forgot Password?
                  </button>
                </div>

                {/* Submit Button */}
                <Button type="submit" className="w-full h-12 text-base font-semibold rounded-xl shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-primary/30 transition-all" disabled={loading}>
                  {loading ? (
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white" />
                  ) : (
                    <>
                      <LogIn className="h-5 w-5 mr-2" />
                      Sign In
                    </>
                  )}
                </Button>
              </form>

              {/* Register Link */}
              <div className="mt-6 pt-5 border-t">
                <p className="text-center text-sm text-muted-foreground">
                  Don&apos;t have an account?{' '}
                  <button
                    type="button"
                    className="text-primary hover:underline font-semibold inline-flex items-center gap-1 group"
                    onClick={() => navigate('register')}
                  >
                    Create Account
                    <span className="inline-block group-hover:translate-x-0.5 transition-transform">&rarr;</span>
                  </button>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
