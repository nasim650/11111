'use client'

import React, { useEffect, useState } from 'react'
import { useAppStore, type PageName } from '@/lib/store'
import { extractItems } from '@/lib/api'
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarInset,
  SidebarTrigger,
  SidebarSeparator,
} from '@/components/ui/sidebar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import {
  LayoutDashboard,
  Package,
  FolderTree,
  Image,
  LayoutGrid,
  Menu,
  ShoppingCart,
  Users,
  Star,
  Ticket,
  FileText,
  Settings,
  Camera,
  MessageSquareQuote,
  HelpCircle,
  UserCircle,
  Handshake,
  Bell,
  ArrowLeft,
  ChevronDown,
  ClipboardList,
} from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import DashboardHome from './admin/DashboardHome'
import AdminProductsPage from './admin/AdminProductsPage'
import AdminCategoriesPage from './admin/AdminCategoriesPage'
import AdminBannersPage from './admin/AdminBannersPage'
import AdminHomepagePage from './admin/AdminHomepagePage'
import AdminMenuPage from './admin/AdminMenuPage'
import AdminOrdersPage from './admin/AdminOrdersPage'
import AdminCustomersPage from './admin/AdminCustomersPage'
import AdminReviewsPage from './admin/AdminReviewsPage'
import AdminCouponsPage from './admin/AdminCouponsPage'
import AdminPolicyPagesPage from './admin/AdminPolicyPagesPage'
import AdminSettingsPage from './admin/AdminSettingsPage'
import AdminMediaPage from './admin/AdminMediaPage'
import AdminTestimonialsPage from './admin/AdminTestimonialsPage'
import AdminFAQPage from './admin/AdminFAQPage'
import AdminTeamPage from './admin/AdminTeamPage'
import AdminPartnersPage from './admin/AdminPartnersPage'
import AdminAuditLogPage from './admin/AdminAuditLogPage'
import AdminPaymentsPage from './admin/AdminPaymentsPage'

interface NavItem {
  label: string
  page: PageName
  icon: React.ElementType
  badge?: string
}

const mainNav: NavItem[] = [
  { label: 'Dashboard', page: 'admin-dashboard', icon: LayoutDashboard },
  { label: 'Products', page: 'admin-products', icon: Package },
  { label: 'Categories', page: 'admin-categories', icon: FolderTree },
  { label: 'Banners', page: 'admin-banners', icon: Image },
  { label: 'Homepage Sections', page: 'admin-homepage', icon: LayoutGrid },
  { label: 'Menu Management', page: 'admin-menu', icon: Menu },
  { label: 'Orders', page: 'admin-orders', icon: ShoppingCart },
  { label: 'Payments', page: 'admin-payments', icon: Ticket },
  { label: 'Customers', page: 'admin-customers', icon: Users },
  { label: 'Reviews', page: 'admin-reviews', icon: Star },
  { label: 'Coupons', page: 'admin-coupons', icon: Ticket },
  { label: 'Policy Pages', page: 'admin-policy-pages', icon: FileText },
  { label: 'Media Library', page: 'admin-media', icon: Camera },
  { label: 'Testimonials', page: 'admin-testimonials', icon: MessageSquareQuote },
  { label: 'FAQ Management', page: 'admin-faq', icon: HelpCircle },
  { label: 'Team Members', page: 'admin-team', icon: UserCircle },
  { label: 'Partners', page: 'admin-partners', icon: Handshake },
  { label: 'Site Settings', page: 'admin-settings', icon: Settings },
  { label: 'Audit Log', page: 'admin-audit-log', icon: ClipboardList },
]

function renderPage(page: PageName) {
  switch (page) {
    case 'admin-dashboard':
      return <DashboardHome />
    case 'admin-products':
      return <AdminProductsPage />
    case 'admin-categories':
      return <AdminCategoriesPage />
    case 'admin-banners':
      return <AdminBannersPage />
    case 'admin-homepage':
      return <AdminHomepagePage />
    case 'admin-menu':
      return <AdminMenuPage />
    case 'admin-orders':
      return <AdminOrdersPage />
    case 'admin-payments':
      return <AdminPaymentsPage />
    case 'admin-customers':
      return <AdminCustomersPage />
    case 'admin-reviews':
      return <AdminReviewsPage />
    case 'admin-coupons':
      return <AdminCouponsPage />
    case 'admin-policy-pages':
      return <AdminPolicyPagesPage />
    case 'admin-settings':
      return <AdminSettingsPage />
    case 'admin-media':
      return <AdminMediaPage />
    case 'admin-testimonials':
      return <AdminTestimonialsPage />
    case 'admin-faq':
      return <AdminFAQPage />
    case 'admin-team':
      return <AdminTeamPage />
    case 'admin-partners':
      return <AdminPartnersPage />
    case 'admin-audit-log':
      return <AdminAuditLogPage />
    default:
      return <DashboardHome />
  }
}

function getPageTitle(page: PageName): string {
  const item = mainNav.find((n) => n.page === page)
  return item?.label ?? 'Dashboard'
}

interface NotificationItem {
  id: string
  isRead: boolean
}

function AdminNotificationBell() {
  const user = useAppStore((state) => state.user)
  const [unreadCount, setUnreadCount] = useState(0)

  useEffect(() => {
    async function fetchUnread() {
      try {
        const token = useAppStore.getState().accessToken
        const headers: Record<string, string> = {}
        if (token) headers['Authorization'] = `Bearer ${token}`
        const userId = user?.id || ''
        const res = await fetch(`/api/notifications?limit=50&userId=${userId}`, { headers })
        if (res.ok) {
          const data = await res.json()
          const items = extractItems<NotificationItem>(data)
          const count = items.filter((n) => !n.isRead).length
          setUnreadCount(count)
        }
      } catch {
        // silent
      }
    }
    fetchUnread()
    const interval = setInterval(fetchUnread, 30000)
    return () => clearInterval(interval)
  }, [user?.id])

  return (
    <Button variant="ghost" size="icon" className="relative" title="Notifications">
      <Bell className="size-4" />
      {unreadCount > 0 && (
        <span className="absolute -top-0.5 -right-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-destructive text-[10px] text-destructive-foreground animate-in zoom-in-50 duration-200">
          {unreadCount > 9 ? '9+' : unreadCount}
        </span>
      )}
    </Button>
  )
}

export default function AdminDashboardPage() {
  const { currentPage, navigate, user, siteConfig } = useAppStore()

  return (
    <SidebarProvider>
      <Sidebar side="left" variant="sidebar" collapsible="icon" className="border-r-0">
        <SidebarHeader className="bg-primary text-primary-foreground p-4">
          <div className="flex items-center gap-2 group-data-[collapsible=icon]:justify-center">
            {siteConfig?.logo ? (
              <img
                src={siteConfig.logo}
                alt="Khati Khadyo"
                className="h-8 w-auto object-contain rounded-md group-data-[collapsible=icon]:mx-auto"
              />
            ) : (
              <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary-foreground/20 text-primary-foreground font-bold text-sm">
                KK
              </div>
            )}
            <div className="group-data-[collapsible=icon]:hidden">
              <h2 className="text-sm font-bold leading-tight">Khati Khadyo</h2>
              <p className="text-xs text-primary-foreground/70">Admin Panel</p>
            </div>
          </div>
        </SidebarHeader>

        <SidebarSeparator className="bg-primary-foreground/20" />

        <SidebarContent className="bg-primary text-primary-foreground px-2">
          <SidebarGroup>
            <SidebarGroupLabel className="text-primary-foreground/60 group-data-[collapsible=icon]:hidden">
              Navigation
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {mainNav.map((item) => {
                  const isActive = currentPage === item.page
                  return (
                    <SidebarMenuItem key={item.page}>
                      <SidebarMenuButton
                        isActive={isActive}
                        onClick={() => navigate(item.page)}
                        tooltip={item.label}
                        className={`${
                          isActive
                            ? 'bg-primary-foreground/20 text-primary-foreground hover:bg-primary-foreground/30'
                            : 'text-primary-foreground/80 hover:bg-primary-foreground/10 hover:text-primary-foreground'
                        } transition-colors`}
                      >
                        <item.icon className="size-4" />
                        <span>{item.label}</span>
                        {item.badge && (
                          <Badge variant="secondary" className="ml-auto text-xs">
                            {item.badge}
                          </Badge>
                        )}
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  )
                })}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        </SidebarContent>

        <SidebarSeparator className="bg-primary-foreground/20" />

        <SidebarFooter className="bg-primary text-primary-foreground p-3">
          <div className="flex items-center gap-2 group-data-[collapsible=icon]:justify-center">
            {user?.avatar ? (
              <img
                src={user.avatar}
                alt="User"
                className="h-8 w-8 rounded-full object-cover"
              />
            ) : (
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary-foreground/20 text-xs font-medium">
                {user?.name?.charAt(0)?.toUpperCase() ?? 'A'}
              </div>
            )}
            <div className="group-data-[collapsible=icon]:hidden">
              <p className="text-xs font-medium truncate">
                {user?.name ?? 'Admin'}
              </p>
              <p className="text-xs text-primary-foreground/60 truncate">
                {user?.email ?? 'admin@khatikhadyo.com'}
              </p>
            </div>
          </div>
        </SidebarFooter>
      </Sidebar>

      <SidebarInset>
        <header className="flex h-14 items-center gap-3 border-b bg-background px-4 sticky top-0 z-20">
          <SidebarTrigger className="-ml-1" />
          <Separator orientation="vertical" className="h-6" />
          <h1 className="text-lg font-semibold">{getPageTitle(currentPage)}</h1>

          <div className="ml-auto flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate('home')}
              className="gap-1"
              title="Back to Site"
            >
              <ArrowLeft className="size-4" />
              <span className="hidden sm:inline text-sm">View Site</span>
            </Button>

            <AdminNotificationBell />

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="gap-2">
                  <div className="flex h-7 w-7 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-medium">
                    {user?.name?.charAt(0)?.toUpperCase() ?? 'A'}
                  </div>
                  <span className="hidden sm:inline text-sm">{user?.name ?? 'Admin'}</span>
                  <ChevronDown className="size-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => navigate('admin-settings')}>
                  <Settings className="mr-2 size-4" /> Settings
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => navigate('home')}>
                  <ArrowLeft className="mr-2 size-4" /> Back to Site
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        <div className="flex-1 overflow-auto p-4 md:p-6">
          {renderPage(currentPage)}
        </div>
      </SidebarInset>
    </SidebarProvider>
  )
}
