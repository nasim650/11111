'use client'

import { useEffect, useState } from 'react'
import {
  Users, Handshake, ShieldCheck, Leaf, Award, Heart,
  Truck, Clock, TrendingUp, Package, Star, ArrowRight
} from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { Button } from '@/components/ui/button'
import { useAppStore } from '@/lib/store'
import { extractItems } from '@/lib/api'

interface TeamMember {
  id: string
  name: string
  role: string
  bio?: string
  image?: string
  email?: string
}

interface Partner {
  id: string
  name: string
  logo?: string
  url?: string
}

interface PolicyPage {
  id: string
  title: string
  content: string
}

const stats = [
  { icon: Package, label: 'Products', value: '500+', color: 'from-primary to-emerald-600' },
  { icon: Users, label: 'Happy Customers', value: '10K+', color: 'from-secondary to-amber-600' },
  { icon: TrendingUp, label: 'Categories', value: '50+', color: 'from-teal-500 to-cyan-600' },
  { icon: Clock, label: 'Years of Trust', value: '5+', color: 'from-orange-500 to-red-500' },
]

const storyTimeline = [
  {
    year: '2019',
    title: 'The Beginning',
    description: 'Khati Khadyo started as a small online shop with a mission to bring authentic Bangladeshi food products to every household.',
  },
  {
    year: '2020',
    title: 'Growing Fast',
    description: 'Despite the challenges of the pandemic, we expanded our product range and started delivering across all major cities in Bangladesh.',
  },
  {
    year: '2021',
    title: 'Quality Promise',
    description: 'We launched our Quality Promise initiative, guaranteeing 100% authentic products sourced directly from trusted farmers and producers.',
  },
  {
    year: '2022',
    title: 'Nationwide Delivery',
    description: 'Achieved full nationwide delivery coverage across all 64 districts of Bangladesh with our growing logistics network.',
  },
  {
    year: '2023',
    title: 'Innovation & Growth',
    description: 'Introduced same-day delivery in Dhaka, launched our mobile app, and reached 10,000+ happy customers.',
  },
  {
    year: '2024',
    title: 'The Future',
    description: 'Expanding our product range, partnering with more local producers, and building a sustainable food supply chain for Bangladesh.',
  },
]

const qualityPromises = [
  { icon: ShieldCheck, title: '100% Authentic', desc: 'Every product is verified for authenticity before it reaches you.' },
  { icon: Leaf, title: 'Natural & Fresh', desc: 'No artificial preservatives. Products are sourced fresh from farms.' },
  { icon: Truck, title: 'Fast Delivery', desc: 'Same-day delivery in Dhaka, 2-3 days across Bangladesh.' },
  { icon: Award, title: 'Quality Certified', desc: 'All products meet BSTI and international quality standards.' },
]

export default function AboutPage() {
  const { navigate } = useAppStore()
  const [content, setContent] = useState<PolicyPage | null>(null)
  const [team, setTeam] = useState<TeamMember[]>([])
  const [partners, setPartners] = useState<Partner[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([
      fetch('/api/policy-pages/slug/about').then((r) => r.json()).catch(() => null),
      fetch('/api/team').then((r) => r.json()).catch(() => []),
      fetch('/api/partners').then((r) => r.json()).catch(() => []),
    ])
      .then(([pageData, teamData, partnerData]) => {
        if (pageData) {
          // API might return { data: PolicyPage } or just the page
          const page = (pageData as Record<string, unknown>)?.data
            ? ((pageData as Record<string, unknown>).data as PolicyPage)
            : pageData
          setContent(page as PolicyPage)
        }
        setTeam(extractItems<TeamMember>(teamData))
        setPartners(extractItems<Partner>(partnerData))
      })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-4xl space-y-6">
        <Skeleton className="h-10 w-64" />
        <Skeleton className="h-64 rounded-lg" />
      </div>
    )
  }

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary via-primary/95 to-primary/90 text-primary-foreground py-16 md:py-24 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-20 w-40 h-40 rounded-full bg-white/20 blur-3xl" />
          <div className="absolute bottom-10 right-10 w-60 h-60 rounded-full bg-secondary/30 blur-3xl" />
          <div className="absolute top-1/2 right-1/3 w-32 h-32 rounded-full bg-white/15 blur-2xl" />
        </div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-full px-4 py-2 mb-6">
              <Heart className="h-4 w-4 text-red-300" />
              <span className="text-sm font-medium">Since 2019</span>
            </div>
            <h1 className="text-3xl md:text-5xl font-bold mb-5">
              {content?.title || 'About Khati Khadyo'}
            </h1>
            <p className="text-lg md:text-xl opacity-90 max-w-2xl mx-auto leading-relaxed">
              Bringing the authentic taste of Bangladesh to your doorstep.
              We connect you with real, pure, and traditional food products from trusted local sources.
            </p>
          </div>
        </div>
      </section>

      {/* Stats Counter */}
      <section className="container mx-auto px-4 -mt-10 relative z-20 mb-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {stats.map((stat, idx) => (
            <Card key={idx} className="shadow-lg border-0 hover:shadow-xl transition-shadow duration-300">
              <CardContent className="p-5 text-center">
                <div className={`h-12 w-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center mx-auto mb-3 shadow-md`}>
                  <stat.icon className="h-6 w-6 text-white" />
                </div>
                <p className="text-2xl md:text-3xl font-bold text-primary">{stat.value}</p>
                <p className="text-sm text-muted-foreground mt-1">{stat.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Mission Statement */}
      <section className="container mx-auto px-4 py-12 max-w-4xl">
        <div className="bg-gradient-to-br from-primary/5 via-primary/10 to-secondary/5 rounded-2xl p-8 md:p-12 text-center">
          <Star className="h-10 w-10 text-secondary mx-auto mb-4" />
          <h2 className="text-2xl md:text-3xl font-bold mb-4">Our Mission</h2>
          <p className="text-muted-foreground leading-relaxed max-w-2xl mx-auto text-base">
            To connect Bangladeshi consumers with authentic, high-quality food products while supporting
            local farmers and producers. We are committed to quality, transparency, and sustainability in
            everything we do. Every product on our platform tells a story of tradition, care, and authenticity.
          </p>
        </div>
      </section>

      {/* Our Story Timeline */}
      <section className="container mx-auto px-4 py-12 max-w-4xl">
        <div className="text-center mb-10">
          <h2 className="text-2xl md:text-3xl font-bold">Our Story</h2>
          <p className="text-muted-foreground mt-2">The journey of Khati Khadyo</p>
        </div>
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-primary/20 -translate-x-1/2" />

          <div className="space-y-8">
            {storyTimeline.map((item, idx) => (
              <div key={idx} className={`relative flex items-start gap-6 ${idx % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'}`}>
                {/* Content */}
                <div className={`flex-1 ml-12 md:ml-0 ${idx % 2 === 0 ? 'md:text-right md:pr-10' : 'md:text-left md:pl-10'}`}>
                  <Card className="shadow-sm border-0 hover:shadow-md transition-shadow duration-300 inline-block">
                    <CardContent className="p-5">
                      <span className="text-xs font-bold text-primary bg-primary/10 px-2 py-1 rounded-full">
                        {item.year}
                      </span>
                      <h3 className="font-semibold mt-2 mb-1">{item.title}</h3>
                      <p className="text-sm text-muted-foreground">{item.description}</p>
                    </CardContent>
                  </Card>
                </div>

                {/* Dot */}
                <div className="absolute left-4 md:left-1/2 -translate-x-1/2 h-4 w-4 rounded-full bg-primary border-4 border-white shadow-md z-10" />

                {/* Spacer for opposite side */}
                <div className="flex-1 hidden md:block" />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Quality Promise */}
      <section className="bg-gradient-to-b from-muted/30 to-muted/50 py-12">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="text-center mb-10">
            <h2 className="text-2xl md:text-3xl font-bold">Our Quality Promise</h2>
            <p className="text-muted-foreground mt-2">What sets us apart from the rest</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {qualityPromises.map((promise, idx) => (
              <Card key={idx} className="shadow-sm border-0 hover:shadow-md transition-all duration-300 hover:-translate-y-1 group">
                <CardContent className="p-6 flex items-start gap-4">
                  <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0 group-hover:bg-primary group-hover:text-white transition-colors duration-300">
                    <promise.icon className="h-6 w-6 text-primary group-hover:text-white transition-colors duration-300" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">{promise.title}</h3>
                    <p className="text-sm text-muted-foreground">{promise.desc}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      {team.length > 0 && (
        <section className="container mx-auto px-4 py-12 max-w-4xl">
          <div className="text-center mb-10">
            <h2 className="text-2xl md:text-3xl font-bold flex items-center justify-center gap-2">
              <Users className="h-7 w-7 text-primary" />
              Meet Our Team
            </h2>
            <p className="text-muted-foreground mt-2">The passionate people behind Khati Khadyo</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {team.map((member) => (
              <Card
                key={member.id}
                className="text-center group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border-0 shadow-sm"
              >
                <CardContent className="p-6">
                  <div className="relative h-24 w-24 rounded-full bg-gradient-to-br from-primary/10 to-secondary/10 flex items-center justify-center text-primary text-3xl font-bold mx-auto mb-4 overflow-hidden border-4 border-white shadow-md group-hover:border-primary/20 transition-colors duration-300">
                    {member.image ? (
                      <img src={member.image} alt={member.name} className="h-full w-full rounded-full object-cover group-hover:scale-110 transition-transform duration-500" />
                    ) : (
                      <span>{member.name.charAt(0)}</span>
                    )}
                  </div>
                  <h3 className="font-semibold text-lg">{member.name}</h3>
                  <p className="text-sm text-primary font-medium">{member.role}</p>
                  {member.bio && (
                    <p className="text-xs text-muted-foreground mt-2 line-clamp-3 leading-relaxed">
                      {member.bio}
                    </p>
                  )}
                  {member.email && (
                    <p className="text-xs text-muted-foreground mt-2">{member.email}</p>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      )}

      {/* Partners Section */}
      {partners.length > 0 && (
        <section className="bg-gradient-to-b from-muted/30 to-muted/50 py-12">
          <div className="container mx-auto px-4 max-w-4xl">
            <div className="text-center mb-10">
              <h2 className="text-2xl md:text-3xl font-bold flex items-center justify-center gap-2">
                <Handshake className="h-7 w-7 text-primary" />
                Our Partners
              </h2>
              <p className="text-muted-foreground mt-2">Trusted brands we work with</p>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6">
              {partners.map((partner) => (
                <a
                  key={partner.id}
                  href={partner.url || '#'}
                  target={partner.url ? '_blank' : undefined}
                  rel="noopener noreferrer"
                  className="group"
                >
                  <Card className="flex items-center justify-center p-6 h-24 hover:shadow-md transition-all duration-300 border-0 shadow-sm grayscale group-hover:grayscale-0">
                    {partner.logo ? (
                      <img
                        src={partner.logo}
                        alt={partner.name}
                        className="h-10 object-contain group-hover:scale-110 transition-transform duration-300"
                      />
                    ) : (
                      <span className="font-semibold text-muted-foreground group-hover:text-primary transition-colors duration-300">
                        {partner.name}
                      </span>
                    )}
                  </Card>
                </a>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* CTA Section */}
      <section className="bg-gradient-to-br from-primary via-primary/95 to-primary text-primary-foreground py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl md:text-3xl font-bold mb-4">Ready to Experience Authentic Flavors?</h2>
          <p className="opacity-90 mb-8 max-w-lg mx-auto">
            Join thousands of happy customers who trust Khati Khadyo for their daily food essentials.
            Fresh, authentic, and delivered to your door.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button
              variant="secondary"
              size="lg"
              className="rounded-full px-8"
              onClick={() => navigate('products')}
            >
              Shop Now
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="rounded-full px-8 border-white/30 text-white hover:bg-white/10"
              onClick={() => navigate('contact')}
            >
              Contact Us
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
