'use client'

import { useState, useMemo } from 'react'
import { Eye, EyeOff, UserPlus, Mail, Phone, Lock, User, Check, X, AlertCircle, ChevronRight, Shield, ShieldCheck, BadgeCheck } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Checkbox } from '@/components/ui/checkbox'
import { Separator } from '@/components/ui/separator'
import { useAppStore } from '@/lib/store'
import { toast } from 'sonner'

function getPasswordStrength(password: string): { score: number; label: string; color: string; bgColor: string } {
  let score = 0
  if (password.length >= 6) score++
  if (password.length >= 8) score++
  if (/[A-Z]/.test(password)) score++
  if (/[0-9]/.test(password)) score++
  if (/[^A-Za-z0-9]/.test(password)) score++

  if (score <= 1) return { score: 20, label: 'Weak', color: 'bg-red-500', bgColor: 'bg-red-500/10' }
  if (score <= 2) return { score: 40, label: 'Fair', color: 'bg-orange-500', bgColor: 'bg-orange-500/10' }
  if (score <= 3) return { score: 60, label: 'Good', color: 'bg-yellow-500', bgColor: 'bg-yellow-500/10' }
  if (score <= 4) return { score: 80, label: 'Strong', color: 'bg-emerald-500', bgColor: 'bg-emerald-500/10' }
  return { score: 100, label: 'Very Strong', color: 'bg-emerald-600', bgColor: 'bg-emerald-600/10' }
}

export default function RegisterPage() {
  const { register, navigate, siteConfig } = useAppStore()
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [phone, setPhone] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [agreeTerms, setAgreeTerms] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [fieldErrors, setFieldErrors] = useState<Record<string, boolean>>({})
  const [registered, setRegistered] = useState(false)

  const passwordStrength = useMemo(() => getPasswordStrength(password), [password])
  const passwordsMatch = confirmPassword.length > 0 && password === confirmPassword
  const passwordsMismatch = confirmPassword.length > 0 && password !== confirmPassword

  const nameValid = name.trim().length >= 2
  const emailValid = email.trim() && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
  const phoneValid = phone.trim() && /^01[3-9]\d{8}$/.test(phone.trim())

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setFieldErrors({})
    if (!name.trim()) {
      setError('Please enter your name')
      setFieldErrors({ name: true })
      return
    }
    if (!email.trim() && !phone.trim()) {
      setError('Please enter your email or phone number')
      setFieldErrors({ email: true, phone: true })
      return
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters')
      setFieldErrors({ password: true })
      return
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match')
      setFieldErrors({ confirmPassword: true })
      return
    }
    if (!agreeTerms) {
      setError('Please agree to the Terms & Conditions')
      return
    }

    setLoading(true)
    try {
      await register({
        name: name.trim(),
        email: email.trim() || undefined,
        phone: phone.trim() || undefined,
        password,
      })
      setRegistered(true)
      toast.success('Registration successful!')
      setTimeout(() => {
        navigate('home')
      }, 2500)
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Registration failed'
      setError(message)
    } finally {
      setLoading(false)
    }
  }

  // Success Animation
  if (registered) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/5 to-emerald-50 relative overflow-hidden">
        {/* Animated background */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-[20%] left-[10%] w-48 h-48 rounded-full bg-primary/5 animate-pulse" style={{ animationDuration: '3s' }} />
          <div className="absolute bottom-[15%] right-[15%] w-32 h-32 rounded-full bg-secondary/5 animate-pulse" style={{ animationDuration: '4s' }} />
        </div>
        <div className="text-center p-8 relative z-10">
          <div className="w-24 h-24 rounded-full bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center mx-auto mb-6 shadow-2xl animate-in zoom-in-50 duration-500">
            <Check className="h-12 w-12 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-foreground mb-2">Welcome to Khati Khadyo!</h2>
          <p className="text-muted-foreground mb-6">Your account has been created successfully.</p>
          <p className="text-sm text-muted-foreground">Redirecting you to the homepage...</p>
          <div className="mt-4 flex justify-center gap-1">
            {[0, 1, 2].map((i) => (
              <div key={i} className="w-2 h-2 rounded-full bg-primary animate-pulse" style={{ animationDelay: `${i * 0.2}s` }} />
            ))}
          </div>
        </div>
      </div>
    )
  }

  // Step indicators with completed checkmarks
  const steps = [
    { num: 1, label: 'Personal Info', done: nameValid, icon: User },
    { num: 2, label: 'Contact', done: emailValid || phoneValid, icon: Mail },
    { num: 3, label: 'Security', done: password.length >= 6 && passwordsMatch, icon: Lock },
  ]
  const currentStep = !nameValid ? 1 : !(emailValid || phoneValid) ? 2 : 3

  return (
    <div className="min-h-screen flex relative">
      {/* Animated Background Pattern */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
        <svg className="absolute inset-0 w-full h-full opacity-[0.03]" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="reg-food-pattern" x="0" y="0" width="60" height="60" patternUnits="userSpaceOnUse">
              <circle cx="30" cy="30" r="8" fill="none" stroke="#2D6A4F" strokeWidth="1.5" />
              <path d="M30 22 L30 38 M22 30 L38 30" stroke="#2D6A4F" strokeWidth="0.5" opacity="0.5" />
            </pattern>
            <pattern id="reg-dot-pattern" x="0" y="0" width="30" height="30" patternUnits="userSpaceOnUse">
              <circle cx="15" cy="15" r="1" fill="#B8860B" opacity="0.4" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#reg-food-pattern)" />
          <rect width="100%" height="100%" fill="url(#reg-dot-pattern)" />
        </svg>
        <div className="absolute top-[10%] left-[10%] w-64 h-64 rounded-full border border-primary/10 animate-pulse" style={{ animationDuration: '4s' }} />
        <div className="absolute bottom-[20%] right-[10%] w-40 h-40 rounded-full border border-secondary/10 animate-pulse" style={{ animationDuration: '5s', animationDelay: '1s' }} />
      </div>

      {/* Decorative Left Panel */}
      <div className="hidden lg:flex lg:w-[45%] bg-gradient-to-br from-emerald-800 via-primary to-primary relative overflow-hidden z-10">
        {/* Animated background pattern */}
        <div className="absolute inset-0 opacity-10">
          <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="leaf-reg-pattern" x="0" y="0" width="80" height="80" patternUnits="userSpaceOnUse">
                <path d="M40 10 C50 25, 55 40, 40 70 C25 40, 30 25, 40 10Z" fill="none" stroke="white" strokeWidth="1" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#leaf-reg-pattern)" />
          </svg>
          <div className="absolute top-16 right-16 w-40 h-40 rounded-full border-4 border-white animate-pulse" style={{ animationDuration: '3s' }} />
          <div className="absolute bottom-32 left-16 w-32 h-32 rounded-full border-4 border-white animate-pulse" style={{ animationDuration: '4s', animationDelay: '1s' }} />
          <div className="absolute top-1/2 right-1/3 w-24 h-24 rounded-full bg-white/20 animate-bounce" style={{ animationDuration: '5s' }} />
        </div>

        {/* Floating food icons */}
        <div className="absolute top-24 left-12 text-5xl opacity-20 animate-bounce" style={{ animationDuration: '3.2s' }}>🥘</div>
        <div className="absolute top-1/2 right-16 text-4xl opacity-20 animate-bounce" style={{ animationDuration: '4s', animationDelay: '0.8s' }}>🌿</div>
        <div className="absolute bottom-1/3 left-1/4 text-4xl opacity-20 animate-bounce" style={{ animationDuration: '3.8s', animationDelay: '1.2s' }}>🍯</div>
        <div className="absolute bottom-20 right-20 text-5xl opacity-20 animate-bounce" style={{ animationDuration: '4.2s', animationDelay: '0.3s' }}>🫒</div>

        <div className="relative z-10 flex flex-col justify-center items-center px-12 text-white">
          <div className="w-24 h-24 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center mb-8 shadow-2xl ring-1 ring-white/20">
            <span className="text-5xl font-bold text-secondary">KK</span>
          </div>
          <h1 className="text-4xl font-bold mb-2">Join Khati Khadyo</h1>
          <p className="text-white/80 text-lg mb-10 text-center">
            Create an account and start exploring authentic Bangladeshi food products
          </p>

          {/* Registration Steps Progress with Checkmarks */}
          <div className="w-full max-w-sm space-y-6">
            {steps.map((step, i) => {
              const StepIcon = step.icon
              return (
                <div key={step.num} className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-sm font-bold transition-all duration-500 ${
                    step.done
                      ? 'bg-secondary text-white shadow-lg shadow-secondary/30 scale-105'
                      : currentStep === step.num
                      ? 'bg-white/20 backdrop-blur-sm text-white ring-2 ring-white/40'
                      : 'bg-white/10 text-white/40'
                  }`}>
                    {step.done ? <Check className="h-6 w-6" /> : <StepIcon className="h-5 w-5" />}
                  </div>
                  <div className="flex-1">
                    <p className={`text-sm font-medium transition-colors ${step.done ? 'text-white' : currentStep === step.num ? 'text-white' : 'text-white/40'}`}>
                      {step.label}
                    </p>
                    <div className="h-2 rounded-full bg-white/10 mt-2 overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-700 ease-out ${step.done ? 'bg-secondary w-full' : currentStep === step.num ? 'bg-white/40 w-1/2' : 'w-0'}`}
                      />
                    </div>
                  </div>
                  {i < steps.length - 1 && (
                    <ChevronRight className={`h-5 w-5 transition-colors ${step.done ? 'text-secondary' : 'text-white/20'}`} />
                  )}
                </div>
              )
            })}
          </div>

          {/* Trust Badges with Lucide Icons */}
          <div className="mt-12 flex items-center gap-6 text-white/60 text-xs">
            <div className="flex items-center gap-1.5">
              <div className="w-8 h-8 rounded-lg bg-white/10 backdrop-blur-sm flex items-center justify-center">
                <Shield className="h-4 w-4 text-white/70" />
              </div>
              <span>Secure</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-8 h-8 rounded-lg bg-white/10 backdrop-blur-sm flex items-center justify-center">
                <ShieldCheck className="h-4 w-4 text-white/70" />
              </div>
              <span>Private</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-8 h-8 rounded-lg bg-white/10 backdrop-blur-sm flex items-center justify-center">
                <BadgeCheck className="h-4 w-4 text-white/70" />
              </div>
              <span>Verified</span>
            </div>
          </div>
        </div>
      </div>

      {/* Right Panel - Registration Form */}
      <div className="w-full lg:w-[55%] flex flex-col relative z-10">
        {/* Mobile Top Banner */}
        <div className="lg:hidden bg-gradient-to-r from-primary to-emerald-700 p-6 text-white text-center relative overflow-hidden">
          <div className="absolute inset-0 opacity-10">
            <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="mobile-reg-pattern" x="0" y="0" width="40" height="40" patternUnits="userSpaceOnUse">
                  <circle cx="20" cy="20" r="5" fill="none" stroke="white" strokeWidth="1" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#mobile-reg-pattern)" />
            </svg>
          </div>
          <div className="relative">
            <div className="w-14 h-14 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center mx-auto mb-3 shadow-lg">
              <span className="text-2xl font-bold text-secondary">KK</span>
            </div>
            <h1 className="text-xl font-bold">Join Khati Khadyo</h1>
            <p className="text-white/70 text-sm mt-1">Create your account today</p>
          </div>
        </div>

        {/* Form Container */}
        <div className="flex-1 flex items-center justify-center p-6 sm:p-8">
          <div className="w-full max-w-md">
            {/* Glassmorphism Form Card */}
            <div className="bg-white/70 backdrop-blur-xl rounded-2xl shadow-xl ring-1 ring-white/50 p-8">
              <div className="mb-8 text-center">
                {siteConfig?.logo && (
                  <div className="flex justify-center mb-4">
                    <img
                      src={siteConfig.logo}
                      alt="Khati Khadyo"
                      className="h-12 w-auto object-contain"
                    />
                  </div>
                )}
                <h2 className="text-2xl font-bold text-foreground">Create Account</h2>
                <p className="text-muted-foreground mt-1">Join Khati Khadyo for the best authentic food experience</p>
              </div>

              {/* Error Message */}
              {error && (
                <div className="mb-6 p-4 rounded-xl bg-red-50 border-2 border-red-200 flex items-start gap-3 animate-in fade-in slide-in-from-top-2 duration-300">
                  <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-semibold text-red-800">Registration Failed</p>
                    <p className="text-sm text-red-600 mt-0.5">{error}</p>
                  </div>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Full Name */}
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-sm font-medium flex items-center gap-1.5">
                    Full Name <span className="text-red-500">*</span>
                    {nameValid && <Check className="h-3.5 w-3.5 text-emerald-500" />}
                  </Label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="name"
                      placeholder="Your full name"
                      value={name}
                      onChange={(e) => { setName(e.target.value); setFieldErrors(prev => ({ ...prev, name: false })) }}
                      className={`pl-10 h-11 transition-colors ${fieldErrors.name ? 'border-red-400 ring-2 ring-red-100 focus-visible:ring-red-200' : nameValid ? 'border-emerald-300 focus-visible:ring-emerald-200' : 'focus-visible:ring-primary/20'}`}
                    />
                  </div>
                </div>

                {/* Email */}
                <div className="space-y-2">
                  <Label htmlFor="reg-email" className="text-sm font-medium flex items-center gap-1.5">
                    Email Address
                    {emailValid && <Check className="h-3.5 w-3.5 text-emerald-500" />}
                  </Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="reg-email"
                      type="email"
                      placeholder="your@email.com"
                      value={email}
                      onChange={(e) => { setEmail(e.target.value); setFieldErrors(prev => ({ ...prev, email: false })) }}
                      className={`pl-10 h-11 transition-colors ${fieldErrors.email ? 'border-red-400 ring-2 ring-red-100 focus-visible:ring-red-200' : emailValid ? 'border-emerald-300 focus-visible:ring-emerald-200' : 'focus-visible:ring-primary/20'}`}
                    />
                  </div>
                </div>

                {/* Phone */}
                <div className="space-y-2">
                  <Label htmlFor="reg-phone" className="text-sm font-medium flex items-center gap-1.5">
                    Phone Number
                    {phoneValid && <Check className="h-3.5 w-3.5 text-emerald-500" />}
                  </Label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="reg-phone"
                      type="tel"
                      placeholder="01XXXXXXXXX"
                      value={phone}
                      onChange={(e) => { setPhone(e.target.value); setFieldErrors(prev => ({ ...prev, phone: false })) }}
                      className={`pl-10 h-11 transition-colors ${fieldErrors.phone ? 'border-red-400 ring-2 ring-red-100 focus-visible:ring-red-200' : phoneValid ? 'border-emerald-300 focus-visible:ring-emerald-200' : 'focus-visible:ring-primary/20'}`}
                    />
                  </div>
                </div>

                {/* Password */}
                <div className="space-y-2">
                  <Label htmlFor="reg-password" className="text-sm font-medium flex items-center gap-1.5">
                    Password <span className="text-red-500">*</span>
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="reg-password"
                      type={showPassword ? 'text' : 'password'}
                      placeholder="Min. 6 characters"
                      value={password}
                      onChange={(e) => { setPassword(e.target.value); setFieldErrors(prev => ({ ...prev, password: false })) }}
                      className={`pl-10 pr-10 h-11 transition-colors ${fieldErrors.password ? 'border-red-400 ring-2 ring-red-100 focus-visible:ring-red-200' : 'focus-visible:ring-primary/20'}`}
                    />
                    <button
                      type="button"
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                  {/* Password Strength Indicator with Color-Coded Bar */}
                  {password.length > 0 && (
                    <div className="space-y-2">
                      <div className="flex gap-1">
                        {[20, 40, 60, 80, 100].map((level) => (
                          <div
                            key={level}
                            className={`h-1.5 flex-1 rounded-full transition-all duration-500 ${
                              passwordStrength.score >= level
                                ? passwordStrength.color
                                : 'bg-gray-200'
                            }`}
                          />
                        ))}
                      </div>
                      <div className="flex items-center justify-between">
                        <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${passwordStrength.bgColor} ${
                          passwordStrength.label === 'Weak' ? 'text-red-600' :
                          passwordStrength.label === 'Fair' ? 'text-orange-600' :
                          passwordStrength.label === 'Good' ? 'text-yellow-700' :
                          passwordStrength.label === 'Strong' ? 'text-emerald-600' :
                          'text-emerald-700'
                        }`}>
                          {passwordStrength.label}
                        </span>
                        <span className="text-xs text-muted-foreground">{password.length}/6+ chars</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Confirm Password */}
                <div className="space-y-2">
                  <Label htmlFor="confirm-password" className="text-sm font-medium flex items-center gap-1.5">
                    Confirm Password <span className="text-red-500">*</span>
                    {passwordsMatch && <Check className="h-3.5 w-3.5 text-emerald-500" />}
                    {passwordsMismatch && <X className="h-3.5 w-3.5 text-red-500" />}
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="confirm-password"
                      type={showConfirmPassword ? 'text' : 'password'}
                      placeholder="Confirm your password"
                      value={confirmPassword}
                      onChange={(e) => { setConfirmPassword(e.target.value); setFieldErrors(prev => ({ ...prev, confirmPassword: false })) }}
                      className={`pl-10 pr-10 h-11 transition-colors ${
                        fieldErrors.confirmPassword ? 'border-red-400 ring-2 ring-red-100 focus-visible:ring-red-200' :
                        passwordsMatch ? 'border-emerald-300 focus-visible:ring-emerald-200' :
                        passwordsMismatch ? 'border-red-300 focus-visible:ring-red-200' : 'focus-visible:ring-primary/20'
                      }`}
                    />
                    <button
                      type="button"
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    >
                      {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                  {passwordsMismatch && (
                    <p className="text-xs text-red-500 flex items-center gap-1">
                      <X className="h-3 w-3" /> Passwords do not match
                    </p>
                  )}
                </div>

                {/* Terms & Conditions */}
                <div className="flex items-start gap-2.5 pt-1">
                  <Checkbox
                    id="terms"
                    checked={agreeTerms}
                    onCheckedChange={(checked) => setAgreeTerms(checked === true)}
                    className="mt-0.5 data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                  />
                  <Label htmlFor="terms" className="text-sm text-muted-foreground cursor-pointer leading-relaxed">
                    I agree to the{' '}
                    <button
                      type="button"
                      className="text-primary hover:underline font-semibold"
                      onClick={() => navigate('terms')}
                    >
                      Terms & Conditions
                    </button>
                    {' '}and{' '}
                    <button
                      type="button"
                      className="text-primary hover:underline font-semibold"
                      onClick={() => navigate('privacy')}
                    >
                      Privacy Policy
                    </button>
                  </Label>
                </div>

                {/* Submit Button */}
                <Button type="submit" className="w-full h-12 text-base font-semibold rounded-xl shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-primary/30 transition-all" disabled={loading}>
                  {loading ? (
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white" />
                  ) : (
                    <>
                      <UserPlus className="h-5 w-5 mr-2" />
                      Create Account
                    </>
                  )}
                </Button>
              </form>

              {/* Sign In Link */}
              <div className="mt-6 pt-5 border-t">
                <p className="text-center text-sm text-muted-foreground">
                  Already have an account?{' '}
                  <button
                    type="button"
                    className="text-primary hover:underline font-semibold inline-flex items-center gap-1 group"
                    onClick={() => navigate('login')}
                  >
                    Sign In
                    <span className="inline-block group-hover:translate-x-0.5 transition-transform">&rarr;</span>
                  </button>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
