'use client'

import { useEffect, useState, useCallback } from 'react'
import {
  SlidersHorizontal, Grid3X3, List, ChevronRight, ChevronLeft, ChevronDown,
  X, Home, Search, Package, ShoppingBag, Leaf
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Checkbox } from '@/components/ui/checkbox'
import { Label } from '@/components/ui/label'
import { Slider } from '@/components/ui/slider'
import { Skeleton } from '@/components/ui/skeleton'
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger, SheetDescription } from '@/components/ui/sheet'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbSeparator } from '@/components/ui/breadcrumb'
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible'
import { useAppStore } from '@/lib/store'
import { extractItems, extractPagination } from '@/lib/api'
import ProductCard from '@/components/shared/ProductCard'

interface Product {
  id: string
  name: string
  slug: string
  price: number
  discountPrice?: number | null
  unit: string
  stock: number
  images?: Array<{ url: string; alt?: string }>
  category?: { name: string; slug: string }
  status?: string
  isNewArrival?: boolean
  isBestSeller?: boolean
}

interface Category {
  id: string
  name: string
  slug: string
}

export default function ProductsPage() {
  const { navigate, pageParams, searchQuery, setSearchQuery, selectedCategory, setSelectedCategory } = useAppStore()
  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [totalProducts, setTotalProducts] = useState(0)
  const [sort, setSort] = useState('latest')
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 10000])
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])
  const [statusFilter, setStatusFilter] = useState<string>('active')
  const [filterOpen, setFilterOpen] = useState(false)
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [categoryOpen, setCategoryOpen] = useState(true)
  const [priceOpen, setPriceOpen] = useState(true)
  const [availabilityOpen, setAvailabilityOpen] = useState(true)

  // Initialize from page params
  useEffect(() => {
    if (pageParams?.category) {
      setSelectedCategories([String(pageParams.category)])
      setSelectedCategory(String(pageParams.category))
    }
    if (pageParams?.sort) {
      setSort(String(pageParams.sort))
    }
    if (pageParams?.search || searchQuery) {
      setSearchQuery(String(pageParams.search || searchQuery))
    }
  }, [pageParams, searchQuery, setSearchQuery, setSelectedCategory])

  // Load categories
  useEffect(() => {
    fetch('/api/categories')
      .then((res) => res.json())
      .then((data) => {
        const cats = extractItems<Category>(data)
        setCategories(cats)
      })
      .catch(() => {})
  }, [])

  const loadProducts = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      params.set('page', String(page))
      params.set('limit', '12')
      params.set('status', statusFilter)

      if (sort === 'latest') params.set('sort', 'latest')
      else if (sort === 'price-low') params.set('sort', 'price_asc')
      else if (sort === 'price-high') params.set('sort', 'price_desc')
      else if (sort === 'best-selling') params.set('sort', 'best_selling')

      if (selectedCategories.length > 0) {
        params.set('category', selectedCategories[0])
      }
      if (priceRange[0] > 0) params.set('minPrice', String(priceRange[0]))
      if (priceRange[1] < 10000) params.set('maxPrice', String(priceRange[1]))
      if (searchQuery) params.set('search', searchQuery)

      const res = await fetch(`/api/products?${params.toString()}`)
      if (!res.ok) throw new Error('Failed to load products')
      const data = await res.json()

      const prods = extractItems<Product>(data)
      const pagination = extractPagination(data)
      setProducts(prods)
      setTotalPages(pagination.totalPages || Math.ceil(prods.length / 12) || 1)
      setTotalProducts(pagination.total || prods.length)
    } catch (error) {
      console.error('Failed to load products:', error)
      setProducts([])
    } finally {
      setLoading(false)
    }
  }, [page, sort, selectedCategories, priceRange, statusFilter, searchQuery])

  useEffect(() => {
    loadProducts()
  }, [loadProducts])

  const toggleCategory = (slug: string) => {
    setSelectedCategories((prev) =>
      prev.includes(slug) ? prev.filter((c) => c !== slug) : [slug]
    )
    setPage(1)
  }

  const clearFilters = () => {
    setSelectedCategories([])
    setPriceRange([0, 10000])
    setStatusFilter('active')
    setSort('latest')
    setSearchQuery('')
    setSelectedCategory('')
    setPage(1)
  }

  const activeCategory = selectedCategories.length > 0
    ? categories.find((c) => c.slug === selectedCategories[0])
    : null

  const activeFilterCount = selectedCategories.length + (searchQuery ? 1 : 0) + (priceRange[0] > 0 || priceRange[1] < 10000 ? 1 : 0) + (statusFilter !== 'active' ? 1 : 0)

  // Pagination helpers
  const getPageNumbers = () => {
    const pages: (number | string)[] = []
    if (totalPages <= 7) {
      for (let i = 1; i <= totalPages; i++) pages.push(i)
    } else {
      pages.push(1)
      if (page > 3) pages.push('...')
      const start = Math.max(2, page - 1)
      const end = Math.min(totalPages - 1, page + 1)
      for (let i = start; i <= end; i++) pages.push(i)
      if (page < totalPages - 2) pages.push('...')
      pages.push(totalPages)
    }
    return pages
  }

  const FilterContent = () => (
    <div className="space-y-1">
      {/* Category Filter - Collapsible */}
      <Collapsible open={categoryOpen} onOpenChange={setCategoryOpen}>
        <CollapsibleTrigger className="flex items-center justify-between w-full py-3 px-1 hover:bg-muted/50 rounded-lg transition-colors">
          <span className="font-semibold text-sm flex items-center gap-2">
            <ShoppingBag className="h-4 w-4 text-primary" />
            Categories
          </span>
          <ChevronDown className={`h-4 w-4 text-muted-foreground transition-transform duration-300 ${categoryOpen ? 'rotate-180' : ''}`} />
        </CollapsibleTrigger>
        <CollapsibleContent className="overflow-hidden transition-all duration-300 data-[state=closed]:animate-collapsible-up data-[state=open]:animate-collapsible-down">
          <div className="space-y-2.5 pb-3 px-1">
            {categories.map((cat) => (
              <div key={cat.id} className="flex items-center gap-2.5 group">
                <Checkbox
                  id={`cat-${cat.id}`}
                  checked={selectedCategories.includes(cat.slug)}
                  onCheckedChange={() => toggleCategory(cat.slug)}
                  className="transition-colors"
                />
                <Label htmlFor={`cat-${cat.id}`} className="text-sm cursor-pointer group-hover:text-primary transition-colors flex-1">
                  {cat.name}
                </Label>
                {selectedCategories.includes(cat.slug) && (
                  <Badge variant="secondary" className="text-[10px] h-5 px-1.5 bg-primary/10 text-primary">
                    ✓
                  </Badge>
                )}
              </div>
            ))}
          </div>
        </CollapsibleContent>
      </Collapsible>

      {/* Price Range - Collapsible */}
      <Collapsible open={priceOpen} onOpenChange={setPriceOpen}>
        <CollapsibleTrigger className="flex items-center justify-between w-full py-3 px-1 hover:bg-muted/50 rounded-lg transition-colors">
          <span className="font-semibold text-sm flex items-center gap-2">
            <span className="text-primary font-bold">৳</span>
            Price Range
          </span>
          <ChevronDown className={`h-4 w-4 text-muted-foreground transition-transform duration-300 ${priceOpen ? 'rotate-180' : ''}`} />
        </CollapsibleTrigger>
        <CollapsibleContent className="overflow-hidden transition-all duration-300 data-[state=closed]:animate-collapsible-up data-[state=open]:animate-collapsible-down">
          <div className="pb-3 px-1 space-y-3">
            <Slider
              value={priceRange}
              min={0}
              max={10000}
              step={100}
              onValueChange={(val) => setPriceRange(val as [number, number])}
              className="mt-2"
            />
            <div className="flex items-center justify-between gap-2">
              <div className="bg-muted/50 rounded-md px-2 py-1.5 text-xs font-medium text-center flex-1">
                ৳{priceRange[0].toLocaleString()}
              </div>
              <span className="text-muted-foreground text-xs">—</span>
              <div className="bg-muted/50 rounded-md px-2 py-1.5 text-xs font-medium text-center flex-1">
                ৳{priceRange[1].toLocaleString()}
              </div>
            </div>
          </div>
        </CollapsibleContent>
      </Collapsible>

      {/* Availability - Collapsible */}
      <Collapsible open={availabilityOpen} onOpenChange={setAvailabilityOpen}>
        <CollapsibleTrigger className="flex items-center justify-between w-full py-3 px-1 hover:bg-muted/50 rounded-lg transition-colors">
          <span className="font-semibold text-sm flex items-center gap-2">
            <Package className="h-4 w-4 text-primary" />
            Availability
          </span>
          <ChevronDown className={`h-4 w-4 text-muted-foreground transition-transform duration-300 ${availabilityOpen ? 'rotate-180' : ''}`} />
        </CollapsibleTrigger>
        <CollapsibleContent className="overflow-hidden transition-all duration-300 data-[state=closed]:animate-collapsible-up data-[state=open]:animate-collapsible-down">
          <div className="pb-3 px-1">
            <Select value={statusFilter} onValueChange={(val) => { setStatusFilter(val); setPage(1) }}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="active">In Stock</SelectItem>
                <SelectItem value="all">All</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CollapsibleContent>
      </Collapsible>

      <div className="pt-2">
        <Button variant="outline" className="w-full hover:bg-red-50 hover:text-red-600 hover:border-red-200 transition-colors" onClick={clearFilters}>
          Clear All Filters
        </Button>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen">
      {/* Hero Banner */}
      <div className="relative bg-gradient-to-br from-[#2D6A4F] via-[#1B4332] to-[#2D6A4F] overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-64 h-64 bg-white rounded-full -translate-x-1/2 -translate-y-1/2" />
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-white rounded-full translate-x-1/3 translate-y-1/3" />
          <div className="absolute top-1/2 left-1/3 w-32 h-32 bg-white rounded-full" />
        </div>
        <div className="relative container mx-auto px-4 py-10 md:py-14 text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Leaf className="h-5 w-5 text-emerald-300" />
            <span className="text-emerald-200 text-sm font-medium tracking-wider uppercase">সবচেয়ে ভালো দামে খাঁটি খাদ্য</span>
            <Leaf className="h-5 w-5 text-emerald-300" />
          </div>
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-3">
            Our Products
          </h1>
          <p className="text-emerald-100/80 text-base md:text-lg max-w-xl mx-auto">
            Discover our curated collection of authentic Bangladeshi food products, sourced directly from trusted farmers and producers
          </p>
        </div>
      </div>

      {/* Breadcrumb */}
      <div className="bg-muted/30 py-3 border-b">
        <div className="container mx-auto px-4">
          <Breadcrumb>
            <BreadcrumbList>
              <BreadcrumbItem>
                <BreadcrumbLink onClick={() => navigate('home')} className="cursor-pointer flex items-center gap-1">
                  <Home className="h-3.5 w-3.5" />
                  Home
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbLink>Products</BreadcrumbLink>
              </BreadcrumbItem>
              {activeCategory && (
                <>
                  <BreadcrumbSeparator />
                  <BreadcrumbItem>
                    <BreadcrumbLink>{activeCategory.name}</BreadcrumbLink>
                  </BreadcrumbItem>
                </>
              )}
            </BreadcrumbList>
          </Breadcrumb>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        <div className="flex gap-6">
          {/* Desktop Sidebar */}
          <aside className="hidden lg:block w-72 flex-shrink-0">
            <div className="sticky top-4 bg-background border rounded-xl p-5 shadow-sm">
              <h2 className="font-bold text-lg mb-4 flex items-center gap-2">
                <SlidersHorizontal className="h-5 w-5 text-primary" />
                Filters
                {activeFilterCount > 0 && (
                  <Badge className="ml-auto bg-primary text-primary-foreground text-xs h-5 min-w-[20px] flex items-center justify-center">
                    {activeFilterCount}
                  </Badge>
                )}
              </h2>
              <FilterContent />
            </div>
          </aside>

          {/* Main Content */}
          <div className="flex-1 min-w-0">
            {/* Top bar */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-5 gap-3">
              <div className="flex items-center gap-3">
                {/* Mobile filter button */}
                <Sheet open={filterOpen} onOpenChange={setFilterOpen}>
                  <SheetTrigger asChild>
                    <Button variant="outline" className="lg:hidden rounded-lg">
                      <SlidersHorizontal className="h-4 w-4 mr-2" />
                      Filters
                      {activeFilterCount > 0 && (
                        <Badge className="ml-2 bg-primary text-primary-foreground text-[10px] h-4 min-w-[16px] px-1">
                          {activeFilterCount}
                        </Badge>
                      )}
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="left">
                    <SheetHeader>
                      <SheetTitle className="flex items-center gap-2">
                        <SlidersHorizontal className="h-5 w-5 text-primary" />
                        Filters
                      </SheetTitle>
                      <SheetDescription className="sr-only">Filter products by category, price, and availability</SheetDescription>
                    </SheetHeader>
                    <div className="mt-4">
                      <FilterContent />
                    </div>
                  </SheetContent>
                </Sheet>
                <span className="text-sm text-muted-foreground">
                  Showing <span className="font-semibold text-foreground">{products.length}</span> of <span className="font-semibold text-foreground">{totalProducts}</span> products
                </span>
              </div>

              <div className="flex items-center gap-2">
                {/* View Toggle */}
                <div className="hidden sm:flex items-center border rounded-lg overflow-hidden">
                  <button
                    className={`h-9 w-9 flex items-center justify-center transition-colors ${viewMode === 'grid' ? 'bg-primary text-primary-foreground' : 'hover:bg-muted'}`}
                    onClick={() => setViewMode('grid')}
                    aria-label="Grid view"
                  >
                    <Grid3X3 className="h-4 w-4" />
                  </button>
                  <button
                    className={`h-9 w-9 flex items-center justify-center transition-colors ${viewMode === 'list' ? 'bg-primary text-primary-foreground' : 'hover:bg-muted'}`}
                    onClick={() => setViewMode('list')}
                    aria-label="List view"
                  >
                    <List className="h-4 w-4" />
                  </button>
                </div>
                <Select value={sort} onValueChange={(val) => { setSort(val); setPage(1) }}>
                  <SelectTrigger className="w-[180px] rounded-lg">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="latest">Latest</SelectItem>
                    <SelectItem value="price-low">Price: Low to High</SelectItem>
                    <SelectItem value="price-high">Price: High to Low</SelectItem>
                    <SelectItem value="best-selling">Best Selling</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Active filter badges */}
            {(selectedCategories.length > 0 || searchQuery || priceRange[0] > 0 || priceRange[1] < 10000 || statusFilter !== 'active') && (
              <div className="flex flex-wrap gap-2 mb-5 p-3 bg-muted/30 rounded-lg border">
                <span className="text-xs text-muted-foreground font-medium self-center mr-1">Active filters:</span>
                {selectedCategories.map((slug) => {
                  const cat = categories.find((c) => c.slug === slug)
                  return (
                    <Badge key={slug} variant="secondary" className="gap-1 bg-primary/10 text-primary hover:bg-primary/20 transition-colors cursor-default">
                      {cat?.name || slug}
                      <X className="h-3 w-3 cursor-pointer hover:text-red-500" onClick={() => toggleCategory(slug)} />
                    </Badge>
                  )
                })}
                {searchQuery && (
                  <Badge variant="secondary" className="gap-1 bg-primary/10 text-primary hover:bg-primary/20 transition-colors cursor-default">
                    <Search className="h-3 w-3" />
                    {searchQuery}
                    <X
                      className="h-3 w-3 cursor-pointer hover:text-red-500"
                      onClick={() => { setSearchQuery(''); setPage(1) }}
                    />
                  </Badge>
                )}
                {(priceRange[0] > 0 || priceRange[1] < 10000) && (
                  <Badge variant="secondary" className="gap-1 bg-secondary/10 text-secondary hover:bg-secondary/20 transition-colors cursor-default">
                    ৳{priceRange[0]} - ৳{priceRange[1]}
                    <X className="h-3 w-3 cursor-pointer hover:text-red-500" onClick={() => { setPriceRange([0, 10000]); setPage(1) }} />
                  </Badge>
                )}
                {statusFilter !== 'active' && (
                  <Badge variant="secondary" className="gap-1 bg-primary/10 text-primary hover:bg-primary/20 transition-colors cursor-default">
                    All (incl. out of stock)
                    <X className="h-3 w-3 cursor-pointer hover:text-red-500" onClick={() => { setStatusFilter('active'); setPage(1) }} />
                  </Badge>
                )}
                <Button variant="ghost" size="sm" className="h-6 text-xs text-red-500 hover:text-red-600 hover:bg-red-50" onClick={clearFilters}>
                  Clear all
                </Button>
              </div>
            )}

            {/* Products Grid / List */}
            {loading ? (
              <div className={viewMode === 'grid' ? 'grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 gap-4' : 'space-y-4'}>
                {Array.from({ length: 12 }).map((_, i) => (
                  <Skeleton key={i} className={viewMode === 'grid' ? 'h-72 rounded-xl' : 'h-28 rounded-xl'} />
                ))}
              </div>
            ) : products.length === 0 ? (
              <div className="text-center py-20 px-4">
                <div className="w-24 h-24 rounded-full bg-muted/50 flex items-center justify-center mx-auto mb-6">
                  <Search className="h-10 w-10 text-muted-foreground/40" />
                </div>
                <h3 className="text-xl font-bold mb-2">No products found</h3>
                <p className="text-muted-foreground mb-6 max-w-sm mx-auto">
                  We couldn&apos;t find any products matching your current filters. Try adjusting your search or filter criteria.
                </p>
                <div className="flex flex-col sm:flex-row gap-3 justify-center">
                  <Button onClick={clearFilters} className="rounded-lg">
                    Clear All Filters
                  </Button>
                  <Button variant="outline" onClick={() => navigate('home')} className="rounded-lg">
                    Back to Home
                  </Button>
                </div>
              </div>
            ) : (
              <div className={viewMode === 'grid'
                ? 'grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 gap-4'
                : 'space-y-3'
              }>
                {products.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            )}

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex items-center justify-center gap-1.5 mt-10">
                <Button
                  variant="outline"
                  size="sm"
                  className="h-9 gap-1 rounded-lg"
                  disabled={page <= 1}
                  onClick={() => setPage((p) => p - 1)}
                >
                  <ChevronLeft className="h-4 w-4" />
                  <span className="hidden sm:inline">Prev</span>
                </Button>
                <div className="flex items-center gap-1">
                  {getPageNumbers().map((pageNum, idx) => (
                    typeof pageNum === 'number' ? (
                      <Button
                        key={`page-${pageNum}`}
                        variant={page === pageNum ? 'default' : 'outline'}
                        size="sm"
                        className={`h-9 w-9 rounded-lg ${page === pageNum ? 'shadow-md' : ''}`}
                        onClick={() => setPage(pageNum)}
                      >
                        {pageNum}
                      </Button>
                    ) : (
                      <span key={`dots-${idx}`} className="px-1 text-muted-foreground">…</span>
                    )
                  ))}
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  className="h-9 gap-1 rounded-lg"
                  disabled={page >= totalPages}
                  onClick={() => setPage((p) => p + 1)}
                >
                  <span className="hidden sm:inline">Next</span>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
