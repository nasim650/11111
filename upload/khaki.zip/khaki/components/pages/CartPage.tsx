'use client'

import { useEffect, useReducer, useState } from 'react'
import Image from 'next/image'
import {
  Minus, Plus, Trash2, ShoppingCart, Tag, ArrowRight, ArrowLeft,
  ShieldCheck, Truck, Clock, ShoppingBag, Heart, X, AlertTriangle,
  Package, Home, ChevronRight, Gift, BadgeCheck
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { Badge } from '@/components/ui/badge'
import { Label } from '@/components/ui/label'
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbSeparator } from '@/components/ui/breadcrumb'
import { useAppStore } from '@/lib/store'
import { extractItems } from '@/lib/api'
import { toast } from 'sonner'

interface SuggestedProduct {
  id: string
  name: string
  price: number
  discountPrice?: number | null
  images?: Array<{ url: string; alt?: string }>
  unit: string
}

export default function CartPage() {
  const {
    cartItems,
    removeFromCart,
    updateQuantity,
    subtotal,
    totalItems,
    navigate,
    siteConfig,
    clearCart,
    addToCart,
    addToWishlist,
  } = useAppStore()

  const [couponCode, setCouponCode] = useState('')
  const [couponLoading, setCouponLoading] = useState(false)
  const [discount, setDiscount] = useState(0)
  const [appliedCoupon, setAppliedCoupon] = useState('')
  const [removingId, setRemovingId] = useState<string | null>(null)
  const [confirmClear, setConfirmClear] = useState(false)
  const [suggestedProducts, setSuggestedProducts] = useReducer(
    (_: SuggestedProduct[], next: SuggestedProduct[]) => next,
    []
  )

  const sub = subtotal()
  const shipping = sub >= (siteConfig?.freeShippingThreshold || 1500) ? 0 : (siteConfig?.shippingCharge || 60)
  const total = sub + shipping - discount
  const itemCount = totalItems()
  const totalSavings = cartItems.reduce((sum, item) => {
    if (item.discountPrice != null && item.discountPrice < item.price) {
      return sum + ((item.price - item.discountPrice) * item.quantity)
    }
    return sum
  }, 0)

  const estimatedDelivery = (() => {
    const date = new Date()
    date.setDate(date.getDate() + 4)
    return date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })
  })()

  useEffect(() => {
    fetch('/api/products?limit=6&status=active')
      .then((r) => r.json())
      .then((data) => {
        setSuggestedProducts(extractItems<SuggestedProduct>(data))
      })
      .catch(() => {})
  }, [])

  const handleQuantityChange = async (cartItemId: string, newQty: number) => {
    if (newQty < 1) return
    await updateQuantity(cartItemId, newQty)
  }

  const handleRemove = async (cartItemId: string) => {
    setRemovingId(cartItemId)
    setTimeout(async () => {
      await removeFromCart(cartItemId)
      setRemovingId(null)
      toast.success('Item removed from cart')
    }, 300)
  }

  const handleApplyCoupon = async () => {
    if (!couponCode.trim()) return
    setCouponLoading(true)
    try {
      const res = await fetch('/api/coupons/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: couponCode, totalAmount: sub }),
      })
      const data = await res.json()
      if (!res.ok) {
        toast.error(data.error || 'Invalid coupon code')
        return
      }
      const discountAmount = data.type === 'percentage'
        ? Math.min(sub * (data.value / 100), data.maxDiscount || Infinity)
        : data.value
      setDiscount(discountAmount)
      setAppliedCoupon(couponCode)
      toast.success(`Coupon applied! You save ৳${discountAmount.toFixed(0)}`)
    } catch {
      toast.error('Failed to validate coupon')
    } finally {
      setCouponLoading(false)
    }
  }

  const handleRemoveCoupon = () => {
    setDiscount(0)
    setAppliedCoupon('')
    setCouponCode('')
    toast.success('Coupon removed')
  }

  const handleClearCart = async () => {
    if (!confirmClear) {
      setConfirmClear(true)
      return
    }
    await clearCart()
    setConfirmClear(false)
    toast.success('Cart cleared')
  }

  const handleAddSuggestedToCart = async (product: SuggestedProduct) => {
    const effectivePrice = product.discountPrice ?? product.price
    await addToCart({
      productId: product.id,
      productName: product.name,
      price: product.price,
      discountPrice: product.discountPrice,
      quantity: 1,
      unit: product.unit || 'kg',
      image: product.images?.[0]?.url || '/placeholder.png',
      stock: 100,
    })
  }

  // Empty cart state
  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen flex flex-col">
        {/* Breadcrumb */}
        <div className="bg-muted/30 py-3 border-b">
          <div className="container mx-auto px-4">
            <Breadcrumb>
              <BreadcrumbList>
                <BreadcrumbItem>
                  <BreadcrumbLink onClick={() => navigate('home')} className="cursor-pointer flex items-center gap-1">
                    <Home className="h-3.5 w-3.5" />
                    Home
                  </BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator />
                <BreadcrumbItem>
                  <BreadcrumbLink className="text-foreground font-medium">Shopping Cart</BreadcrumbLink>
                </BreadcrumbItem>
              </BreadcrumbList>
            </Breadcrumb>
          </div>
        </div>

        <div className="flex-1 flex flex-col items-center justify-center py-20 px-4">
          {/* Better empty state */}
          <div className="relative mb-8">
            <div className="w-36 h-36 rounded-full bg-gradient-to-br from-primary/5 to-primary/15 flex items-center justify-center">
              <div className="w-28 h-28 rounded-full bg-gradient-to-br from-primary/10 to-primary/20 flex items-center justify-center">
                <ShoppingCart className="h-14 w-14 text-primary/30" />
              </div>
            </div>
            <div className="absolute -top-1 -right-1 w-10 h-10 rounded-full bg-red-100 flex items-center justify-center border-2 border-background shadow-sm">
              <span className="text-lg">0</span>
            </div>
          </div>
          <h2 className="text-2xl font-bold mb-2">Your Cart is Empty</h2>
          <p className="text-muted-foreground mb-8 text-center max-w-sm">
            Looks like you haven&apos;t added anything to your cart yet. Start exploring our authentic Bangladeshi food products!
          </p>
          <div className="flex flex-col sm:flex-row gap-3">
            <Button onClick={() => navigate('products')} size="lg" className="h-12 px-8 rounded-xl">
              <ShoppingBag className="h-5 w-5 mr-2" /> Start Shopping
            </Button>
            <Button variant="outline" onClick={() => navigate('offers')} size="lg" className="h-12 px-8 rounded-xl">
              <Tag className="h-5 w-5 mr-2" /> Check Offers
            </Button>
          </div>
        </div>

        {suggestedProducts.length > 0 && (
          <div className="border-t bg-muted/30 py-8 px-4">
            <div className="container mx-auto max-w-4xl">
              <h3 className="text-lg font-semibold mb-4">You Might Also Like</h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
                {suggestedProducts.slice(0, 6).map((product) => (
                  <div key={product.id} className="text-center group cursor-pointer" onClick={() => navigate('product-detail', { id: product.id })}>
                    <div className="w-full aspect-square rounded-lg bg-muted/50 overflow-hidden mb-2">
                      <img src={product.images?.[0]?.url || '/placeholder.png'} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                    </div>
                    <p className="text-xs font-medium line-clamp-2">{product.name}</p>
                    <p className="text-xs text-primary font-semibold mt-0.5">৳{(product.discountPrice ?? product.price).toLocaleString()}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    )
  }

  return (
    <div className="min-h-screen">
      {/* Breadcrumb */}
      <div className="bg-muted/30 py-3 border-b">
        <div className="container mx-auto px-4">
          <Breadcrumb>
            <BreadcrumbList>
              <BreadcrumbItem>
                <BreadcrumbLink onClick={() => navigate('home')} className="cursor-pointer flex items-center gap-1">
                  <Home className="h-3.5 w-3.5" />
                  Home
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbLink className="text-foreground font-medium">Shopping Cart</BreadcrumbLink>
              </BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>
        </div>
      </div>

      {/* Header */}
      <div className="bg-background border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Shopping Cart</h1>
            <p className="text-sm text-muted-foreground">{itemCount} item{itemCount !== 1 ? 's' : ''} in your cart</p>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="text-red-500 hover:text-red-600 hover:bg-red-50 rounded-lg"
            onClick={handleClearCart}
          >
            {confirmClear ? (
              <>
                <AlertTriangle className="h-4 w-4 mr-1" /> Confirm Clear?
              </>
            ) : (
              <>
                <Trash2 className="h-4 w-4 mr-1" /> Clear Cart
              </>
            )}
          </Button>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {cartItems.map((item) => {
              const price = item.discountPrice != null ? item.discountPrice : item.price
              const hasDiscount = item.discountPrice != null && item.discountPrice < item.price
              const isRemoving = removingId === item.id
              return (
                <Card
                  key={item.id}
                  className={`overflow-hidden transition-all duration-300 border shadow-sm hover:shadow-md ${
                    isRemoving ? 'opacity-0 scale-95 translate-x-4' : 'opacity-100 scale-100'
                  }`}
                >
                  <CardContent className="p-4 sm:p-5">
                    <div className="flex gap-4 sm:gap-5">
                      {/* Product Image - More prominent */}
                      <div
                        className="relative h-28 w-28 sm:h-36 sm:w-36 rounded-xl overflow-hidden bg-muted/30 flex-shrink-0 cursor-pointer group shadow-sm"
                        onClick={() => navigate('product-detail', { id: item.productId })}
                      >
                        <Image
                          src={item.image}
                          alt={item.productName}
                          fill
                          className="object-cover group-hover:scale-110 transition-transform duration-500"
                          sizes="144px"
                        />
                        {hasDiscount && (
                          <div className="absolute top-1.5 left-1.5 bg-red-500 text-white text-xs px-2 py-0.5 rounded-md font-bold shadow-sm">
                            -{Math.round(((item.price - (item.discountPrice ?? item.price)) / item.price) * 100)}%
                          </div>
                        )}
                      </div>

                      {/* Item Details */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <h3
                              className="font-semibold line-clamp-2 cursor-pointer hover:text-primary transition-colors text-base"
                              onClick={() => navigate('product-detail', { id: item.productId })}
                            >
                              {item.productName}
                            </h3>
                            <p className="text-xs text-muted-foreground mt-0.5">per {item.unit}</p>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-muted-foreground hover:text-red-500 hover:bg-red-50 flex-shrink-0 rounded-lg"
                            onClick={() => handleRemove(item.id)}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>

                        <div className="flex items-baseline gap-2 mt-1.5">
                          <span className="font-bold text-primary text-lg">৳{price.toLocaleString()}</span>
                          {hasDiscount && (
                            <span className="text-sm text-muted-foreground line-through">৳{item.price.toLocaleString()}</span>
                          )}
                        </div>

                        <div className="flex items-center justify-between mt-3">
                          {/* Quantity Stepper */}
                          <div className="flex items-center border rounded-lg overflow-hidden shadow-sm">
                            <button
                              className="h-9 w-9 flex items-center justify-center hover:bg-primary/10 transition-colors active:scale-90"
                              onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                              disabled={item.quantity <= 1}
                            >
                              <Minus className="h-3.5 w-3.5" />
                            </button>
                            <span className="h-9 w-12 flex items-center justify-center text-sm font-semibold border-x bg-muted/30">{item.quantity}</span>
                            <button
                              className="h-9 w-9 flex items-center justify-center hover:bg-primary/10 transition-colors active:scale-90"
                              onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                              disabled={item.quantity >= item.stock}
                            >
                              <Plus className="h-3.5 w-3.5" />
                            </button>
                          </div>

                          <div className="flex items-center gap-3">
                            <span className="font-bold text-base">৳{(price * item.quantity).toLocaleString()}</span>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-muted-foreground hover:text-red-500 hover:bg-red-50 rounded-lg"
                              onClick={() => handleRemove(item.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>

                        <button
                          className="text-xs text-muted-foreground hover:text-primary mt-2 flex items-center gap-1 transition-colors"
                          onClick={async () => {
                            await addToWishlist({
                              productId: item.productId,
                              productName: item.productName,
                              price: item.price,
                              discountPrice: item.discountPrice,
                              image: item.image,
                            })
                            toast.success('Moved to wishlist')
                          }}
                        >
                          <Heart className="h-3 w-3" /> Move to Wishlist
                        </button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}

            {/* Continue Shopping */}
            <button
              className="text-sm text-primary hover:underline font-medium flex items-center gap-1 mt-2 py-2"
              onClick={() => navigate('products')}
            >
              <ArrowLeft className="h-4 w-4" /> Continue Shopping
            </button>
          </div>

          {/* Order Summary */}
          <div>
            <Card className="sticky top-4 shadow-lg border">
              <CardHeader className="pb-3 bg-gradient-to-r from-primary/5 to-transparent rounded-t-lg">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Package className="h-5 w-5 text-primary" />
                  Order Summary
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2.5">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Subtotal ({itemCount} items)</span>
                    <span className="font-medium">৳{sub.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Delivery Charge</span>
                    <span className={`font-medium ${shipping === 0 ? 'text-emerald-600' : ''}`}>
                      {shipping === 0 ? '✓ Free' : `৳${shipping}`}
                    </span>
                  </div>
                  {discount > 0 && (
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">
                        Discount
                        {appliedCoupon && <Badge variant="secondary" className="ml-2 text-xs">{appliedCoupon}</Badge>}
                      </span>
                      <span className="text-emerald-600 font-medium">-৳{discount.toLocaleString()}</span>
                    </div>
                  )}
                  <Separator />
                  <div className="flex justify-between font-bold text-lg">
                    <span>Total</span>
                    <span className="text-primary">৳{Math.max(0, total).toLocaleString()}</span>
                  </div>
                </div>

                {/* You saved summary */}
                {(totalSavings > 0 || discount > 0) && (
                  <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 flex items-center gap-2">
                    <BadgeCheck className="h-5 w-5 text-emerald-600 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-semibold text-emerald-700">
                        You save ৳{((totalSavings || 0) + (discount || 0)).toLocaleString()}
                      </p>
                      <p className="text-[11px] text-emerald-600">
                        {totalSavings > 0 && `Product discounts: ৳${totalSavings.toLocaleString()}`}
                        {totalSavings > 0 && discount > 0 && ' · '}
                        {discount > 0 && `Coupon: ৳${discount.toLocaleString()}`}
                      </p>
                    </div>
                  </div>
                )}

                {/* Coupon Code - Better visual treatment */}
                <div className="p-4 rounded-xl bg-gradient-to-r from-secondary/5 to-secondary/10 border border-secondary/15">
                  <Label className="text-sm font-semibold mb-2.5 block flex items-center gap-1.5">
                    <Gift className="h-4 w-4 text-secondary" />
                    Coupon Code
                  </Label>
                  {appliedCoupon ? (
                    <div className="flex items-center justify-between">
                      <Badge className="text-sm bg-emerald-100 text-emerald-800 border-emerald-200">
                        <Tag className="h-3 w-3 mr-1" />
                        {appliedCoupon}
                      </Badge>
                      <Button variant="ghost" size="sm" onClick={handleRemoveCoupon} className="text-red-500 h-7 text-xs">
                        Remove
                      </Button>
                    </div>
                  ) : (
                    <div className="flex gap-2">
                      <Input
                        placeholder="Enter coupon code"
                        value={couponCode}
                        onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                        className="h-9 text-sm border-secondary/20 focus:border-secondary"
                      />
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={handleApplyCoupon}
                        disabled={couponLoading || !couponCode.trim()}
                        className="h-9 border-secondary/30 text-secondary hover:bg-secondary/10"
                      >
                        {couponLoading ? '...' : 'Apply'}
                      </Button>
                    </div>
                  )}
                </div>

                {/* Free Shipping Progress */}
                {shipping > 0 && (
                  <div className="p-3 rounded-lg bg-primary/5 border border-primary/10">
                    <p className="text-xs text-muted-foreground mb-1.5 flex items-center gap-1">
                      <Truck className="h-3.5 w-3.5 text-primary" />
                      Add ৳{Math.max(0, (siteConfig?.freeShippingThreshold || 1500) - sub).toLocaleString()} more for free delivery
                    </p>
                    <div className="h-2 rounded-full bg-muted overflow-hidden">
                      <div
                        className="h-full rounded-full bg-primary transition-all duration-500"
                        style={{ width: `${Math.min(100, (sub / (siteConfig?.freeShippingThreshold || 1500)) * 100)}%` }}
                      />
                    </div>
                  </div>
                )}

                {/* Estimated Delivery */}
                <div className="flex items-center gap-2 text-sm text-muted-foreground p-3 rounded-lg bg-muted/30">
                  <Truck className="h-4 w-4 text-primary flex-shrink-0" />
                  <span>Estimated delivery: <strong className="text-foreground">{estimatedDelivery}</strong></span>
                </div>

                {/* Checkout Button */}
                <Button
                  className="w-full h-12 text-base rounded-xl shadow-md shadow-primary/20 font-semibold"
                  size="lg"
                  onClick={() => navigate('checkout')}
                >
                  Proceed to Checkout <ArrowRight className="h-4 w-4 ml-2" />
                </Button>

                {/* Continue Shopping */}
                <Button
                  variant="outline"
                  className="w-full h-10 rounded-xl"
                  onClick={() => navigate('products')}
                >
                  <ArrowLeft className="h-4 w-4 mr-2" /> Continue Shopping
                </Button>

                {/* Secure Badge */}
                <div className="flex items-center justify-center gap-1.5 text-xs text-muted-foreground">
                  <ShieldCheck className="h-3.5 w-3.5 text-emerald-500" />
                  Secure checkout with SSL encryption
                </div>

                {shipping > 0 && (
                  <p className="text-xs text-muted-foreground text-center">
                    Free delivery on orders over ৳{(siteConfig?.freeShippingThreshold || 1500).toLocaleString()}
                  </p>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* You Might Also Like Section */}
        {suggestedProducts.length > 0 && (
          <div className="mt-10 border-t pt-8">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <ShoppingBag className="h-5 w-5 text-primary" />
              You Might Also Like
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
              {suggestedProducts.slice(0, 6).map((product) => {
                const effectivePrice = product.discountPrice ?? product.price
                return (
                  <div key={product.id} className="border rounded-xl p-2 hover:shadow-md transition-all duration-200 group">
                    <div
                      className="aspect-square rounded-lg bg-muted/50 overflow-hidden mb-2 cursor-pointer"
                      onClick={() => navigate('product-detail', { id: product.id })}
                    >
                      <img
                        src={product.images?.[0]?.url || '/placeholder.png'}
                        alt={product.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <p
                      className="text-xs font-medium line-clamp-2 cursor-pointer hover:text-primary transition-colors"
                      onClick={() => navigate('product-detail', { id: product.id })}
                    >
                      {product.name}
                    </p>
                    <p className="text-sm text-primary font-bold mt-1">৳{effectivePrice.toLocaleString()}</p>
                    <Button
                      size="sm"
                      className="w-full h-7 text-xs mt-2 rounded-lg"
                      onClick={() => handleAddSuggestedToCart(product)}
                    >
                      Add to Cart
                    </Button>
                  </div>
                )
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
