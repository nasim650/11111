'use client'

import { useState, useReducer, useEffect } from 'react'
import {
  Heart, ShoppingCart, Trash2, Share2, ArrowUpDown,
  ShoppingBag, Sparkles, X, Package, Check, Copy, Facebook, MessageCircle
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { useAppStore, type CartItem, type WishlistItem } from '@/lib/store'
import { toast } from 'sonner'

type SortOption = 'date' | 'price-asc' | 'price-desc' | 'name'

interface ProductStock {
  id: string
  stock: number
}

function sortWishlistItems(items: WishlistItem[], sort: SortOption): WishlistItem[] {
  const sorted = [...items]
  switch (sort) {
    case 'price-asc':
      return sorted.sort((a, b) => {
        const pa = a.discountPrice != null ? a.discountPrice : a.price
        const pb = b.discountPrice != null ? b.discountPrice : b.price
        return pa - pb
      })
    case 'price-desc':
      return sorted.sort((a, b) => {
        const pa = a.discountPrice != null ? a.discountPrice : a.price
        const pb = b.discountPrice != null ? b.discountPrice : b.price
        return pb - pa
      })
    case 'name':
      return sorted.sort((a, b) => a.productName.localeCompare(b.productName))
    default:
      return sorted
  }
}

function WishlistItemCard({
  item,
  onRemove,
  stockInfo,
}: {
  item: WishlistItem
  onRemove: (productId: string) => void
  stockInfo: number | null
}) {
  const { navigate, addToCart } = useAppStore()
  const [adding, setAdding] = useState(false)
  const [removing, setRemoving] = useState(false)

  const handleAddToCart = async (e: React.MouseEvent) => {
    e.stopPropagation()
    if (stockInfo !== null && stockInfo <= 0) {
      toast.error('This product is out of stock')
      return
    }
    setAdding(true)
    try {
      const cartItem: Omit<CartItem, 'id'> = {
        productId: item.productId,
        productName: item.productName,
        price: item.price,
        discountPrice: item.discountPrice,
        quantity: 1,
        unit: 'kg',
        image: item.image,
        stock: stockInfo ?? 999,
      }
      await addToCart(cartItem)
      toast.success('Added to cart')
    } catch {
      toast.error('Failed to add to cart')
    } finally {
      setAdding(false)
    }
  }

  const handleRemove = async (e: React.MouseEvent) => {
    e.stopPropagation()
    setRemoving(true)
    setTimeout(() => onRemove(item.productId), 300)
  }

  const effectivePrice = item.discountPrice != null ? item.discountPrice : item.price
  const hasDiscount = item.discountPrice != null && item.discountPrice < item.price
  const savings = hasDiscount ? item.price - (item.discountPrice ?? 0) : 0
  const isInStock = stockInfo === null || stockInfo > 0
  const isLowStock = stockInfo !== null && stockInfo > 0 && stockInfo <= 5

  return (
    <div
      className={`group cursor-pointer border rounded-xl overflow-hidden hover:shadow-lg transition-all duration-300 bg-white ${
        removing ? 'opacity-0 scale-95 translate-x-4' : 'opacity-100 scale-100'
      }`}
      onClick={() => navigate('product-detail', { id: item.productId })}
    >
      <div className="relative aspect-square bg-muted/30 overflow-hidden">
        <img
          src={item.image}
          alt={item.productName}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        {/* Gradient overlay on hover */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

        {/* Remove button */}
        <button
          className="absolute top-2 right-2 h-8 w-8 rounded-full bg-white/95 shadow-md flex items-center justify-center hover:bg-red-500 hover:text-white transition-all duration-200 active:scale-90 z-10"
          onClick={handleRemove}
          title="Remove from wishlist"
        >
          <X className="h-4 w-4" />
        </button>

        {/* Discount badge */}
        {hasDiscount && (
          <Badge className="absolute top-2 left-2 bg-red-500 text-white text-xs z-10">
            -{Math.round(((item.price - (item.discountPrice ?? item.price)) / item.price) * 100)}%
          </Badge>
        )}

        {/* Stock badge */}
        <div className="absolute bottom-2 left-2 z-10">
          {stockInfo !== null && !isInStock && (
            <Badge className="bg-red-500/90 text-white text-xs backdrop-blur-sm">Out of Stock</Badge>
          )}
          {isLowStock && (
            <Badge className="bg-amber-500/90 text-white text-xs backdrop-blur-sm">Low Stock ({stockInfo})</Badge>
          )}
          {isInStock && !isLowStock && stockInfo !== null && (
            <Badge className="bg-emerald-500/90 text-white text-xs backdrop-blur-sm">In Stock</Badge>
          )}
        </div>
      </div>
      <div className="p-4 space-y-2">
        <h3 className="font-medium text-sm line-clamp-2 group-hover:text-primary transition-colors">
          {item.productName}
        </h3>
        <div className="flex items-baseline gap-2">
          <span className="font-bold text-primary text-base">
            ৳{(effectivePrice ?? 0).toLocaleString()}
          </span>
          {hasDiscount && (
            <span className="text-xs text-muted-foreground line-through">
              ৳{item.price.toLocaleString()}
            </span>
          )}
        </div>
        {savings > 0 && (
          <p className="text-xs text-emerald-600 font-medium">You save ৳{savings.toLocaleString()}</p>
        )}
        <Button
          className="w-full h-10 text-xs rounded-lg"
          size="sm"
          disabled={adding || !isInStock}
          onClick={handleAddToCart}
          variant={!isInStock ? 'secondary' : 'default'}
        >
          <ShoppingCart className="h-3.5 w-3.5 mr-1.5" />
          {!isInStock ? 'Out of Stock' : adding ? 'Adding...' : 'Add to Cart'}
        </Button>
      </div>
    </div>
  )
}

function ShareDialog({ wishlistItems }: { wishlistItems: WishlistItem[] }) {
  const [copied, setCopied] = useState(false)
  const shareText = `Check out my wishlist on Khati Khadyo!\n\n${wishlistItems.map((i) => `- ${i.productName} (৳${(i.discountPrice ?? i.price).toLocaleString()})`).join('\n')}`
  const shareUrl = typeof window !== 'undefined' ? window.location.origin : ''

  const handleCopyLink = async () => {
    await navigator.clipboard.writeText(shareText)
    setCopied(true)
    toast.success('Wishlist copied to clipboard!')
    setTimeout(() => setCopied(false), 2000)
  }

  const handleFacebookShare = () => {
    const url = `https://www.facebook.com/sharer/sharer.php?quote=${encodeURIComponent(shareText)}`
    window.open(url, '_blank', 'width=600,height=400')
  }

  const handleWhatsAppShare = () => {
    const url = `https://wa.me/?text=${encodeURIComponent(shareText)}`
    window.open(url, '_blank')
  }

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'My Khati Khadyo Wishlist',
          text: shareText,
          url: shareUrl,
        })
      } catch {
        // user cancelled
      }
    }
  }

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="rounded-lg">
          <Share2 className="h-4 w-4 mr-1.5" />
          Share
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md rounded-xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Share2 className="h-5 w-5 text-primary" />
            Share Your Wishlist
          </DialogTitle>
          <DialogDescription>
            Share your wishlist with friends and family
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3 pt-2">
          <Button
            className="w-full justify-start gap-3 h-12 rounded-xl"
            variant="outline"
            onClick={handleFacebookShare}
          >
            <div className="w-8 h-8 rounded-lg bg-[#1877F2] flex items-center justify-center">
              <Facebook className="h-4 w-4 text-white" />
            </div>
            Share on Facebook
          </Button>
          <Button
            className="w-full justify-start gap-3 h-12 rounded-xl"
            variant="outline"
            onClick={handleWhatsAppShare}
          >
            <div className="w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center">
              <MessageCircle className="h-4 w-4 text-white" />
            </div>
            Share on WhatsApp
          </Button>
          <Button
            className="w-full justify-start gap-3 h-12 rounded-xl"
            variant="outline"
            onClick={handleCopyLink}
          >
            <div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center">
              {copied ? <Check className="h-4 w-4 text-emerald-500" /> : <Copy className="h-4 w-4 text-gray-500" />}
            </div>
            {copied ? 'Copied!' : 'Copy to Clipboard'}
          </Button>
          {typeof navigator !== 'undefined' && 'share' in navigator && (
            <Button
              className="w-full justify-start gap-3 h-12 rounded-xl"
              variant="outline"
              onClick={handleNativeShare}
            >
              <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                <Share2 className="h-4 w-4 text-primary" />
              </div>
              More Options...
            </Button>
          )}
        </div>
        {/* Preview */}
        <div className="mt-2 p-3 bg-muted/50 rounded-xl">
          <p className="text-xs text-muted-foreground mb-1 font-medium">Preview</p>
          <p className="text-xs text-muted-foreground line-clamp-3">{shareText}</p>
        </div>
      </DialogContent>
    </Dialog>
  )
}

export default function WishlistPage() {
  const { wishlistItems, removeFromWishlist, addToCart, navigate } = useAppStore()
  const [sortBy, setSortBy] = useState<SortOption>('date')
  const [removedIds, setRemovedIds] = useState<Set<string>>(new Set())

  // Fetch stock info for wishlist items
  const [stockMap, setStockMap] = useReducer(
    (prev: Record<string, number>, next: Record<string, number>) => ({ ...prev, ...next }),
    {}
  )

  useEffect(() => {
    if (wishlistItems.length === 0) return
    const fetchStock = async () => {
      const newStockData: Record<string, number> = {}
      await Promise.all(
        wishlistItems.map(async (item) => {
          if (stockMap[item.productId] !== undefined) return
          try {
            const res = await fetch(`/api/products/${item.productId}`)
            if (res.ok) {
              const data = await res.json()
              const product = data.data || data
              if (product && typeof product.stock === 'number') {
                newStockData[item.productId] = product.stock
              }
            }
          } catch {
            // ignore
          }
        })
      )
      if (Object.keys(newStockData).length > 0) {
        setStockMap(newStockData)
      }
    }
    fetchStock()
  }, [wishlistItems, stockMap])

  const handleRemove = async (productId: string) => {
    setRemovedIds((prev) => new Set(prev).add(productId))
    setTimeout(async () => {
      await removeFromWishlist(productId)
      setRemovedIds((prev) => {
        const next = new Set(prev)
        next.delete(productId)
        return next
      })
      toast.success('Removed from wishlist')
    }, 300)
  }

  const handleAddAllToCart = async () => {
    const inStockItems = wishlistItems.filter((item) => {
      const stock = stockMap[item.productId]
      return stock === undefined || stock > 0
    })
    if (inStockItems.length === 0) {
      toast.error('No items in stock to add')
      return
    }
    let added = 0
    for (const item of inStockItems) {
      try {
        const cartItem: Omit<CartItem, 'id'> = {
          productId: item.productId,
          productName: item.productName,
          price: item.price,
          discountPrice: item.discountPrice,
          quantity: 1,
          unit: 'kg',
          image: item.image,
          stock: stockMap[item.productId] ?? 999,
        }
        await addToCart(cartItem)
        added++
      } catch {
        // continue
      }
    }
    toast.success(`${added} item${added !== 1 ? 's' : ''} added to cart`)
  }

  const visibleItems = sortWishlistItems(
    wishlistItems.filter((i) => !removedIds.has(i.productId)),
    sortBy
  )

  // Empty state
  if (wishlistItems.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center py-20 px-4 max-w-md mx-auto">
          {/* Heart Illustration */}
          <div className="relative mb-8 inline-block">
            <div className="h-40 w-40 rounded-full bg-gradient-to-br from-red-50 to-pink-50 flex items-center justify-center mx-auto border-2 border-dashed border-red-200">
              <div className="relative">
                <Heart className="h-16 w-16 text-red-300" />
                <div className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-secondary animate-ping" style={{ animationDuration: '2s' }} />
              </div>
            </div>
            {/* Decorative sparkles */}
            <Sparkles className="h-6 w-6 text-secondary absolute -top-2 -right-2 animate-pulse" />
            <Sparkles className="h-4 w-4 text-primary absolute bottom-2 -left-3 animate-pulse" style={{ animationDelay: '0.5s' }} />
            <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-8 h-1 rounded-full bg-red-200" />
          </div>
          <h2 className="text-2xl font-bold mb-2">Your Wishlist is Empty</h2>
          <p className="text-muted-foreground mb-6 leading-relaxed">
            Start saving your favorite products here! Click the{' '}
            <Heart className="h-4 w-4 inline text-red-400" /> icon on any product to add it to your wishlist.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button onClick={() => navigate('products')} className="rounded-xl px-6">
              <ShoppingBag className="h-4 w-4 mr-2" />
              Start Exploring
            </Button>
            <Button variant="outline" onClick={() => navigate('offers')} className="rounded-xl px-6">
              <Sparkles className="h-4 w-4 mr-2" />
              Check Offers
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary/5 via-primary/10 to-primary/5 py-6 border-b">
        <div className="container mx-auto px-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold flex items-center gap-2">
                <Heart className="h-6 w-6 text-red-500 fill-red-500" />
                My Wishlist
                <Badge className="bg-primary text-primary-foreground ml-1 rounded-full px-2.5">
                  {wishlistItems.length}
                </Badge>
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                {wishlistItems.length} item{wishlistItems.length !== 1 ? 's' : ''} saved for later
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              {/* Sort */}
              <div className="flex items-center gap-2">
                <ArrowUpDown className="h-4 w-4 text-muted-foreground" />
                <Select value={sortBy} onValueChange={(v) => setSortBy(v as SortOption)}>
                  <SelectTrigger className="w-[160px] h-9 text-sm rounded-lg">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="date">Date Added</SelectItem>
                    <SelectItem value="price-asc">Price: Low to High</SelectItem>
                    <SelectItem value="price-desc">Price: High to Low</SelectItem>
                    <SelectItem value="name">Name A-Z</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {/* Share with Dialog */}
              <ShareDialog wishlistItems={wishlistItems} />
              {/* Add All to Cart with count badge */}
              <Button size="sm" onClick={handleAddAllToCart} className="rounded-lg relative">
                <ShoppingCart className="h-4 w-4 mr-1.5" />
                Add All to Cart
                <Badge className="absolute -top-2 -right-2 bg-secondary text-white text-xs h-5 min-w-5 flex items-center justify-center rounded-full px-1">
                  {wishlistItems.length}
                </Badge>
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Items Grid */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {visibleItems.map((item) => (
            <WishlistItemCard
              key={item.productId}
              item={item}
              onRemove={handleRemove}
              stockInfo={stockMap[item.productId] ?? null}
            />
          ))}
        </div>
      </div>
    </div>
  )
}
