'use client'

import { useEffect, useReducer, useState } from 'react'
import {
  User, Mail, Phone, MapPin, Lock, Package, LogOut, Save,
  Heart, ShoppingBag, Camera, Calendar, Edit3, Trash2, Plus,
  Check, Eye, EyeOff, ChevronRight, Settings, Home, Bell,
  Shield, Globe, CreditCard, HelpCircle
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useAppStore } from '@/lib/store'
import { extractItems } from '@/lib/api'
import { toast } from 'sonner'

interface Address {
  id: string
  name: string
  phone: string
  address: string
  city: string
  district?: string
  postalCode?: string
  isDefault: boolean
}

interface OrderSummary {
  id: string
  orderNumber: string
  total: number
  status: string
  createdAt: string
  items: number
}

type ProfileTab = 'profile' | 'orders' | 'addresses' | 'settings'

export default function ProfilePage() {
  const { user, isAuthenticated, navigate, logout, wishlistItems } = useAppStore()
  const [activeTab, setActiveTab] = useState<ProfileTab>('profile')
  const [editing, setEditing] = useState(false)

  const [name, setName] = useState(user?.name || '')
  const [email, setEmail] = useState(user?.email || '')
  const [phone, setPhone] = useState(user?.phone || '')

  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmNewPassword, setConfirmNewPassword] = useState('')
  const [showCurrentPassword, setShowCurrentPassword] = useState(false)
  const [showNewPassword, setShowNewPassword] = useState(false)
  const [saving, setSaving] = useState(false)

  // Address form
  const [showAddressForm, setShowAddressForm] = useState(false)
  const [editingAddressId, setEditingAddressId] = useState<string | null>(null)
  const [addressForm, setAddressForm] = useState({
    name: '', phone: '', address: '', city: '', district: '', postalCode: '', isDefault: false
  })

  // Use reducer for data fetched in effects
  const [addresses, setAddresses] = useReducer(
    (_: Address[], next: Address[]) => next,
    []
  )
  const [recentOrders, setRecentOrders] = useReducer(
    (_: OrderSummary[], next: OrderSummary[]) => next,
    []
  )

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('login')
      return
    }
    if (user?.id) {
      fetch(`/api/addresses?userId=${user.id}`)
        .then((r) => r.json())
        .then((data) => {
          setAddresses(extractItems<Address>(data))
        })
        .catch(() => {})

      fetch(`/api/orders?userId=${user.id}&limit=5`)
        .then((r) => r.json())
        .then((data) => {
          const items = extractItems<OrderSummary>(data)
          setRecentOrders(items)
        })
        .catch(() => {})
    }
  }, [isAuthenticated, user?.id, navigate])

  const handleSaveProfile = async () => {
    if (!user?.id) return
    setSaving(true)
    try {
      const res = await fetch(`/api/users/${user.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, phone }),
      })
      if (!res.ok) throw new Error('Failed to update profile')
      toast.success('Profile updated successfully!')
      setEditing(false)
    } catch {
      toast.error('Failed to update profile')
    } finally {
      setSaving(false)
    }
  }

  const handleChangePassword = async () => {
    if (!currentPassword || !newPassword) {
      toast.error('Please fill in both password fields')
      return
    }
    if (newPassword.length < 6) {
      toast.error('New password must be at least 6 characters')
      return
    }
    if (newPassword !== confirmNewPassword) {
      toast.error('Passwords do not match')
      return
    }
    setSaving(true)
    try {
      const res = await fetch(`/api/users/${user?.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ currentPassword, newPassword }),
      })
      if (!res.ok) throw new Error('Failed to change password')
      toast.success('Password changed successfully!')
      setCurrentPassword('')
      setNewPassword('')
      setConfirmNewPassword('')
    } catch {
      toast.error('Failed to change password')
    } finally {
      setSaving(false)
    }
  }

  const handleDeleteAddress = async (addressId: string) => {
    try {
      const res = await fetch(`/api/addresses/${addressId}`, { method: 'DELETE', headers: { 'Authorization': `Bearer ${useAppStore.getState().accessToken}` } })
      if (!res.ok) throw new Error('Failed to delete address')
      setAddresses(addresses.filter((a) => a.id !== addressId))
      toast.success('Address deleted')
    } catch {
      toast.error('Failed to delete address')
    }
  }

  const handleAddAddress = async () => {
    if (!user?.id) return
    if (!addressForm.name || !addressForm.phone || !addressForm.address || !addressForm.city) {
      toast.error('Please fill in all required fields')
      return
    }
    try {
      if (editingAddressId) {
        const res = await fetch(`/api/addresses/${editingAddressId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(addressForm),
        })
        if (!res.ok) throw new Error('Failed to update address')
        const data = await res.json()
        const updated = data.data || data
        setAddresses(addresses.map((a) => a.id === editingAddressId ? { ...a, ...updated } : a))
        toast.success('Address updated!')
      } else {
        const res = await fetch('/api/addresses', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...addressForm, userId: user.id }),
        })
        if (!res.ok) throw new Error('Failed to add address')
        const data = await res.json()
        const newAddr = data.data || data
        setAddresses([...addresses, newAddr])
        toast.success('Address added!')
      }
      setShowAddressForm(false)
      setEditingAddressId(null)
      setAddressForm({ name: '', phone: '', address: '', city: '', district: '', postalCode: '', isDefault: false })
    } catch {
      toast.error(editingAddressId ? 'Failed to update address' : 'Failed to add address')
    }
  }

  const handleEditAddress = (addr: Address) => {
    setEditingAddressId(addr.id)
    setAddressForm({
      name: addr.name,
      phone: addr.phone,
      address: addr.address,
      city: addr.city,
      district: addr.district || '',
      postalCode: addr.postalCode || '',
      isDefault: addr.isDefault,
    })
    setShowAddressForm(true)
  }

  const handleLogout = () => {
    logout()
    navigate('home')
    toast.success('Logged out successfully')
  }

  const getStatusColor = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'delivered': return 'bg-emerald-100 text-emerald-800 border-emerald-200'
      case 'shipped': return 'bg-sky-100 text-sky-800 border-sky-200'
      case 'processing': return 'bg-amber-100 text-amber-800 border-amber-200'
      case 'pending': return 'bg-gray-100 text-gray-800 border-gray-200'
      case 'cancelled': return 'bg-red-100 text-red-800 border-red-200'
      default: return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'delivered': return '✅'
      case 'shipped': return '🚚'
      case 'processing': return '⏳'
      case 'pending': return '🕐'
      case 'cancelled': return '❌'
      default: return '📦'
    }
  }

  if (!isAuthenticated || !user) {
    return null
  }

  const joinDate = user.createdAt ? new Date(user.createdAt).toLocaleDateString('en-US', { month: 'long', year: 'numeric' }) : 'N/A'

  return (
    <div className="min-h-screen bg-gray-50/50">
      {/* Profile Header with Cover Photo Area */}
      <div className="relative">
        {/* Cover Photo Gradient */}
        <div className="h-40 sm:h-52 bg-gradient-to-br from-primary via-emerald-700 to-emerald-800 relative overflow-hidden">
          {/* Decorative patterns */}
          <div className="absolute inset-0 opacity-10">
            <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="profile-pattern" x="0" y="0" width="60" height="60" patternUnits="userSpaceOnUse">
                  <circle cx="30" cy="30" r="10" fill="none" stroke="white" strokeWidth="0.5" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#profile-pattern)" />
            </svg>
          </div>
          <div className="absolute top-4 right-8 w-32 h-32 rounded-full border-2 border-white/10 animate-pulse" style={{ animationDuration: '4s' }} />
          <div className="absolute bottom-4 left-12 w-20 h-20 rounded-full border-2 border-white/10" />
        </div>

        {/* Profile Info Section - Overlapping cover */}
        <div className="container mx-auto px-4 -mt-16 sm:-mt-20 relative z-10">
          <div className="bg-white rounded-2xl shadow-lg ring-1 ring-gray-100 p-6">
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5">
              {/* Avatar with Edit Overlay */}
              <div className="relative group -mt-16 sm:-mt-20">
                <Avatar className="h-28 w-28 ring-4 ring-white shadow-xl">
                  <AvatarImage src={user.avatar || undefined} />
                  <AvatarFallback className="text-4xl bg-gradient-to-br from-primary to-emerald-600 text-white font-bold">
                    {user.name?.charAt(0)?.toUpperCase() || 'U'}
                  </AvatarFallback>
                </Avatar>
                <button className="absolute inset-0 flex items-center justify-center bg-black/40 rounded-full opacity-0 group-hover:opacity-100 transition-all duration-200 cursor-pointer">
                  <div className="w-8 h-8 rounded-full bg-white/90 flex items-center justify-center">
                    <Camera className="h-4 w-4 text-primary" />
                  </div>
                </button>
              </div>

              {/* Info */}
              <div className="text-center sm:text-left flex-1 pt-2">
                <h1 className="text-2xl font-bold">{user.name || 'User'}</h1>
                <div className="flex flex-col sm:flex-row items-center gap-2 sm:gap-4 mt-1 text-muted-foreground text-sm">
                  {user.email && (
                    <span className="flex items-center gap-1.5"><Mail className="h-3.5 w-3.5" /> {user.email}</span>
                  )}
                  {user.phone && (
                    <span className="flex items-center gap-1.5"><Phone className="h-3.5 w-3.5" /> {user.phone}</span>
                  )}
                </div>
                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 mt-3">
                  <Badge className="bg-primary/10 text-primary border-primary/20 hover:bg-primary/15">
                    <Calendar className="h-3 w-3 mr-1" /> Joined {joinDate}
                  </Badge>
                  <Badge className="bg-secondary/10 text-secondary border-secondary/20 hover:bg-secondary/15">
                    {user.role === 'admin' ? '⭐ Admin' : '👤 Customer'}
                  </Badge>
                </div>
              </div>

              {/* Quick Actions */}
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="rounded-xl hover:bg-red-50 hover:text-red-600 hover:border-red-200" onClick={handleLogout}>
                  <LogOut className="h-4 w-4 mr-1.5" /> Logout
                </Button>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-3 gap-4 mt-6 max-w-lg mx-auto sm:mx-0">
              <button
                className="bg-primary/5 hover:bg-primary/10 rounded-xl p-3 text-center transition-all duration-200 cursor-pointer group"
                onClick={() => navigate('orders')}
              >
                <Package className="h-5 w-5 mx-auto mb-1 text-primary group-hover:scale-110 transition-transform" />
                <p className="text-lg font-bold text-primary">{recentOrders.length}</p>
                <p className="text-xs text-muted-foreground">Orders</p>
              </button>
              <button
                className="bg-red-5 hover:bg-red-50 rounded-xl p-3 text-center transition-all duration-200 cursor-pointer group"
                onClick={() => navigate('wishlist')}
              >
                <Heart className="h-5 w-5 mx-auto mb-1 text-red-500 group-hover:scale-110 transition-transform" />
                <p className="text-lg font-bold text-red-500">{wishlistItems.length}</p>
                <p className="text-xs text-muted-foreground">Wishlist</p>
              </button>
              <button
                className="bg-secondary/5 hover:bg-secondary/10 rounded-xl p-3 text-center transition-all duration-200 cursor-pointer group"
                onClick={() => setActiveTab('addresses')}
              >
                <MapPin className="h-5 w-5 mx-auto mb-1 text-secondary group-hover:scale-110 transition-transform" />
                <p className="text-lg font-bold text-secondary">{addresses.length}</p>
                <p className="text-xs text-muted-foreground">Addresses</p>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="container mx-auto px-4 py-6 max-w-5xl">
        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as ProfileTab)}>
          <TabsList className="grid w-full grid-cols-4 mb-6 h-12">
            <TabsTrigger value="profile" className="gap-1.5 text-sm">
              <User className="h-4 w-4 hidden sm:block" /> Profile
            </TabsTrigger>
            <TabsTrigger value="orders" className="gap-1.5 text-sm">
              <Package className="h-4 w-4 hidden sm:block" /> Orders
            </TabsTrigger>
            <TabsTrigger value="addresses" className="gap-1.5 text-sm">
              <MapPin className="h-4 w-4 hidden sm:block" /> Addresses
            </TabsTrigger>
            <TabsTrigger value="settings" className="gap-1.5 text-sm">
              <Settings className="h-4 w-4 hidden sm:block" /> Settings
            </TabsTrigger>
          </TabsList>

          {/* Profile Tab */}
          <TabsContent value="profile">
            <Card className="rounded-xl">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5 text-primary" />
                  Personal Information
                </CardTitle>
                <Button
                  variant={editing ? 'default' : 'outline'}
                  size="sm"
                  className="rounded-lg"
                  onClick={() => {
                    if (editing) handleSaveProfile()
                    else setEditing(true)
                  }}
                  disabled={saving}
                >
                  {editing ? (
                    <>{saving ? <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-1.5" /> : <Save className="h-4 w-4 mr-1.5" />} Save</>
                  ) : (
                    <><Edit3 className="h-4 w-4 mr-1.5" /> Edit</>
                  )}
                </Button>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Full Name</Label>
                    <Input
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      disabled={!editing}
                      className={`h-11 rounded-lg ${!editing ? 'bg-muted/50' : ''}`}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Email</Label>
                    <Input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      disabled={!editing}
                      className={`h-11 rounded-lg ${!editing ? 'bg-muted/50' : ''}`}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Phone</Label>
                  <Input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    disabled={!editing}
                    className={`h-11 rounded-lg ${!editing ? 'bg-muted/50' : ''}`}
                  />
                </div>
                {editing && (
                  <p className="text-xs text-muted-foreground flex items-center gap-1">
                    <Check className="h-3 w-3 text-primary" /> Click Save to update your profile
                  </p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Orders Tab */}
          <TabsContent value="orders">
            <Card className="rounded-xl">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <ShoppingBag className="h-5 w-5 text-primary" />
                  Recent Orders
                </CardTitle>
                <Button variant="outline" size="sm" className="rounded-lg" onClick={() => navigate('orders')}>
                  View All <ChevronRight className="h-4 w-4 ml-1" />
                </Button>
              </CardHeader>
              <CardContent>
                {recentOrders.length === 0 ? (
                  <div className="text-center py-12">
                    <div className="w-20 h-20 rounded-full bg-muted/30 flex items-center justify-center mx-auto mb-4">
                      <Package className="h-10 w-10 text-muted-foreground/40" />
                    </div>
                    <p className="text-muted-foreground font-medium">No orders yet</p>
                    <p className="text-xs text-muted-foreground mt-1">Start shopping to see your orders here</p>
                    <Button variant="outline" className="mt-4 rounded-xl" onClick={() => navigate('products')}>
                      Start Shopping
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {recentOrders.map((order) => (
                      <div
                        key={order.id}
                        className="flex items-center justify-between p-4 border rounded-xl hover:border-primary/30 hover:shadow-sm transition-all cursor-pointer group"
                        onClick={() => navigate('order-detail', { id: order.id })}
                      >
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/15 transition-colors">
                            <Package className="h-6 w-6 text-primary" />
                          </div>
                          <div>
                            <p className="font-semibold text-sm">#{order.orderNumber || order.id.slice(-8)}</p>
                            <p className="text-xs text-muted-foreground mt-0.5">
                              {new Date(order.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                              {' · '}{order.items || 0} item{(order.items || 0) !== 1 ? 's' : ''}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-sm">৳{(order.total ?? 0).toLocaleString()}</p>
                          <Badge className={`text-xs mt-1 border ${getStatusColor(order.status)}`}>
                            {getStatusIcon(order.status)} {order.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Wishlist Summary */}
            <Card className="mt-4 rounded-xl">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-red-500" />
                  Wishlist ({wishlistItems.length})
                </CardTitle>
                {wishlistItems.length > 0 && (
                  <Button variant="outline" size="sm" className="rounded-lg" onClick={() => navigate('wishlist')}>
                    View All <ChevronRight className="h-4 w-4 ml-1" />
                  </Button>
                )}
              </CardHeader>
              <CardContent>
                {wishlistItems.length === 0 ? (
                  <p className="text-muted-foreground text-sm py-4 text-center">No items in your wishlist</p>
                ) : (
                  <div className="flex gap-3 overflow-x-auto pb-2">
                    {wishlistItems.slice(0, 5).map((item) => (
                      <div key={item.productId} className="flex-shrink-0 w-28 text-center group cursor-pointer" onClick={() => navigate('product-detail', { id: item.productId })}>
                        <div className="w-28 h-28 rounded-xl bg-muted/30 overflow-hidden mb-2 ring-1 ring-gray-100 group-hover:ring-primary/30 transition-all">
                          <img
                            src={item.image}
                            alt={item.productName}
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                          />
                        </div>
                        <p className="text-xs font-medium line-clamp-2">{item.productName}</p>
                        <p className="text-xs text-primary font-semibold mt-0.5">
                          ৳{(item.discountPrice ?? item.price).toLocaleString()}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Addresses Tab */}
          <TabsContent value="addresses">
            <Card className="rounded-xl">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-primary" />
                  Saved Addresses
                </CardTitle>
                <Button size="sm" className="rounded-lg" onClick={() => {
                  setEditingAddressId(null)
                  setAddressForm({ name: '', phone: '', address: '', city: '', district: '', postalCode: '', isDefault: false })
                  setShowAddressForm(!showAddressForm)
                }}>
                  <Plus className="h-4 w-4 mr-1.5" /> Add Address
                </Button>
              </CardHeader>
              <CardContent>
                {/* Add/Edit Address Form */}
                {showAddressForm && (
                  <div className="mb-6 p-5 border-2 border-dashed border-primary/30 rounded-xl bg-primary/5">
                    <h4 className="font-medium text-sm mb-3 flex items-center gap-2">
                      <Home className="h-4 w-4 text-primary" /> {editingAddressId ? 'Edit Address' : 'New Address'}
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="space-y-1.5">
                        <Label className="text-xs">Full Name *</Label>
                        <Input
                          value={addressForm.name}
                          onChange={(e) => setAddressForm({ ...addressForm, name: e.target.value })}
                          placeholder="Recipient name"
                          className="h-9 text-sm"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs">Phone *</Label>
                        <Input
                          value={addressForm.phone}
                          onChange={(e) => setAddressForm({ ...addressForm, phone: e.target.value })}
                          placeholder="01XXXXXXXXX"
                          className="h-9 text-sm"
                        />
                      </div>
                      <div className="sm:col-span-2 space-y-1.5">
                        <Label className="text-xs">Address *</Label>
                        <Input
                          value={addressForm.address}
                          onChange={(e) => setAddressForm({ ...addressForm, address: e.target.value })}
                          placeholder="House, road, area"
                          className="h-9 text-sm"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs">City *</Label>
                        <Input
                          value={addressForm.city}
                          onChange={(e) => setAddressForm({ ...addressForm, city: e.target.value })}
                          placeholder="City"
                          className="h-9 text-sm"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs">District</Label>
                        <Input
                          value={addressForm.district}
                          onChange={(e) => setAddressForm({ ...addressForm, district: e.target.value })}
                          placeholder="District"
                          className="h-9 text-sm"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs">Postal Code</Label>
                        <Input
                          value={addressForm.postalCode}
                          onChange={(e) => setAddressForm({ ...addressForm, postalCode: e.target.value })}
                          placeholder="Postal code"
                          className="h-9 text-sm"
                        />
                      </div>
                    </div>
                    <div className="flex gap-2 mt-4">
                      <Button size="sm" className="rounded-lg" onClick={handleAddAddress}>
                        {editingAddressId ? 'Update Address' : 'Save Address'}
                      </Button>
                      <Button size="sm" variant="outline" className="rounded-lg" onClick={() => {
                        setShowAddressForm(false)
                        setEditingAddressId(null)
                      }}>Cancel</Button>
                    </div>
                  </div>
                )}

                {addresses.length === 0 && !showAddressForm ? (
                  <div className="text-center py-12">
                    <div className="w-20 h-20 rounded-full bg-muted/30 flex items-center justify-center mx-auto mb-4">
                      <MapPin className="h-10 w-10 text-muted-foreground/40" />
                    </div>
                    <p className="text-muted-foreground font-medium">No saved addresses</p>
                    <p className="text-xs text-muted-foreground mt-1">Add an address to speed up checkout</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {addresses.map((addr) => (
                      <div key={addr.id} className="relative border rounded-xl p-5 hover:border-primary/30 hover:shadow-sm transition-all group">
                        {addr.isDefault && (
                          <Badge className="absolute top-3 right-3 bg-primary/10 text-primary text-xs border border-primary/20">Default</Badge>
                        )}
                        <div className="flex items-start gap-3">
                          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5 group-hover:bg-primary/15 transition-colors">
                            <Home className="h-5 w-5 text-primary" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-semibold text-sm">{addr.name}</p>
                            <p className="text-xs text-muted-foreground mt-0.5">{addr.phone}</p>
                            <p className="text-xs text-muted-foreground mt-1.5 line-clamp-2 leading-relaxed">
                              {addr.address}, {addr.city}{addr.district ? `, ${addr.district}` : ''}{addr.postalCode ? ` - ${addr.postalCode}` : ''}
                            </p>
                          </div>
                        </div>
                        <div className="flex gap-2 mt-4 pt-3 border-t">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-xs h-8 rounded-lg text-primary hover:text-primary hover:bg-primary/10"
                            onClick={() => handleEditAddress(addr)}
                          >
                            <Edit3 className="h-3.5 w-3.5 mr-1" /> Edit
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-xs h-8 rounded-lg text-red-500 hover:text-red-600 hover:bg-red-50"
                            onClick={() => handleDeleteAddress(addr.id)}
                          >
                            <Trash2 className="h-3.5 w-3.5 mr-1" /> Delete
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-4">
            {/* Change Password */}
            <Card className="rounded-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lock className="h-5 w-5 text-primary" />
                  Security
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 max-w-md">
                <div className="space-y-2">
                  <Label>Current Password</Label>
                  <div className="relative">
                    <Input
                      type={showCurrentPassword ? 'text' : 'password'}
                      value={currentPassword}
                      onChange={(e) => setCurrentPassword(e.target.value)}
                      className="pr-10 h-11 rounded-lg"
                    />
                    <button
                      type="button"
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                      onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                    >
                      {showCurrentPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>New Password</Label>
                  <div className="relative">
                    <Input
                      type={showNewPassword ? 'text' : 'password'}
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="pr-10 h-11 rounded-lg"
                    />
                    <button
                      type="button"
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                      onClick={() => setShowNewPassword(!showNewPassword)}
                    >
                      {showNewPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Confirm New Password</Label>
                  <Input
                    type="password"
                    value={confirmNewPassword}
                    onChange={(e) => setConfirmNewPassword(e.target.value)}
                    className="h-11 rounded-lg"
                  />
                  {confirmNewPassword.length > 0 && newPassword !== confirmNewPassword && (
                    <p className="text-xs text-red-500">Passwords do not match</p>
                  )}
                </div>
                <Button onClick={handleChangePassword} disabled={saving} className="rounded-xl">
                  {saving ? <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" /> : <Lock className="h-4 w-4 mr-2" />}
                  Change Password
                </Button>
              </CardContent>
            </Card>

            {/* Preferences */}
            <Card className="rounded-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="h-5 w-5 text-primary" />
                  Preferences
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 rounded-xl hover:bg-muted/30 transition-colors">
                    <div className="flex items-center gap-3">
                      <Bell className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <p className="text-sm font-medium">Notifications</p>
                        <p className="text-xs text-muted-foreground">Order updates and offers</p>
                      </div>
                    </div>
                    <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200">On</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-xl hover:bg-muted/30 transition-colors">
                    <div className="flex items-center gap-3">
                      <CreditCard className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <p className="text-sm font-medium">Payment Methods</p>
                        <p className="text-xs text-muted-foreground">Manage saved cards</p>
                      </div>
                    </div>
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-xl hover:bg-muted/30 transition-colors">
                    <div className="flex items-center gap-3">
                      <Shield className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <p className="text-sm font-medium">Privacy</p>
                        <p className="text-xs text-muted-foreground">Data and privacy settings</p>
                      </div>
                    </div>
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-xl hover:bg-muted/30 transition-colors cursor-pointer" onClick={() => navigate('faq')}>
                    <div className="flex items-center gap-3">
                      <HelpCircle className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <p className="text-sm font-medium">Help & Support</p>
                        <p className="text-xs text-muted-foreground">FAQs and contact support</p>
                      </div>
                    </div>
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Account Actions */}
            <Card className="rounded-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5 text-primary" />
                  Account Actions
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button
                  variant="outline"
                  className="w-full justify-start text-red-500 hover:text-red-600 hover:bg-red-50 hover:border-red-200 rounded-xl h-11"
                  onClick={handleLogout}
                >
                  <LogOut className="h-4 w-4 mr-2" /> Logout from Account
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
