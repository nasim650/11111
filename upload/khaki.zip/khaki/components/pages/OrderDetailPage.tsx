'use client'

import { useCallback, useEffect, useState } from 'react'
import Image from 'next/image'
import {
  ArrowLeft,
  Truck,
  CheckCircle2,
  Clock,
  Package,
  X,
  CreditCard,
  MapPin,
  Calendar,
  Printer,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { Skeleton } from '@/components/ui/skeleton'
import { useAppStore } from '@/lib/store'

interface OrderItem {
  id: string
  productId: string
  productName: string
  quantity: number
  unit: string
  price: number
  image?: string
}

interface OrderDetail {
  id: string
  orderNumber: string
  totalAmount: number
  discountAmount: number
  deliveryCharge: number
  paymentMethod: string
  paymentStatus: string
  orderStatus: string
  orderNote?: string
  couponCode?: string
  createdAt: string
  updatedAt: string
  userId?: string
  guestName?: string
  guestPhone?: string
  guestEmail?: string
  guestAddress?: string
  items: OrderItem[]
  payment?: {
    method: string
    status: string
    transactionId?: string
    paidAt?: string
  }
}

const statusSteps = [
  { key: 'pending', label: 'Order Placed', icon: Clock },
  { key: 'confirmed', label: 'Confirmed', icon: CheckCircle2 },
  { key: 'processing', label: 'Processing', icon: Package },
  { key: 'shipped', label: 'Shipped', icon: Truck },
  { key: 'delivered', label: 'Delivered', icon: CheckCircle2 },
]

const statusColors: Record<string, string> = {
  pending: 'bg-yellow-100 text-yellow-800',
  confirmed: 'bg-blue-100 text-blue-800',
  processing: 'bg-indigo-100 text-indigo-800',
  shipped: 'bg-purple-100 text-purple-800',
  delivered: 'bg-emerald-100 text-emerald-800',
  cancelled: 'bg-red-100 text-red-800',
}

function getStepIndex(status: string): number {
  if (status === 'cancelled') return -1
  const idx = statusSteps.findIndex((s) => s.key === status)
  return idx >= 0 ? idx : 0
}

export default function OrderDetailPage() {
  const { pageParams, navigate } = useAppStore()
  const [order, setOrder] = useState<OrderDetail | null>(null)
  const [loading, setLoading] = useState(() => true)

  const orderId = String(pageParams?.id || '')

  const fetchOrder = useCallback(async (id: string) => {
    try {
      const r = await fetch(`/api/orders/${id}`)
      if (!r.ok) throw new Error('Order not found')
      const data = await r.json()
      setOrder(data)
    } catch {
      setOrder(null)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (!orderId) return
    fetchOrder(orderId)
  }, [orderId, fetchOrder])

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-6 max-w-4xl space-y-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-64 rounded-lg" />
        <Skeleton className="h-48 rounded-lg" />
      </div>
    )
  }

  if (!order) {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <h2 className="text-2xl font-bold mb-2">Order Not Found</h2>
        <p className="text-muted-foreground mb-4">The order you are looking for does not exist.</p>
        <Button onClick={() => navigate('orders')}>View All Orders</Button>
      </div>
    )
  }

  const currentStep = getStepIndex(order.orderStatus)
  const isCancelled = order.orderStatus === 'cancelled'
  const subtotal = order.items.reduce((sum, item) => sum + item.price * item.quantity, 0)

  return (
    <div className="min-h-screen">
      <div className="bg-muted/30 py-3">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => navigate('orders')}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-xl font-bold">Order #{order.orderNumber}</h1>
              <p className="text-sm text-muted-foreground">
                Placed on {new Date(order.createdAt).toLocaleDateString('en-BD', { year: 'numeric', month: 'long', day: 'numeric' })}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6 max-w-4xl space-y-6">
        {/* Status & Actions */}
        <div className="flex items-center justify-between">
          <Badge className={`text-sm px-3 py-1 ${statusColors[order.orderStatus] || 'bg-gray-100 text-gray-800'}`}>
            {order.orderStatus.toUpperCase()}
          </Badge>
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigate('invoice-view', { id: order.id })}
          >
            <Printer className="h-4 w-4 mr-1" />
            View Invoice
          </Button>
        </div>

        {/* Status Timeline */}
        {!isCancelled && (
          <Card>
            <CardContent className="p-6">
              <h3 className="font-semibold mb-6">Order Status</h3>
              <div className="flex items-center justify-between relative">
                {/* Progress bar */}
                <div className="absolute top-5 left-0 right-0 h-0.5 bg-muted">
                  <div
                    className="h-full bg-primary transition-all duration-500"
                    style={{ width: `${(currentStep / (statusSteps.length - 1)) * 100}%` }}
                  />
                </div>

                {statusSteps.map((step, idx) => {
                  const Icon = step.icon
                  const isCompleted = idx <= currentStep
                  const isCurrent = idx === currentStep
                  return (
                    <div key={step.key} className="relative flex flex-col items-center z-10">
                      <div
                        className={`h-10 w-10 rounded-full flex items-center justify-center border-2 transition-colors ${
                          isCompleted
                            ? 'bg-primary border-primary text-primary-foreground'
                            : 'bg-background border-muted-foreground/30 text-muted-foreground'
                        } ${isCurrent ? 'ring-2 ring-primary/30 ring-offset-2' : ''}`}
                      >
                        <Icon className="h-5 w-5" />
                      </div>
                      <span
                        className={`text-xs mt-2 text-center max-w-[80px] ${
                          isCompleted ? 'text-foreground font-medium' : 'text-muted-foreground'
                        }`}
                      >
                        {step.label}
                      </span>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        )}

        {isCancelled && (
          <Card className="border-red-200 bg-red-50">
            <CardContent className="p-6 text-center">
              <X className="h-10 w-10 text-red-500 mx-auto mb-2" />
              <h3 className="font-semibold text-red-700">This order has been cancelled</h3>
            </CardContent>
          </Card>
        )}

        {/* Order Items */}
        <Card>
          <CardHeader>
            <CardTitle>Order Items</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {order.items.map((item) => (
                <div key={item.id} className="flex items-center gap-4">
                  <div className="relative h-16 w-16 rounded-md overflow-hidden bg-muted/30 flex-shrink-0">
                    {item.image ? (
                      <Image src={item.image} alt={item.productName} fill className="object-cover" sizes="64px" />
                    ) : (
                      <div className="flex items-center justify-center h-full text-2xl">📦</div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm line-clamp-1">{item.productName}</p>
                    <p className="text-xs text-muted-foreground">{item.quantity} × ৳{item.price.toLocaleString()} per {item.unit}</p>
                  </div>
                  <span className="font-semibold text-sm">৳{(item.price * item.quantity).toLocaleString()}</span>
                </div>
              ))}
            </div>

            <Separator className="my-4" />

            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal</span>
                <span>৳{subtotal.toLocaleString()}</span>
              </div>
              {order.discountAmount > 0 && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Discount {order.couponCode ? `(${order.couponCode})` : ''}</span>
                  <span className="text-emerald-600">-৳{order.discountAmount.toLocaleString()}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-muted-foreground">Delivery Charge</span>
                <span>{order.deliveryCharge === 0 ? 'Free' : `৳${order.deliveryCharge.toLocaleString()}`}</span>
              </div>
              <Separator />
              <div className="flex justify-between font-semibold text-lg">
                <span>Total</span>
                <span className="text-primary">৳{order.totalAmount.toLocaleString()}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Payment & Delivery Info */}
        <div className="grid md:grid-cols-2 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <CreditCard className="h-4 w-4" />
                Payment Info
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Method</span>
                <span className="capitalize">{order.paymentMethod}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Status</span>
                <Badge variant="outline" className="text-xs capitalize">{order.paymentStatus}</Badge>
              </div>
              {order.payment?.transactionId && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Transaction ID</span>
                  <span className="font-mono text-xs">{order.payment.transactionId}</span>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <MapPin className="h-4 w-4" />
                Delivery Info
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              {order.guestName && <p><span className="text-muted-foreground">Name:</span> {order.guestName}</p>}
              {order.guestPhone && <p><span className="text-muted-foreground">Phone:</span> {order.guestPhone}</p>}
              {order.guestAddress && <p><span className="text-muted-foreground">Address:</span> {order.guestAddress}</p>}
              {order.orderNote && <p><span className="text-muted-foreground">Note:</span> {order.orderNote}</p>}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
