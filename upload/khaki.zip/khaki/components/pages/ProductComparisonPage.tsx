'use client'

import { useEffect, useState } from 'react'
import Image from 'next/image'
import { GitCompare, X, ShoppingCart } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { useAppStore, type CartItem } from '@/lib/store'
import { toast } from 'sonner'

interface CompareProduct {
  id: string
  name: string
  price: number
  discountPrice?: number | null
  unit: string
  stock: number
  shortDescription?: string
  description?: string
  origin?: string
  qualityNote?: string
  ingredients?: string
  specifications?: string
  images?: Array<{ url: string; alt?: string }>
  category?: { name: string }
}

export default function ProductComparisonPage() {
  const { compareProducts, removeFromCompare, clearCompare, navigate, addToCart } = useAppStore()
  const [products, setProducts] = useState<CompareProduct[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (compareProducts.length === 0) return
    let cancelled = false
    Promise.all(
      compareProducts.map((id) =>
        fetch(`/api/products/${id}`)
          .then((r) => r.json())
          .catch(() => null)
      )
    )
      .then((results) => {
        if (!cancelled) setProducts(results.filter(Boolean) as CompareProduct[])
      })
      .catch(() => {})
      .finally(() => { if (!cancelled) setLoading(false) })
    return () => { cancelled = true }
  }, [compareProducts])

  const handleAddToCart = async (product: CompareProduct) => {
    try {
      const imageUrl = product.images?.[0]?.url || '/placeholder.png'
      const cartItem: Omit<CartItem, 'id'> = {
        productId: product.id,
        productName: product.name,
        price: product.price,
        discountPrice: product.discountPrice,
        quantity: 1,
        unit: product.unit,
        image: imageUrl,
        stock: product.stock,
      }
      await addToCart(cartItem)
      toast.success('Added to cart')
    } catch {
      toast.error('Failed to add to cart')
    }
  }

  const getSpecs = (product: CompareProduct): Array<{ key: string; value: string }> => {
    try {
      if (product.specifications) {
        const parsed = JSON.parse(product.specifications)
        return Array.isArray(parsed) ? parsed : Object.entries(parsed).map(([key, value]) => ({ key, value: String(value) }))
      }
    } catch { /* ignore */ }
    return []
  }

  // Gather all unique spec keys
  const allSpecKeys = products.reduce<Set<string>>((acc, p) => {
    getSpecs(p).forEach((s) => acc.add(s.key))
    return acc
  }, new Set())

  if (compareProducts.length === 0 && !loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center py-20 px-4">
        <GitCompare className="h-20 w-20 text-muted-foreground/30 mb-4" />
        <h2 className="text-2xl font-bold mb-2">No Products to Compare</h2>
        <p className="text-muted-foreground mb-6 text-center">
          Add products to compare by clicking the compare icon on product cards
        </p>
        <Button onClick={() => navigate('products')}>Browse Products</Button>
      </div>
    )
  }

  return (
    <div className="min-h-screen">
      <div className="bg-muted/30 py-3">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold flex items-center gap-2">
                <GitCompare className="h-6 w-6" />
                Compare Products
              </h1>
              <p className="text-sm text-muted-foreground">Compare {products.length} product{products.length !== 1 ? 's' : ''} side by side</p>
            </div>
            <Button variant="outline" size="sm" onClick={clearCompare}>
              Clear All
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {Array.from({ length: compareProducts.length }).map((_, i) => (
              <Skeleton key={i} className="h-96 rounded-lg" />
            ))}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[600px]">
              <thead>
                <tr>
                  <th className="text-left p-3 w-32 text-sm font-medium text-muted-foreground">Feature</th>
                  {products.map((product) => (
                    <th key={product.id} className="p-3 text-center">
                      <div className="flex flex-col items-center">
                        <div className="relative h-32 w-32 mx-auto mb-3 rounded-lg overflow-hidden bg-muted/30">
                          <Image
                            src={product.images?.[0]?.url || '/placeholder.png'}
                            alt={product.name}
                            fill
                            className="object-cover"
                            sizes="128px"
                          />
                        </div>
                        <h3 className="font-semibold text-sm line-clamp-2 mb-1">{product.name}</h3>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6 text-muted-foreground hover:text-red-500"
                          onClick={() => removeFromCompare(product.id)}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {/* Price */}
                <tr className="border-t">
                  <td className="p-3 text-sm font-medium text-muted-foreground">Price</td>
                  {products.map((p) => (
                    <td key={p.id} className="p-3 text-center">
                      <span className="font-bold text-primary">
                        ৳{(p.discountPrice != null ? p.discountPrice : p.price).toLocaleString()}
                      </span>
                      {p.discountPrice != null && p.discountPrice < p.price && (
                        <span className="block text-xs text-muted-foreground line-through">৳{p.price.toLocaleString()}</span>
                      )}
                    </td>
                  ))}
                </tr>

                {/* Unit */}
                <tr className="border-t bg-muted/20">
                  <td className="p-3 text-sm font-medium text-muted-foreground">Unit</td>
                  {products.map((p) => (
                    <td key={p.id} className="p-3 text-center text-sm">{p.unit}</td>
                  ))}
                </tr>

                {/* Stock */}
                <tr className="border-t">
                  <td className="p-3 text-sm font-medium text-muted-foreground">Availability</td>
                  {products.map((p) => (
                    <td key={p.id} className="p-3 text-center">
                      <Badge variant={p.stock > 0 ? 'secondary' : 'destructive'} className="text-xs">
                        {p.stock > 0 ? `In Stock (${p.stock})` : 'Out of Stock'}
                      </Badge>
                    </td>
                  ))}
                </tr>

                {/* Category */}
                <tr className="border-t bg-muted/20">
                  <td className="p-3 text-sm font-medium text-muted-foreground">Category</td>
                  {products.map((p) => (
                    <td key={p.id} className="p-3 text-center text-sm">{p.category?.name || '-'}</td>
                  ))}
                </tr>

                {/* Origin */}
                <tr className="border-t">
                  <td className="p-3 text-sm font-medium text-muted-foreground">Origin</td>
                  {products.map((p) => (
                    <td key={p.id} className="p-3 text-center text-sm">{p.origin || '-'}</td>
                  ))}
                </tr>

                {/* Quality */}
                <tr className="border-t bg-muted/20">
                  <td className="p-3 text-sm font-medium text-muted-foreground">Quality</td>
                  {products.map((p) => (
                    <td key={p.id} className="p-3 text-center text-sm">{p.qualityNote || '-'}</td>
                  ))}
                </tr>

                {/* Ingredients */}
                <tr className="border-t">
                  <td className="p-3 text-sm font-medium text-muted-foreground">Ingredients</td>
                  {products.map((p) => (
                    <td key={p.id} className="p-3 text-center text-sm line-clamp-3">{p.ingredients || '-'}</td>
                  ))}
                </tr>

                {/* Dynamic Specs */}
                {Array.from(allSpecKeys).map((key) => (
                  <tr key={key} className="border-t bg-muted/20">
                    <td className="p-3 text-sm font-medium text-muted-foreground">{key}</td>
                    {products.map((p) => {
                      const specs = getSpecs(p)
                      const spec = specs.find((s) => s.key === key)
                      return (
                        <td key={p.id} className="p-3 text-center text-sm">{spec?.value || '-'}</td>
                      )
                    })}
                  </tr>
                ))}

                {/* Action */}
                <tr className="border-t">
                  <td className="p-3 text-sm font-medium text-muted-foreground">Action</td>
                  {products.map((p) => (
                    <td key={p.id} className="p-3 text-center">
                      <div className="flex flex-col gap-2 items-center">
                        <Button
                          size="sm"
                          disabled={p.stock <= 0}
                          onClick={() => handleAddToCart(p)}
                        >
                          <ShoppingCart className="h-3 w-3 mr-1" />
                          Add to Cart
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => navigate('product-detail', { id: p.id })}
                        >
                          View Details
                        </Button>
                      </div>
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}
