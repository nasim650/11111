'use client'

import { useEffect, useState, useRef } from 'react'
import Image from 'next/image'
import { ChevronLeft, ChevronRight, X, Clock, Package } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useAppStore } from '@/lib/store'
import { extractItems } from '@/lib/api'

// ─── Types ────────────────────────────────────────────────────────────────────

interface ViewedProduct {
  id: string
  name: string
  slug: string
  price: number
  discountPrice?: number | null
  unit: string
  stock: number
  images?: Array<{ url: string; alt?: string }>
  category?: { name: string; slug: string }
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function RecentlyViewedProducts() {
  const { recentlyViewed, clearRecentlyViewed, navigate, currentPage } = useAppStore()
  const [products, setProducts] = useState<ViewedProduct[]>([])
  const [loading, setLoading] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)
  const [canScrollLeft, setCanScrollLeft] = useState(false)
  const [canScrollRight, setCanScrollRight] = useState(false)

  // Only show on homepage and products page
  const shouldShow = currentPage === 'home' || currentPage === 'products'

  // ── Fetch product details for recently viewed IDs ──
  useEffect(() => {
    if (!shouldShow || recentlyViewed.length === 0) {
      setProducts([])
      return
    }

    const fetchProducts = async () => {
      setLoading(true)
      try {
        const results = await Promise.all(
          recentlyViewed.slice(0, 10).map(async (id) => {
            try {
              const res = await fetch(`/api/products/${id}`)
              if (res.ok) {
                const data = await res.json()
                // API may return { success, data: product } or just product
                return (data.data || data) as ViewedProduct
              }
              return null
            } catch {
              return null
            }
          })
        )
        // Filter out nulls and maintain order matching recentlyViewed
        const validProducts = results.filter(
          (p): p is ViewedProduct => p !== null && p.id !== undefined
        )
        setProducts(validProducts)
      } catch {
        setProducts([])
      } finally {
        setLoading(false)
      }
    }

    fetchProducts()
  }, [recentlyViewed, shouldShow])

  // ── Scroll detection ──
  const checkScroll = () => {
    if (!scrollRef.current) return
    const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current
    setCanScrollLeft(scrollLeft > 0)
    setCanScrollRight(scrollLeft + clientWidth < scrollWidth - 4)
  }

  useEffect(() => {
    checkScroll()
    const el = scrollRef.current
    if (el) {
      el.addEventListener('scroll', checkScroll, { passive: true })
      return () => el.removeEventListener('scroll', checkScroll)
    }
  }, [products])

  const scroll = (direction: 'left' | 'right') => {
    if (!scrollRef.current) return
    const amount = 280
    scrollRef.current.scrollBy({
      left: direction === 'left' ? -amount : amount,
      behavior: 'smooth',
    })
  }

  if (!shouldShow || recentlyViewed.length === 0) return null

  return (
    <section className="py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-muted-foreground" />
            <h2 className="text-xl md:text-2xl font-bold">Recently Viewed</h2>
            <Badge variant="secondary" className="text-xs">
              {products.length}
            </Badge>
          </div>
          <div className="flex items-center gap-2">
            {/* Scroll arrows - desktop only */}
            <div className="hidden sm:flex items-center gap-1">
              <Button
                variant="outline"
                size="icon"
                className="h-8 w-8"
                onClick={() => scroll('left')}
                disabled={!canScrollLeft}
                aria-label="Scroll left"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                className="h-8 w-8"
                onClick={() => scroll('right')}
                disabled={!canScrollRight}
                aria-label="Scroll right"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={clearRecentlyViewed}
              className="text-muted-foreground hover:text-destructive"
            >
              <X className="h-3.5 w-3.5 mr-1" />
              Clear All
            </Button>
          </div>
        </div>

        {/* Loading state */}
        {loading && (
          <div className="flex items-center gap-3 overflow-hidden">
            {Array.from({ length: Math.min(recentlyViewed.length, 4) }).map((_, i) => (
              <div
                key={i}
                className="flex-shrink-0 w-44 h-52 rounded-lg bg-muted/30 animate-pulse"
              />
            ))}
          </div>
        )}

        {/* Products scroll row */}
        {!loading && products.length > 0 && (
          <div className="relative group">
            {/* Left fade */}
            {canScrollLeft && (
              <div className="hidden sm:block absolute left-0 top-0 bottom-0 w-8 bg-gradient-to-r from-background to-transparent z-10 pointer-events-none" />
            )}

            <div
              ref={scrollRef}
              className="flex gap-3 overflow-x-auto scrollbar-hide pb-2 -mx-1 px-1"
              style={{
                scrollbarWidth: 'none',
                msOverflowStyle: 'none',
              }}
            >
              {products.map((product) => {
                const effectivePrice =
                  product.discountPrice != null ? product.discountPrice : product.price
                const hasDiscount =
                  product.discountPrice != null && product.discountPrice < product.price
                const imageUrl = product.images?.[0]?.url

                return (
                  <button
                    key={product.id}
                    className="flex-shrink-0 w-36 sm:w-44 group/card"
                    onClick={() => navigate('product-detail', { id: product.id })}
                  >
                    <div className="relative aspect-square rounded-lg overflow-hidden bg-muted/30 border border-border/50 group-hover/card:shadow-md group-hover/card:border-primary/30 transition-all">
                      {imageUrl ? (
                        <Image
                          src={imageUrl}
                          alt={product.name}
                          fill
                          className="object-cover"
                          sizes="176px"
                        />
                      ) : (
                        <div className="flex items-center justify-center h-full">
                          <Package className="h-8 w-8 text-muted-foreground/30" />
                        </div>
                      )}
                      {hasDiscount && (
                        <Badge className="absolute top-1.5 left-1.5 bg-red-500 text-white text-[10px] px-1.5 py-0">
                          -{Math.round(((product.price - product.discountPrice!) / product.price) * 100)}%
                        </Badge>
                      )}
                    </div>
                    <div className="mt-2 space-y-0.5 text-left">
                      <p className="text-xs font-medium line-clamp-2 leading-tight">
                        {product.name}
                      </p>
                      <div className="flex items-baseline gap-1">
                        <span className="text-sm font-bold text-primary">
                          ৳{effectivePrice.toLocaleString()}
                        </span>
                        {hasDiscount && (
                          <span className="text-xs text-muted-foreground line-through">
                            ৳{product.price.toLocaleString()}
                          </span>
                        )}
                      </div>
                    </div>
                  </button>
                )
              })}
            </div>

            {/* Right fade */}
            {canScrollRight && (
              <div className="hidden sm:block absolute right-0 top-0 bottom-0 w-8 bg-gradient-to-l from-background to-transparent z-10 pointer-events-none" />
            )}
          </div>
        )}
      </div>
    </section>
  )
}
