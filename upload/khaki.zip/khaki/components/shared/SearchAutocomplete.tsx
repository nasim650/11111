'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import Image from 'next/image'
import { Search, X, Package, ArrowRight, Loader2 } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { useAppStore } from '@/lib/store'
import { extractItems } from '@/lib/api'

// ─── Types ────────────────────────────────────────────────────────────────────

interface SearchProduct {
  id: string
  name: string
  slug: string
  price: number
  discountPrice?: number | null
  unit: string
  stock: number
  images?: Array<{ url: string; alt?: string }>
  category?: { name: string; slug: string }
}

interface SearchCategory {
  id: string
  name: string
  slug: string
  image?: string
}

interface SearchAutocompleteProps {
  /** Whether this is the mobile variant */
  isMobile?: boolean
  /** Callback when search is submitted */
  onSubmit?: () => void
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function SearchAutocomplete({ isMobile = false, onSubmit }: SearchAutocompleteProps) {
  const { searchQuery, setSearchQuery, navigate } = useAppStore()

  const [isOpen, setIsOpen] = useState(false)
  const [products, setProducts] = useState<SearchProduct[]>([])
  const [categories, setCategories] = useState<SearchCategory[]>([])
  const [loading, setLoading] = useState(false)
  const [highlightedIndex, setHighlightedIndex] = useState(-1)

  const containerRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const debounceRef = useRef<NodeJS.Timeout | null>(null)
  const resultsRef = useRef<HTMLDivElement>(null)

  // Total items for keyboard navigation
  const totalItems = categories.length + products.length
  const hasResults = categories.length > 0 || products.length > 0

  // ── Debounced search ──
  const performSearch = useCallback(async (query: string) => {
    if (!query.trim()) {
      setProducts([])
      setCategories([])
      setIsOpen(false)
      return
    }

    setLoading(true)
    try {
      const [prodRes, catRes] = await Promise.all([
        fetch(`/api/products?search=${encodeURIComponent(query)}&limit=6&status=active`).catch(() => null),
        fetch(`/api/categories?search=${encodeURIComponent(query)}&limit=4&isActive=true`).catch(() => null),
      ])

      if (prodRes?.ok) {
        const data = await prodRes.json()
        setProducts(extractItems<SearchProduct>(data))
      } else {
        setProducts([])
      }

      if (catRes?.ok) {
        const data = await catRes.json()
        setCategories(extractItems<SearchCategory>(data))
      } else {
        setCategories([])
      }

      setIsOpen(true)
    } catch {
      setProducts([])
      setCategories([])
    } finally {
      setLoading(false)
    }
  }, [])

  const handleInputChange = useCallback(
    (value: string) => {
      setSearchQuery(value)
      setHighlightedIndex(-1)

      if (debounceRef.current) {
        clearTimeout(debounceRef.current)
      }

      if (!value.trim()) {
        setProducts([])
        setCategories([])
        setIsOpen(false)
        return
      }

      debounceRef.current = setTimeout(() => {
        performSearch(value)
      }, 300)
    },
    [setSearchQuery, performSearch]
  )

  // ── Keyboard navigation ──
  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (!isOpen || !hasResults) {
        if (e.key === 'Enter') {
          e.preventDefault()
          if (searchQuery.trim()) {
            navigate('products', { search: searchQuery.trim() })
            setIsOpen(false)
            onSubmit?.()
          }
        }
        return
      }

      switch (e.key) {
        case 'ArrowDown':
          e.preventDefault()
          setHighlightedIndex((prev) =>
            prev < totalItems ? prev + 1 : 0
          )
          break
        case 'ArrowUp':
          e.preventDefault()
          setHighlightedIndex((prev) =>
            prev > 0 ? prev - 1 : totalItems
          )
          break
        case 'Enter':
          e.preventDefault()
          if (highlightedIndex >= 0) {
            if (highlightedIndex < categories.length) {
              // Category selected
              const cat = categories[highlightedIndex]
              navigate('products', { category: cat.slug })
            } else {
              // Product selected
              const prodIndex = highlightedIndex - categories.length
              const prod = products[prodIndex]
              if (prod) {
                navigate('product-detail', { id: prod.id })
              }
            }
            setIsOpen(false)
            onSubmit?.()
          } else {
            // No highlight, submit search
            if (searchQuery.trim()) {
              navigate('products', { search: searchQuery.trim() })
              setIsOpen(false)
              onSubmit?.()
            }
          }
          break
        case 'Escape':
          setIsOpen(false)
          setHighlightedIndex(-1)
          inputRef.current?.blur()
          break
      }
    },
    [isOpen, hasResults, totalItems, highlightedIndex, categories, products, navigate, searchQuery, onSubmit]
  )

  // ── Click outside to close ──
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false)
        setHighlightedIndex(-1)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  // ── Scroll highlighted item into view ──
  useEffect(() => {
    if (highlightedIndex >= 0 && resultsRef.current) {
      const items = resultsRef.current.querySelectorAll('[data-search-item]')
      if (items[highlightedIndex]) {
        items[highlightedIndex].scrollIntoView({ block: 'nearest' })
      }
    }
  }, [highlightedIndex])

  const handleSelectCategory = (cat: SearchCategory) => {
    navigate('products', { category: cat.slug })
    setIsOpen(false)
    onSubmit?.()
  }

  const handleSelectProduct = (prod: SearchProduct) => {
    navigate('product-detail', { id: prod.id })
    setIsOpen(false)
    onSubmit?.()
  }

  const handleViewAll = () => {
    navigate('products', { search: searchQuery.trim() })
    setIsOpen(false)
    onSubmit?.()
  }

  const handleClear = () => {
    setSearchQuery('')
    setProducts([])
    setCategories([])
    setIsOpen(false)
    setHighlightedIndex(-1)
    inputRef.current?.focus()
  }

  return (
    <div ref={containerRef} className="relative w-full">
      {/* Input */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
        <Input
          ref={inputRef}
          type="text"
          placeholder="Search for products, categories..."
          value={searchQuery}
          onChange={(e) => handleInputChange(e.target.value)}
          onFocus={() => {
            if (searchQuery.trim() && (products.length > 0 || categories.length > 0)) {
              setIsOpen(true)
            }
          }}
          onKeyDown={handleKeyDown}
          className={`${isMobile ? 'h-10 pl-10 pr-10' : 'h-9 pl-9 pr-9'} text-sm`}
          autoComplete="off"
          aria-label="Search products"
          aria-expanded={isOpen}
          role="combobox"
          aria-autocomplete="list"
        />
        {searchQuery && (
          <button
            onClick={handleClear}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
            aria-label="Clear search"
          >
            <X className="h-4 w-4" />
          </button>
        )}
        {loading && searchQuery && (
          <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 animate-spin text-muted-foreground" />
        )}
      </div>

      {/* Dropdown Results */}
      {isOpen && searchQuery.trim() && (
        <div
          ref={resultsRef}
          className="absolute z-50 top-full mt-1 w-full bg-background border border-border rounded-lg shadow-xl overflow-hidden"
          role="listbox"
        >
          <div className="max-h-80 overflow-y-auto overscroll-contain">
            {/* Loading state */}
            {loading && (
              <div className="flex items-center justify-center py-8 gap-2 text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" />
                <span className="text-sm">Searching...</span>
              </div>
            )}

            {/* No results */}
            {!loading && !hasResults && (
              <div className="py-8 text-center text-muted-foreground">
                <p className="text-sm">No results found for &ldquo;{searchQuery}&rdquo;</p>
                <p className="text-xs mt-1">Try different keywords</p>
              </div>
            )}

            {/* Categories Section */}
            {!loading && categories.length > 0 && (
              <div>
                <div className="px-3 py-2 bg-muted/50 border-b">
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                    Categories
                  </p>
                </div>
                {categories.map((cat, idx) => (
                  <button
                    key={cat.id}
                    data-search-item
                    className={`flex items-center gap-3 w-full px-3 py-2.5 text-left transition-colors ${
                      highlightedIndex === idx
                        ? 'bg-primary/10 text-primary'
                        : 'hover:bg-muted/50'
                    }`}
                    onClick={() => handleSelectCategory(cat)}
                    role="option"
                    aria-selected={highlightedIndex === idx}
                  >
                    <div className="h-8 w-8 rounded-full overflow-hidden bg-muted/30 flex-shrink-0">
                      {cat.image ? (
                        <Image
                          src={cat.image}
                          alt={cat.name}
                          width={32}
                          height={32}
                          className="object-cover w-full h-full"
                        />
                      ) : (
                        <div className="flex items-center justify-center h-full text-sm">🍽️</div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{cat.name}</p>
                    </div>
                    <ArrowRight className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0" />
                  </button>
                ))}
              </div>
            )}

            {/* Products Section */}
            {!loading && products.length > 0 && (
              <div>
                <div className="px-3 py-2 bg-muted/50 border-b">
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                    Products
                  </p>
                </div>
                {products.map((prod, idx) => {
                  const globalIdx = categories.length + idx
                  const effectivePrice =
                    prod.discountPrice != null ? prod.discountPrice : prod.price
                  const hasDiscount =
                    prod.discountPrice != null && prod.discountPrice < prod.price

                  return (
                    <button
                      key={prod.id}
                      data-search-item
                      className={`flex items-center gap-3 w-full px-3 py-2.5 text-left transition-colors ${
                        highlightedIndex === globalIdx
                          ? 'bg-primary/10 text-primary'
                          : 'hover:bg-muted/50'
                      }`}
                      onClick={() => handleSelectProduct(prod)}
                      role="option"
                      aria-selected={highlightedIndex === globalIdx}
                    >
                      <div className="h-10 w-10 rounded-md overflow-hidden bg-muted/30 flex-shrink-0">
                        {prod.images?.[0]?.url ? (
                          <Image
                            src={prod.images[0].url}
                            alt={prod.name}
                            width={40}
                            height={40}
                            className="object-cover w-full h-full"
                          />
                        ) : (
                          <div className="flex items-center justify-center h-full">
                            <Package className="h-4 w-4 text-muted-foreground/50" />
                          </div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{prod.name}</p>
                        <div className="flex items-center gap-1.5">
                          {prod.category && (
                            <span className="text-xs text-muted-foreground truncate">
                              {prod.category.name}
                            </span>
                          )}
                          <span className="text-xs text-muted-foreground">·</span>
                          <span className="text-xs font-semibold text-primary">
                            ৳{effectivePrice.toLocaleString()}
                          </span>
                          {hasDiscount && (
                            <span className="text-xs text-muted-foreground line-through">
                              ৳{prod.price.toLocaleString()}
                            </span>
                          )}
                        </div>
                      </div>
                    </button>
                  )
                })}
              </div>
            )}

            {/* View All Results */}
            {!loading && hasResults && (
              <div className="border-t">
                <button
                  data-search-item
                  className={`flex items-center justify-center gap-2 w-full px-3 py-3 text-sm font-medium transition-colors ${
                    highlightedIndex === totalItems
                      ? 'bg-primary/10 text-primary'
                      : 'text-primary hover:bg-primary/5'
                  }`}
                  onClick={handleViewAll}
                >
                  View all results for &ldquo;{searchQuery}&rdquo;
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
