'use client'

import { useState } from 'react'
import Image from 'next/image'
import { X, Minus, Plus, ShoppingBag, Trash2, Truck, Gift, Sparkles } from 'lucide-react'
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription, SheetFooter } from '@/components/ui/sheet'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Progress } from '@/components/ui/progress'
import { useAppStore } from '@/lib/store'

export default function CartSidebar() {
  const {
    isCartOpen,
    setCartOpen,
    cartItems,
    removeFromCart,
    updateQuantity,
    subtotal,
    totalItems,
    siteConfig,
    navigate,
  } = useAppStore()

  const [updatingId, setUpdatingId] = useState<string | null>(null)
  const [removingId, setRemovingId] = useState<string | null>(null)

  const freeShippingThreshold = siteConfig?.freeShippingThreshold || 1500
  const shippingCharge = siteConfig?.shippingCharge || 60
  const currentSubtotal = subtotal()
  const itemCount = totalItems()
  const shippingProgress = Math.min((currentSubtotal / freeShippingThreshold) * 100, 100)
  const isFreeShipping = currentSubtotal >= freeShippingThreshold
  const estimatedShipping = isFreeShipping ? 0 : shippingCharge
  const estimatedTotal = currentSubtotal + estimatedShipping
  const amountToFreeShipping = freeShippingThreshold - currentSubtotal

  const handleQuantityChange = async (cartItemId: string, newQty: number) => {
    if (newQty < 1) return
    setUpdatingId(cartItemId)
    try {
      await updateQuantity(cartItemId, newQty)
    } finally {
      setUpdatingId(null)
    }
  }

  const handleRemove = async (cartItemId: string) => {
    setRemovingId(cartItemId)
    try {
      await removeFromCart(cartItemId)
    } finally {
      setRemovingId(null)
    }
  }

  const handleCheckout = () => {
    setCartOpen(false)
    navigate('checkout')
  }

  return (
    <Sheet open={isCartOpen} onOpenChange={setCartOpen}>
      <SheetContent className="flex flex-col w-full sm:max-w-md p-0">
        {/* Header */}
        <SheetHeader className="px-6 pt-6 pb-4 border-b">
          <SheetTitle className="flex items-center gap-2">
            <ShoppingBag className="h-5 w-5 text-primary" />
            Shopping Cart
            {itemCount > 0 && (
              <span className="inline-flex items-center justify-center min-w-[22px] h-[22px] rounded-full bg-primary text-primary-foreground text-xs font-bold px-1.5 animate-in zoom-in-50 duration-200">
                {itemCount}
              </span>
            )}
          </SheetTitle>
          <SheetDescription className="sr-only">Your shopping cart items</SheetDescription>
        </SheetHeader>

        {cartItems.length === 0 ? (
          /* ── Empty Cart State ── */
          <div className="flex-1 flex flex-col items-center justify-center gap-6 p-8">
            <div className="relative">
              <div className="h-28 w-28 rounded-full bg-primary/5 flex items-center justify-center">
                <ShoppingBag className="h-12 w-12 text-primary/30" />
              </div>
              <div className="absolute -bottom-1 -right-1 h-10 w-10 rounded-full bg-secondary/10 flex items-center justify-center">
                <Sparkles className="h-5 w-5 text-secondary/50" />
              </div>
            </div>
            <div className="text-center space-y-2">
              <h3 className="font-semibold text-lg">Your cart is empty</h3>
              <p className="text-muted-foreground text-sm max-w-[240px]">
                Looks like you haven&apos;t added any authentic Bangladeshi products yet!
              </p>
            </div>
            <Button
              className="gap-2 min-w-[200px]"
              onClick={() => {
                setCartOpen(false)
                navigate('products')
              }}
            >
              <ShoppingBag className="h-4 w-4" />
              Start Shopping
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="text-primary gap-1"
              onClick={() => {
                setCartOpen(false)
                navigate('offers')
              }}
            >
              <Gift className="h-4 w-4" />
              Check out our offers
            </Button>
          </div>
        ) : (
          <>
            {/* ── Free Shipping Progress ── */}
            <div className="px-6 py-3 bg-primary/5 border-b">
              {isFreeShipping ? (
                <div className="flex items-center gap-2 text-primary text-sm font-medium">
                  <Truck className="h-4 w-4 shrink-0" />
                  <span>You qualify for FREE shipping!</span>
                  <span className="text-lg">🎉</span>
                </div>
              ) : (
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2 text-sm">
                    <Truck className="h-4 w-4 shrink-0 text-muted-foreground" />
                    <span className="text-muted-foreground">
                      Add <span className="font-semibold text-primary">৳{amountToFreeShipping.toLocaleString()}</span> more for free shipping
                    </span>
                  </div>
                  <Progress value={shippingProgress} className="h-2" />
                </div>
              )}
            </div>

            {/* ── Cart Items ── */}
            <ScrollArea className="flex-1">
              <div className="space-y-1 p-6">
                {cartItems.map((item, index) => {
                  const price = item.discountPrice != null ? item.discountPrice : item.price
                  const hasDiscount = item.discountPrice != null && item.discountPrice < item.price
                  const qty = Number(item.quantity) || 1
                  const itemPrice = Number(price) || 0
                  const originalPrice = Number(item.price) || 0
                  return (
                    <div
                      key={`cart-${item.id}-${index}`}
                      className={`flex gap-3 p-3 rounded-xl hover:bg-muted/50 transition-all duration-300 ${
                        removingId === item.id ? 'opacity-0 scale-95 translate-x-4' : 'opacity-100'
                      }`}
                      style={{ animationDelay: `${index * 50}ms` }}
                    >
                      {/* Product Image */}
                      <div className="relative h-20 w-20 rounded-lg overflow-hidden bg-muted/30 flex-shrink-0 ring-1 ring-border/50">
                        <Image
                          src={item.image}
                          alt={item.productName}
                          fill
                          className="object-cover"
                          sizes="80px"
                        />
                      </div>

                      {/* Product Details */}
                      <div className="flex-1 min-w-0">
                        <h4 className="text-sm font-medium line-clamp-2 leading-tight">{item.productName}</h4>
                        <p className="text-xs text-muted-foreground mt-0.5">/{item.unit}</p>

                        {/* Price with strikethrough for discount */}
                        <div className="flex items-baseline gap-1.5 mt-1">
                          <span className="text-sm font-bold text-primary">
                            ৳{(itemPrice * qty).toLocaleString()}
                          </span>
                          {hasDiscount && (
                            <span className="text-xs text-muted-foreground line-through">
                              ৳{(originalPrice * qty).toLocaleString()}
                            </span>
                          )}
                        </div>

                        {/* Quantity Controls */}
                        <div className="flex items-center justify-between mt-2">
                          <div className="flex items-center rounded-lg border bg-background overflow-hidden">
                            <button
                              className="h-8 w-8 flex items-center justify-center hover:bg-primary/10 text-primary transition-all duration-150 active:scale-90"
                              onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                              disabled={updatingId === item.id}
                              aria-label="Decrease quantity"
                            >
                              <Minus className="h-3 w-3" />
                            </button>
                            <span className="h-8 w-9 flex items-center justify-center text-sm font-semibold border-x">
                              {qty}
                            </span>
                            <button
                              className="h-8 w-8 flex items-center justify-center hover:bg-primary/10 text-primary transition-all duration-150 active:scale-90 disabled:opacity-40 disabled:cursor-not-allowed"
                              onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                              disabled={updatingId === item.id || item.quantity >= item.stock}
                              aria-label="Increase quantity"
                            >
                              <Plus className="h-3 w-3" />
                            </button>
                          </div>

                          {/* Delete button */}
                          <button
                            className="h-8 w-8 flex items-center justify-center rounded-lg text-muted-foreground hover:text-red-500 hover:bg-red-50 transition-all duration-150 active:scale-90"
                            onClick={() => handleRemove(item.id)}
                            aria-label="Remove item"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            </ScrollArea>

            {/* ── You Might Also Like ── */}
            <div className="px-6 py-3 border-t bg-muted/20">
              <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground mb-2">
                <Sparkles className="h-3.5 w-3.5 text-secondary" />
                You might also like
              </div>
              <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
                {cartItems.slice(0, 2).map((item, index) => (
                  <button
                    key={`suggest-${item.id}-${index}`}
                    className="flex items-center gap-2 p-2 rounded-lg border border-border/50 bg-background hover:shadow-sm transition-shadow shrink-0"
                    onClick={() => {
                      setCartOpen(false)
                      navigate('products')
                    }}
                  >
                    <div className="h-8 w-8 rounded bg-muted/30 overflow-hidden relative shrink-0">
                      <Image src={item.image} alt="" fill className="object-cover" sizes="32px" />
                    </div>
                    <span className="text-xs text-muted-foreground line-clamp-1">Explore more</span>
                  </button>
                ))}
              </div>
            </div>

            {/* ── Cart Summary & Actions ── */}
            <div className="border-t px-6 py-4 space-y-3 bg-background">
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Subtotal ({itemCount} items)</span>
                  <span className="font-medium">৳{currentSubtotal.toLocaleString()}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Shipping</span>
                  {isFreeShipping ? (
                    <span className="font-medium text-primary">FREE</span>
                  ) : (
                    <span className="font-medium">৳{estimatedShipping.toLocaleString()}</span>
                  )}
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <span className="font-semibold">Estimated Total</span>
                  <span className="text-lg font-bold text-primary">৳{estimatedTotal.toLocaleString()}</span>
                </div>
                {!isFreeShipping && (
                  <p className="text-xs text-muted-foreground">
                    Shipping calculated at checkout. Free shipping on orders ৳{freeShippingThreshold.toLocaleString()}+
                  </p>
                )}
              </div>

              <SheetFooter className="gap-2 sm:gap-2 p-0">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => {
                    setCartOpen(false)
                    navigate('cart')
                  }}
                >
                  View Cart
                </Button>
                <Button className="flex-1 gap-2" onClick={handleCheckout}>
                  Checkout
                  <span className="text-xs opacity-80">৳{estimatedTotal.toLocaleString()}</span>
                </Button>
              </SheetFooter>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  )
}
