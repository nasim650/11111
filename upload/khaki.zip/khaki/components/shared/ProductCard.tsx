'use client'

import { useState } from 'react'
import Image from 'next/image'
import { Heart, ShoppingCart, Eye, Star, Package, Check } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import { useAppStore, type CartItem, type WishlistItem } from '@/lib/store'
import { toast } from 'sonner'

interface Product {
  id: string
  name: string
  slug: string
  price: number
  discountPrice?: number | null
  unit: string
  stock: number
  images?: Array<{ url: string; alt?: string }>
  category?: { name: string; slug: string }
  status?: string
  isNewArrival?: boolean
  isBestSeller?: boolean
  isFeatured?: boolean
  shortDescription?: string
  averageRating?: number
  reviewCount?: number
}

interface ProductCardProps {
  product: Product
}

export default function ProductCard({ product }: ProductCardProps) {
  const { navigate, addToCart, isInWishlist, toggleWishlist, openQuickView, isInCompare, addToCompare, removeFromCompare } =
    useAppStore()
  const [loading, setLoading] = useState(false)
  const [imgError, setImgError] = useState(false)
  const [imgLoaded, setImgLoaded] = useState(false)
  const [compareChecked, setCompareChecked] = useState(isInCompare(product.id))
  const wishlisted = isInWishlist(product.id)
  const imageUrl =
    product.images?.[0]?.url && !imgError ? product.images[0].url : ''
  const effectivePrice =
    product.discountPrice != null ? product.discountPrice : product.price
  const hasDiscount =
    product.discountPrice != null && product.discountPrice < product.price
  const discountPercent = hasDiscount
    ? Math.round(((product.price - product.discountPrice!) / product.price) * 100)
    : 0

  // Stock status
  const outOfStock = product.stock <= 0
  const lowStock = product.stock > 0 && product.stock <= 5

  const handleAddToCart = async (e: React.MouseEvent) => {
    e.stopPropagation()
    if (outOfStock) return
    setLoading(true)
    try {
      const cartItem: Omit<CartItem, 'id'> = {
        productId: product.id,
        productName: product.name,
        price: product.price,
        discountPrice: product.discountPrice,
        quantity: 1,
        unit: product.unit,
        image: imageUrl || '/placeholder.png',
        stock: product.stock,
      }
      await addToCart(cartItem)
      toast.success('Added to cart')
    } catch {
      toast.error('Failed to add to cart')
    } finally {
      setLoading(false)
    }
  }

  const handleWishlist = async (e: React.MouseEvent) => {
    e.stopPropagation()
    const item: WishlistItem = {
      productId: product.id,
      productName: product.name,
      price: product.price,
      discountPrice: product.discountPrice,
      image: imageUrl || '/placeholder.png',
    }
    await toggleWishlist(item)
    toast.success(wishlisted ? 'Removed from wishlist' : 'Added to wishlist')
  }

  const handleQuickView = (e: React.MouseEvent) => {
    e.stopPropagation()
    openQuickView(product.id)
  }

  const handleCompare = (e: React.MouseEvent) => {
    e.stopPropagation()
    if (compareChecked) {
      removeFromCompare(product.id)
      setCompareChecked(false)
      toast.success('Removed from comparison')
    } else {
      addToCompare(product.id)
      setCompareChecked(true)
      toast.success('Added to comparison')
    }
  }

  return (
    <Card
      className="group cursor-pointer overflow-hidden border-border/50 transition-all duration-300 hover:shadow-xl hover:-translate-y-1 rounded-xl"
      onClick={() => navigate('product-detail', { id: product.id })}
    >
      <div className="relative aspect-square overflow-hidden bg-muted/30 rounded-t-xl">
        {/* Shimmer loading effect for images */}
        {imageUrl && !imgLoaded && (
          <div className="absolute inset-0 bg-gradient-to-r from-muted/50 via-muted to-muted/50 animate-pulse" />
        )}

        {imageUrl ? (
          <Image
            src={imageUrl}
            alt={product.name}
            fill
            className={`object-cover transition-all duration-500 group-hover:scale-110 ${imgLoaded ? 'opacity-100' : 'opacity-0'}`}
            sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
            onError={() => setImgError(true)}
            onLoad={() => setImgLoaded(true)}
          />
        ) : (
          <div className="flex items-center justify-center h-full bg-gradient-to-br from-primary/10 to-primary/5">
            <Package className="h-12 w-12 text-primary/30" />
          </div>
        )}

        {/* Badges - Top Left (fixed duplicate bug) */}
        <div className="absolute top-2 left-2 flex flex-col gap-1 z-10">
          {hasDiscount && (
            <Badge className="bg-red-500 text-white text-xs px-2 py-0.5 font-bold shadow-sm">
              -{discountPercent}%
            </Badge>
          )}
          {product.isNewArrival && (
            <Badge className="bg-emerald-500 text-white text-xs px-2 shadow-sm">
              New
            </Badge>
          )}
          {product.isBestSeller && (
            <Badge className="bg-amber-500 text-white text-xs px-2 shadow-sm">
              Best Seller
            </Badge>
          )}
          {lowStock && !outOfStock && (
            <Badge className="bg-orange-500 text-white text-xs px-2 shadow-sm">
              Low Stock
            </Badge>
          )}
        </div>

        {/* Wishlist Button - Top Right */}
        <Button
          variant="secondary"
          size="icon"
          className="absolute top-2 right-2 h-9 w-9 rounded-full bg-white/90 shadow-md hover:bg-white hover:scale-110 transition-all z-10"
          onClick={handleWishlist}
          aria-label={wishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
        >
          <Heart
            className={`h-4 w-4 transition-all duration-300 ${wishlisted ? 'fill-red-500 text-red-500 scale-110' : 'text-gray-600'}`}
          />
        </Button>

        {/* Compare checkbox - Bottom Left */}
        <div className="absolute bottom-2 left-2 z-10">
          <button
            onClick={handleCompare}
            className={`flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-medium transition-all duration-200 ${
              compareChecked
                ? 'bg-primary text-primary-foreground shadow-sm'
                : 'bg-white/80 text-muted-foreground hover:bg-white hover:text-foreground'
            }`}
            aria-label={compareChecked ? 'Remove from comparison' : 'Add to comparison'}
          >
            {compareChecked ? (
              <Check className="h-3 w-3" />
            ) : (
              <div className="h-3 w-3 rounded border border-current" />
            )}
            Compare
          </button>
        </div>

        {/* Hover Actions Overlay */}
        <div className="absolute bottom-2 right-2 left-14 flex gap-2 opacity-0 group-hover:opacity-100 translate-y-3 group-hover:translate-y-0 transition-all duration-300 z-10">
          <Button
            size="sm"
            className="flex-1 h-9 text-xs font-semibold shadow-md min-h-[44px]"
            disabled={outOfStock || loading}
            onClick={handleAddToCart}
          >
            <ShoppingCart className="h-3.5 w-3.5 mr-1" />
            {loading ? 'Adding...' : outOfStock ? 'Out of Stock' : 'Add'}
          </Button>
          <Button
            variant="secondary"
            size="icon"
            className="h-9 w-9 min-w-[44px] rounded-full bg-white/90 shadow-md hover:bg-white shrink-0"
            onClick={handleQuickView}
            aria-label="Quick view"
          >
            <Eye className="h-3.5 w-3.5" />
          </Button>
        </div>

        {/* Out of stock overlay */}
        {outOfStock && (
          <div className="absolute inset-0 bg-black/40 flex items-center justify-center z-20">
            <Badge variant="secondary" className="text-sm bg-white/90 text-gray-800 font-semibold px-4 py-1">
              Out of Stock
            </Badge>
          </div>
        )}
      </div>

      <CardContent className="p-3 space-y-1.5">
        {/* Category */}
        {product.category && (
          <p className="text-xs text-muted-foreground truncate">
            {product.category.name}
          </p>
        )}

        {/* Name */}
        <h3 className="font-medium text-sm line-clamp-2 leading-tight min-h-[2.5rem]">
          {product.name}
        </h3>

        {/* Rating */}
        {product.averageRating != null && product.averageRating > 0 && (
          <div className="flex items-center gap-1">
            <div className="flex">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star
                  key={i}
                  className={`h-3 w-3 ${
                    i < Math.round(product.averageRating!)
                      ? 'fill-amber-400 text-amber-400'
                      : 'text-gray-200'
                  }`}
                />
              ))}
            </div>
            {product.reviewCount != null && product.reviewCount > 0 && (
              <span className="text-xs text-muted-foreground">
                ({product.reviewCount})
              </span>
            )}
          </div>
        )}

        {/* Price - larger discount price, strikethrough original */}
        <div className="flex items-baseline gap-1.5 flex-wrap">
          <span className="text-lg font-bold text-primary">
            ৳{effectivePrice.toLocaleString()}
          </span>
          {hasDiscount && (
            <span className="text-sm text-muted-foreground line-through">
              ৳{product.price.toLocaleString()}
            </span>
          )}
          <span className="text-xs text-muted-foreground">/{product.unit}</span>
        </div>

        {/* Savings amount for discount items */}
        {hasDiscount && (
          <p className="text-xs text-emerald-600 font-medium">
            You save ৳{(product.price - product.discountPrice!).toLocaleString()}
          </p>
        )}

        {/* Add to cart button (visible on mobile / always) - bigger touch target */}
        <Button
          className="w-full h-11 text-sm mt-2 min-h-[44px] transition-all duration-200 active:scale-[0.98]"
          size="sm"
          disabled={outOfStock || loading}
          onClick={handleAddToCart}
        >
          <ShoppingCart className="h-4 w-4 mr-1" />
          {loading ? 'Adding...' : outOfStock ? 'Out of Stock' : 'Add to Cart'}
        </Button>
      </CardContent>
    </Card>
  )
}
