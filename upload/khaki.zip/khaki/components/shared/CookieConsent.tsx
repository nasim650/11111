'use client'

import { useState, useEffect, useCallback } from 'react'
import { Cookie, Settings, ShieldCheck } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { useAppStore } from '@/lib/store'

// ─── Types ────────────────────────────────────────────────────────────────────

interface CookiePreferences {
  essential: boolean // Always true - can't be disabled
  analytics: boolean
  marketing: boolean
  functional: boolean
}

// ─── Constants ────────────────────────────────────────────────────────────────

const COOKIE_CONSENT_KEY = 'kk_cookie_consent'
const COOKIE_PREFS_KEY = 'kk_cookie_prefs'

const defaultPreferences: CookiePreferences = {
  essential: true,
  analytics: true,
  marketing: true,
  functional: true,
}

// ─── Helper: Load preferences from localStorage ──

function loadSavedPreferences(): CookiePreferences {
  if (typeof window === 'undefined') return defaultPreferences
  try {
    const savedPrefs = localStorage.getItem(COOKIE_PREFS_KEY)
    if (savedPrefs) {
      return { ...defaultPreferences, ...JSON.parse(savedPrefs) }
    }
  } catch {
    // Ignore parse errors
  }
  return defaultPreferences
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function CookieConsent() {
  const navigate = useAppStore((s) => s.navigate)

  // Initialize with false to avoid hydration mismatch
  // Then check localStorage after hydration in useEffect
  const [showBanner, setShowBanner] = useState(false)
  const [visible, setVisible] = useState(false)
  const [preferences, setPreferences] = useState<CookiePreferences>(defaultPreferences)
  const [customizeOpen, setCustomizeOpen] = useState(false)

  // ── Check localStorage and animate banner in after mount if not yet consented ──
  useEffect(() => {
    // Check if user has already given consent
    const hasConsent = localStorage.getItem(COOKIE_CONSENT_KEY)
    if (hasConsent) return

    // Load saved preferences
    const savedPrefs = loadSavedPreferences()
    setPreferences(savedPrefs)
    setShowBanner(true)

    // Animate banner in
    const timer = setTimeout(() => {
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          setVisible(true)
        })
      })
    }, 1000)
    return () => clearTimeout(timer)
  }, [])

  const dismissBanner = useCallback(() => {
    setVisible(false)
    setTimeout(() => setShowBanner(false), 300)
  }, [])

  const handleAcceptAll = useCallback(() => {
    const allAccepted: CookiePreferences = {
      essential: true,
      analytics: true,
      marketing: true,
      functional: true,
    }
    localStorage.setItem(COOKIE_CONSENT_KEY, 'accepted')
    localStorage.setItem(COOKIE_PREFS_KEY, JSON.stringify(allAccepted))
    setPreferences(allAccepted)
    dismissBanner()
  }, [dismissBanner])

  const handleAcceptCustom = useCallback(() => {
    localStorage.setItem(COOKIE_CONSENT_KEY, 'custom')
    localStorage.setItem(COOKIE_PREFS_KEY, JSON.stringify(preferences))
    setCustomizeOpen(false)
    dismissBanner()
  }, [preferences, dismissBanner])

  const handleRejectOptional = useCallback(() => {
    const essentialOnly: CookiePreferences = {
      essential: true,
      analytics: false,
      marketing: false,
      functional: false,
    }
    localStorage.setItem(COOKIE_CONSENT_KEY, 'essential_only')
    localStorage.setItem(COOKIE_PREFS_KEY, JSON.stringify(essentialOnly))
    setPreferences(essentialOnly)
    dismissBanner()
  }, [dismissBanner])

  const togglePreference = useCallback((key: keyof CookiePreferences) => {
    if (key === 'essential') return // Can't disable essential
    setPreferences((prev) => ({
      ...prev,
      [key]: !prev[key],
    }))
  }, [])

  if (!showBanner) return null

  return (
    <div
      className={`fixed bottom-0 left-0 right-0 z-50 transition-transform duration-300 ease-out ${
        visible ? 'translate-y-0' : 'translate-y-full'
      }`}
    >
      <div className="bg-background border-t border-border shadow-2xl">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            {/* Cookie icon and text */}
            <div className="flex items-start gap-3 flex-1">
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                <Cookie className="h-5 w-5 text-primary" />
              </div>
              <div className="space-y-1">
                <h3 className="text-sm font-semibold flex items-center gap-2">
                  We value your privacy
                  <ShieldCheck className="h-3.5 w-3.5 text-primary" />
                </h3>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  We use cookies to enhance your browsing experience, serve personalized content, and analyze our traffic. 
                  By clicking &ldquo;Accept All&rdquo;, you consent to our use of cookies.{' '}
                  <button
                    onClick={() => navigate('privacy')}
                    className="text-primary hover:underline inline"
                  >
                    Read our Privacy Policy
                  </button>
                </p>
              </div>
            </div>

            {/* Action buttons */}
            <div className="flex items-center gap-2 flex-shrink-0 w-full sm:w-auto">
              <Dialog open={customizeOpen} onOpenChange={setCustomizeOpen}>
                <DialogTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    className="gap-1.5 h-9 text-xs"
                  >
                    <Settings className="h-3.5 w-3.5" />
                    Customize
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                      <Cookie className="h-5 w-5 text-primary" />
                      Cookie Preferences
                    </DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    {/* Essential */}
                    <div className="flex items-center justify-between gap-3">
                      <div className="space-y-0.5">
                        <Label className="text-sm font-medium">Essential Cookies</Label>
                        <p className="text-xs text-muted-foreground">
                          Required for the site to function properly. Cannot be disabled.
                        </p>
                      </div>
                      <Switch checked={true} disabled />
                    </div>

                    {/* Analytics */}
                    <div className="flex items-center justify-between gap-3">
                      <div className="space-y-0.5">
                        <Label className="text-sm font-medium">Analytics Cookies</Label>
                        <p className="text-xs text-muted-foreground">
                          Help us understand how visitors interact with the site.
                        </p>
                      </div>
                      <Switch
                        checked={preferences.analytics}
                        onCheckedChange={() => togglePreference('analytics')}
                      />
                    </div>

                    {/* Marketing */}
                    <div className="flex items-center justify-between gap-3">
                      <div className="space-y-0.5">
                        <Label className="text-sm font-medium">Marketing Cookies</Label>
                        <p className="text-xs text-muted-foreground">
                          Used to deliver personalized advertisements.
                        </p>
                      </div>
                      <Switch
                        checked={preferences.marketing}
                        onCheckedChange={() => togglePreference('marketing')}
                      />
                    </div>

                    {/* Functional */}
                    <div className="flex items-center justify-between gap-3">
                      <div className="space-y-0.5">
                        <Label className="text-sm font-medium">Functional Cookies</Label>
                        <p className="text-xs text-muted-foreground">
                          Enable enhanced functionality and personalization.
                        </p>
                      </div>
                      <Switch
                        checked={preferences.functional}
                        onCheckedChange={() => togglePreference('functional')}
                      />
                    </div>
                  </div>
                  <div className="flex justify-end gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={handleRejectOptional}
                    >
                      Essential Only
                    </Button>
                    <Button size="sm" onClick={handleAcceptCustom}>
                      Save Preferences
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>

              <Button
                variant="ghost"
                size="sm"
                className="h-9 text-xs text-muted-foreground hover:text-foreground"
                onClick={handleRejectOptional}
              >
                Essential Only
              </Button>

              <Button
                size="sm"
                className="h-9 text-xs gap-1.5"
                onClick={handleAcceptAll}
              >
                Accept All
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
