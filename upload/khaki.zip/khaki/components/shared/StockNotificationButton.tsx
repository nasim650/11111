'use client'

import { useState } from 'react'
import { Bell, Mail, CheckCircle2, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { toast } from 'sonner'

interface StockNotificationButtonProps {
  productId: string
  productName: string
}

export default function StockNotificationButton({ productId, productName }: StockNotificationButtonProps) {
  const [open, setOpen] = useState(false)
  const [email, setEmail] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [alreadyRegistered, setAlreadyRegistered] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!email.trim()) {
      toast.error('Please enter your email address')
      return
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      toast.error('Please enter a valid email address')
      return
    }

    setSubmitting(true)
    try {
      const res = await fetch('/api/stock-notifications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productId, email: email.trim() }),
      })
      const data = await res.json()

      if (!res.ok) {
        // If product is actually in stock
        if (data.error?.includes('in stock')) {
          toast.info(data.error)
          setOpen(false)
          return
        }
        throw new Error(data.error || 'Failed to register')
      }

      // Check if already registered
      if (data.message?.includes('already registered') || data.message?.includes('already been notified')) {
        setAlreadyRegistered(true)
        toast.info(data.message)
      } else {
        setSubmitted(true)
        toast.success(data.message || `You'll be notified when "${productName}" is back in stock!`)
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Failed to register for notification')
    } finally {
      setSubmitting(false)
    }
  }

  function handleOpenChange(newOpen: boolean) {
    setOpen(newOpen)
    if (newOpen) {
      // Reset state when opening
      setSubmitted(false)
      setAlreadyRegistered(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        <Button
          variant="outline"
          className="w-full gap-2 border-primary/30 text-primary hover:bg-primary/5"
        >
          <Bell className="size-4" />
          Notify Me When Available
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Bell className="size-5 text-primary" />
            Back in Stock Notification
          </DialogTitle>
          <DialogDescription>
            {submitted || alreadyRegistered
              ? 'Notification status'
              : `We'll email you when "${productName}" is back in stock.`}
          </DialogDescription>
        </DialogHeader>

        {submitted ? (
          <div className="py-6 text-center">
            <div className="size-12 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-3">
              <CheckCircle2 className="size-6 text-emerald-600" />
            </div>
            <h3 className="font-semibold mb-1">You&apos;re all set!</h3>
            <p className="text-sm text-muted-foreground">
              We&apos;ll send an email to <span className="font-medium">{email}</span> when
              this product is back in stock.
            </p>
            <Button
              variant="outline"
              className="mt-4"
              onClick={() => setOpen(false)}
            >
              Done
            </Button>
          </div>
        ) : alreadyRegistered ? (
          <div className="py-6 text-center">
            <div className="size-12 rounded-full bg-amber-100 flex items-center justify-center mx-auto mb-3">
              <Mail className="size-6 text-amber-600" />
            </div>
            <h3 className="font-semibold mb-1">You&apos;ll be notified</h3>
            <p className="text-sm text-muted-foreground">
              {email} is already registered to receive a notification when this product is back in stock.
            </p>
            <Button
              variant="outline"
              className="mt-4"
              onClick={() => setOpen(false)}
            >
              Done
            </Button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="stock-notification-email">Email Address</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                <Input
                  id="stock-notification-email"
                  type="email"
                  placeholder="your@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10"
                  required
                  autoFocus
                />
              </div>
              <p className="text-xs text-muted-foreground">
                We&apos;ll only use your email for this notification. No spam.
              </p>
            </div>
            <div className="flex gap-2 justify-end">
              <Button
                type="button"
                variant="outline"
                onClick={() => setOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={submitting} className="gap-2">
                {submitting ? (
                  <>
                    <Loader2 className="size-4 animate-spin" />
                    Registering...
                  </>
                ) : (
                  <>
                    <Bell className="size-4" />
                    Notify Me
                  </>
                )}
              </Button>
            </div>
          </form>
        )}
      </DialogContent>
    </Dialog>
  )
}
