'use client'

import { useEffect, useState } from 'react'
import Image from 'next/image'
import { ShoppingCart, Heart, Eye } from 'lucide-react'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useAppStore, type CartItem, type WishlistItem } from '@/lib/store'
import { toast } from 'sonner'

interface QuickProduct {
  id: string
  name: string
  price: number
  discountPrice?: number | null
  unit: string
  stock: number
  shortDescription?: string
  images?: Array<{ url: string; alt?: string }>
  category?: { name: string }
}

export default function QuickViewModal() {
  const { isQuickViewOpen, quickViewProductId, closeQuickView, navigate, addToCart, isInWishlist, toggleWishlist } = useAppStore()
  const [product, setProduct] = useState<QuickProduct | null>(null)
  const [loading, setLoading] = useState(true)
  const [adding, setAdding] = useState(false)
  const wishlisted = quickViewProductId ? isInWishlist(quickViewProductId) : false

  useEffect(() => {
    if (isQuickViewOpen && quickViewProductId) {
      setLoading(true)
      fetch(`/api/products/${quickViewProductId}`)
        .then((res) => res.json())
        .then((data) => {
          // Extract product from API response wrapper
          const productData = data?.data || data
          setProduct(productData)
          setLoading(false)
        })
        .catch(() => {
          setProduct(null)
          setLoading(false)
        })
    } else {
      setProduct(null)
    }
  }, [isQuickViewOpen, quickViewProductId])

  const handleAddToCart = async () => {
    if (!product || product.stock <= 0) return
    setAdding(true)
    try {
      const imageUrl = product.images?.[0]?.url || '/placeholder.png'
      const cartItem: Omit<CartItem, 'id'> = {
        productId: product.id,
        productName: product.name,
        price: product.price,
        discountPrice: product.discountPrice,
        quantity: 1,
        unit: product.unit,
        image: imageUrl,
        stock: product.stock,
      }
      await addToCart(cartItem)
      toast.success('Added to cart')
    } catch {
      toast.error('Failed to add to cart')
    } finally {
      setAdding(false)
    }
  }

  const handleWishlist = async () => {
    if (!product) return
    const imageUrl = product.images?.[0]?.url || '/placeholder.png'
    const item: WishlistItem = {
      productId: product.id,
      productName: product.name,
      price: product.price,
      discountPrice: product.discountPrice,
      image: imageUrl,
    }
    await toggleWishlist(item)
    toast.success(wishlisted ? 'Removed from wishlist' : 'Added to wishlist')
  }

  const handleViewDetails = () => {
    if (!product) return
    closeQuickView()
    navigate('product-detail', { id: product.id })
  }

  const imageUrl = product?.images?.[0]?.url || '/placeholder.png'
  const effectivePrice = product?.discountPrice != null ? product.discountPrice : product?.price
  const hasDiscount = product?.discountPrice != null && product.discountPrice < product.price

  return (
    <Dialog open={isQuickViewOpen} onOpenChange={(open) => !open && closeQuickView()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{product?.name || 'Quick View'}</DialogTitle>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
          </div>
        ) : product ? (
          <div className="space-y-4">
            <div className="relative aspect-square rounded-lg overflow-hidden bg-muted/30">
              <Image
                src={imageUrl}
                alt={product.name}
                fill
                className="object-cover"
                sizes="400px"
              />
              {hasDiscount && (
                <Badge className="absolute top-2 left-2 bg-red-500 text-white">
                  -{Math.round(((product.price - product.discountPrice!) / product.price) * 100)}%
                </Badge>
              )}
            </div>

            {product.category && (
              <p className="text-xs text-muted-foreground">{product.category.name}</p>
            )}

            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold text-primary">
                ৳{effectivePrice?.toLocaleString()}
              </span>
              {hasDiscount && (
                <span className="text-lg text-muted-foreground line-through">
                  ৳{product.price.toLocaleString()}
                </span>
              )}
              <span className="text-sm text-muted-foreground">/{product.unit}</span>
            </div>

            {product.shortDescription && (
              <p className="text-sm text-muted-foreground line-clamp-3">
                {product.shortDescription}
              </p>
            )}

            {product.stock <= 0 ? (
              <Badge variant="secondary" className="text-red-500">Out of Stock</Badge>
            ) : (
              <p className="text-sm text-emerald-600">
                In Stock ({product.stock} available)
              </p>
            )}

            <div className="flex gap-2">
              <Button
                className="flex-1"
                disabled={product.stock <= 0 || adding}
                onClick={handleAddToCart}
              >
                <ShoppingCart className="h-4 w-4 mr-2" />
                {adding ? 'Adding...' : 'Add to Cart'}
              </Button>
              <Button
                variant="outline"
                size="icon"
                onClick={handleWishlist}
              >
                <Heart className={`h-4 w-4 ${wishlisted ? 'fill-red-500 text-red-500' : ''}`} />
              </Button>
            </div>

            <Button
              variant="outline"
              className="w-full"
              onClick={handleViewDetails}
            >
              <Eye className="h-4 w-4 mr-2" />
              View Full Details
            </Button>
          </div>
        ) : (
          <p className="text-center text-muted-foreground py-8">Product not found</p>
        )}
      </DialogContent>
    </Dialog>
  )
}
