'use client'

import { useState } from 'react'
import { Phone, MessageCircle, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useAppStore } from '@/lib/store'

export default function FloatingSupport() {
  const { siteConfig } = useAppStore()
  const [isOpen, setIsOpen] = useState(false)

  const phone = siteConfig?.phone || '+880 1XXX-XXXXXX'
  const whatsappNumber = phone.replace(/[^0-9]/g, '')

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-2">
      {isOpen && (
        <div className="flex flex-col gap-2 mb-2 animate-in slide-in-from-bottom-2 duration-200">
          <Button
            variant="default"
            size="sm"
            className="rounded-full shadow-lg gap-2 bg-[#25D366] hover:bg-[#20bd5a]"
            asChild
          >
            <a
              href={`https://wa.me/${whatsappNumber}`}
              target="_blank"
              rel="noopener noreferrer"
            >
              <MessageCircle className="h-4 w-4" />
              WhatsApp
            </a>
          </Button>
          <Button
            variant="default"
            size="sm"
            className="rounded-full shadow-lg gap-2"
            asChild
          >
            <a href={`tel:${phone}`}>
              <Phone className="h-4 w-4" />
              Call Us
            </a>
          </Button>
        </div>
      )}
      <Button
        className="h-14 w-14 rounded-full shadow-xl hover:shadow-2xl transition-all"
        size="icon"
        onClick={() => setIsOpen(!isOpen)}
      >
        {isOpen ? (
          <X className="h-6 w-6" />
        ) : (
          <MessageCircle className="h-6 w-6" />
        )}
      </Button>
    </div>
  )
}
