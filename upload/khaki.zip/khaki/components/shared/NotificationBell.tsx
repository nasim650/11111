'use client'

import { useEffect, useReducer, useRef, useState } from 'react'
import { Bell, Check, CheckCheck, Trash2, ShoppingCart, Tag, AlertCircle, Info, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { useAppStore } from '@/lib/store'
import { extractItems } from '@/lib/api'
import { toast } from 'sonner'

interface Notification {
  id: string
  title: string
  message: string
  type: string
  isRead: boolean
  createdAt: string
  userId?: string
}

type NotificationAction =
  | { type: 'SET'; payload: Notification[] }
  | { type: 'MARK_READ'; id: string }
  | { type: 'MARK_ALL_READ' }
  | { type: 'REMOVE'; id: string }
  | { type: 'CLEAR_ALL' }

function notificationReducer(state: Notification[], action: NotificationAction): Notification[] {
  switch (action.type) {
    case 'SET':
      return action.payload
    case 'MARK_READ':
      return state.map((n) => (n.id === action.id ? { ...n, isRead: true } : n))
    case 'MARK_ALL_READ':
      return state.map((n) => ({ ...n, isRead: true }))
    case 'REMOVE':
      return state.filter((n) => n.id !== action.id)
    case 'CLEAR_ALL':
      return []
    default:
      return state
  }
}

function getNotificationIcon(type: string) {
  switch (type) {
    case 'order':
      return <ShoppingCart className="size-4 text-primary" />
    case 'promo':
      return <Tag className="size-4 text-secondary" />
    case 'restock':
      return <AlertCircle className="size-4 text-amber-600" />
    case 'system':
      return <Info className="size-4 text-sky-600" />
    default:
      return <Bell className="size-4 text-muted-foreground" />
  }
}

function getNotificationBg(type: string) {
  switch (type) {
    case 'order':
      return 'bg-primary/10'
    case 'promo':
      return 'bg-secondary/10'
    case 'restock':
      return 'bg-amber-50'
    case 'system':
      return 'bg-sky-50'
    default:
      return 'bg-muted'
  }
}

function timeAgo(dateStr: string): string {
  const date = new Date(dateStr)
  const now = new Date()
  const diff = Math.floor((now.getTime() - date.getTime()) / 1000)

  if (diff < 60) return 'Just now'
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`
  if (diff < 604800) return `${Math.floor(diff / 86400)}d ago`
  return date.toLocaleDateString()
}

export default function NotificationBell() {
  const { isAuthenticated, user } = useAppStore()
  const [notifications, dispatch] = useReducer(notificationReducer, [])
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const panelRef = useRef<HTMLDivElement>(null)
  const bellRef = useRef<HTMLButtonElement>(null)

  const unreadCount = notifications.filter((n) => !n.isRead).length

  // Fetch notifications
  useEffect(() => {
    if (!isAuthenticated || !user?.id) return
    const userId = user.id
    async function fetchNotifications() {
      setLoading(true)
      try {
        const token = useAppStore.getState().accessToken
        const headers: Record<string, string> = {}
        if (token) headers['Authorization'] = `Bearer ${token}`
        const res = await fetch(`/api/notifications?limit=20&userId=${userId}`, { headers })
        if (res.ok) {
          const data = await res.json()
          dispatch({ type: 'SET', payload: extractItems<Notification>(data) })
        }
      } catch {
        // silent
      } finally {
        setLoading(false)
      }
    }
    fetchNotifications()
    // Poll every 30 seconds
    const interval = setInterval(fetchNotifications, 30000)
    return () => clearInterval(interval)
  }, [isAuthenticated, user?.id])

  // Click outside to close
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (
        panelRef.current &&
        !panelRef.current.contains(e.target as Node) &&
        bellRef.current &&
        !bellRef.current.contains(e.target as Node)
      ) {
        setOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  async function handleMarkRead(id: string) {
    dispatch({ type: 'MARK_READ', id })
    try {
      await fetch(`/api/notifications/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isRead: true }),
      })
    } catch {
      // silent
    }
  }

  async function handleMarkAllRead() {
    dispatch({ type: 'MARK_ALL_READ' })
    try {
      await fetch(`/api/notifications/mark-all`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ markAllRead: true, userId: user?.id }),
      })
    } catch {
      // Fallback to individual
      for (const n of notifications.filter((n) => !n.isRead)) {
        await fetch(`/api/notifications/${n.id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ isRead: true }),
        })
      }
    }
    toast.success('All notifications marked as read')
  }

  async function handleDelete(id: string) {
    dispatch({ type: 'REMOVE', id })
    try {
      await fetch(`/api/notifications/${id}`, { method: 'DELETE' })
    } catch {
      // silent
    }
  }

  async function handleClearAll() {
    dispatch({ type: 'CLEAR_ALL' })
    try {
      for (const n of notifications) {
        await fetch(`/api/notifications/${n.id}`, { method: 'DELETE' })
      }
      toast.success('All notifications cleared')
    } catch {
      // silent
    }
  }

  if (!isAuthenticated) return null

  return (
    <div className="relative">
      {/* Bell Button */}
      <Button
        ref={bellRef}
        variant="ghost"
        size="icon"
        className="size-9 relative"
        onClick={() => setOpen(!open)}
        aria-label={`Notifications (${unreadCount} unread)`}
      >
        <Bell className="size-4" />
        {unreadCount > 0 && (
          <Badge className="absolute -top-1 -right-1 min-w-[18px] h-[18px] p-0 flex items-center justify-center text-[10px] bg-red-500 text-white animate-in zoom-in-50 duration-200 border-0">
            {unreadCount > 9 ? '9+' : unreadCount}
          </Badge>
        )}
      </Button>

      {/* Dropdown Panel */}
      {open && (
        <div
          ref={panelRef}
          className="absolute right-0 top-full mt-2 w-80 sm:w-96 bg-background border rounded-xl shadow-xl z-50 overflow-hidden animate-in slide-in-from-top-2 duration-200"
        >
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b bg-muted/30">
            <div className="flex items-center gap-2">
              <h3 className="font-semibold text-sm">Notifications</h3>
              {unreadCount > 0 && (
                <Badge variant="secondary" className="text-xs">
                  {unreadCount} new
                </Badge>
              )}
            </div>
            <div className="flex items-center gap-1">
              {unreadCount > 0 && (
                <Button variant="ghost" size="sm" className="h-7 text-xs gap-1" onClick={handleMarkAllRead}>
                  <CheckCheck className="size-3.5" />
                  <span className="hidden sm:inline">Mark all read</span>
                </Button>
              )}
              <Button variant="ghost" size="icon" className="size-7" onClick={() => setOpen(false)} aria-label="Close notifications">
                <X className="size-3.5" />
              </Button>
            </div>
          </div>

          {/* Notifications List */}
          <div className="max-h-80 overflow-y-auto">
            {loading ? (
              <div className="p-6 text-center">
                <div className="size-6 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
                <p className="text-xs text-muted-foreground mt-2">Loading...</p>
              </div>
            ) : notifications.length === 0 ? (
              <div className="p-8 text-center">
                <Bell className="size-10 text-muted-foreground/20 mx-auto mb-3" />
                <p className="font-medium text-sm text-muted-foreground">No notifications yet</p>
                <p className="text-xs text-muted-foreground/60 mt-1">
                  We&apos;ll notify you about orders, offers, and updates
                </p>
              </div>
            ) : (
              <div className="divide-y">
                {notifications.map((notification) => (
                  <div
                    key={notification.id}
                    className={`p-3 hover:bg-muted/30 transition-colors ${
                      !notification.isRead ? 'bg-primary/5' : ''
                    }`}
                  >
                    <div className="flex gap-3">
                      {/* Icon */}
                      <div className={`shrink-0 size-8 rounded-full flex items-center justify-center ${getNotificationBg(notification.type)}`}>
                        {getNotificationIcon(notification.type)}
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <p className={`text-sm ${!notification.isRead ? 'font-semibold' : 'font-medium'} line-clamp-1`}>
                            {notification.title}
                          </p>
                          <span className="text-[10px] text-muted-foreground shrink-0 mt-0.5">
                            {timeAgo(notification.createdAt)}
                          </span>
                        </div>
                        <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">
                          {notification.message}
                        </p>
                        <div className="flex items-center gap-2 mt-1.5">
                          {!notification.isRead && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 text-[10px] gap-1 px-1.5"
                              onClick={() => handleMarkRead(notification.id)}
                            >
                              <Check className="size-3" /> Mark read
                            </Button>
                          )}
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-6 text-[10px] gap-1 px-1.5 text-destructive hover:text-destructive"
                            onClick={() => handleDelete(notification.id)}
                          >
                            <Trash2 className="size-3" /> Remove
                          </Button>
                        </div>
                      </div>

                      {/* Unread indicator */}
                      {!notification.isRead && (
                        <div className="size-2 rounded-full bg-primary shrink-0 mt-2" />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Footer */}
          {notifications.length > 0 && (
            <div className="p-3 border-t bg-muted/30">
              <Button
                variant="ghost"
                size="sm"
                className="w-full text-xs text-destructive hover:text-destructive gap-1"
                onClick={handleClearAll}
              >
                <Trash2 className="size-3.5" /> Clear All Notifications
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
