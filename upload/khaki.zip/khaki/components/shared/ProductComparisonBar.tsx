'use client'

import { useEffect, useReducer } from 'react'
import Image from 'next/image'
import { X, GitCompareArrows, Package } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useAppStore } from '@/lib/store'

// ─── Types ────────────────────────────────────────────────────────────────────

interface CompareProduct {
  id: string
  name: string
  slug: string
  price: number
  discountPrice?: number | null
  unit: string
  images?: Array<{ url: string; alt?: string }>
  category?: { name: string; slug: string }
}

type ProductsAction =
  | { type: 'SET'; products: CompareProduct[] }
  | { type: 'CLEAR' }

function productsReducer(_state: CompareProduct[], action: ProductsAction): CompareProduct[] {
  switch (action.type) {
    case 'SET':
      return action.products
    case 'CLEAR':
      return []
    default:
      return _state
  }
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function ProductComparisonBar() {
  const {
    compareProducts,
    removeFromCompare,
    clearCompare,
    navigate,
  } = useAppStore()

  const [products, dispatch] = useReducer(productsReducer, [])

  // Only show when 2+ products in compare
  const shouldShow = compareProducts.length >= 2

  // ── Fetch product details when compare list changes ──
  useEffect(() => {
    if (compareProducts.length === 0) return

    let cancelled = false

    const fetchProducts = async () => {
      try {
        const results = await Promise.all(
          compareProducts.map(async (id) => {
            try {
              const res = await fetch(`/api/products/${id}`)
              if (res.ok) {
                const data = await res.json()
                return (data.data || data) as CompareProduct
              }
              return null
            } catch {
              return null
            }
          })
        )
        if (!cancelled) {
          dispatch({ type: 'SET', products: results.filter((p): p is CompareProduct => p !== null && p.id !== undefined) })
        }
      } catch {
        if (!cancelled) {
          dispatch({ type: 'CLEAR' })
        }
      }
    }

    fetchProducts()

    return () => {
      cancelled = true
    }
  }, [compareProducts])

  if (!shouldShow) return null

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 animate-in slide-in-from-bottom-4 duration-300">
      {/* Backdrop shadow */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/10 to-transparent pointer-events-none -top-8 h-8" />

      <div className="bg-background/95 backdrop-blur-md border-t border-border shadow-2xl">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center gap-3">
            {/* Compare label */}
            <div className="hidden sm:flex items-center gap-2 shrink-0">
              <GitCompareArrows className="h-5 w-5 text-primary" />
              <span className="text-sm font-semibold">Compare</span>
              <Badge variant="secondary" className="text-xs">
                {compareProducts.length}/4
              </Badge>
            </div>

            {/* Product thumbnails */}
            <div className="flex-1 flex items-center gap-2 overflow-x-auto py-1" style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}>
              {products.map((product) => {
                const imageUrl = product.images?.[0]?.url
                return (
                  <div
                    key={product.id}
                    className="flex-shrink-0 flex items-center gap-2 bg-muted/50 rounded-lg px-2 py-1.5 group hover:bg-muted transition-colors"
                  >
                    <div className="relative h-10 w-10 rounded-md overflow-hidden bg-muted/30 flex-shrink-0">
                      {imageUrl ? (
                        <Image
                          src={imageUrl}
                          alt={product.name}
                          width={40}
                          height={40}
                          className="object-cover w-full h-full"
                        />
                      ) : (
                        <div className="flex items-center justify-center h-full">
                          <Package className="h-4 w-4 text-muted-foreground/50" />
                        </div>
                      )}
                    </div>
                    <span className="text-xs font-medium line-clamp-1 max-w-[80px] sm:max-w-[120px]">
                      {product.name}
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation()
                        removeFromCompare(product.id)
                      }}
                      className="h-5 w-5 rounded-full flex items-center justify-center text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors flex-shrink-0"
                      aria-label={`Remove ${product.name} from comparison`}
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </div>
                )
              })}
            </div>

            {/* Action buttons */}
            <div className="flex items-center gap-2 shrink-0">
              <Button
                size="sm"
                className="h-9 gap-1.5"
                onClick={() => navigate('compare')}
              >
                <GitCompareArrows className="h-4 w-4" />
                <span className="hidden sm:inline">Compare Now</span>
                <span className="sm:hidden">Compare</span>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="h-9 text-muted-foreground hover:text-destructive"
                onClick={clearCompare}
              >
                <X className="h-4 w-4 sm:mr-1" />
                <span className="hidden sm:inline">Clear</span>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
