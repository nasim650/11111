# Task 2: Order API Critical Fixes

## Summary
Fixed 7 critical and medium-priority issues across 3 order API route files.

## Changes Made

### File: `/home/z/my-project/src/app/api/orders/route.ts`

1. **CRITICAL: Wrapped order creation in `db.$transaction()`**
   - Moved stock deduction, coupon usage increment, order creation, payment creation, cart clearing, and delivery label creation into a single `db.$transaction()` block
   - Stock deductions now roll back automatically if any subsequent operation fails (order creation, payment creation, etc.)
   - Coupon increment moved into the transaction to ensure atomicity
   - All `db.*` calls inside the transaction changed to `tx.*`

2. **Fixed redundant ternary** (line 254)
   - Changed: `paymentStatus: paymentMethod === 'online' ? 'pending' : 'pending'`
   - To: `paymentStatus: 'pending'`

3. **Fixed response shape** (line 308)
   - Changed: `return NextResponse.json({ success: true, data: order, ...order }, { status: 201 })`
   - To: `return NextResponse.json({ success: true, data: order }, { status: 201 })`
   - Removed `...order` spread that was duplicating all order fields at the response root level

4. **Fixed free shipping threshold default** (line 174)
   - Changed: `|| 500`
   - To: `|| 1500`
   - Now matches the client-side default of 1500

5. **Removed stock deduction from the item verification loop**
   - Stock is now deducted inside the transaction instead of during the price verification loop

### File: `/home/z/my-project/src/app/api/orders/[id]/cancel/route.ts`

1. **CRITICAL: Added stock restoration on cancellation**
   - After updating order status to 'cancelled', loops through all order items and increments product stock by the item quantity
   - Uses `order.items` (fetched before the update with `include: { items: true }`)

### File: `/home/z/my-project/src/app/api/orders/[id]/route.ts`

1. **Fixed shippedAt always null** (line 164)
   - Changed: `shippedAt: getOrderStep(order.orderStatus) >= 3 ? null : null`
   - To: `shippedAt: getOrderStep(order.orderStatus) >= 3 ? order.updatedAt.toISOString() : null`
   - Now returns the order's updatedAt timestamp when the order has reached 'shipped' status or beyond

2. **Added stock restoration when admin cancels via PUT**
   - Added a fetch of the current order (with items) before the update
   - After the update, if `orderStatus === 'cancelled'` and the previous status wasn't already 'cancelled', restores stock for all order items
   - Prevents double-restoration if an already-cancelled order is updated again

## Verification
- Lint check passes (only pre-existing unrelated errors remain)
- Dev server compiles successfully with no errors
