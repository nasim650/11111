# PRODUCTION_CHECKLIST.md

> Launch checklist for **Khati Khadyo** production deployment.
> Every box must be checked before public traffic is enabled.

---

## 1. Database

- [ ] `prisma/schema.prisma` `provider` is `postgresql`.
- [ ] `DATABASE_URL` points to the Neon **pooled** endpoint with `sslmode=require`.
- [ ] `DIRECT_URL` points to the Neon **direct** endpoint (for migrations).
- [ ] `bun run db:generate` succeeds with zero errors.
- [ ] `bun run db:migrate deploy` succeeds with zero errors.
- [ ] All 30+ tables exist in Postgres.
- [ ] Row counts match the pre-migration SQLite snapshot (users, orders, products, categories, site configs).
- [ ] Foreign-key relationships intact.
- [ ] `Order.orderNumber` format `KK-YYYYMMDD-NNNNN` preserved.
- [ ] `cuid()` primary keys preserve their string values.
- [ ] Neon PITR enabled (30-day retention).
- [ ] Nightly `pg_dump` to object storage scheduled (14-day rolling).
- [ ] Stale `db/custom.db` file deleted (`BUG-3`).
- [ ] `OrderStatusHistory` writes persist reliably (`BUG-1` fixed).
- [ ] `PrintQueue` writes persist reliably (`BUG-2` fixed).

---

## 2. Authentication

- [ ] `JWT_SECRET` is set and ≥ 32 characters (random).
- [ ] `NODE_ENV=production` (auth throws without `JWT_SECRET` in production).
- [ ] Password hashing: bcrypt cost factor 12 (`src/lib/auth.ts`).
- [ ] JWT expiry: 7 days (documented; refresh mechanism is a known follow-up).
- [ ] Tokens transported via `Authorization: Bearer` + httpOnly cookie.
- [ ] Register endpoint: duplicate email/phone returns 409.
- [ ] Login endpoint: wrong password returns 401.
- [ ] Session restore (`/api/auth/me`) returns user + addresses.
- [ ] Address CRUD ownership checks enforced server-side.
- [ ] Admin endpoints enforce `isAdmin(role)` server-side.
- [ ] Rate limiting active on `/api/auth/login` (5/min) and `/api/auth/register` (3/min).
- [ ] CSRF guard (`src/lib/security.ts`) active.

---

## 3. Payment

- [ ] `SSLCOMMERZ_STORE_ID` set.
- [ ] `SSLCOMMERZ_STORE_PASSWD` set.
- [ ] `SSLCOMMERZ_STORE_NAME` set.
- [ ] `SSLCOMMERZ_SANDBOX=false` (live mode).
- [ ] `SSLCOMMERZ_IPN_URL` = `https://khatikhadyo.com/api/payments/sslcommerz/ipn` (publicly reachable).
- [ ] SSLCommerz success route redirects to `order-confirmation`.
- [ ] SSLCommerz fail route redirects to `orders` with error toast.
- [ ] SSLCommerz cancel route handles cancellation.
- [ ] IPN route reconciles payment status with order (`payment-sync.ts`).
- [ ] Cash on Delivery (COD) creates orders with `paymentStatus = pending`.
- [ ] Online payment initiates SSLCommerz session and redirects to gateway.
- [ ] Gateway return URL is HTTPS.
- [ ] `totalAmount > 0` validation enforced on order creation.
- [ ] `loyaltyDiscountAmount` stored on the `Order` record.
- [ ] Order number collision risk eliminated (`KK-YYYYMMDD-NNNNN` format).

---

## 4. Images

- [ ] `CLOUDINARY_CLOUD_NAME` set.
- [ ] `CLOUDINARY_API_KEY` set.
- [ ] `CLOUDINARY_API_SECRET` set.
- [ ] `src/lib/cloudinary.ts` initialised with env vars.
- [ ] `/api/uploads` returns Cloudinary-hosted URLs.
- [ ] Product images served from Cloudinary with `f_auto,q_auto`.
- [ ] Banner images (desktop + mobile) served from Cloudinary.
- [ ] Category images served from Cloudinary.
- [ ] `SiteConfig.logo` points to a Cloudinary URL (or `/all_logo.png` fallback).
- [ ] No media stored locally in `/public` for production data (seed assets excepted).
- [ ] `MediaFile` table decision made (populate on upload, or drop — see `MIGRATION_PLAN.md` §4).

---

## 5. Orders

- [ ] Order creation: guest + logged-in flows both work.
- [ ] Stock decremented on order creation.
- [ ] Server-side price verification (client prices not trusted).
- [ ] Delivery label auto-created on order creation.
- [ ] Order status history auto-creates "pending" entry on creation.
- [ ] Print queue entries created for each document type.
- [ ] Loyalty points earned on delivered orders (1 pt / ৳100).
- [ ] Loyalty points redeemable at checkout (1 pt = ৳1, max 20% of subtotal).
- [ ] 50-point welcome bonus for first-time earners.
- [ ] Order cancellation route works (`/api/orders/[id]/cancel`).
- [ ] Order timeline renders all status changes.
- [ ] Production status flow supported: New → Confirmed → Processing → Packed → Ready to Ship → Shipped → Delivered.
- [ ] Terminal states: Cancelled, Returned.
- [ ] Admin can advance status (quick "Advance to Next" button).
- [ ] Admin can bulk-update status.

---

## 6. Admin

- [ ] All 17 admin modules render and CRUD works (QA-3).
- [ ] Admin route guard: client-side `user.role === 'admin'` check in `src/app/page.tsx`.
- [ ] Admin API endpoints enforce `isAdmin(role)` server-side.
- [ ] Admin Products: create / edit / delete / stock management.
- [ ] Admin Orders: status update + timeline + print panel.
- [ ] Admin Homepage: section show/hide / order / title / subtitle / enable / disable / delete.
- [ ] Admin Settings → Homepage tab: announcement bar, free delivery, flash sale, promo text.
- [ ] Admin Print Queue Monitor: progress bar + auto-refresh.
- [ ] Admin Audit Log: records admin actions.
- [ ] Admin Media Library: upload + browse.
- [ ] Admin Coupons: create / validate / usage tracking.
- [ ] Admin Customers: view + role management.
- [ ] Admin Reviews: approve / reject.
- [ ] Admin Banners: create / edit / schedule.
- [ ] Admin Settings: all tabs (General, Contact, Social, SEO, Payment, Notifications, Security, API Keys, Appearance, Homepage).

---

## 7. Printing

- [ ] Invoice PDF generates and downloads (`/api/orders/[id]/invoice`).
- [ ] Packing slip generates and downloads (`/api/orders/[id]/packing-slip`).
- [ ] Delivery label generates (`/api/orders/[id]/delivery-label`).
- [ ] Thermal receipt 58mm prints (`/api/orders/[id]/thermal-receipt?width=58`).
- [ ] Thermal receipt 80mm prints (`/api/orders/[id]/thermal-receipt?width=80`).
- [ ] Courier label generates for Pathao / Steadfast / RedX / Paperfly (`/api/orders/[id]/courier-label?courier=…`).
- [ ] QR code generates (`/api/orders/[id]/qr-code`).
- [ ] CODE128 barcode generates (`/api/orders/[id]/barcode`).
- [ ] Bulk print works (`/api/orders/bulk-print`).
- [ ] Print Queue (`/api/print-queue`) tracks PENDING / PRINTING / PRINTED / FAILED.
- [ ] Unified `OrderPrintPanel` renders all 5 document types in the admin detail dialog.
- [ ] PDF generation is resilient to OOM (entry created before async work begins; `FAILED` status on throw).

---

## 8. Security

- [ ] `middleware.ts` sets CSP, X-Frame-Options (DENY), X-Content-Type-Options, Referrer-Policy, Permissions-Policy.
- [ ] HSTS: `max-age=31536000; includeSubDomains` (HTTPS only).
- [ ] HTTP→HTTPS redirect enforced at Caddy.
- [ ] `JWT_SECRET` not committed to Git; stored in secret manager.
- [ ] SSLCommerz credentials not committed to Git; stored in secret manager.
- [ ] Cloudinary credentials not committed to Git; stored in secret manager.
- [ ] `ZAI_API_KEY` not committed to Git; stored in secret manager.
- [ ] `.env` is in `.gitignore`.
- [ ] No `console.log` of secrets or PII in production.
- [ ] Rate limiting on auth + chat endpoints.
- [ ] CSRF guard active (`src/lib/security.ts`).
- [ ] Input validation (zod) on all API inputs (`src/lib/validation.ts`).
- [ ] Ownership checks on all user-scoped resources (orders, addresses, cart, wishlist).
- [ ] Admin endpoints server-protected (`isAdmin(role)`).
- [ ] CSP `script-src` does not include `'unsafe-eval'` (or document the exception).
- [ ] Dependency audit: `bun audit` clean.
- [ ] No known vulnerabilities in `package.json` dependencies.

---

## 9. Performance

- [ ] Next.js standalone build produced (`bun run build`).
- [ ] Code-splitting: admin pages and heavy customer pages are `React.lazy` + `Suspense`.
- [ ] `next/image` used for product / banner / category images.
- [ ] Cloudinary `f_auto,q_auto` transformations on served images.
- [ ] `SiteConfig` reads cached (5-min TTL in `src/lib/cache.ts`).
- [ ] Prisma client is a singleton (`src/lib/db.ts`) — no per-route instantiation.
- [ ] No N+1 queries in hot paths (order list, product list, homepage).
- [ ] Container memory limit ≥ 512 MB (avoids dev-OOM seen in sandbox).
- [ ] Lighthouse score ≥ 90 for homepage (performance, accessibility, SEO).
- [ ] API response times < 500ms for p95 on hot endpoints.

---

## 10. Monitoring

- [ ] Structured logging (pino/winston) replaces `console.error` in route handlers.
- [ ] Sentry (or equivalent) installed for client + server error tracking.
- [ ] Uptime monitor on `GET /` (HTTP 200).
- [ ] Uptime monitor on `GET /api/site-config` (HTTP 200).
- [ ] Neon dashboard monitored (compute, connections, storage).
- [ ] Alert: any `Payment.status = pending` older than 30 minutes.
- [ ] Alert: any `PrintQueue` entry in `FAILED` status.
- [ ] Alert: error rate > 1% over 5 minutes.
- [ ] Alert: Neon compute saturation > 80%.
- [ ] Log retention ≥ 30 days.

---

## 11. Backup

- [ ] Neon automated backups enabled.
- [ ] Neon PITR retention = 30 days.
- [ ] Nightly `pg_dump` to object storage scheduled.
- [ ] `pg_dump` retention = 14 days rolling.
- [ ] Git tags on every release.
- [ ] Environment variables exported to encrypted vault.
- [ ] `data/homepage-sections.json` (if still file-based) backed up nightly.
- [ ] Quarterly restore drill scheduled on staging.

---

## 12. Environment Variables

- [ ] All variables in `ENVIRONMENT_VARIABLES.md` are set in the production environment.
- [ ] `DATABASE_URL` → Neon pooled endpoint.
- [ ] `DIRECT_URL` → Neon direct endpoint.
- [ ] `JWT_SECRET` → 32+ char random string.
- [ ] `SSLCOMMERZ_STORE_ID`, `SSLCOMMERZ_STORE_PASSWD`, `SSLCOMMERZ_STORE_NAME` → live credentials.
- [ ] `SSLCOMMERZ_IPN_URL` → public HTTPS URL.
- [ ] `SSLCOMMERZ_SANDBOX=false`.
- [ ] `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET` → production cloud.
- [ ] `ZAI_API_KEY` → valid AI API key.
- [ ] `NEXT_PUBLIC_SITE_URL` → `https://khatikhadyo.com`.
- [ ] `NEXT_PUBLIC_CURRENCY` → `BDT`.
- [ ] `NEXT_PUBLIC_CURRENCY_SYMBOL` → `৳`.
- [ ] `NODE_ENV=production`.
- [ ] No secrets in `.env` committed to Git.
- [ ] Secrets stored in hosting platform's secret manager.

---

## 13. Final QA

- [ ] QA-1: Auth test suite passes (register / login / session / address CRUD / duplicate / wrong-password).
- [ ] QA-2: Order-flow test passes (create → stock decrement → delivery label → invoice).
- [ ] QA-3: All 17 admin modules render and CRUD works.
- [ ] QA-4: SSLCommerz success / fail / cancel / IPN round-trip with live credentials.
- [ ] QA-5: Print artefacts (invoice / packing-slip / delivery-label / thermal / courier / QR / barcode) generate and download.
- [ ] QA-6: Responsive + sticky-footer on mobile and desktop widths.
- [ ] Homepage renders in the product-first order (Search → Categories → Hero → Flash Sale → …).
- [ ] Multi-step checkout (4 steps) works end-to-end.
- [ ] Admin order workflow: production flow + terminal states render correctly.
- [ ] AI chat widget responds.
- [ ] Loyalty points display + redemption work.
- [ ] Notification system works.
- [ ] Cookie consent banner appears.
- [ ] Back-to-top button works.
- [ ] No console errors on any page.
- [ ] No hydration mismatches.
- [ ] Lighthouse score ≥ 90 on homepage.
- [ ] SSL certificate valid for `khatikhadyo.com` + `www.khatikhadyo.com`.
- [ ] DNS A/AAAA records point to the production server.
- [ ] HTTP→HTTPS redirect works.
- [ ] Maintenance page (503) configured and tested.
- [ ] Rollback procedure documented and rehearsed.
