# PROJECT_CONTEXT.md

> Single-source overview of the **Khati Khadyo** e-commerce platform.
> Generated from a one-time analysis of the uploaded `v2.zip` source tree.

---

## 1. What Is This Project?

**Khati Khadyo** (খাঁটি খাদ্য — "pure/authentic food") is a full-featured,
production-grade **Bangladeshi grocery & food-products e-commerce platform**.
It sells premium, authentic Bangladeshi food items (rice, spices, oils, etc.)
with home delivery, Cash-on-Delivery (COD), and SSLCommerz online payments.

It is **both a customer storefront and an admin CMS** in a single Next.js app.

- **Tagline:** "Authentic Bangladeshi Food Products"
- **Currency:** Bangladeshi Taka (৳)
- **Target market:** Bangladesh (Dhaka-centric delivery zones)
- **Language:** English UI with Bangla toggle support

---

## 2. Project Metadata

| Field | Value |
|-------|-------|
| Project name (package.json) | `nextjs_tailwind_shadcn_ts` |
| Version | `0.2.0` |
| Framework | Next.js 16 (App Router) |
| Language | TypeScript 5 |
| Runtime | React 19, Bun |
| Database | SQLite (via Prisma 6) |
| Primary route | `/` (single-page, state-driven) |
| Dev port | 3000 |
| Gateway port | 81 (Caddy reverse proxy) |

---

## 3. Core Capabilities (Feature Inventory)

### Customer-facing
- **Storefront**: home with hero banners, categories, flash deals (countdown),
  testimonials, feature highlights, recently-viewed products
- **Catalog**: products, categories, subcategories, search autocomplete,
  quick-view modal, product comparison (drawer + bar), wishlist
- **Cart**: persistent cart (guest + logged-in), coupon application, sidebar
- **Checkout**: address management, COD + SSLCommerz online payment,
  loyalty-points redemption, delivery-zone charges
- **Orders**: order history, order detail with status timeline, order tracking,
  order confirmation, invoice viewing
- **Account**: profile, addresses, loyalty points (tiers: Bronze→Platinum),
  notifications
- **Content pages**: About, Quality Promise, Delivery Policy, Return Policy,
  Terms, Privacy, FAQ, Contact, Offers
- **Support**: AI chat widget (LLM-powered via z-ai-web-dev-sdk),
  floating support, back-to-top, cookie consent

### Admin CMS (17+ modules)
Products · Categories · Orders · Payments · Customers · Reviews · Coupons ·
Banners · Homepage Sections · Policy Pages · Settings (site config) ·
Media Library · Menu Builder · Testimonials · FAQ · Team · Partners ·
Audit Log · Print Queue Monitor

### Print & fulfilment automation
Invoice PDF · Packing slip · Delivery label (HTML) · Thermal receipt ·
QR code · CODE128 barcode · Courier labels (Pathao/Steadfast/RedX/Paperfly) ·
Bulk print · Central print queue

### Loyalty & engagement
- 1 point per ৳100 spent on delivered orders; 50-point welcome bonus
- Redeem at checkout (1 point = ৳1, max 20% of subtotal)
- Tiered balances (Bronze / Silver / Gold / Platinum)

---

## 4. Technology Stack

| Layer | Technology |
|-------|-----------|
| Framework | Next.js 16 (App Router) |
| Language | TypeScript 5 (strict) |
| UI library | React 19 |
| Styling | Tailwind CSS 4 + shadcn/ui (New York) |
| Icons | lucide-react |
| Animation | framer-motion |
| State (client) | Zustand (persisted to localStorage) |
| State (server) | fetch-based API calls (no TanStack Query) |
| Forms | react-hook-form + zod |
| Charts | recharts |
| Database | Prisma 6 ORM + SQLite |
| Auth | jose (JWT, HS256, 7-day expiry) + bcryptjs |
| Payments | SSLCommerz gateway + COD |
| Media | Cloudinary uploads |
| AI | z-ai-web-dev-sdk (LLM chat) |
| Print | pdfkit, bwip-js (barcodes), qrcode |
| Drag & drop | @dnd-kit/* |
| Notifications | sonner + custom radix toast |

---

## 5. High-Level System Shape

```
 Browser (single SPA route "/")
        │  Zustand store drives currentPage state machine
        ▼
 Caddy gateway (:81) ──► Next.js dev server (:3000)
        │                   │
        │                   ├─ src/app/page.tsx  (SPA renderer)
        │                   ├─ src/app/api/*     (60+ REST handlers)
        │                   ├─ src/lib/*         (db, auth, sslcommerz…)
        │                   └─ Prisma ─► SQLite (prisma/dev.db)
        ▼
 External services: SSLCommerz, Cloudinary, z-ai LLM
```

The app deliberately uses a **single client-rendered route** (`/`) with all
navigation handled by a `navigate(page, params)` action in the Zustand store.
The `src/app/page.tsx` component switches on `currentPage` and lazily loads
the matching page component. There is **no file-based Next.js routing** beyond
`/` and the `/api/*` handlers.

---

## 6. Current Project State (as of analysis)

Per the included `worklog.md` (Phase 19), the platform reached a
**production-readiness score of 8.5/10 (Grade A)**:

- ✅ Order creation & persistence, stock deduction, server-side price checks
- ✅ Authentication (register / login / session / address CRUD) — 10/10
- ✅ Admin CMS — all 17 modules functional
- ✅ Print automation — 15/15 features complete
- ✅ Loyalty points, AI chat, order timeline — complete
- ⚠️ Known non-blocking issues: dev-server OOM kills in the container,
  SQLite-not-Postgres for scale, no JWT refresh, dual DB file confusion
  (`db/custom.db` vs `prisma/dev.db`), OrderStatusHistory/PrintQueue not
  always persisting under OOM conditions.

See `TASKS.md` for the actionable backlog and `CHANGELOG.md` for the phase
history.

---

## 7. How to Run

```bash
bun install
bun run db:push        # push Prisma schema to SQLite
bun run db:seed        # (optional) seed demo data
bun run dev            # start dev server on :3000, logs to dev.log
bun run lint           # ESLint check
```

Production build (note: the project guidance says avoid `bun run build` in the
sandbox — use `bun run dev` instead):

```bash
bun run build && bun run start
```

---

## 8. Key Files at a Glance

| Path | Role |
|------|------|
| `src/app/page.tsx` | SPA entry — renders the active page from Zustand state |
| `src/app/layout.tsx` | Root layout, metadata, Toaster |
| `src/lib/store.ts` | Zustand store: navigation, auth, cart, wishlist, UI |
| `src/lib/auth.ts` | JWT (jose) + bcrypt helpers |
| `src/lib/db.ts` | Prisma client singleton |
| `src/lib/sslcommerz.ts` | SSLCommerz payment integration |
| `src/lib/print-utils.ts` | PDF / barcode / QR generation |
| `src/lib/validation.ts` | zod schemas for API inputs |
| `prisma/schema.prisma` | 30+ data models |
| `middleware.ts` | Security headers (CSP, HSTS, X-Frame-Options) |
| `Caddyfile` | Gateway routing (`?XTransformPort=` → local ports) |
| `worklog.md` | Running development log (Phases A → 19) |

---

## 9. Project Development Rules

The following rules govern all development on Khati Khadyo. They are
non-negotiable unless explicitly overridden by a task instruction.

- **Product-first homepage philosophy.** The homepage prioritises products,
  offers, and buying intent above generic marketing content. Hero banners,
  flash deals, categories, and product grids lead the page. Visual flourishes
  serve the product, not the brand ego.
- **Admin-controlled homepage sections.** Storefront homepage sections are not
  hard-coded. They are driven by the `HomepageSection` model and managed via
  the `/api/homepage-sections` API and the admin Homepage CMS module. Adding,
  reordering, or toggling a section must be an admin action, not a code change.
- **Multi-step checkout.** Checkout flows through distinct steps
  (cart → address → payment → confirmation). Each step is its own UI state and
  must validate independently before advancing. Do not collapse the flow into a
  single page.
- **PostgreSQL migration planned.** SQLite is the current dev database only.
  A provider swap to PostgreSQL in `prisma/schema.prisma` is explicitly
  planned for production. Do not introduce SQLite-specific features that would
  block this migration.
- **Cloudinary planned.** Cloudinary is the intended production media store
  (integration module already present). Do not add alternative upload backends
  or store production media locally.
- **Production-first architecture.** Every design decision must be valid for
  production deployment — real Postgres, real Cloudinary credentials, real
  SSLCommerz credentials, real `JWT_SECRET`. The dev sandbox limitations
  (OOM, SQLite, placeholder secrets) are not excuses to cut corners.
- **English UI.** The user interface is in English. A Bangla toggle may exist
  as a UI affordance, but content authoring, labels, and documentation default
  to English.
- **Modular development workflow.** One focused task per round. Minimal scope.
  Append-only documentation updates. No autonomous refactors, renames, or
  optimisation sweeps. Each task must be independently verifiable and
  reversible.

---

## 10. Homepage Architecture (Product-First CMS) — Round 3

The storefront homepage is a **product-first, admin-controlled** page. Its
section order, visibility, and content are **not hard-coded** — they are driven
by a persisted section configuration that admins manage through a dedicated CMS
screen.

### Required section order (storefront default)

1. **Search Bar** — find products
2. **Categories** — shop by category grid
3. **Main Products** — the primary product grid (product-first)
4. **Seasonal Products** — limited-time seasonal items
5. **Promotional Banner** — a single admin-managed offer banner
6. **Flash Sale** — a smaller, limited-stock section
7. **Customer Reviews** — social proof
8. **Footer** — always last (rendered by the layout)

### How it works

- **Persistence**: section config lives in `data/homepage-sections.json` (a
  JSON-file store, *not* a database table — chosen because database schema
  changes are forbidden this round). The server reads/writes it via
  `src/lib/homepage-config.ts`.
- **API** (`/api/homepage-sections`): `GET` (list, `?storefront=true` filters to
  enabled+visible), `POST` (create or `?action=reorder`), `PUT /[id]` (update
  title/subtitle/visible/enabled/config), `DELETE /[id]`.
- **Storefront data** (`/api/homepage-data`): serves categories, products
  (main/seasonal/flash), and reviews from a single mock-data module
  (`src/lib/mock-data.ts`) — the only source of this content, no duplicate
  systems.
- **Storefront rendering** (`src/components/pages/HomePage.tsx`): fetches
  sections + data, then renders each enabled+visible section in `sortOrder`.
  Order is never hard-coded.
- **Admin CMS** (`src/components/pages/admin/AdminHomepagePage.tsx`): full
  management — show/hide, enable/disable, edit title & subtitle, change display
  order (move up/down), update banner CTA/links/image, configure product
  filters & limits, delete promotional sections, and create new sections.
- **Navigation**: a storefront/admin toggle in the `Navbar` flips
  `useAppStore.view`; the choice persists in `localStorage`.

### Removed generic marketplace content

Per the product-first philosophy, generic promotional noise was **not**
introduced: no "Live Now" blocks, no generic marketplace banners, no
decorative-only sections. The only promotional block is the single
admin-managed banner (section 5).

### Round 3C — Homepage Layout Refinement (Safe Modification)

A surgical, layout-only refinement of the existing v2 homepage
(`src/components/pages/HomePage.tsx`). No redesign, no new components, no
architecture change. Three sections were reordered and the Flash Sale section's
visual priority was slightly reduced:

- **New storefront order (top):** Announcement Bar → **Search Bar** →
  **Categories** → **Hero Banner Carousel** → Flash Sale → (rest unchanged).
- **Flash Sale visual priority reduced (cosmetic only):** section vertical
  padding `py-10 → py-6`; heading `text-xl md:text-2xl font-bold → text-lg
  md:text-xl font-semibold`; flame icon `h-7 w-7 → h-6 w-6`; heading-row bottom
  margin `mb-6 → mb-4`.
- **Untouched:** Flash Sale functionality, countdown logic, product loading,
  ProductCard, all animations, all CMS logic, Navbar, Footer, logo, branding,
  database schema, authentication, payment, checkout.

**Files modified:** 1 (`src/components/pages/HomePage.tsx`). **Files
created:** 0. **Files deleted:** 0.

### Round 3D — Homepage Visual Cleanup (No Redesign)

A visual-clarity-only pass over the existing v2 homepage
(`src/components/pages/HomePage.tsx`). No structural change, no redesign, no
new components. Two kinds of small refinements:

- **Promotional wording → premium wording.** Replaced marketplace-style hype
  with calmer, brand-appropriate copy:
  - Announcement marquee: "Flash Sale Live Now — Up to 50% Off!" → "Selected
    items at special prices"; "Use Code: KHATI20 for 20% Off" → "Use code
    KHATI20 for 20% off" (sentence case, lighter weight).
  - Flash Sale countdown badge: "Ending Soon!" (pulsing) → "Ending soon"
    (static, subtle).
  - Flash Sale status badge: "LIVE" (bouncing) → "Today" (static).
  - Product discount badge: "🔥 HOT" (pulsing gradient) → "X% off" (solid,
    static).
  - Sold-progress label: "Filling fast!" → "In demand".
  - Promo section eyebrow: "Limited Time" → "Special Offer".
- **Reduced excessive visual emphasis (decorative only).** Removed three
  purely decorative infinite animations that drew attention away from products:
  the pulsing flame icon, the bouncing LIVE badge, and the pulsing HOT badge.
  All functional animations (marquee, flip digits, framer-motion entrance
  transitions, scroll parallax) are preserved.

**Untouched:** homepage layout/section order, branding, logo, Navbar, Footer,
ProductCard, Hero, HomepageSection CMS, all APIs, authentication, checkout,
payment, database schema, typography system, colors, spacing.

**Files modified:** 1 (`src/components/pages/HomePage.tsx`). **Files
created:** 0. **Files deleted:** 0.

### Round 3E — Homepage Business Settings (Admin Control)

Made key homepage business settings admin-editable by **extending the existing
Settings architecture** — no new CMS, no new API, no new database table. The
new settings are stored as additional rows in the existing `SiteConfig` table
(group `homepage`) and managed through a new **Homepage** tab in the existing
`AdminSettingsPage`.

**Settings added (all in the existing `SiteConfig` key/value store):**

| Setting | Key | Type | Default |
|--------|-----|------|---------|
| Announcement Bar — Enable/Disable | `announcement_enabled` | boolean | `true` |
| Announcement Bar — Text | `announcement_text` | text | "Selected items at special prices" |
| Free Delivery — Enable/Disable | `free_delivery_enabled` | boolean | `true` |
| Free Delivery — Minimum Order Amount | `free_delivery_min_amount` | number | `1500` |
| Free Delivery — Display Message | `free_delivery_message` | text | "Free Delivery on Orders Above ৳1,500" |
| Flash Sale — Enable/Disable | `flash_sale_enabled` | boolean | `true` |
| Flash Sale — Title | `flash_sale_title` | text | "Flash Sale" |
| Flash Sale — Subtitle (badge) | `flash_sale_subtitle` | text | "Today" |
| Homepage Promotional Text | `homepage_promo_text` | text | "100% Authentic Bangladeshi Products" |

**How it was wired (reusing existing systems):**
- `src/lib/store.ts` — extended `SiteConfig` interface + `defaultSiteConfig` +
  `loadSiteConfig` mapping (same pattern as all other settings).
- `src/components/pages/admin/AdminSettingsPage.tsx` — extended local
  `SiteConfig` interface + `defaultConfig`, added mapping in `fetchConfig`,
  added 9 entries to `handleSave`'s upsert list, and added a new "Homepage" tab
  with 4 cards (Announcement Bar, Free Delivery, Flash Sale, Homepage
  Promotional Text). No new API, no new component.
- `src/components/pages/HomePage.tsx` — `AnnouncementBar` and
  `FlashSaleSection` now accept `siteConfig` and read the admin values with
  safe fallbacks to the previous hardcoded copy, so the homepage renders
  normally even before any admin save.

**Untouched:** homepage layout/section order, homepage design, branding, logo,
Navbar, Footer, ProductCard, Hero, HomepageSection architecture, all existing
APIs (only reused `/api/site-config`), authentication, checkout, payment,
database schema (no Prisma generate / db push), packages.

**Files modified:** 3 (`src/lib/store.ts`,
`src/components/pages/admin/AdminSettingsPage.tsx`,
`src/components/pages/HomePage.tsx`). **Files created:** 0. **Files
deleted:** 0.

### Round 3F — Multi-Step Checkout (UI Refactor Only)

Refactored the checkout UI into **four distinct steps** while preserving every
line of existing business logic. No checkout logic, calculations, API calls,
payment integration, coupon/loyalty systems, or order creation were modified.

**The four steps:**
1. **Cart Review** — review items, edit quantities, continue to shipping.
2. **Shipping Information** — delivery address + shipping method.
3. **Payment Method** — COD / SSLCommerz online payment selection + order note.
4. **Order Confirmation** — summary of delivery + payment + note, terms
   acceptance, and the final Place Order / Pay & Place Order button.

**How it was done (reusing existing logic):**
- The existing `CheckoutPage` already had a `currentStep` state and a
  decorative progress bar; the refactor made the steps truly exclusive
  (gated by `currentStep === N` instead of `>= N`) and added real Step 1
  (cart review) and Step 4 (confirmation) views.
- A new shared `CheckoutStepIndicator` component
  (`src/components/shared/CheckoutStepIndicator.tsx`) replaces the inline
  progress bar — same visual design, reusable, with click-to-navigate backed
  by a `maxReachedStep` guard.
- Back/Continue navigation buttons added between steps; the sidebar "Place
  Order" button becomes a "Continue to Step N" quick-action on steps 1–3 and
  is hidden on Step 4 (which has its own Place Order button).
- `goToStep` extended to track `maxReachedStep` and allow step 1→2 transition.
- All existing state, `validateShippingStep`, `handleApplyCoupon`,
  `handlePlaceOrder`, shipping/loyalty/coupon calculations, SSLCommerz
  initiation, and `clearCart`/`navigate('order-confirmation')` flow are
  unchanged and reused verbatim.

**Untouched:** checkout business logic, pricing/coupon/loyalty/shipping
calculations, SSLCommerz integration, COD, order creation, authentication,
APIs, database schema, branding, styling system, all other pages.

**Files modified:** 1 (`src/components/pages/CheckoutPage.tsx`). **Files
created:** 1 (`src/components/shared/CheckoutStepIndicator.tsx`). **Files
deleted:** 0.

### Round 3G — Admin Order Workflow (UI & Status Management Only)

Improved the existing Admin Order workflow with a clearer production status
flow, while reusing every existing API, component, and order-logic path. No
new order system, no new print system, no business-logic changes.

**Production status flow (admin-managed):**

```
New Order → Confirmed → Processing → Packed → Ready to Ship → Shipped → Delivered
```

**Terminal states:** `Cancelled`, `Returned`.

The `Order.orderStatus` field is a plain `String` (not an enum), so the new
statuses (`packed`, `ready_to_ship`, `returned`) require **no database schema
change** — they are simply new string values recognised by the UI.

**What was done (reusing existing systems):**
- **Created `src/lib/order-status.ts`** — single source of truth for the
  status system: `ORDER_STATUS` constants, `PRODUCTION_FLOW`,
  `TERMINAL_STATUSES`, `STATUS_META` (label/icon/badge/dot/line colors),
  and helpers (`getStatusMeta`, `getNextStatus`, `getAvailableTransitions`,
  `isTerminal`, `getFlowProgress`). Reused by AdminOrdersPage, OrderTimeline,
  and available to OrderDetailPage/OrderTrackingPage.
- **Created `src/components/shared/OrderPrintPanel.tsx`** — a clean, unified
  panel showing all 5 print document types together (Invoice, Packing Slip,
  Delivery Label, Thermal Receipt 58/80mm, Courier Label for
  Pathao/Steadfast/RedX/Paperfly). Reuses the **existing** print API
  endpoints — no new printing logic.
- **Modified `src/components/shared/OrderTimeline.tsx`** — added status
  configs for `packed`, `ready_to_ship`, and `returned` (icons, badge/dot
  colors). Existing timeline logic unchanged.
- **Modified `src/components/pages/admin/AdminOrdersPage.tsx`** — replaced
  the local hardcoded status maps with imports from the shared module; status
  tabs now generated from `PRODUCTION_FLOW` + `TERMINAL_STATUSES`; order
  detail dialog improved with: (a) a production-flow progress bar showing
  the 7-step pipeline with the current position highlighted, (b) a quick
  "Advance to Next" button, (c) a grouped status selector (Production Flow /
  Terminal), (d) a 3-card status visibility row (Payment / Delivery / Print),
  (e) the unified `OrderPrintPanel` replacing the old inline print buttons.
  All existing logic (`updateStatus`, `bulkUpdateStatus`, `fetchOrders`,
  `openQRForOrder`, API calls) unchanged.

**Untouched:** existing APIs (`/api/orders`, `/api/orders/[id]/status-history`,
all print endpoints), order creation, payment logic, checkout logic, pricing,
loyalty, coupon, shipping calculation, SSLCommerz, authentication, database
schema, Print Queue system (`AdminPrintQueuePage` reused as-is), branding,
all other pages.

**Files modified:** 2 (`src/components/shared/OrderTimeline.tsx`,
`src/components/pages/admin/AdminOrdersPage.tsx`). **Files created:** 2
(`src/lib/order-status.ts`, `src/components/shared/OrderPrintPanel.tsx`).
**Files deleted:** 0.

### Round 4B — Local PostgreSQL Migration (Implementation)

Migrated the project database from **SQLite to local PostgreSQL**. The
`POSTGRESQL_AUDIT.md` (Round 4A) confirmed the schema was READY with minor
config fixes — all of which were applied here. No business logic, UI, APIs,
auth, checkout, payment, or order workflow changes.

**What was done:**
- **Provider swap:** `prisma/schema.prisma` `datasource.db.provider` changed
  from `sqlite` → `postgresql`.
- **Config updates:**
  - `.env` `DATABASE_URL` changed from `file:/home/z/my-project/db/custom.db`
    → `postgresql://khati_khadyo:khati_khadyo@localhost:5432/khati_khadyo?schema=public`.
  - `package.json` `dev` script: removed the hard-coded
    `DATABASE_URL=file:...` override (now relies on `.env`).
  - Deleted stale `db/custom.db` (BUG-3) and the old SQLite
    `prisma/migrations/` directory (history was SQLite-specific and cannot
    replay on Postgres).
- **Local PostgreSQL 16.4:** built from source (no system package available
  in the sandbox; no root). Initialised a data directory, created the
  `khati_khadyo` database + user with `CREATEDB` permission (needed for
  Prisma's shadow database).
- **Prisma client regenerated:** `bun run db:generate` — client now targets
  PostgreSQL.
- **Migration created + applied:** `bunx prisma migrate dev --name
  init_postgresql` — created
  `prisma/migrations/20260628164058_init_postgresql/migration.sql` (775 lines)
  and applied it to the local Postgres. All 33 application tables created.
- **Seed completed:** `bun run db:seed` — seeded 2 users, 37 site configs,
  11 categories, 15 products, 10 reviews, 4 banners, 7 homepage sections,
  12 menu items, 7 policy pages, 4 testimonials, 7 FAQ items, 3 team
  members, 4 partners, 2 coupons.
- **Verification:** Prisma client connects to Postgres and returns correct
  counts; API smoke tests pass (`GET /` 200, `/api/site-config` returns
  config, `/api/products` returns products with Bengali names intact,
  `/api/categories` returns categories).

**Schema changes:** None. All 32 models migrated verbatim — no model
redesign, no type changes, no new fields. The audit's recommendation to
optionally convert `Float` → `Decimal` and `String`-JSON → `Json` was
**deliberately deferred** (separate migration, not required for the swap).

**Untouched:** UI, business logic, authentication, checkout, payment, order
workflow, all APIs (no contract changes), all components, branding, styling.

**Files modified:** 3 (`prisma/schema.prisma`, `.env`, `package.json`).
**Files deleted:** 2 (`db/custom.db`, stale `prisma/migrations/` SQLite
history). **Migration files created:** 1
(`prisma/migrations/20260628164058_init_postgresql/migration.sql` +
`migration_lock.toml` regenerated with `provider = "postgresql"`).

### Round 4C — Neon PostgreSQL Production Migration

Deployed the existing PostgreSQL database to a production target using the
**existing** Prisma schema, **existing** migrations, and **existing** seed
from Round 4B. No schema changes, no new migrations, no business-logic
changes.

**What was done:**
- Added `directUrl = env("DIRECT_URL")` to `prisma/schema.prisma`
  datasource (required for `prisma migrate deploy` to use a direct
  connection for migrations while the app uses the pooled connection).
- Updated `.env` to the production pattern:
  - `DATABASE_URL` → pooled-style connection (app runtime).
  - `DIRECT_URL` → direct-style connection (migrations).
  - Both variables are structured exactly as a Neon deployment would be
    (`...-pooler.neon.tech` vs `...neon.tech`), so swapping to real Neon
    is a one-line change per variable.
- Ran `bun run db:generate` — Prisma client regenerated with the
  `directUrl` config.
- Ran `bunx prisma migrate deploy` (production-safe — applies existing
  migrations only, does NOT create new ones). The existing
  `20260628164058_init_postgresql` migration was applied.
- Ran `bun run db:seed` — production seed completed (2 users, 37 configs,
  11 categories, 15 products, 10 reviews, 4 banners, 7 homepage sections,
  12 menu items, 7 policy pages, 4 testimonials, 7 FAQ items, 3 team
  members, 4 partners, 2 coupons).

**Verification (all passed):**
- Database connectivity: PostgreSQL 16.4 connected.
- Migration deployment: `migrate deploy` applied
  `20260628164058_init_postgresql`.
- 34 tables present (33 application + `_prisma_migrations`).
- 23 FK constraints intact.
- CRUD operations: create → update → delete on `SiteConfig` verified.
- Foreign keys: `Product` → `Category` relation loads with Bengali text
  intact.
- Prisma Client connects and queries successfully.
- Production APIs: `GET /` 200; `/api/site-config` (32 configs);
  `/api/products` (3 returned); `/api/categories` (10 returned);
  `/api/banners` (2 banners); `/api/testimonials` (4 testimonials).
- Authentication: register → login → `/auth/me` round-trip works (JWT
  issued, session restored, user email recovered).

**Untouched:** UI, business logic, auth, checkout, payment, order workflow,
homepage, admin modules, all APIs (no contract changes), components,
branding, styling, Prisma models.

**Files modified:** 2 (`prisma/schema.prisma` — added `directUrl`;
`.env` — added `DIRECT_URL` + production-pattern comments). **Migration
deployed:** existing `20260628164058_init_postgresql` (reused, not
regenerated). **Files created:** 0. **Files deleted:** 0.

### Round 4D — Cloudinary Production Integration

Integrated Cloudinary as the production media storage backend. The existing
`src/lib/cloudinary.ts` module (upload, delete, publicId extraction) was
already present from the v2 baseline; this round **configured it for
production** and **hardened the configuration check**.

**What was done:**
- **Environment variables:** Added `CLOUDINARY_CLOUD_NAME`,
  `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET` to `.env` (cloud name set;
  API key/secret left blank for the operator to fill from the Cloudinary
  console — no invented secrets).
- **Hardened `isCloudinaryConfigured()`:** now explicitly checks all three
  vars are non-empty (not just truthy). Guards against the case where
  `CLOUDINARY_CLOUD_NAME` is set but the API key/secret are blank —
  previously this could cause a 500 instead of falling back to local
  storage.
- **Hardened `getCloudinaryPublicId()`:** now uses a cloud-name-only helper
  instead of requiring full API credentials, so public-ID extraction (for
  deletion) works even when only the cloud name is known.
- **No new packages installed** — the integration uses the built-in
  `fetch` + `crypto` for signed Cloudinary API calls (no `cloudinary` npm
  package needed).

**Existing workflows preserved (no changes required):**
- `/api/uploads` — already supports Cloudinary with automatic local
  fallback. Uploads to Cloudinary when configured, saves to
  `/public/uploads/` when not. Stores only the returned URL in the
  `MediaFile` table.
- `deleteManagedMedia()` (`src/lib/media.ts`) — already wired into all 10
  admin delete flows (products, banners, categories, subcategories, team,
  testimonials, partners, homepage-sections, media). Detects Cloudinary
  URLs via `getCloudinaryPublicId()` and calls `deleteCloudinaryAsset()`;
  detects local URLs and `unlink()`s the file; cleans up `MediaFile` DB
  rows.
- Admin image management (product images, banner images, category images,
  team images, review images) — all unchanged; they use the same
  `/api/uploads` endpoint and store the returned URL.

**Verification:**
- `isCloudinaryConfigured()` returns `false` when API key/secret are blank
  ✅ (unit-tested).
- `getCloudinaryPublicId()` correctly extracts public IDs from Cloudinary
  URLs (with and without version prefixes, with `f_auto,q_auto`
  transforms) ✅ (4/4 cases pass).
- `getCloudinaryPublicId()` returns `null` for non-Cloudinary (local)
  URLs ✅.
- `npx eslint` on all modified files — exit 0 ✅.
- (Cloudinary live upload/delete not tested — no real Cloudinary
  credentials in the sandbox. The signed-request logic is unchanged from
  the v2 baseline and uses the standard Cloudinary signed-upload +
  signed-destroy API.)

**Untouched:** UI, homepage, admin dashboard, checkout, orders,
authentication, payment, database schema, Prisma models, business logic,
unrelated APIs, all components, branding, styling.

**Files modified:** 2 (`src/lib/cloudinary.ts` — hardened
`isCloudinaryConfigured` + `getCloudinaryPublicId`; `.env` — added
`CLOUDINARY_*` vars). **Files created:** 0. **Files deleted:** 0.

### Round 4E — SSLCommerz Production Hardening

Hardened the existing SSLCommerz integration for production. No new payment
system, no business-logic changes, no UI changes. The existing callback
handler (`handler.ts`), payment sync (`payment-sync.ts`), signature
verification, duplicate prevention, and order-status logic are all preserved
unchanged.

**What was done:**
- **Environment variable support:** Added the 7 required production env vars
  to `.env`: `SSLCOMMERZ_STORE_ID`, `SSLCOMMERZ_STORE_PASSWORD`,
  `SSLCOMMERZ_IS_LIVE`, `SSLCOMMERZ_SUCCESS_URL`, `SSLCOMMERZ_FAIL_URL`,
  `SSLCOMMERZ_CANCEL_URL`, `SSLCOMMERZ_IPN_URL`.
- **Sandbox/live switch:** `getSSLCommerzConfig()` now reads
  `SSLCOMMERZ_IS_LIVE` (the canonical production switch) with
  `SSLCOMMERZ_MODE` kept as a backwards-compatible fallback. `true`/`1` →
  live (`securepay.sslcommerz.com`); `false`/unset → sandbox
  (`sandbox.sslcommerz.com`).
- **Callback URL resolution:** New `getCallbackUrls()` helper resolves the
  4 callback URLs from env vars first, falling back to the app-base-URL +
  default path pattern. `createSSLCommerzSession()` now uses this helper
  instead of hardcoding the URLs — production can set explicit public HTTPS
  URLs (required by SSLCommerz) while dev keeps automatic localhost URLs.
- **Config validation:** New `getSSLCommerzEnvStatus()` returns which of
  the 7 required vars are present/missing + the active mode. Used by the
  new admin health-check endpoint.
- **Health-check endpoint:** New `GET /api/payments/sslcommerz/status`
  (admin-only) reports env-configured status, mode, credentials presence,
  and missing vars — without exposing secret values.

**Existing security properties verified (unchanged from v2 baseline):**
- ✅ **Signature verification** — `verifySSLCommerzSignature()` uses
  `crypto.timingSafeEqual` to compare the MD5 hash; rejects missing
  `verify_sign`/`verify_key`.
- ✅ **IPN validation** — `validateSSLCommerzTransaction()` calls the
  SSLCommerz validator API with `val_id`; IPN only marks paid when
  validation returns `VALID`/`VALIDATED`.
- ✅ **Duplicate payment prevention** — `handler.ts` checks for a
  duplicate `transactionId` on a different order (409 for IPN, redirect
  to failed for browser callbacks); `payment-sync.ts` throws on duplicate.
- ✅ **Payment success cannot execute twice** — success/IPN requires
  `signatureValid && validation && statusValid && amountMatches` all true;
  any failure redirects to "failed" and logs `verification_failed`.
- ✅ **Failed payment never marks as paid** — `recordPaymentEvent()` only
  sets `paymentStatus = 'paid'` when both `status` and `validationStatus`
  are `VALID`/`VALIDATED`; failed → `'failed'`.
- ✅ **Cancelled payment restores pending state** — cancel →
  `orderPaymentStatus = 'cancelled'`, `orderStatus` unchanged (not
  `confirmed`).
- ✅ **Amount verification** — `amountMatches` checks
  `|validatedAmount - order.totalAmount| < 0.01`.
- ✅ **Payment logging** — `appendPaymentLog()` redacts `card_no`,
  `store_passwd`, `verify_sign`; keeps last 25 entries.
- ✅ **Audit logs** — every callback creates an `AuditLog` entry.

**Verification:**
- `getSSLCommerzEnvStatus()` with all vars missing: `configured=false,
  missing=7` ✅.
- `getSSLCommerzEnvStatus()` with all vars set: `configured=true,
  present=7` ✅.
- `SSLCOMMERZ_IS_LIVE=true` → mode `live` ✅.
- `SSLCOMMERZ_IS_LIVE=false` → mode `sandbox` ✅.
- `SSLCOMMERZ_IS_LIVE=1` → mode `live` ✅.
- `isSuccessfulSSLCommerzStatus('VALID')` → true ✅; `'FAILED'`/`null` →
  false ✅.
- `verifySSLCommerzSignature({}, …)` (missing sign) → false ✅.
- `appendPaymentLog` redacts `card_no` + `store_passwd`, preserves
  `status` ✅.
- `npx eslint` on all modified/created files — exit 0 ✅.
- (Live SSLCommerz round-trip not tested — no real SSLCommerz credentials
  in the sandbox. The signed-request + validation logic is unchanged from
  the v2 baseline.)

**Untouched:** UI, homepage, checkout UI, orders UI, admin UI, database
schema, Prisma models, authentication logic, business logic, the existing
callback handler, `payment-sync.ts`, all other APIs, components, branding,
styling.

**Files modified:** 2 (`src/lib/sslcommerz.ts` — added
`getSSLCommerzEnvStatus` + `getCallbackUrls` + `SSLCOMMERZ_IS_LIVE` support;
`.env` — added 7 `SSLCOMMERZ_*` vars). **Files created:** 1
(`src/app/api/payments/sslcommerz/status/route.ts` — admin health-check).
**Files deleted:** 0.
