# POSTGRESQL_AUDIT.md

> PostgreSQL migration readiness audit for **Khati Khadyo**.
> Read-only analysis of `prisma/schema.prisma` (613 lines, 32 models) and
> related config. No implementation proposed. No files modified.

---

## 1. Current Prisma Configuration

```prisma
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "sqlite"
  url      = env("DATABASE_URL")
}
```

- **Prisma version:** `^6.11.1` (from `package.json`).
- **Client singleton:** `src/lib/db.ts` — `new PrismaClient({ log: ['query'] })`,
  cached on `globalThis` in non-production. No per-route instantiation.
- **Migration lock:** `prisma/migrations/migration_lock.toml` declares
  `provider = "sqlite"` — **must be updated** when swapping providers.
- **Scripts (`package.json`):** `db:push`, `db:generate`, `db:migrate`,
  `db:reset`, `db:seed`. The `dev` script hard-codes
  `DATABASE_URL=file:/home/z/my-project/prisma/dev.db`, overriding `.env`.

---

## 2. Current Database Provider

- **Provider:** `sqlite`.
- **URL pattern:** `file:<absolute-path>` (e.g. `file:/home/z/my-project/prisma/dev.db`).
- **Canonical DB file:** `prisma/dev.db`.
- **Stale duplicate:** `db/custom.db` (referenced by `.env`; flagged as `BUG-3`
  in `TASKS.md` — must be deleted before migration to avoid confusion).
- **Suitability:** SQLite is adequate for local dev and single-instance demos
  but **not safe for concurrent writes** at production scale.

---

## 3. SQLite-Specific Implementation (if any)

**Schema level:** None. The `prisma/schema.prisma` uses only portable Prisma
types (`String`, `Int`, `Float`, `Boolean`, `DateTime`, `@id`, `@unique`,
`@default`, `@relation`, `@@index`, `@@unique`). No `@db.` type annotations,
no SQLite-specific pragmas.

**Application level:** None. No raw SQL. No SQLite-specific functions (e.g.
`datetime('now')`, `GROUP_CONCAT`). All data access is via Prisma Client.

**The only SQLite-specific artefacts are config, not code:**
- `datasource db { provider = "sqlite" }` (line 6).
- `migration_lock.toml` → `provider = "sqlite"`.
- `DATABASE_URL=file:...` in `.env` and the `dev` script.

**Verdict:** The schema is provider-agnostic. The swap is purely a config
change + migration regeneration.

---

## 4. Raw SQL Usage (if any)

**None.** A grep for `$queryRaw`, `$executeRaw`, and `prisma.$transaction`
across `src/` returned zero matches. All queries use the Prisma Client
 fluent API (`db.model.findMany`, `db.model.create`, etc.).

**Migration implication:** No SQL dialect to port. Zero raw-SQL risk.

---

## 5. File-System Database Dependencies

| Dependency | Location | Migration action |
|-----------|----------|------------------|
| `prisma/dev.db` | SQLite file (canonical dev DB) | Replace with Neon Postgres connection string |
| `db/custom.db` | Stale SQLite duplicate | Delete (BUG-3) |
| `.env` → `DATABASE_URL=file:/home/z/my-project/db/custom.db` | Points at the stale file | Repoint to Neon pooled URL |
| `package.json` `dev` script → `DATABASE_URL=file:/home/z/my-project/prisma/dev.db` | Hard-coded file path | Remove the override; rely on `.env` |
| `prisma/migrations/migration_lock.toml` → `provider = "sqlite"` | Locks migrations to SQLite | Regenerate for Postgres |

**No other file-system DB dependencies** (no SQLite WAL files, no `-shm`
files referenced in code, no `attach database` calls).

---

## 6. Prisma Models Compatibility with PostgreSQL

All **32 models** use only portable Prisma scalar types. None require
SQLite-specific features. Full compatibility checklist:

| Model | PK | Relations | Indexes | Unique | PG-compatible? |
|-------|----|-----------|---------|--------|----|
| `SiteConfig` | `cuid()` | 0 | 2 | 1 (`key`) | ✅ |
| `User` | `cuid()` | 6 | 0 | 2 (`email`, `phone`) | ✅ |
| `Category` | `cuid()` | 3 | 2 | 1 (`slug`) | ✅ |
| `Subcategory` | `cuid()` | 2 | 0 | 1 (`slug`) | ✅ |
| `Product` | `cuid()` | 8 | 4 | 1 (`slug`) | ✅ |
| `ProductImage` | `cuid()` | 1 | 1 | 0 | ✅ |
| `ProductVideo` | `cuid()` | 1 | 0 | 0 | ✅ |
| `Banner` | `cuid()` | 0 | 2 | 0 | ✅ |
| `HomepageSection` | `cuid()` | 1 | 0 | 0 | ✅ |
| `MenuItem` | `cuid()` | 2 (self-ref) | 2 | 0 | ✅ |
| `CartItem` | `cuid()` | 2 | 1 | 0 | ✅ |
| `Address` | `cuid()` | 1 | 1 | 0 | ✅ |
| `Order` | `cuid()` | 6 | 3 | 1 (`orderNumber`) | ✅ |
| `OrderItem` | `cuid()` | 2 | 2 | 0 | ✅ |
| `Payment` | `cuid()` | 1 | 0 | 1 (`orderId`) | ✅ |
| `DeliveryLabel` | `cuid()` | 1 | 0 | 1 (`orderId`) | ✅ |
| `Review` | `cuid()` | 2 | 3 | 0 | ✅ |
| `Wishlist` | `cuid()` | 2 | 2 | 1 (`userId+productId`) | ✅ |
| `Coupon` | `cuid()` | 0 | 2 | 1 (`code`) | ✅ |
| `ContactMessage` | `cuid()` | 0 | 1 | 0 | ✅ |
| `PolicyPage` | `cuid()` | 0 | 1 | 1 (`slug`) | ✅ |
| `Notification` | `cuid()` | 0 | 2 | 0 | ✅ |
| `NewsletterSubscriber` | `cuid()` | 0 | 1 | 1 (`email`) | ✅ |
| `MediaFile` | `cuid()` | 0 | 0 | 0 | ✅ |
| `AuditLog` | `cuid()` | 0 | 0 | 0 | ✅ |
| `Testimonial` | `cuid()` | 0 | 0 | 0 | ✅ |
| `FAQItem` | `cuid()` | 0 | 0 | 0 | ✅ |
| `TeamMember` | `cuid()` | 0 | 0 | 0 | ✅ |
| `StockNotification` | `cuid()` | 1 | 0 | 1 (`productId+email`) | ✅ |
| `Partner` | `cuid()` | 0 | 0 | 0 | ✅ |
| `OrderStatusHistory` | `cuid()` | 1 | 2 | 0 | ✅ |
| `PrintQueue` | `cuid()` | 1 | 3 | 0 | ✅ |
| `LoyaltyPoint` | `cuid()` | 1 | 3 | 0 | ✅ |

**Verdict:** 32 / 32 models are PostgreSQL-compatible with zero structural changes.

---

## 7. Indexes

**Total `@@index` declarations:** 30 (single-column and composite). All use
standard Prisma `@@index([field])` syntax — fully portable to Postgres.

**Notable indexed columns (hot paths):**
- `Order`: `userId`, `orderStatus`, `createdAt` — order list queries.
- `Product`: `categoryId`, `status`, `slug`, `isFeatured` — catalog browsing.
- `OrderStatusHistory`: `orderId`, `createdAt` — timeline queries.
- `PrintQueue`: `orderId`, `status`, `createdAt` — queue monitor.
- `LoyaltyPoint`: `userId`, `type`, `createdAt` — balance queries.

**No functional indexes** (Postgres-specific expression indexes) are used —
none needed. All indexes are on plain columns.

**Migration action:** None. Prisma regenerates indexes automatically via
`db:migrate`.

---

## 8. Constraints

| Constraint type | Count | PG-compatible? |
|-----------------|-------|----|
| `@id` | 32 (all `cuid()`) | ✅ |
| `@unique` (single-column) | 16 | ✅ |
| `@@unique` (composite) | 2 (`Wishlist[userId,productId]`, `StockNotification[productId,email]`) | ✅ |
| `@default(now())` | 32 `createdAt` fields | ✅ Postgres `now()` |
| `@updatedAt` | 20 `updatedAt` fields | ✅ Prisma-managed |
| `onDelete: Cascade` | 14 relations | ✅ Postgres `ON DELETE CASCADE` |
| `onDelete` (default = `Restrict`) | remaining relations | ✅ Postgres `ON DELETE NO ACTION` |
| `relation` (self-referential) | 1 (`MenuItem` "MenuHierarchy") | ✅ |

**No check constraints, no triggers, no stored procedures** in the schema.
All constraints are declarative Prisma constructs that map 1:1 to Postgres.

**Migration action:** None.

---

## 9. JSON Fields

**No native `Json` Prisma type is used.** JSON-like data is stored as
`String` and (de)serialised in application code via `JSON.parse` /
`JSON.stringify`:

| Model | Field | Storage | Content |
|-------|-------|---------|---------|
| `Product` | `specifications` | `String?` | JSON string of key-value specs |
| `Product` | `tags` | `String?` | Comma-separated tags (not JSON) |
| `HomepageSection` | `content` | `String?` | JSON string for custom content |
| `Payment` | `gatewayResponse` | `String?` | Opaque gateway response |
| `AuditLog` | `oldData`, `newData` | `String?` | JSON snapshots |

**Migration implication:** These work identically on Postgres (stored as
`TEXT`). An **optional optimisation** (not required) would be to convert
`content`, `specifications`, `oldData`, `newData` to Prisma `Json` type for
native Postgres `JSONB` — enabling server-side querying. **Not a blocker.**

---

## 10. Date/Time Fields

- **`DateTime` fields:** ~70 across all models (`createdAt`, `updatedAt`,
  `startDate`, `endDate`, `paidAt`, `printedAt`, `expiresAt`,
  `subscribedAt`, `unsubscribedAt`, `validFrom`, `validTo`).
- **Defaults:** `@default(now())` and `@updatedAt`.
- **Nullable DateTimes:** `startDate?`, `endDate?`, `paidAt?`, `printedAt?`,
  `expiresAt?`, `unsubscribedAt?`.

**Migration implication:** Prisma `DateTime` maps to Postgres `timestamp(3)`
— identical semantics. `@default(now())` maps to `DEFAULT CURRENT_TIMESTAMP`.
`@updatedAt` is Prisma-client-managed (not a DB trigger), so it works
identically. **Zero risk.**

---

## 11. Decimal Fields

**None.** All monetary values use `Float`:

| Model | Fields | Type |
|-------|--------|------|
| `Product` | `price`, `discountPrice` | `Float` |
| `Order` | `totalAmount`, `discountAmount`, `loyaltyDiscountAmount`, `deliveryCharge` | `Float` |
| `OrderItem` | `price` | `Float` |
| `Payment` | `amount` | `Float` |
| `DeliveryLabel` | `totalAmount` | `Float` |
| `Coupon` | `value`, `minOrder`, `maxDiscount` | `Float` |

**Migration implication:** `Float` maps to Postgres `double precision` (8-byte
float). This is **technically compatible** but a **known precision risk** for
financial data (floating-point rounding on ৳ amounts).

**Recommendation (not a blocker):** Before launch, consider migrating monetary
fields to `Decimal @db.Decimal(10,2)` for exact arithmetic. This is a
**schema change** and should be done as its own isolated migration step after
the Postgres swap. **Not required for the provider swap itself.**

---

## 12. Text Fields

All `String` fields map to Postgres `TEXT` (Prisma default for `String`
without `@db.VarChar`). Notable long-text fields:

| Model | Field | Content |
|-------|-------|---------|
| `Product` | `description`, `shortDescription`, `qualityNote`, `ingredients`, `storageInstruction`, `deliveryNote` | Long-form product text |
| `PolicyPage` | `content` | Full HTML policy body |
| `ContactMessage` | `message` | User message |
| `Testimonial` | `content` | Review text |
| `AuditLog` | `oldData`, `newData` | JSON snapshots |
| `Payment` | `gatewayResponse` | Opaque gateway payload |

**Migration implication:** Postgres `TEXT` has no length limit (unlike
SQLite's `TEXT` which is also effectively unlimited). **No truncation risk.**
No `@db.VarChar(n)` constraints to port. **Zero risk.**

---

## 13. Auto-Increment Fields

**None.** No `@default(autoincrement())` is used anywhere. All primary keys
are `@default(cuid())` (24-character collision-resistant string IDs generated
client-side by Prisma).

**Migration implication:** No `SERIAL` / `IDENTITY` column porting needed.
`cuid()` values are preserved verbatim across the migration. **Zero risk.**

---

## 14. UUID Usage

**No `UUID` type is used.** All IDs are `cuid()` strings, not UUIDs.

- `@default(cuid())` — 32 models × 1 PK each = 32 cuid generators.
- No `@default(uuid())` anywhere.
- No `@db.Uuid` anywhere.

**Migration implication:** IDs remain `TEXT` on Postgres (storing cuid strings).
If a future task wants native Postgres `UUID` columns, that's a separate
schema change — not required for this migration. **Zero risk.**

---

## 15. Foreign Key Compatibility

**Total relations:** ~38 across all models.

| Pattern | Count | PG-compatible? |
|---------|-------|----|
| `@relation(fields: [fk], references: [id])` (M:1) | ~25 | ✅ |
| `@relation(..., onDelete: Cascade)` | 14 | ✅ Postgres `ON DELETE CASCADE` |
| `@relation(...)` (default `onDelete: Restrict`) | ~23 | ✅ Postgres `ON DELETE NO ACTION` |
| Self-referential (`MenuItem` "MenuHierarchy") | 1 | ✅ |
| Optional FK (`categoryId String?`) | 3 (`HomepageSection`, `Product.subcategoryId`, `MenuItem.parentId`) | ✅ |
| `@@unique` on FK composite | 2 (`Wishlist`, `StockNotification`) | ✅ |

**All FKs reference `@id` fields (cuid strings).** No composite FKs, no
non-id FK targets. Postgres handles all of these natively.

**Migration implication:** Prisma regenerates FK constraints via `db:migrate`.
The `onDelete: Cascade` behaviour is enforced at the DB level on Postgres
(SQLite enforced it via Prisma client in some cases). **Verify cascade
behaviour in QA** — but no schema change needed. **Low risk.**

---

## 16. Transaction Compatibility

**No explicit `$transaction` calls** in the codebase (grep returned 0
matches). All writes are single-statement Prisma operations.

**Known issue (TASKS.md BUG-1, BUG-2):** `OrderStatusHistory` and
`PrintQueue` rows are written **after** the main order transaction commits,
in the same route handler. Under dev-container OOM, these post-transaction
writes can be lost. The fix (wrapping the history/queue insert in a
`prisma.$transaction` with the order update) is **independent of the provider
swap** — `prisma.$transaction` works identically on Postgres and SQLite.

**Migration implication:** Postgres has superior transaction semantics (MVCC,
proper isolation levels, SERIALIZABLE support). The provider swap will
**improve** transaction reliability, not break it. **Zero risk.**

---

## 17. Migration Risks

| # | Risk | Severity | Likelihood | Mitigation |
|---|------|----------|-----------|------------|
| R1 | `Float` monetary fields cause rounding errors on Postgres | 🟡 Medium | Low (Float→double precision is lossless) | Optional: convert to `Decimal` post-migration |
| R2 | `onDelete: Cascade` semantics differ slightly (SQLite Prisma-enforced → Postgres DB-enforced) | 🟢 Low | Low | Verify cascade in QA-2 (order flow) |
| R3 | Data-loss if `prisma migrate reset` is accidentally run in production | 🔴 High | Low | Document; restrict CI from running reset |
| R4 | `migration_lock.toml` left as `sqlite` blocks Postgres migrations | 🟡 Medium | High (easy to miss) | Delete `prisma/migrations/`, regenerate fresh |
| R5 | `dev` script hard-codes `DATABASE_URL=file:...`, overriding `.env` | 🟡 Medium | High | Remove the override from `package.json` `dev` script |
| R6 | Stale `db/custom.db` causes confusion during ETL | 🟢 Low | Medium | Delete file + `.env` line (BUG-3) before migration |
| R7 | Existing `prisma/migrations/` history is SQLite-specific and cannot be replayed on Postgres | 🟡 Medium | Certain | Start fresh migration history with `db:migrate dev --name init_postgres` |
| R8 | No transactional guard on `OrderStatusHistory` / `PrintQueue` writes (BUG-1/2) | 🟡 Medium | Medium (dev OOM) | Fix before or during migration; Postgres won't OOM |
| R9 | `Product.tags` stored as comma-separated string — no change, but a future search feature would benefit from Postgres arrays | 🟢 Low | Low | Optional; not a blocker |
| R10 | Seed script (`prisma/seed.ts`) may use SQLite-specific IDs or order — verify it runs clean on Postgres | 🟢 Low | Low | Test seed against staging before prod |

**No high-severity, high-likelihood risks.** All risks are either low
severity or have straightforward mitigations.

---

## 18. Required Changes Before Migration

**Config changes (no code, no schema logic):**

1. `prisma/schema.prisma` line 6: `provider = "sqlite"` → `provider = "postgresql"`.
2. `prisma/migrations/migration_lock.toml`: delete the `prisma/migrations/`
   directory entirely (SQLite history cannot be replayed on Postgres).
3. `.env`: `DATABASE_URL=file:/home/z/my-project/db/custom.db` →
   `DATABASE_URL=postgresql://USER:PASS@HOST-pooler.neon.tech/DB?sslmode=require`.
4. Add `DIRECT_URL=postgresql://USER:PASS@HOST.neon.tech/DB?sslmode=require`
   for migrations.
5. `package.json` `dev` script: remove the `DATABASE_URL=file:...` override
   (let `.env` supply it).
6. Delete `db/custom.db` (BUG-3).

**Post-swap regeneration (mechanical, no judgment):**

7. `bun run db:generate` — regenerate Prisma client for Postgres.
8. `bun run db:migrate dev --name init_postgres` — create fresh migration
   baseline against Neon.
9. `bun run db:seed` — re-seed from `prisma/seed.ts`.

**Strongly recommended (but not strictly required for the swap):**

10. Fix BUG-1 / BUG-2 (transactional `OrderStatusHistory` + `PrintQueue`
    writes) — Postgres won't OOM, but the transactional guard is still
    correct engineering.

**Optional (defer if risky):**

11. Convert monetary `Float` fields → `Decimal @db.Decimal(10,2)` as a
    separate migration step after the swap is stable.
12. Convert `Product.specifications`, `HomepageSection.content`,
    `AuditLog.oldData/newData` → Prisma `Json` for native `JSONB` querying.

---

## 19. Estimated Migration Difficulty

| Dimension | Rating | Notes |
|-----------|--------|-------|
| Schema portability | 🟢 Trivial | 32/32 models portable; no SQLite-specific types |
| Raw SQL porting | 🟢 Trivial | Zero raw SQL in the codebase |
| Config changes | 🟢 Trivial | 6 mechanical edits (schema provider, env, lock file, dev script) |
| Data migration (ETL) | 🟡 Moderate | One-off script to copy SQLite → Postgres; cuid PKs preserve |
| Migration history | 🟢 Trivial | Delete + regenerate fresh |
| FK / constraint semantics | 🟢 Low risk | Verify cascade in QA |
| Transactional code | 🟢 Low risk | No `$transaction` to port; Postgres improves reliability |
| Monetary precision | 🟡 Medium | Float works but Decimal is safer (optional, separate step) |
| Seed script | 🟢 Low risk | Test on staging first |
| **Overall** | 🟢 **Low** | **A clean, low-risk migration.** |

**Estimated effort:** 0.5–1 day for an engineer familiar with Prisma +
Neon, including ETL and staging QA.

---

## 20. Final Recommendation

# ✅ **READY (with minor config fixes)**

The Khati Khadyo Prisma schema is **fully PostgreSQL-compatible**. The
migration is a **low-risk, config-driven swap** — no schema redesign, no
raw SQL to port, no SQLite-specific types, no autoincrement/UUID issues,
and no transactional incompatibilities.

**The "minor fixes" required before flipping the switch:**

1. Update `prisma/schema.prisma` provider: `sqlite` → `postgresql`.
2. Delete `prisma/migrations/` (SQLite history) and regenerate fresh.
3. Repoint `DATABASE_URL` to Neon (pooled) + add `DIRECT_URL` (direct).
4. Remove the `DATABASE_URL=file:...` override in the `dev` script.
5. Delete the stale `db/custom.db` (BUG-3).

**Strongly recommended (same engineering pass):**

6. Fix BUG-1 / BUG-2 (transactional guards on `OrderStatusHistory` /
   `PrintQueue`).

**Optional, defer to a later step:**

7. Convert monetary `Float` → `Decimal` (separate migration, post-swap).
8. Convert JSON-in-`String` fields → native `Json` (separate migration).

**Bottom line:** The codebase was clearly designed with this migration in
mind (per `PROJECT_CONTEXT.md` §9: "PostgreSQL migration planned… Do not
introduce SQLite-specific features"). That discipline paid off — the audit
found zero blockers.
