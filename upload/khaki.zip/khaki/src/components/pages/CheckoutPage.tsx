'use client'

import { useEffect, useState } from 'react'
import Image from 'next/image'
import { motion, AnimatePresence } from 'framer-motion'
import {
  CreditCard, Truck, MapPin, ChevronRight, Loader2, ShieldCheck,
  Gift, Clock, CheckCircle2, Package, Wallet, Banknote, Lock,
  ArrowLeft, RefreshCw, Zap, Tag, ShoppingBag, ChevronDown,
  Phone, User, Mail, Home as HomeIcon, AlertCircle, Minus, Plus,
  X, ChevronUp, Info, Star, Sparkles
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Separator } from '@/components/ui/separator'
import { Badge } from '@/components/ui/badge'
import { Checkbox } from '@/components/ui/checkbox'
import { Progress } from '@/components/ui/progress'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { useAppStore } from '@/lib/store'
import { extractItems } from '@/lib/api'
import CheckoutStepIndicator from '@/components/shared/CheckoutStepIndicator'
import { toast } from 'sonner'

// ─── Types ────────────────────────────────────────────────────────────────────

interface Address {
  id: string
  name: string
  phone: string
  address: string
  city: string
  district?: string
  postalCode?: string
  isDefault: boolean
}

// ─── Bangladesh Districts (grouped by division) ─────────────────────────────

const divisionDistricts: Record<string, string[]> = {
  'Dhaka Division': ['Dhaka', 'Faridpur', 'Gazipur', 'Gopalganj', 'Kishoreganj', 'Madaripur', 'Manikganj', 'Munshiganj', 'Narayanganj', 'Narsingdi', 'Rajbari', 'Shariatpur', 'Tangail'],
  'Rajshahi Division': ['Bogra', 'Joypurhat', 'Naogaon', 'Natore', 'Nawabganj', 'Pabna', 'Rajshahi', 'Sirajganj'],
  'Chittagong Division': ['Chittagong', 'Comilla', "Cox's Bazar", 'Feni', 'Khagrachhari', 'Lakshmipur', 'Noakhali', 'Rangamati', 'Brahmanbaria', 'Chandpur'],
  'Khulna Division': ['Khulna', 'Bagerhat', 'Chuadanga', 'Jessore', 'Jhenaidah', 'Kushtia', 'Magura', 'Meherpur', 'Narail', 'Satkhira'],
  'Barisal Division': ['Barisal', 'Barguna', 'Bhola', 'Jhalokati', 'Patuakhali', 'Pirojpur'],
  'Sylhet Division': ['Sylhet', 'Habiganj', 'Moulvibazar', 'Sunamganj'],
  'Rangpur Division': ['Rangpur', 'Dinajpur', 'Gaibandha', 'Kurigram', 'Lalmonirhat', 'Nilphamari', 'Panchagarh', 'Thakurgaon'],
  'Mymensingh Division': ['Mymensingh', 'Jamalpur', 'Netrokona', 'Sherpur'],
}

const bangladeshDistricts = Object.values(divisionDistricts).flat()

// ─── Component ────────────────────────────────────────────────────────────────

export default function CheckoutPage() {
  const { cartItems, subtotal, totalItems, navigate, isAuthenticated, user, siteConfig, clearCart, updateQuantity, removeFromCart } = useAppStore()
  const [addresses, setAddresses] = useState<Address[]>([])
  const [selectedAddressId, setSelectedAddressId] = useState('')
  const [shippingMethod, setShippingMethod] = useState('standard')
  const [paymentMethod, setPaymentMethod] = useState('cod')
  const [note, setNote] = useState('')
  const [couponCode, setCouponCode] = useState('')
  const [discount, setDiscount] = useState(0)
  const [placing, setPlacing] = useState(false)
  const [currentStep, setCurrentStep] = useState(1)
  const [maxReachedStep, setMaxReachedStep] = useState(1)
  const [couponApplied, setCouponApplied] = useState(false)
  const [termsAccepted, setTermsAccepted] = useState(false)
  const [formErrors, setFormErrors] = useState<Record<string, string>>({})
  const [showCouponInput, setShowCouponInput] = useState(true)

  // Loyalty points state
  const [loyaltyBalance, setLoyaltyBalance] = useState(0)
  const [loyaltyPointsToUse, setLoyaltyPointsToUse] = useState(0)
  const [loyaltyApplied, setLoyaltyApplied] = useState(false)
  const [showLoyaltyInput, setShowLoyaltyInput] = useState(false)

  // Guest form
  const [guestName, setGuestName] = useState('')
  const [guestPhone, setGuestPhone] = useState('')
  const [guestEmail, setGuestEmail] = useState('')
  const [guestAddress, setGuestAddress] = useState('')
  const [guestCity, setGuestCity] = useState('')
  const [guestDistrict, setGuestDistrict] = useState('')

  // Add address form
  const [showAddAddress, setShowAddAddress] = useState(false)
  const [newAddr, setNewAddr] = useState({ name: '', phone: '', address: '', city: '', district: '', postalCode: '' })

  useEffect(() => {
    if (isAuthenticated && user?.id) {
      fetch(`/api/addresses?userId=${user.id}`)
        .then((r) => r.json())
        .then((data) => {
          const addrs = extractItems<Address>(data)
          setAddresses(addrs)
          const defaultAddr = addrs.find((a: Address) => a.isDefault)
          if (defaultAddr) setSelectedAddressId(defaultAddr.id)
          else if (addrs.length > 0) setSelectedAddressId(addrs[0].id)
        })
        .catch(() => {})
    }
  }, [isAuthenticated, user?.id])

  // Fetch loyalty balance for logged-in users
  useEffect(() => {
    if (isAuthenticated && user?.id) {
      fetch('/api/loyalty')
        .then((r) => r.json())
        .then((data) => {
          if (data.success) {
            setLoyaltyBalance(data.data.balance || 0)
          }
        })
        .catch(() => {})
    }
  }, [isAuthenticated, user?.id])

  const sub = subtotal()
  const standardShipping = siteConfig?.shippingCharge || 60
  const expressShipping = 120
  const freeThreshold = siteConfig?.freeShippingThreshold || 1500

  let shipping = standardShipping
  if (sub >= freeThreshold) {
    shipping = 0
  }
  if (shippingMethod === 'express') {
    shipping = expressShipping
    if (sub >= freeThreshold) {
      shipping = expressShipping - standardShipping
    }
  }

  const loyaltyDiscount = loyaltyApplied ? Math.min(loyaltyPointsToUse, Math.floor(sub * 0.2), loyaltyBalance) : 0
  const maxLoyaltyDiscount = Math.floor(sub * 0.2)
  const effectiveLoyaltyPoints = Math.min(loyaltyPointsToUse, maxLoyaltyDiscount, loyaltyBalance)

  const total = sub + shipping - discount - loyaltyDiscount
  const freeShippingProgress = Math.min((sub / freeThreshold) * 100, 100)
  const freeShippingRemaining = Math.max(freeThreshold - sub, 0)

  // ─── Validation ───────────────────────────────────────────────────────────

  const validatePhone = (p: string) => /^(?:01\d{9}|\+8801\d{9})$/.test(p)

  const validateShippingStep = (): boolean => {
    const errors: Record<string, string> = {}
    if (isAuthenticated) {
      if (!selectedAddressId) errors.address = 'Please select a delivery address'
    } else {
      if (!guestName.trim()) errors.guestName = 'Full name is required'
      if (!guestPhone.trim()) {
        errors.guestPhone = 'Phone number is required'
      } else if (!validatePhone(guestPhone)) {
        errors.guestPhone = 'Enter a valid BD number (01XXXXXXXXX)'
      }
      if (!guestAddress.trim()) errors.guestAddress = 'Address is required'
      if (!guestCity.trim()) errors.guestCity = 'City is required'
    }
    setFormErrors(errors)
    return Object.keys(errors).length === 0
  }

  // ─── Step Navigation ─────────────────────────────────────────────────────

  const goToStep = (step: number) => {
    if (step <= currentStep) {
      setCurrentStep(step)
      return
    }
    if (step === 3 && currentStep === 2) {
      if (!validateShippingStep()) {
        toast.error('Please fill in all required fields')
        return
      }
    }
    if (step === 2 && currentStep === 1) {
      // Moving from cart review to shipping — no validation needed
    }
    if (step > currentStep + 1) return
    setCurrentStep(step)
    setMaxReachedStep((prev) => Math.max(prev, step))
  }

  // ─── Coupon ───────────────────────────────────────────────────────────────

  const handleApplyCoupon = async () => {
    if (!couponCode.trim()) return
    try {
      const res = await fetch('/api/coupons/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: couponCode, totalAmount: sub }),
      })
      const data = await res.json()
      if (!res.ok) {
        toast.error(data.error || 'Invalid coupon')
        return
      }
      const discountAmount = data.type === 'percentage'
        ? Math.min(sub * (data.value / 100), data.maxDiscount || Infinity)
        : data.value
      setDiscount(discountAmount)
      setCouponApplied(true)
      toast.success('Coupon applied!')
    } catch {
      toast.error('Failed to validate coupon')
    }
  }

  // ─── Add Address ──────────────────────────────────────────────────────────

  const handleAddAddress = async () => {
    if (!user?.id) return
    try {
      const res = await fetch('/api/addresses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id, ...newAddr, isDefault: addresses.length === 0 }),
      })
      if (!res.ok) throw new Error('Failed to add address')
      const saved = await res.json()
      setAddresses((prev) => [...prev, saved])
      setSelectedAddressId(saved.id)
      setShowAddAddress(false)
      setNewAddr({ name: '', phone: '', address: '', city: '', district: '', postalCode: '' })
      toast.success('Address added')
    } catch {
      toast.error('Failed to add address')
    }
  }

  // ─── Place Order ──────────────────────────────────────────────────────────

  const handlePlaceOrder = async () => {
    if (cartItems.length === 0) {
      toast.error('Your cart is empty')
      return
    }

    if (!validateShippingStep()) {
      toast.error('Please fill in all required fields')
      setCurrentStep(2)
      return
    }

    if (!termsAccepted) {
      toast.error('Please accept the terms & conditions')
      return
    }

    setPlacing(true)
    try {
      const orderData: Record<string, unknown> = {
        paymentMethod,
        shippingMethod,
        orderNote: note,
        couponCode: couponCode || undefined,
        discountAmount: discount,
        deliveryCharge: shipping,
        totalAmount: total,
        loyaltyPoints: loyaltyApplied ? effectiveLoyaltyPoints : undefined,
        items: cartItems.map((item) => ({
          productId: item.productId,
          productName: item.productName,
          quantity: item.quantity,
          unit: item.unit,
          price: item.discountPrice != null ? item.discountPrice : item.price,
          image: item.image,
        })),
      }

      if (isAuthenticated && user?.id) {
        orderData.userId = user.id
        orderData.addressId = selectedAddressId
      } else {
        orderData.guestName = guestName
        orderData.guestPhone = guestPhone
        orderData.guestEmail = guestEmail || undefined
        orderData.guestAddress = `${guestAddress}, ${guestCity}${guestDistrict ? `, ${guestDistrict}` : ''}`
      }

      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(useAppStore.getState().accessToken ? { 'Authorization': `Bearer ${useAppStore.getState().accessToken}` } : {})
        },
        body: JSON.stringify(orderData),
      })

      if (!res.ok) {
        const data = await res.json()
        throw new Error(data.error || 'Failed to place order')
      }

      const order = await res.json()
      const orderId = order.data?.id || order.id
      const orderNum = order.data?.orderNumber || order.orderNumber

      if (paymentMethod === 'online') {
        const initRes = await fetch('/api/payments/sslcommerz/initiate', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...(useAppStore.getState().accessToken ? { 'Authorization': `Bearer ${useAppStore.getState().accessToken}` } : {})
          },
          body: JSON.stringify({ orderId }),
        })
        const initData = await initRes.json()

        if (initData.success && initData.data?.gatewayPageURL) {
          window.location.href = initData.data.gatewayPageURL
          return
        } else {
          throw new Error(initData.error || 'Failed to initialize payment gateway')
        }
      } else {
        await clearCart()
        toast.success('Order placed successfully!')
        navigate('order-confirmation', { orderId, orderNumber: orderNum })
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Failed to place order')
      setPlacing(false)
    }
  }

  // ─── Empty Cart ───────────────────────────────────────────────────────────

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center py-20 px-4">
        <div className="text-center">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="h-28 w-28 rounded-full bg-gradient-to-br from-emerald-50 to-teal-50 flex items-center justify-center mx-auto mb-6"
          >
            <ShoppingBag className="h-12 w-12 text-emerald-400" />
          </motion.div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Your cart is empty</h2>
          <p className="text-muted-foreground mb-6">Add products to your cart before checkout</p>
          <Button onClick={() => navigate('products')} className="rounded-full px-8 bg-emerald-600 hover:bg-emerald-700">
            Browse Products
          </Button>
        </div>
      </div>
    )
  }

  // ─── Main Render ──────────────────────────────────────────────────────────

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* ─── Header ──────────────────────────────────────────────────────── */}
      <div className="bg-gradient-to-r from-emerald-700 via-emerald-600 to-teal-600 text-white">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3 cursor-pointer hover:opacity-80 transition-opacity" onClick={() => navigate('home')}>
            {siteConfig?.logo ? (
              <img src={siteConfig.logo} alt="Khati Khadyo" className="h-8 w-auto object-contain brightness-0 invert" />
            ) : (
              <img src="/all_logo.png" alt="Khati Khadyo" className="h-8 w-auto object-contain brightness-0 invert" />
            )}
            <span className="font-bold text-lg hidden sm:block">Khati Khadyo</span>
          </div>
          <Button
            variant="ghost"
            className="text-white hover:bg-white/10 rounded-full"
            onClick={() => navigate('cart')}
          >
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back to Cart
          </Button>
        </div>
      </div>

      {/* ─── Progress Steps Bar ────────────────────────────────────────────── */}
      <CheckoutStepIndicator
        currentStep={currentStep}
        onStepClick={goToStep}
        maxReachedStep={maxReachedStep}
      />

      {/* ─── Main Content ────────────────────────────────────────────────── */}
      <div className="container mx-auto px-4 py-6 sm:py-8">
        <div className="grid lg:grid-cols-3 gap-6 lg:gap-8">
          {/* Left: Forms */}
          <div className="lg:col-span-2 space-y-6">

            {/* ─── Step 1: Cart Review ─────────────────────────────────────── */}
            <AnimatePresence mode="wait">
              {currentStep === 1 && (
                <motion.div
                  key="cart-review"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.4, ease: 'easeOut' }}
                  className="space-y-6"
                >
                  <Card className="shadow-md border-0 overflow-hidden">
                    <div className="bg-gradient-to-r from-emerald-600 to-emerald-700 px-6 py-5">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-xl bg-white/20 flex items-center justify-center backdrop-blur-sm">
                          <ShoppingBag className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <h2 className="text-white font-bold text-lg">Review Your Cart</h2>
                          <p className="text-emerald-100 text-xs mt-0.5">{totalItems()} item(s) in your cart</p>
                        </div>
                        <Badge className="ml-auto bg-white/20 text-white border-0 text-xs backdrop-blur-sm">Step 1</Badge>
                      </div>
                    </div>
                    <CardContent className="p-6 space-y-3">
                      {cartItems.map((item, idx) => (
                        <motion.div
                          key={item.id}
                          initial={{ opacity: 0, x: 20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: idx * 0.05 }}
                          className="flex items-center gap-3 p-3 rounded-xl border border-gray-100 hover:bg-gray-50 transition-colors"
                        >
                          <div className="relative h-16 w-16 rounded-lg bg-gray-100 flex-shrink-0 overflow-hidden border">
                            <Image
                              src={item.image}
                              alt={item.productName}
                              fill
                              className="object-cover"
                              sizes="64px"
                              onError={(e) => {
                                const target = e.target as HTMLImageElement
                                target.style.display = 'none'
                              }}
                            />
                            <span className="absolute -top-0.5 -right-0.5 h-5 w-5 rounded-full bg-emerald-600 text-white text-[10px] font-bold flex items-center justify-center shadow-sm">
                              {item.quantity}
                            </span>
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-gray-900 truncate">{item.productName}</p>
                            <p className="text-xs text-gray-500 mt-0.5">
                              ৳{(item.discountPrice != null ? item.discountPrice : item.price).toLocaleString()} {item.unit && `per ${item.unit}`}
                            </p>
                            <div className="flex items-center gap-1.5 mt-1.5">
                              <button
                                onClick={() => updateQuantity(item.id, Math.max(1, item.quantity - 1))}
                                className="h-6 w-6 rounded-md border border-gray-200 flex items-center justify-center hover:bg-emerald-50 hover:border-emerald-300 transition-colors"
                              >
                                <Minus className="h-2.5 w-2.5" />
                              </button>
                              <span className="text-xs font-semibold w-6 text-center">{item.quantity}</span>
                              <button
                                onClick={() => updateQuantity(item.id, item.quantity + 1)}
                                className="h-6 w-6 rounded-md border border-gray-200 flex items-center justify-center hover:bg-emerald-50 hover:border-emerald-300 transition-colors"
                              >
                                <Plus className="h-2.5 w-2.5" />
                              </button>
                              <button
                                onClick={() => removeFromCart(item.id)}
                                className="h-6 w-6 rounded-md flex items-center justify-center text-red-400 hover:text-red-600 hover:bg-red-50 ml-1 transition-colors"
                              >
                                <X className="h-3 w-3" />
                              </button>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-bold text-gray-900">
                              ৳{((item.discountPrice != null ? item.discountPrice : item.price) * item.quantity).toLocaleString()}
                            </p>
                          </div>
                        </motion.div>
                      ))}

                      <div className="flex justify-between items-center pt-4 border-t">
                        <Button
                          variant="ghost"
                          onClick={() => navigate('cart')}
                          className="text-gray-600 hover:text-gray-900"
                        >
                          <ArrowLeft className="h-4 w-4 mr-1" />
                          Edit Cart
                        </Button>
                        <Button
                          onClick={() => goToStep(2)}
                          className="bg-emerald-600 hover:bg-emerald-700 rounded-xl px-8 h-11 shadow-md shadow-emerald-200"
                        >
                          Continue to Shipping
                          <ChevronRight className="h-4 w-4 ml-1" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>

            {/* ─── Step 2: Shipping & Delivery ─────────────────────────────── */}
            <AnimatePresence mode="wait">
              {currentStep === 2 && (
                <motion.div
                  key="shipping"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.4, ease: 'easeOut' }}
                  className="space-y-6"
                >
                  {/* Delivery Information Card */}
                  <Card className="shadow-md border-0 overflow-hidden">
                    <div className="bg-gradient-to-r from-emerald-600 to-emerald-700 px-6 py-5">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-xl bg-white/20 flex items-center justify-center backdrop-blur-sm">
                          <MapPin className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <h2 className="text-white font-bold text-lg">Delivery Information</h2>
                          <p className="text-emerald-100 text-xs mt-0.5">Where should we deliver your order?</p>
                        </div>
                        <Badge className="ml-auto bg-white/20 text-white border-0 text-xs backdrop-blur-sm">Step 1</Badge>
                      </div>
                    </div>
                    <CardContent className="p-6">
                      {isAuthenticated ? (
                        <div className="space-y-5">
                          {/* Saved Addresses */}
                          {addresses.length > 0 && (
                            <div>
                              <Label className="text-sm font-semibold text-gray-700 mb-3 block flex items-center gap-2">
                                <MapPin className="h-4 w-4 text-emerald-600" />
                                Saved Addresses
                              </Label>
                              <RadioGroup value={selectedAddressId} onValueChange={(v) => { setSelectedAddressId(v); setFormErrors((p) => ({ ...p, address: '' })) }}>
                                <div className="space-y-3">
                                  {addresses.map((addr, idx) => (
                                    <motion.div
                                      key={addr.id}
                                      initial={{ opacity: 0, x: -10 }}
                                      animate={{ opacity: 1, x: 0 }}
                                      transition={{ delay: idx * 0.05 }}
                                    >
                                      <div
                                        className={`relative flex items-start gap-4 p-4 rounded-xl border-2 cursor-pointer transition-all duration-300 ${
                                          selectedAddressId === addr.id
                                            ? 'border-emerald-500 bg-emerald-50/50 shadow-md shadow-emerald-100'
                                            : 'border-gray-200 bg-white hover:border-emerald-300 hover:bg-emerald-50/20'
                                        }`}
                                        onClick={() => { setSelectedAddressId(addr.id); setFormErrors((p) => ({ ...p, address: '' })) }}
                                      >
                                        <RadioGroupItem value={addr.id} id={addr.id} className="mt-1.5 text-emerald-600" />
                                        <Label htmlFor={addr.id} className="flex-1 cursor-pointer">
                                          <div className="flex items-center gap-2 flex-wrap">
                                            <span className="font-semibold text-gray-900">{addr.name}</span>
                                            {addr.isDefault && (
                                              <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200 text-[10px] h-5">Default</Badge>
                                            )}
                                          </div>
                                          <div className="flex items-center gap-1.5 text-sm text-gray-500 mt-1">
                                            <Phone className="h-3 w-3 flex-shrink-0" />
                                            {addr.phone}
                                          </div>
                                          <div className="flex items-start gap-1.5 text-sm text-gray-500 mt-1">
                                            <MapPin className="h-3 w-3 mt-0.5 flex-shrink-0" />
                                            {addr.address}, {addr.city}{addr.district ? `, ${addr.district}` : ''} {addr.postalCode || ''}
                                          </div>
                                        </Label>
                                        {selectedAddressId === addr.id && (
                                          <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: 'spring', stiffness: 300 }}>
                                            <CheckCircle2 className="h-5 w-5 text-emerald-600 flex-shrink-0" />
                                          </motion.div>
                                        )}
                                      </div>
                                    </motion.div>
                                  ))}
                                </div>
                              </RadioGroup>
                              {formErrors.address && (
                                <motion.p initial={{ opacity: 0, y: -5 }} animate={{ opacity: 1, y: 0 }} className="text-xs text-red-500 flex items-center gap-1 mt-2">
                                  <AlertCircle className="h-3 w-3" /> {formErrors.address}
                                </motion.p>
                              )}
                            </div>
                          )}

                          {addresses.length === 0 && !showAddAddress && (
                            <div className="text-center py-10 bg-gradient-to-br from-gray-50 to-emerald-50/20 rounded-xl border-2 border-dashed border-emerald-200">
                              <div className="h-16 w-16 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-4">
                                <MapPin className="h-7 w-7 text-emerald-500" />
                              </div>
                              <p className="text-gray-600 text-sm mb-4 font-medium">No saved addresses yet</p>
                              <Button variant="outline" onClick={() => setShowAddAddress(true)} className="border-emerald-400 text-emerald-700 hover:bg-emerald-50 rounded-full px-6">
                                + Add New Address
                              </Button>
                            </div>
                          )}

                          {/* Add Address Form */}
                          <AnimatePresence>
                            {showAddAddress && (
                              <motion.div
                                initial={{ opacity: 0, height: 0 }}
                                animate={{ opacity: 1, height: 'auto' }}
                                exit={{ opacity: 0, height: 0 }}
                                className="border-2 border-emerald-200 rounded-xl p-6 bg-gradient-to-br from-emerald-50/30 to-teal-50/20 space-y-5 overflow-hidden"
                              >
                                <h4 className="font-bold text-gray-900 flex items-center gap-2 text-base">
                                  <div className="h-8 w-8 rounded-lg bg-emerald-100 flex items-center justify-center">
                                    <MapPin className="h-4 w-4 text-emerald-600" />
                                  </div>
                                  Add New Address
                                </h4>
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                  <div>
                                    <Label className="text-sm font-medium text-gray-700">Full Name *</Label>
                                    <div className="relative mt-1.5">
                                      <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                                      <Input
                                        value={newAddr.name}
                                        onChange={(e) => setNewAddr({ ...newAddr, name: e.target.value })}
                                        className="pl-9 h-10 border-gray-200 focus:border-emerald-400 focus:ring-emerald-200"
                                        placeholder="Enter full name"
                                      />
                                    </div>
                                  </div>
                                  <div>
                                    <Label className="text-sm font-medium text-gray-700">Phone Number *</Label>
                                    <div className="relative mt-1.5">
                                      <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                                      <Input
                                        value={newAddr.phone}
                                        onChange={(e) => setNewAddr({ ...newAddr, phone: e.target.value })}
                                        className="pl-9 h-10 border-gray-200 focus:border-emerald-400 focus:ring-emerald-200"
                                        placeholder="01XXXXXXXXX"
                                      />
                                    </div>
                                  </div>
                                </div>
                                <div>
                                  <Label className="text-sm font-medium text-gray-700">Address *</Label>
                                  <Textarea
                                    value={newAddr.address}
                                    onChange={(e) => setNewAddr({ ...newAddr, address: e.target.value })}
                                    placeholder="House, Road, Area"
                                    className="mt-1.5 border-gray-200 focus:border-emerald-400 focus:ring-emerald-200 resize-none"
                                    rows={2}
                                  />
                                </div>
                                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                                  <div>
                                    <Label className="text-sm font-medium text-gray-700">City *</Label>
                                    <Input
                                      value={newAddr.city}
                                      onChange={(e) => setNewAddr({ ...newAddr, city: e.target.value })}
                                      className="mt-1.5 h-10 border-gray-200 focus:border-emerald-400 focus:ring-emerald-200"
                                      placeholder="e.g. Dhaka"
                                    />
                                  </div>
                                  <div>
                                    <Label className="text-sm font-medium text-gray-700">District</Label>
                                    <Select value={newAddr.district} onValueChange={(v) => setNewAddr({ ...newAddr, district: v })}>
                                      <SelectTrigger className="mt-1.5 w-full h-10 border-gray-200">
                                        <SelectValue placeholder="Select district" />
                                      </SelectTrigger>
                                      <SelectContent>
                                        {Object.entries(divisionDistricts).map(([division, dists]) => (
                                          <div key={division}>
                                            <div className="px-2 py-1.5 text-xs font-bold text-emerald-700 bg-emerald-50">{division}</div>
                                            {dists.map((d) => (
                                              <SelectItem key={d} value={d}>{d}</SelectItem>
                                            ))}
                                          </div>
                                        ))}
                                      </SelectContent>
                                    </Select>
                                  </div>
                                  <div>
                                    <Label className="text-sm font-medium text-gray-700">Postal Code</Label>
                                    <Input
                                      value={newAddr.postalCode}
                                      onChange={(e) => setNewAddr({ ...newAddr, postalCode: e.target.value })}
                                      className="mt-1.5 h-10 border-gray-200 focus:border-emerald-400 focus:ring-emerald-200"
                                      placeholder="e.g. 1200"
                                    />
                                  </div>
                                </div>
                                <div className="flex gap-3 pt-2">
                                  <Button onClick={handleAddAddress} className="bg-emerald-600 hover:bg-emerald-700 rounded-lg px-6">Save Address</Button>
                                  <Button variant="outline" onClick={() => setShowAddAddress(false)} className="rounded-lg px-6">Cancel</Button>
                                </div>
                              </motion.div>
                            )}
                          </AnimatePresence>

                          {!showAddAddress && addresses.length > 0 && (
                            <Button variant="outline" onClick={() => setShowAddAddress(true)} className="border-dashed border-emerald-300 text-emerald-700 hover:bg-emerald-50 w-full rounded-xl h-11">
                              <Plus className="h-4 w-4 mr-2" />
                              Add New Address
                            </Button>
                          )}
                        </div>
                      ) : (
                        /* Guest Checkout Form */
                        <div className="space-y-5">
                          <div className="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3">
                            <div className="h-8 w-8 rounded-lg bg-amber-100 flex items-center justify-center flex-shrink-0">
                              <Info className="h-4 w-4 text-amber-600" />
                            </div>
                            <p className="text-xs text-amber-800 leading-relaxed">
                              Have an account?{' '}
                              <button className="font-bold underline hover:text-amber-900" onClick={() => navigate('login')}>
                                Login
                              </button>{' '}
                              for a faster checkout experience with saved addresses.
                            </p>
                          </div>

                          {/* Contact Info Section */}
                          <div>
                            <h4 className="text-sm font-bold text-gray-800 mb-3 flex items-center gap-2">
                              <div className="h-6 w-6 rounded-md bg-emerald-100 flex items-center justify-center">
                                <User className="h-3 w-3 text-emerald-600" />
                              </div>
                              Contact Information
                            </h4>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                              <div>
                                <Label className="text-sm font-medium text-gray-700">Full Name *</Label>
                                <div className="relative mt-1.5">
                                  <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                                  <Input
                                    value={guestName}
                                    onChange={(e) => { setGuestName(e.target.value); setFormErrors((p) => ({ ...p, guestName: '' })) }}
                                    className={`pl-9 h-10 ${formErrors.guestName ? 'border-red-400 focus-visible:ring-red-200' : 'border-gray-200 focus:border-emerald-400 focus:ring-emerald-200'}`}
                                    placeholder="Your full name"
                                  />
                                </div>
                                {formErrors.guestName && (
                                  <motion.p initial={{ opacity: 0, y: -3 }} animate={{ opacity: 1, y: 0 }} className="text-xs text-red-500 mt-1 flex items-center gap-1">
                                    <AlertCircle className="h-3 w-3" /> {formErrors.guestName}
                                  </motion.p>
                                )}
                              </div>
                              <div>
                                <Label className="text-sm font-medium text-gray-700">Phone Number *</Label>
                                <div className="relative mt-1.5">
                                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                                  <Input
                                    value={guestPhone}
                                    onChange={(e) => { setGuestPhone(e.target.value); setFormErrors((p) => ({ ...p, guestPhone: '' })) }}
                                    className={`pl-9 h-10 ${formErrors.guestPhone ? 'border-red-400 focus-visible:ring-red-200' : 'border-gray-200 focus:border-emerald-400 focus:ring-emerald-200'}`}
                                    placeholder="01XXXXXXXXX"
                                  />
                                </div>
                                {formErrors.guestPhone && (
                                  <motion.p initial={{ opacity: 0, y: -3 }} animate={{ opacity: 1, y: 0 }} className="text-xs text-red-500 mt-1 flex items-center gap-1">
                                    <AlertCircle className="h-3 w-3" /> {formErrors.guestPhone}
                                  </motion.p>
                                )}
                              </div>
                            </div>

                            <div className="mt-4">
                              <Label className="text-sm font-medium text-gray-700">Email (optional)</Label>
                              <div className="relative mt-1.5">
                                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                                <Input
                                  type="email"
                                  value={guestEmail}
                                  onChange={(e) => setGuestEmail(e.target.value)}
                                  className="pl-9 h-10 border-gray-200 focus:border-emerald-400 focus:ring-emerald-200"
                                  placeholder="your@email.com"
                                />
                              </div>
                            </div>
                          </div>

                          <Separator />

                          {/* Shipping Address Section */}
                          <div>
                            <h4 className="text-sm font-bold text-gray-800 mb-3 flex items-center gap-2">
                              <div className="h-6 w-6 rounded-md bg-emerald-100 flex items-center justify-center">
                                <HomeIcon className="h-3 w-3 text-emerald-600" />
                              </div>
                              Shipping Address
                            </h4>
                            <div>
                              <Label className="text-sm font-medium text-gray-700">Delivery Address *</Label>
                              <div className="relative mt-1.5">
                                <HomeIcon className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                                <Textarea
                                  value={guestAddress}
                                  onChange={(e) => { setGuestAddress(e.target.value); setFormErrors((p) => ({ ...p, guestAddress: '' })) }}
                                  className={`pl-9 ${formErrors.guestAddress ? 'border-red-400 focus-visible:ring-red-200' : 'border-gray-200 focus:border-emerald-400 focus:ring-emerald-200'}`}
                                  placeholder="House no, Road, Area"
                                  rows={2}
                                />
                              </div>
                              {formErrors.guestAddress && (
                                <motion.p initial={{ opacity: 0, y: -3 }} animate={{ opacity: 1, y: 0 }} className="text-xs text-red-500 mt-1 flex items-center gap-1">
                                  <AlertCircle className="h-3 w-3" /> {formErrors.guestAddress}
                                </motion.p>
                              )}
                            </div>

                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
                              <div>
                                <Label className="text-sm font-medium text-gray-700">City *</Label>
                                <Input
                                  value={guestCity}
                                  onChange={(e) => { setGuestCity(e.target.value); setFormErrors((p) => ({ ...p, guestCity: '' })) }}
                                  className={`mt-1.5 h-10 ${formErrors.guestCity ? 'border-red-400 focus-visible:ring-red-200' : 'border-gray-200 focus:border-emerald-400 focus:ring-emerald-200'}`}
                                  placeholder="e.g. Dhaka"
                                />
                                {formErrors.guestCity && (
                                  <motion.p initial={{ opacity: 0, y: -3 }} animate={{ opacity: 1, y: 0 }} className="text-xs text-red-500 mt-1 flex items-center gap-1">
                                    <AlertCircle className="h-3 w-3" /> {formErrors.guestCity}
                                  </motion.p>
                                )}
                              </div>
                              <div>
                                <Label className="text-sm font-medium text-gray-700">District</Label>
                                <Select value={guestDistrict} onValueChange={setGuestDistrict}>
                                  <SelectTrigger className="mt-1.5 w-full h-10 border-gray-200">
                                    <SelectValue placeholder="Select district" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {Object.entries(divisionDistricts).map(([division, dists]) => (
                                      <div key={division}>
                                        <div className="px-2 py-1.5 text-xs font-bold text-emerald-700 bg-emerald-50">{division}</div>
                                        {dists.map((d) => (
                                          <SelectItem key={d} value={d}>{d}</SelectItem>
                                        ))}
                                      </div>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  {/* Delivery Method Card */}
                  <Card className="shadow-md border-0 overflow-hidden">
                    <div className="bg-gradient-to-r from-amber-500 to-amber-600 px-6 py-5">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-xl bg-white/20 flex items-center justify-center backdrop-blur-sm">
                          <Truck className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <h2 className="text-white font-bold text-lg">Delivery Method</h2>
                          <p className="text-amber-100 text-xs mt-0.5">Choose your preferred delivery speed</p>
                        </div>
                        <Badge className="ml-auto bg-white/20 text-white border-0 text-xs backdrop-blur-sm">Step 2</Badge>
                      </div>
                    </div>
                    <CardContent className="p-6">
                      <RadioGroup value={shippingMethod} onValueChange={setShippingMethod}>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <label
                            htmlFor="ship-standard"
                            className={`relative flex items-center gap-4 p-5 rounded-xl border-2 cursor-pointer transition-all duration-300 ${
                              shippingMethod === 'standard' ? 'border-emerald-500 bg-emerald-50/50 shadow-md shadow-emerald-100' : 'border-gray-200 bg-white hover:border-emerald-300'
                            }`}
                          >
                            <RadioGroupItem value="standard" id="ship-standard" className="sr-only" />
                            <div className={`h-14 w-14 rounded-xl flex items-center justify-center flex-shrink-0 transition-colors ${
                              shippingMethod === 'standard' ? 'bg-gradient-to-br from-emerald-400 to-emerald-600 shadow-md shadow-emerald-200' : 'bg-gray-100'
                            }`}>
                              <Truck className={`h-6 w-6 ${shippingMethod === 'standard' ? 'text-white' : 'text-gray-400'}`} />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="font-semibold text-sm text-gray-900">Regular Delivery</div>
                              <div className="text-xs text-gray-500 flex items-center gap-1 mt-0.5">
                                <Clock className="h-3 w-3" /> 3-5 business days
                              </div>
                            </div>
                            <div className="text-right">
                              <span className={`font-bold text-sm ${sub >= freeThreshold ? 'text-emerald-600' : 'text-gray-900'}`}>
                                {sub >= freeThreshold ? 'FREE' : `৳${standardShipping}`}
                              </span>
                              {sub >= freeThreshold && <p className="text-[10px] text-emerald-500">You saved!</p>}
                            </div>
                            {shippingMethod === 'standard' && (
                              <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: 'spring', stiffness: 300 }} className="absolute top-3 right-3">
                                <CheckCircle2 className="h-5 w-5 text-emerald-600" />
                              </motion.div>
                            )}
                          </label>

                          <label
                            htmlFor="ship-express"
                            className={`relative flex items-center gap-4 p-5 rounded-xl border-2 cursor-pointer transition-all duration-300 ${
                              shippingMethod === 'express' ? 'border-amber-500 bg-amber-50/50 shadow-md shadow-amber-100' : 'border-gray-200 bg-white hover:border-amber-300'
                            }`}
                          >
                            <RadioGroupItem value="express" id="ship-express" className="sr-only" />
                            <div className={`h-14 w-14 rounded-xl flex items-center justify-center flex-shrink-0 transition-colors ${
                              shippingMethod === 'express' ? 'bg-gradient-to-br from-amber-400 to-amber-600 shadow-md shadow-amber-200' : 'bg-gray-100'
                            }`}>
                              <Zap className={`h-6 w-6 ${shippingMethod === 'express' ? 'text-white' : 'text-gray-400'}`} fill="currentColor" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="font-semibold text-sm text-gray-900 flex items-center gap-1.5">
                                Express Delivery
                                <Badge className="bg-amber-100 text-amber-700 border-0 text-[9px] h-5 px-1.5 font-bold">FAST</Badge>
                              </div>
                              <div className="text-xs text-gray-500 flex items-center gap-1 mt-0.5">
                                <Clock className="h-3 w-3" /> Next day delivery
                              </div>
                            </div>
                            <div className="text-right">
                              <span className="font-bold text-sm text-gray-900">
                                ৳{sub >= freeThreshold ? expressShipping - standardShipping : expressShipping}
                              </span>
                            </div>
                            {shippingMethod === 'express' && (
                              <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: 'spring', stiffness: 300 }} className="absolute top-3 right-3">
                                <CheckCircle2 className="h-5 w-5 text-amber-600" />
                              </motion.div>
                            )}
                          </label>
                        </div>
                      </RadioGroup>

                      <div className="mt-6 flex justify-between">
                        <Button
                          variant="ghost"
                          onClick={() => goToStep(1)}
                          className="text-gray-600 hover:text-gray-900"
                        >
                          <ArrowLeft className="h-4 w-4 mr-1" />
                          Back to Cart
                        </Button>
                        <Button
                          onClick={() => goToStep(3)}
                          className="bg-emerald-600 hover:bg-emerald-700 rounded-xl px-8 h-11 shadow-md shadow-emerald-200"
                        >
                          Continue to Payment
                          <ChevronRight className="h-4 w-4 ml-1" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>

            {/* ─── Step 3: Payment Method ──────────────────────────────────── */}
            <AnimatePresence mode="wait">
              {currentStep === 3 && (
                <motion.div
                  key="payment"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.4, ease: 'easeOut', delay: 0.1 }}
                  className="space-y-6"
                >
                  <Card className="shadow-md border-0 overflow-hidden">
                    <div className="bg-gradient-to-r from-teal-600 to-teal-700 px-6 py-5">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-xl bg-white/20 flex items-center justify-center backdrop-blur-sm">
                          <Wallet className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <h2 className="text-white font-bold text-lg">Payment Method</h2>
                          <p className="text-teal-100 text-xs mt-0.5">Choose how you want to pay</p>
                        </div>
                        <Badge className="ml-auto bg-white/20 text-white border-0 text-xs backdrop-blur-sm">Step 3</Badge>
                      </div>
                    </div>
                    <CardContent className="p-6">
                      <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod} className="space-y-4">
                        {/* COD Option */}
                        <label
                          htmlFor="pay-cod"
                          className={`relative flex items-center gap-5 p-5 rounded-xl border-2 cursor-pointer transition-all duration-300 ${
                            paymentMethod === 'cod' ? 'border-emerald-500 bg-emerald-50/50 shadow-md shadow-emerald-100' : 'border-gray-200 bg-white hover:border-emerald-300'
                          }`}
                        >
                          <RadioGroupItem value="cod" id="pay-cod" className="sr-only" />
                          <div className="h-16 w-16 rounded-xl bg-gradient-to-br from-emerald-400 to-green-600 flex items-center justify-center flex-shrink-0 shadow-lg shadow-emerald-200">
                            <Banknote className="h-8 w-8 text-white" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="font-bold text-gray-900 text-base">Cash on Delivery</div>
                            <div className="text-sm text-gray-500 mt-0.5">Pay when you receive your order</div>
                            <Badge className="mt-2 bg-emerald-100 text-emerald-700 border-0 text-[10px] font-semibold">No extra charge</Badge>
                          </div>
                          {paymentMethod === 'cod' && (
                            <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: 'spring', stiffness: 300 }}>
                              <CheckCircle2 className="h-6 w-6 text-emerald-600 flex-shrink-0" />
                            </motion.div>
                          )}
                        </label>

                        {/* SSLCommerz Option */}
                        <label
                          htmlFor="pay-online"
                          className={`relative flex flex-col p-5 rounded-xl border-2 cursor-pointer transition-all duration-300 ${
                            paymentMethod === 'online' ? 'border-teal-500 bg-teal-50/50 shadow-md shadow-teal-100' : 'border-gray-200 bg-white hover:border-teal-300'
                          }`}
                        >
                          <div className="flex items-center gap-5">
                            <RadioGroupItem value="online" id="pay-online" className="sr-only" />
                            <div className="h-16 w-16 rounded-xl bg-gradient-to-br from-teal-400 to-cyan-600 flex items-center justify-center flex-shrink-0 shadow-lg shadow-teal-200">
                              <CreditCard className="h-8 w-8 text-white" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="font-bold text-gray-900 text-base">SSLCommerz Payment Gateway</div>
                              <div className="text-sm text-gray-500 mt-0.5">Pay via bKash, Nagad, Rocket, Visa, Mastercard & more</div>
                            </div>
                            {paymentMethod === 'online' && (
                              <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: 'spring', stiffness: 300 }}>
                                <CheckCircle2 className="h-6 w-6 text-teal-600 flex-shrink-0" />
                              </motion.div>
                            )}
                          </div>

                          {/* Supported Payment Methods */}
                          {paymentMethod === 'online' && (
                            <motion.div
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: 'auto' }}
                              transition={{ duration: 0.3 }}
                              className="mt-4 ml-[84px] pt-4 border-t border-gray-100 overflow-hidden"
                            >
                              <p className="text-xs text-gray-500 mb-2.5 font-medium">Supported payment methods:</p>
                              <div className="flex flex-wrap gap-2">
                                {['bKash', 'Nagad', 'Rocket', 'Visa', 'Mastercard', 'DBBL', 'City Bank'].map((method) => (
                                  <Badge key={method} variant="outline" className="text-[10px] h-7 bg-white border-gray-200 text-gray-600 font-medium px-2.5 hover:border-teal-300 transition-colors">
                                    {method}
                                  </Badge>
                                ))}
                                <Badge variant="outline" className="text-[10px] h-7 bg-white border-gray-200 text-gray-500 font-medium px-2.5">
                                  +more
                                </Badge>
                              </div>
                              <p className="text-[11px] text-gray-400 mt-3 flex items-center gap-1.5">
                                <ShieldCheck className="h-3.5 w-3.5" />
                                You will be redirected to SSLCommerz secure payment page
                              </p>
                            </motion.div>
                          )}
                        </label>
                      </RadioGroup>

                      {/* Terms & Conditions */}
                      <div className="mt-6 pt-5 border-t">
                        <div className="flex items-start gap-3 p-3 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors">
                          <Checkbox
                            id="terms"
                            checked={termsAccepted}
                            onCheckedChange={(checked) => setTermsAccepted(checked === true)}
                            className="mt-0.5 data-[state=checked]:bg-emerald-600 data-[state=checked]:border-emerald-600"
                          />
                          <Label htmlFor="terms" className="text-xs text-gray-600 leading-relaxed cursor-pointer">
                            I agree to the{' '}
                            <button type="button" className="text-emerald-700 font-semibold underline hover:text-emerald-800" onClick={() => navigate('terms')}>
                              Terms & Conditions
                            </button>{' '}
                            and{' '}
                            <button type="button" className="text-emerald-700 font-semibold underline hover:text-emerald-800" onClick={() => navigate('privacy')}>
                              Privacy Policy
                            </button>
                          </Label>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Order Note */}
                  <Card className="shadow-md border-0">
                    <CardContent className="p-6">
                      <Label className="text-sm font-bold text-gray-700 flex items-center gap-2 mb-3">
                        <div className="h-6 w-6 rounded-md bg-gray-100 flex items-center justify-center">
                          <svg className="h-3.5 w-3.5 text-gray-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                        </div>
                        Order Note (optional)
                      </Label>
                      <Textarea
                        value={note}
                        onChange={(e) => setNote(e.target.value)}
                        placeholder="Any special instructions for your delivery..."
                        className="resize-none bg-gray-50/50 border-gray-200 focus:border-emerald-400 focus:ring-emerald-200"
                        rows={2}
                      />
                    </CardContent>
                  </Card>

                  {/* Step 3 navigation */}
                  <div className="flex justify-between">
                    <Button
                      variant="ghost"
                      onClick={() => goToStep(2)}
                      className="text-gray-600 hover:text-gray-900"
                    >
                      <ArrowLeft className="h-4 w-4 mr-1" />
                      Back to Shipping
                    </Button>
                    <Button
                      onClick={() => goToStep(4)}
                      className="bg-emerald-600 hover:bg-emerald-700 rounded-xl px-8 h-11 shadow-md shadow-emerald-200"
                    >
                      Review Order
                      <ChevronRight className="h-4 w-4 ml-1" />
                    </Button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* ─── Step 4: Order Confirmation ─────────────────────────────── */}
            <AnimatePresence mode="wait">
              {currentStep === 4 && (
                <motion.div
                  key="confirmation"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.4, ease: 'easeOut' }}
                  className="space-y-6"
                >
                  <Card className="shadow-md border-0 overflow-hidden">
                    <div className="bg-gradient-to-r from-emerald-600 to-teal-600 px-6 py-5">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-xl bg-white/20 flex items-center justify-center backdrop-blur-sm">
                          <CheckCircle2 className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <h2 className="text-white font-bold text-lg">Confirm & Place Order</h2>
                          <p className="text-emerald-100 text-xs mt-0.5">Review your order details and place it</p>
                        </div>
                        <Badge className="ml-auto bg-white/20 text-white border-0 text-xs backdrop-blur-sm">Step 4</Badge>
                      </div>
                    </div>
                    <CardContent className="p-6 space-y-5">
                      {/* Shipping summary */}
                      <div className="rounded-xl border border-gray-100 p-4 bg-gray-50/50">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                            <MapPin className="h-4 w-4 text-emerald-600" />
                            Delivery To
                          </h3>
                          <button
                            onClick={() => goToStep(2)}
                            className="text-xs text-emerald-700 font-semibold hover:underline"
                          >
                            Edit
                          </button>
                        </div>
                        {isAuthenticated ? (
                          <p className="text-sm text-gray-600">
                            {addresses.find((a) => a.id === selectedAddressId)?.name || '—'} ·{' '}
                            {addresses.find((a) => a.id === selectedAddressId)?.phone || '—'} ·{' '}
                            {addresses.find((a) => a.id === selectedAddressId)?.address || '—'},{' '}
                            {addresses.find((a) => a.id === selectedAddressId)?.city || '—'}
                          </p>
                        ) : (
                          <p className="text-sm text-gray-600">
                            {guestName || '—'} · {guestPhone || '—'} · {guestAddress || '—'}, {guestCity || '—'}
                          </p>
                        )}
                        <p className="text-xs text-gray-400 mt-1">
                          Method: {shippingMethod === 'express' ? 'Express Delivery' : 'Standard Delivery'}
                        </p>
                      </div>

                      {/* Payment summary */}
                      <div className="rounded-xl border border-gray-100 p-4 bg-gray-50/50">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                            <Wallet className="h-4 w-4 text-teal-600" />
                            Payment Method
                          </h3>
                          <button
                            onClick={() => goToStep(3)}
                            className="text-xs text-emerald-700 font-semibold hover:underline"
                          >
                            Edit
                          </button>
                        </div>
                        <p className="text-sm text-gray-600">
                          {paymentMethod === 'cod'
                            ? 'Cash on Delivery (COD)'
                            : 'Online Payment (SSLCommerz)'}
                        </p>
                      </div>

                      {/* Order note summary */}
                      {note && (
                        <div className="rounded-xl border border-gray-100 p-4 bg-gray-50/50">
                          <h3 className="text-sm font-semibold text-gray-700 mb-1">Order Note</h3>
                          <p className="text-sm text-gray-600">{note}</p>
                        </div>
                      )}

                      {/* Terms acceptance */}
                      <div className="rounded-xl border border-gray-100 p-4">
                        <div className="flex items-start gap-2">
                          <Checkbox
                            id="terms-final"
                            checked={termsAccepted}
                            onCheckedChange={(v) => setTermsAccepted(v === true)}
                            className="mt-0.5 data-[state=checked]:bg-emerald-600 data-[state=checked]:border-emerald-600"
                          />
                          <Label htmlFor="terms-final" className="text-xs text-gray-600 leading-relaxed cursor-pointer">
                            I agree to the{' '}
                            <button type="button" className="text-emerald-700 font-semibold underline hover:text-emerald-800" onClick={() => navigate('terms')}>
                              Terms & Conditions
                            </button>{' '}
                            and{' '}
                            <button type="button" className="text-emerald-700 font-semibold underline hover:text-emerald-800" onClick={() => navigate('privacy')}>
                              Privacy Policy
                            </button>
                          </Label>
                        </div>
                      </div>

                      {/* Step 4 navigation */}
                      <div className="flex justify-between">
                        <Button
                          variant="ghost"
                          onClick={() => goToStep(3)}
                          className="text-gray-600 hover:text-gray-900"
                        >
                          <ArrowLeft className="h-4 w-4 mr-1" />
                          Back to Payment
                        </Button>
                        <motion.div whileTap={{ scale: 0.98 }}>
                          <Button
                            className="rounded-xl text-base font-bold shadow-lg shadow-emerald-200 bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 h-11 px-8"
                            size="lg"
                            onClick={() => handlePlaceOrder()}
                            disabled={placing || !termsAccepted}
                          >
                            {placing ? (
                              <>
                                <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                                {paymentMethod === 'online' ? 'Redirecting to Payment...' : 'Placing Order...'}
                              </>
                            ) : (
                              <>
                                <Lock className="h-4 w-4 mr-2" />
                                {paymentMethod === 'online' ? 'Pay & Place Order' : 'Place Order'}
                                <ChevronRight className="h-4 w-4 ml-1" />
                              </>
                            )}
                          </Button>
                        </motion.div>
                      </div>
                      {!termsAccepted && (
                        <p className="text-xs text-amber-600 text-center">Please accept the Terms & Conditions to place your order.</p>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* ─── Right: Order Summary Sidebar ────────────────────────────── */}
          <div className="space-y-4">
            <div className="lg:sticky lg:top-4">
              <Card className="shadow-lg border-0 overflow-hidden">
                <div className="bg-gradient-to-r from-emerald-600 to-emerald-700 px-5 py-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-white font-bold flex items-center gap-2">
                      <ShoppingBag className="h-4 w-4" />
                      Order Summary
                    </h3>
                    <Badge className="bg-white/20 text-white border-0 backdrop-blur-sm">
                      {totalItems()} items
                    </Badge>
                  </div>
                </div>
                <CardContent className="p-5 space-y-5">
                  {/* Free Shipping Progress */}
                  {freeShippingRemaining > 0 && shipping === 0 ? null : freeShippingRemaining > 0 ? (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-xl p-4"
                    >
                      <div className="flex items-center justify-between text-xs mb-2">
                        <span className="text-amber-800 font-semibold">
                          Add ৳{freeShippingRemaining.toLocaleString()} more for FREE delivery!
                        </span>
                        <Truck className="h-4 w-4 text-amber-600" />
                      </div>
                      <div className="relative">
                        <Progress value={freeShippingProgress} className="h-3 bg-amber-200 [&>div]:bg-gradient-to-r [&>div]:from-amber-400 [&>div]:to-amber-500" />
                        <span className="absolute right-0 -top-4 text-[9px] font-bold text-amber-600">
                          ৳{sub.toLocaleString()} / ৳{freeThreshold.toLocaleString()}
                        </span>
                      </div>
                    </motion.div>
                  ) : (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 rounded-xl p-4 flex items-center gap-3"
                    >
                      <div className="h-10 w-10 rounded-full bg-emerald-100 flex items-center justify-center flex-shrink-0">
                        <Truck className="h-5 w-5 text-emerald-600" />
                      </div>
                      <div>
                        <span className="text-sm text-emerald-800 font-bold">You qualify for FREE delivery!</span>
                        <p className="text-xs text-emerald-600">Shipping savings applied at checkout</p>
                      </div>
                    </motion.div>
                  )}

                  {/* Cart Items */}
                  <div className="space-y-3 max-h-80 overflow-y-auto pr-1 scrollbar-thin">
                    {cartItems.map((item, idx) => (
                      <motion.div
                        key={item.id}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: idx * 0.05 }}
                        className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-gray-50 transition-colors group"
                      >
                        <div className="relative h-14 w-14 rounded-lg bg-gray-100 flex-shrink-0 overflow-hidden border">
                          <Image
                            src={item.image}
                            alt={item.productName}
                            fill
                            className="object-cover"
                            sizes="56px"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement
                              target.style.display = 'none'
                            }}
                          />
                          <span className="absolute -top-0.5 -right-0.5 h-5 w-5 rounded-full bg-emerald-600 text-white text-[10px] font-bold flex items-center justify-center shadow-sm">
                            {item.quantity}
                          </span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-gray-900 truncate">{item.productName}</p>
                          <p className="text-xs text-gray-500 mt-0.5">
                            ৳{(item.discountPrice != null ? item.discountPrice : item.price).toLocaleString()} {item.unit && `per ${item.unit}`}
                          </p>
                          {/* Quantity controls */}
                          <div className="flex items-center gap-1.5 mt-1.5">
                            <button
                              onClick={() => updateQuantity(item.id, Math.max(1, item.quantity - 1))}
                              className="h-6 w-6 rounded-md border border-gray-200 flex items-center justify-center hover:bg-emerald-50 hover:border-emerald-300 transition-colors"
                            >
                              <Minus className="h-2.5 w-2.5" />
                            </button>
                            <span className="text-xs font-semibold w-6 text-center">{item.quantity}</span>
                            <button
                              onClick={() => updateQuantity(item.id, item.quantity + 1)}
                              className="h-6 w-6 rounded-md border border-gray-200 flex items-center justify-center hover:bg-emerald-50 hover:border-emerald-300 transition-colors"
                            >
                              <Plus className="h-2.5 w-2.5" />
                            </button>
                            <button
                              onClick={() => removeFromCart(item.id)}
                              className="h-6 w-6 rounded-md flex items-center justify-center text-red-400 hover:text-red-600 hover:bg-red-50 ml-1 transition-colors"
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </div>
                        </div>
                        <span className="font-bold text-sm text-gray-900 whitespace-nowrap">
                          ৳{((item.discountPrice != null ? item.discountPrice : item.price) * item.quantity).toLocaleString()}
                        </span>
                      </motion.div>
                    ))}
                  </div>

                  <Separator />

                  {/* Coupon Code */}
                  <div>
                    <button
                      className="flex items-center justify-between w-full text-left"
                      onClick={() => setShowCouponInput(!showCouponInput)}
                    >
                      <Label className="text-sm font-bold text-gray-700 flex items-center gap-2 cursor-pointer">
                        <Tag className="h-4 w-4 text-emerald-600" />
                        Coupon Code
                      </Label>
                      {showCouponInput ? (
                        <ChevronUp className="h-4 w-4 text-gray-400" />
                      ) : (
                        <ChevronDown className="h-4 w-4 text-gray-400" />
                      )}
                    </button>
                    <AnimatePresence>
                      {showCouponInput && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          className="overflow-hidden"
                        >
                          {couponApplied ? (
                            <motion.div
                              initial={{ opacity: 0, scale: 0.95 }}
                              animate={{ opacity: 1, scale: 1 }}
                              className="flex items-center justify-between p-3.5 rounded-xl bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 mt-3"
                            >
                              <div className="flex items-center gap-2.5">
                                <div className="h-8 w-8 rounded-lg bg-emerald-100 flex items-center justify-center">
                                  <Gift className="h-4 w-4 text-emerald-600" />
                                </div>
                                <div>
                                  <Badge className="bg-emerald-100 text-emerald-800 border-emerald-200 font-bold">{couponCode}</Badge>
                                  <span className="text-xs text-emerald-700 ml-2 font-semibold">-৳{discount.toLocaleString()}</span>
                                </div>
                              </div>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => { setCouponCode(''); setDiscount(0); setCouponApplied(false) }}
                                className="text-red-500 h-7 text-xs hover:text-red-700 hover:bg-red-50"
                              >
                                Remove
                              </Button>
                            </motion.div>
                          ) : (
                            <div className="flex gap-2 mt-3">
                              <Input
                                placeholder="Enter coupon code"
                                value={couponCode}
                                onChange={(e) => { setCouponCode(e.target.value); if (couponApplied) { setDiscount(0); setCouponApplied(false) } }}
                                className="h-10 text-sm bg-gray-50/50 border-gray-200 focus:border-emerald-400 focus:ring-emerald-200"
                                onKeyDown={(e) => e.key === 'Enter' && handleApplyCoupon()}
                              />
                              <Button
                                variant="outline"
                                onClick={handleApplyCoupon}
                                className="h-10 border-emerald-400 text-emerald-700 hover:bg-emerald-50 font-semibold px-5"
                              >
                                Apply
                              </Button>
                            </div>
                          )}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>

                  <Separator />

                  {/* Loyalty Points Redemption */}
                  {isAuthenticated && loyaltyBalance > 0 && (
                    <div>
                      <button
                        className="flex items-center justify-between w-full text-left"
                        onClick={() => setShowLoyaltyInput(!showLoyaltyInput)}
                      >
                        <Label className="text-sm font-bold text-gray-700 flex items-center gap-2 cursor-pointer">
                          <Star className="h-4 w-4 text-amber-500" />
                          Use Loyalty Points
                        </Label>
                        {showLoyaltyInput ? (
                          <ChevronUp className="h-4 w-4 text-gray-400" />
                        ) : (
                          <ChevronDown className="h-4 w-4 text-gray-400" />
                        )}
                      </button>
                      <AnimatePresence>
                        {showLoyaltyInput && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className="overflow-hidden"
                          >
                            <div className="mt-3 space-y-3">
                              {/* Available balance */}
                              <div className="flex items-center justify-between p-3 rounded-xl bg-gradient-to-r from-amber-50 to-yellow-50 border border-amber-200">
                                <div className="flex items-center gap-2">
                                  <div className="h-8 w-8 rounded-lg bg-amber-100 flex items-center justify-center">
                                    <Sparkles className="h-4 w-4 text-amber-600" />
                                  </div>
                                  <div>
                                    <p className="text-sm font-bold text-amber-800">{loyaltyBalance} points</p>
                                    <p className="text-[11px] text-amber-600">Worth ৳{loyaltyBalance.toLocaleString()}</p>
                                  </div>
                                </div>
                              </div>

                              {loyaltyApplied ? (
                                <motion.div
                                  initial={{ opacity: 0, scale: 0.95 }}
                                  animate={{ opacity: 1, scale: 1 }}
                                  className="flex items-center justify-between p-3.5 rounded-xl bg-gradient-to-r from-amber-50 to-yellow-50 border border-amber-200"
                                >
                                  <div className="flex items-center gap-2.5">
                                    <div className="h-8 w-8 rounded-lg bg-amber-100 flex items-center justify-center">
                                      <Star className="h-4 w-4 text-amber-600" />
                                    </div>
                                    <div>
                                      <Badge className="bg-amber-100 text-amber-800 border-amber-200 font-bold">{loyaltyDiscount} pts</Badge>
                                      <span className="text-xs text-amber-700 ml-2 font-semibold">-৳{loyaltyDiscount.toLocaleString()}</span>
                                    </div>
                                  </div>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => { setLoyaltyApplied(false); setLoyaltyPointsToUse(0) }}
                                    className="text-red-500 h-7 text-xs hover:text-red-700 hover:bg-red-50"
                                  >
                                    Remove
                                  </Button>
                                </motion.div>
                              ) : (
                                <>
                                  {/* Points input */}
                                  <div className="space-y-2">
                                    <div className="flex gap-2">
                                      <div className="relative flex-1">
                                        <Star className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-amber-400" />
                                        <Input
                                          type="number"
                                          min={0}
                                          max={Math.min(loyaltyBalance, maxLoyaltyDiscount)}
                                          value={loyaltyPointsToUse || ''}
                                          onChange={(e) => {
                                            const val = parseInt(e.target.value) || 0
                                            setLoyaltyPointsToUse(Math.min(val, loyaltyBalance, maxLoyaltyDiscount))
                                          }}
                                          className="pl-9 h-10 text-sm bg-gray-50/50 border-gray-200 focus:border-amber-400 focus:ring-amber-200"
                                          placeholder="Points to use"
                                        />
                                      </div>
                                      <Button
                                        variant="outline"
                                        onClick={() => {
                                          if (loyaltyPointsToUse > 0 && loyaltyPointsToUse <= loyaltyBalance) {
                                            setLoyaltyApplied(true)
                                            toast.success(`${effectiveLoyaltyPoints} loyalty points applied! ৳${effectiveLoyaltyPoints} discount`)
                                          } else {
                                            toast.error('Enter valid points to redeem')
                                          }
                                        }}
                                        className="h-10 border-amber-400 text-amber-700 hover:bg-amber-50 font-semibold px-5"
                                      >
                                        Apply
                                      </Button>
                                    </div>

                                    {/* Quick select buttons */}
                                    <div className="flex gap-2">
                                      <button
                                        onClick={() => setLoyaltyPointsToUse(Math.min(Math.floor(loyaltyBalance * 0.25), maxLoyaltyDiscount))}
                                        className="flex-1 text-[11px] font-medium py-1.5 rounded-lg border border-gray-200 hover:border-amber-300 hover:bg-amber-50 transition-colors text-gray-600"
                                      >
                                        25%
                                      </button>
                                      <button
                                        onClick={() => setLoyaltyPointsToUse(Math.min(Math.floor(loyaltyBalance * 0.5), maxLoyaltyDiscount))}
                                        className="flex-1 text-[11px] font-medium py-1.5 rounded-lg border border-gray-200 hover:border-amber-300 hover:bg-amber-50 transition-colors text-gray-600"
                                      >
                                        50%
                                      </button>
                                      <button
                                        onClick={() => setLoyaltyPointsToUse(Math.min(loyaltyBalance, maxLoyaltyDiscount))}
                                        className="flex-1 text-[11px] font-medium py-1.5 rounded-lg border border-gray-200 hover:border-amber-300 hover:bg-amber-50 transition-colors text-gray-600"
                                      >
                                        Max
                                      </button>
                                    </div>

                                    {/* Max 20% warning */}
                                    <div className="flex items-start gap-1.5 p-2 rounded-lg bg-amber-50/50 border border-amber-100">
                                      <Info className="h-3.5 w-3.5 text-amber-500 mt-0.5 flex-shrink-0" />
                                      <p className="text-[11px] text-amber-700 leading-relaxed">
                                        Max <span className="font-bold">20% of subtotal</span> (৳{maxLoyaltyDiscount.toLocaleString()}) can be paid with points. 1 point = ৳1.
                                      </p>
                                    </div>

                                    {loyaltyPointsToUse > maxLoyaltyDiscount && (
                                      <p className="text-[11px] text-orange-600 flex items-center gap-1">
                                        <AlertCircle className="h-3 w-3" />
                                        Capped at {maxLoyaltyDiscount} points (20% of subtotal)
                                      </p>
                                    )}
                                  </div>
                                </>
                              )}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  )}

                  <Separator />
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">Subtotal ({totalItems()} items)</span>
                      <span className="font-semibold text-gray-900">৳{sub.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">Delivery Charge</span>
                      <span className={`font-semibold ${shipping === 0 ? 'text-emerald-600' : 'text-gray-900'}`}>
                        {shipping === 0 ? '✓ FREE' : `৳${shipping}`}
                      </span>
                    </div>
                    {discount > 0 && (
                      <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="flex justify-between text-sm">
                        <span className="text-gray-500">Coupon Discount</span>
                        <span className="text-emerald-600 font-semibold">-৳{discount.toLocaleString()}</span>
                      </motion.div>
                    )}
                    {discount > 0 && (
                      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-1.5 p-2 rounded-lg bg-emerald-50 text-xs">
                        <Gift className="h-3.5 w-3.5 text-emerald-600" />
                        <span className="text-emerald-700 font-semibold">You save ৳{discount.toLocaleString()}!</span>
                      </motion.div>
                    )}
                    {loyaltyDiscount > 0 && (
                      <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="flex justify-between text-sm">
                        <span className="text-gray-500">Loyalty Points Discount</span>
                        <span className="text-amber-600 font-semibold">-৳{loyaltyDiscount.toLocaleString()}</span>
                      </motion.div>
                    )}
                    {(discount > 0 || loyaltyDiscount > 0) && (
                      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-1.5 p-2 rounded-lg bg-gradient-to-r from-emerald-50 to-amber-50 text-xs border border-emerald-100">
                        <Sparkles className="h-3.5 w-3.5 text-amber-500" />
                        <span className="text-emerald-700 font-semibold">Total savings: ৳{(discount + loyaltyDiscount).toLocaleString()}!</span>
                      </motion.div>
                    )}
                    <Separator />
                    <div className="flex justify-between items-center pt-1">
                      <span className="font-bold text-lg text-gray-900">Grand Total</span>
                      <motion.span
                        key={total}
                        initial={{ scale: 1.1 }}
                        animate={{ scale: 1 }}
                        className="font-extrabold text-2xl text-emerald-700"
                      >
                        ৳{Math.max(0, total).toLocaleString()}
                      </motion.span>
                    </div>
                  </div>

                  {/* Place Order Button — shown on steps 1-3 as a quick proceed action */}
                  {currentStep < 4 && (
                    <motion.div whileTap={{ scale: 0.98 }}>
                      <Button
                        className="w-full h-13 rounded-xl text-base font-bold shadow-lg shadow-emerald-200 bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 mt-2 py-3.5"
                        size="lg"
                        onClick={() => goToStep(currentStep + 1)}
                      >
                        <Lock className="h-4 w-4 mr-2" />
                        Continue to Step {currentStep + 1}
                        <ChevronRight className="h-4 w-4 ml-1" />
                      </Button>
                    </motion.div>
                  )}

                  <div className="flex items-center justify-center gap-2 text-xs text-gray-400 pt-1">
                    <ShieldCheck className="h-3.5 w-3.5" />
                    <span>Secure 256-bit SSL Encrypted Checkout</span>
                  </div>
                </CardContent>
              </Card>

              {/* Trust Badges */}
              <Card className="shadow-md border-0 bg-gradient-to-r from-emerald-50 to-teal-50 mt-4">
                <CardContent className="p-5">
                  <div className="grid grid-cols-3 gap-4">
                    {[
                      { icon: Lock, label: 'Secure SSL', sub: 'Encrypted', color: 'text-emerald-600 bg-emerald-100' },
                      { icon: RefreshCw, label: 'Money Back', sub: 'Guarantee', color: 'text-amber-600 bg-amber-100' },
                      { icon: ShieldCheck, label: '100% Safe', sub: 'Checkout', color: 'text-teal-600 bg-teal-100' },
                    ].map((item, idx) => (
                      <motion.div
                        key={idx}
                        whileHover={{ y: -2 }}
                        className="flex flex-col items-center gap-2 p-3 rounded-xl bg-white/80 shadow-sm text-center"
                      >
                        <div className={`h-9 w-9 rounded-lg flex items-center justify-center ${item.color}`}>
                          <item.icon className="h-4.5 w-4.5" />
                        </div>
                        <span className="text-[11px] font-bold text-gray-700 leading-tight">{item.label}</span>
                        <span className="text-[9px] text-gray-400">{item.sub}</span>
                      </motion.div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
