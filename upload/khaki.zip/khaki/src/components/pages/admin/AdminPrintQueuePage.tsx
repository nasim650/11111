'use client'

import React, { useEffect, useState, useCallback, useRef } from 'react'
import { useAppStore } from '@/lib/store'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Printer,
  RefreshCw,
  Trash2,
  CheckCircle,
  AlertCircle,
  Clock,
  Loader2,
  FileText,
  Package,
  Tag,
  Receipt,
  Truck,
  RotateCcw,
  XCircle,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  Timer,
  FileBarChart,
} from 'lucide-react'
import { toast } from 'sonner'
import { motion, AnimatePresence } from 'framer-motion'

interface PrintQueueItem {
  id: string
  orderId: string
  documentType: string
  status: string
  filePath: string | null
  error: string | null
  createdAt: string
  printedAt: string | null
  order: {
    id: string
    orderNumber: string
    orderStatus: string
    guestName: string | null
    guestPhone: string | null
    totalAmount: number
    paymentMethod: string
  }
}

interface QueueStats {
  pending: number
  printing: number
  printed: number
  failed: number
  total: number
}

interface PaginatedData {
  items: PrintQueueItem[]
  total: number
  page: number
  limit: number
  totalPages: number
}

const DOC_TYPE_ICONS: Record<string, React.ElementType> = {
  'invoice': FileText,
  'packing-slip': Package,
  'delivery-label': Tag,
  'thermal-receipt': Receipt,
  'courier-label': Truck,
}

const DOC_TYPE_LABELS: Record<string, string> = {
  'invoice': 'Invoice',
  'packing-slip': 'Packing Slip',
  'delivery-label': 'Delivery Label',
  'thermal-receipt': 'Thermal Receipt',
  'courier-label': 'Courier Label',
}

const DOC_TYPE_COLORS: Record<string, string> = {
  'invoice': 'bg-emerald-500',
  'packing-slip': 'bg-sky-500',
  'delivery-label': 'bg-amber-500',
  'thermal-receipt': 'bg-purple-500',
  'courier-label': 'bg-rose-500',
}

const STATUS_CONFIG: Record<string, { color: string; icon: React.ElementType; bg: string }> = {
  PENDING: { color: 'text-yellow-700', icon: Clock, bg: 'bg-yellow-50 border-yellow-200' },
  PRINTING: { color: 'text-blue-700', icon: Loader2, bg: 'bg-blue-50 border-blue-200' },
  PRINTED: { color: 'text-emerald-700', icon: CheckCircle, bg: 'bg-emerald-50 border-emerald-200' },
  FAILED: { color: 'text-red-700', icon: AlertCircle, bg: 'bg-red-50 border-red-200' },
}

// Animated counter hook
function useAnimatedCounter(target: number, duration: number = 800) {
  const [count, setCount] = useState(0)
  const prevTarget = useRef(0)

  useEffect(() => {
    if (target === prevTarget.current) return
    prevTarget.current = target

    const start = 0
    const diff = target - start
    const startTime = performance.now()

    function step(currentTime: number) {
      const elapsed = currentTime - startTime
      const progress = Math.min(elapsed / duration, 1)
      // Ease out cubic
      const eased = 1 - Math.pow(1 - progress, 3)
      setCount(Math.round(start + diff * eased))
      if (progress < 1) {
        requestAnimationFrame(step)
      }
    }

    requestAnimationFrame(step)
  }, [target, duration])

  return count
}

// Animated stat card component
function AnimatedStatCard({
  label,
  count,
  color,
  bg,
  icon: Icon,
  delay,
}: {
  label: string
  count: number
  color: string
  bg: string
  icon: React.ElementType
  delay: number
}) {
  const animatedCount = useAnimatedCounter(count)

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.4, delay, ease: 'easeOut' }}
    >
      <Card className={`${bg} border-0 shadow-sm hover:shadow-md transition-shadow`}>
        <CardContent className="p-4 flex items-center gap-3">
          <Icon className={`size-8 ${color}`} />
          <div>
            <p className={`text-2xl font-bold ${color}`}>{animatedCount}</p>
            <p className="text-xs text-muted-foreground">{label}</p>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}

export default function AdminPrintQueuePage() {
  const accessToken = useAppStore((s) => s.accessToken)
  const navigate = useAppStore((s) => s.navigate)
  const [queueItems, setQueueItems] = useState<PrintQueueItem[]>([])
  const [stats, setStats] = useState<QueueStats>({ pending: 0, printing: 0, printed: 0, failed: 0, total: 0 })
  const [loading, setLoading] = useState(true)
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [docTypeFilter, setDocTypeFilter] = useState<string>('all')
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [actionLoading, setActionLoading] = useState<string | null>(null)
  const [autoRefresh, setAutoRefresh] = useState(false)

  // Document type distribution for chart
  const [docTypeDistribution, setDocTypeDistribution] = useState<Record<string, number>>({})

  const fetchQueue = useCallback(async () => {
    setLoading(true)
    try {
      const headers: Record<string, string> = {}
      if (accessToken) headers['Authorization'] = `Bearer ${accessToken}`

      const params = new URLSearchParams({
        page: String(page),
        limit: '20',
      })
      if (statusFilter !== 'all') params.set('status', statusFilter)
      if (docTypeFilter !== 'all') params.set('documentType', docTypeFilter)

      const res = await fetch(`/api/print-queue?${params}`, { headers })
      if (res.ok) {
        const data = await res.json()
        const paginated = data.data as PaginatedData
        setQueueItems(paginated.items || [])
        setTotalPages(paginated.totalPages || 1)
        if (data.stats) setStats(data.stats as QueueStats)

        // Calculate document type distribution from items
        const dist: Record<string, number> = {}
        for (const item of paginated.items || []) {
          dist[item.documentType] = (dist[item.documentType] || 0) + 1
        }
        // Also fetch full distribution without pagination for chart
        setDocTypeDistribution(prev => Object.keys(dist).length > 0 ? dist : prev)
      }
    } catch (err) {
      console.error('Fetch queue error:', err)
    } finally {
      setLoading(false)
    }
  }, [accessToken, page, statusFilter, docTypeFilter])

  // Fetch doc type distribution separately (no pagination)
  const fetchDocTypeDistribution = useCallback(async () => {
    try {
      const headers: Record<string, string> = {}
      if (accessToken) headers['Authorization'] = `Bearer ${accessToken}`

      const res = await fetch(`/api/print-queue?limit=1000`, { headers })
      if (res.ok) {
        const data = await res.json()
        const items: PrintQueueItem[] = data.data?.items || []
        const dist: Record<string, number> = {}
        for (const item of items) {
          dist[item.documentType] = (dist[item.documentType] || 0) + 1
        }
        setDocTypeDistribution(dist)
      }
    } catch {
      // Silent fail
    }
  }, [accessToken])

  useEffect(() => {
    fetchQueue()
  }, [fetchQueue])

  useEffect(() => {
    fetchDocTypeDistribution()
  }, [fetchDocTypeDistribution])

  // Auto-refresh with interval
  useEffect(() => {
    if (!autoRefresh) return
    const interval = setInterval(() => {
      fetchQueue()
      fetchDocTypeDistribution()
    }, 30000)
    return () => clearInterval(interval)
  }, [autoRefresh, fetchQueue, fetchDocTypeDistribution])

  async function bulkAction(action: string) {
    setActionLoading(action)
    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' }
      if (accessToken) headers['Authorization'] = `Bearer ${accessToken}`

      const res = await fetch('/api/print-queue', {
        method: 'PATCH',
        headers,
        body: JSON.stringify({ action }),
      })

      if (res.ok) {
        const data = await res.json()
        toast.success(data.message || 'Action completed')
        fetchQueue()
        fetchDocTypeDistribution()
      } else {
        toast.error('Action failed')
      }
    } catch {
      toast.error('Action failed')
    } finally {
      setActionLoading(null)
    }
  }

  async function updateItemStatus(itemId: string, status: string) {
    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' }
      if (accessToken) headers['Authorization'] = `Bearer ${accessToken}`

      const res = await fetch(`/api/print-queue/${itemId}`, {
        method: 'PATCH',
        headers,
        body: JSON.stringify({ status }),
      })

      if (res.ok) {
        toast.success(`Status updated to ${status}`)
        fetchQueue()
      } else {
        toast.error('Failed to update status')
      }
    } catch {
      toast.error('Failed to update status')
    }
  }

  async function deleteItem(itemId: string) {
    try {
      const headers: Record<string, string> = {}
      if (accessToken) headers['Authorization'] = `Bearer ${accessToken}`

      const res = await fetch(`/api/print-queue/${itemId}`, {
        method: 'DELETE',
        headers,
      })

      if (res.ok) {
        toast.success('Item removed from queue')
        fetchQueue()
        fetchDocTypeDistribution()
      } else {
        toast.error('Failed to delete item')
      }
    } catch {
      toast.error('Failed to delete item')
    }
  }

  // Get preview URL for document type
  function getPreviewUrl(item: PrintQueueItem): string | null {
    const orderId = item.orderId
    switch (item.documentType) {
      case 'invoice':
        return `/api/orders/${orderId}/invoice?format=pdf`
      case 'packing-slip':
        return `/api/orders/${orderId}/packing-slip?format=pdf`
      case 'delivery-label':
        return `/api/orders/${orderId}/delivery-label?format=pdf`
      case 'thermal-receipt':
        return `/api/orders/${orderId}/thermal-receipt`
      case 'courier-label':
        return `/api/orders/${orderId}/courier-label`
      default:
        return null
    }
  }

  // Calculate completion rate
  const completionRate = stats.total > 0 ? Math.round((stats.printed / stats.total) * 100) : 0

  // Calculate max distribution value for chart
  const maxDistValue = Math.max(...Object.values(docTypeDistribution), 1)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Print Queue Monitor</h1>
          <p className="text-muted-foreground text-sm mt-1">
            Manage auto-generated documents and print queue
          </p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button
            variant={autoRefresh ? 'default' : 'outline'}
            size="sm"
            onClick={() => {
              setAutoRefresh(!autoRefresh)
              if (!autoRefresh) {
                toast.success('Auto-refresh enabled (every 30s)')
              } else {
                toast.info('Auto-refresh disabled')
              }
            }}
          >
            <Timer className={`size-4 mr-2 ${autoRefresh ? 'animate-pulse' : ''}`} />
            {autoRefresh ? 'Auto: ON' : 'Auto: OFF'}
          </Button>
          <Button variant="outline" size="sm" onClick={() => { fetchQueue(); fetchDocTypeDistribution() }} disabled={loading}>
            <RefreshCw className={`size-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => bulkAction('mark-all-printed')}
            disabled={actionLoading !== null || stats.pending === 0}
          >
            {actionLoading === 'mark-all-printed' ? (
              <Loader2 className="size-4 mr-2 animate-spin" />
            ) : (
              <CheckCircle className="size-4 mr-2 text-emerald-600" />
            )}
            Mark All Printed
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => bulkAction('retry-failed')}
            disabled={actionLoading !== null || stats.failed === 0}
          >
            {actionLoading === 'retry-failed' ? (
              <Loader2 className="size-4 mr-2 animate-spin" />
            ) : (
              <RotateCcw className="size-4 mr-2 text-orange-600" />
            )}
            Retry Failed ({stats.failed})
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => bulkAction('clear-printed')}
            disabled={actionLoading !== null || stats.printed === 0}
          >
            {actionLoading === 'clear-printed' ? (
              <Loader2 className="size-4 mr-2 animate-spin" />
            ) : (
              <Trash2 className="size-4 mr-2 text-red-600" />
            )}
            Clear Printed
          </Button>
        </div>
      </div>

      {/* Progress Bar - Queue Completion Rate */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <FileBarChart className="size-4 text-emerald-600" />
                <span className="text-sm font-medium">Queue Completion Rate</span>
              </div>
              <div className="flex items-center gap-3 text-sm">
                <span className="text-muted-foreground">
                  {stats.printed} of {stats.total} printed
                </span>
                <span className="font-bold text-emerald-700">{completionRate}%</span>
              </div>
            </div>
            <Progress value={completionRate} className="h-3" />
          </CardContent>
        </Card>
      </motion.div>

      {/* Stats Cards - Animated */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <AnimatePresence mode="wait">
          <AnimatedStatCard
            key="pending"
            label="Pending"
            count={stats.pending}
            color="text-yellow-700"
            bg="bg-yellow-50"
            icon={Clock}
            delay={0}
          />
          <AnimatedStatCard
            key="printing"
            label="Printing"
            count={stats.printing}
            color="text-blue-700"
            bg="bg-blue-50"
            icon={Printer}
            delay={0.1}
          />
          <AnimatedStatCard
            key="printed"
            label="Printed"
            count={stats.printed}
            color="text-emerald-700"
            bg="bg-emerald-50"
            icon={CheckCircle}
            delay={0.2}
          />
          <AnimatedStatCard
            key="failed"
            label="Failed"
            count={stats.failed}
            color="text-red-700"
            bg="bg-red-50"
            icon={XCircle}
            delay={0.3}
          />
        </AnimatePresence>
      </div>

      {/* Document Type Distribution Chart */}
      {Object.keys(docTypeDistribution).length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <FileBarChart className="size-4 text-emerald-600" />
                Document Type Distribution
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4 pt-0">
              <div className="space-y-3">
                {Object.entries(docTypeDistribution)
                  .sort(([, a], [, b]) => b - a)
                  .map(([docType, count]) => {
                    const percentage = Math.round((count / maxDistValue) * 100)
                    const colorClass = DOC_TYPE_COLORS[docType] || 'bg-gray-500'
                    const label = DOC_TYPE_LABELS[docType] || docType
                    const Icon = DOC_TYPE_ICONS[docType] || FileText

                    return (
                      <div key={docType} className="flex items-center gap-3">
                        <div className="flex items-center gap-2 w-36 shrink-0">
                          <Icon className="size-4 text-muted-foreground" />
                          <span className="text-xs font-medium">{label}</span>
                        </div>
                        <div className="flex-1 h-6 bg-muted/50 rounded-full overflow-hidden">
                          <motion.div
                            className={`h-full rounded-full ${colorClass}`}
                            initial={{ width: 0 }}
                            animate={{ width: `${percentage}%` }}
                            transition={{ duration: 0.8, ease: 'easeOut' }}
                          />
                        </div>
                        <span className="text-xs font-bold w-8 text-right">{count}</span>
                      </div>
                    )
                  })}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Filters */}
      <div className="flex gap-4 items-center flex-wrap">
        <Select value={statusFilter} onValueChange={(val) => { setStatusFilter(val); setPage(1) }}>
          <SelectTrigger className="w-44">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="PENDING">Pending</SelectItem>
            <SelectItem value="PRINTING">Printing</SelectItem>
            <SelectItem value="PRINTED">Printed</SelectItem>
            <SelectItem value="FAILED">Failed</SelectItem>
          </SelectContent>
        </Select>

        <Select value={docTypeFilter} onValueChange={(val) => { setDocTypeFilter(val); setPage(1) }}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Filter by document type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Document Types</SelectItem>
            <SelectItem value="invoice">Invoice</SelectItem>
            <SelectItem value="packing-slip">Packing Slip</SelectItem>
            <SelectItem value="delivery-label">Delivery Label</SelectItem>
            <SelectItem value="thermal-receipt">Thermal Receipt</SelectItem>
            <SelectItem value="courier-label">Courier Label</SelectItem>
          </SelectContent>
        </Select>

        <div className="ml-auto text-sm text-muted-foreground">
          Total: {stats.total} items
        </div>

        {autoRefresh && (
          <div className="flex items-center gap-1.5 text-xs text-emerald-600">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            Live
          </div>
        )}
      </div>

      {/* Queue Table */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <Printer className="size-5 text-emerald-600" />
            Print Queue
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {loading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="size-8 animate-spin text-emerald-600" />
            </div>
          ) : queueItems.length === 0 ? (
            /* Better empty state */
            <div className="text-center py-16 px-6">
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.5, ease: 'easeOut' }}
              >
                <div className="relative inline-block mb-6">
                  <div className="absolute inset-0 bg-emerald-100 rounded-full blur-xl opacity-50 scale-150" />
                  <motion.div
                    animate={{ y: [0, -8, 0] }}
                    transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
                  >
                    <Printer className="size-16 text-emerald-300 relative" />
                  </motion.div>
                </div>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.3 }}
              >
                <h3 className="text-lg font-semibold text-foreground mb-2">All caught up!</h3>
                <p className="text-muted-foreground text-sm max-w-sm mx-auto mb-4">
                  No documents in the print queue right now. New orders will automatically generate
                  invoices, packing slips, delivery labels, and thermal receipts.
                </p>
                <div className="flex items-center justify-center gap-2 text-xs text-emerald-600">
                  <span className="px-2 py-1 bg-emerald-50 rounded font-mono border border-emerald-200">New Order</span>
                  <span className="text-emerald-400">→</span>
                  <span className="px-2 py-1 bg-emerald-50 rounded font-mono border border-emerald-200">Generate PDFs</span>
                  <span className="text-emerald-400">→</span>
                  <span className="px-2 py-1 bg-emerald-50 rounded font-mono border border-emerald-200">Auto Queue</span>
                  <span className="text-emerald-400">→</span>
                  <span className="px-2 py-1 bg-emerald-50 rounded font-mono border border-emerald-200">Print</span>
                </div>
              </motion.div>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-36">Order</TableHead>
                  <TableHead className="w-36">Document</TableHead>
                  <TableHead className="w-28">Status</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead className="w-28">Amount</TableHead>
                  <TableHead className="w-36">Created</TableHead>
                  <TableHead className="w-28">Preview</TableHead>
                  <TableHead className="w-28">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <AnimatePresence mode="popLayout">
                  {queueItems.map((item, index) => {
                    const statusCfg = STATUS_CONFIG[item.status] || STATUS_CONFIG.PENDING
                    const StatusIcon = statusCfg.icon
                    const DocIcon = DOC_TYPE_ICONS[item.documentType] || FileText
                    const previewUrl = getPreviewUrl(item)

                    return (
                      <motion.tr
                        key={item.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 20 }}
                        transition={{ duration: 0.3, delay: index * 0.03 }}
                        className="hover:bg-muted/50"
                      >
                        <TableCell>
                          <button
                            onClick={() => navigate('admin-orders', { orderId: item.orderId })}
                            className="text-emerald-700 hover:underline font-medium text-sm"
                          >
                            {item.order.orderNumber}
                          </button>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <DocIcon className="size-4 text-muted-foreground" />
                            <span className="text-sm">{DOC_TYPE_LABELS[item.documentType] || item.documentType}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <AnimatePresence mode="wait">
                            <motion.div
                              key={item.status}
                              initial={{ scale: 0.8, opacity: 0 }}
                              animate={{ scale: 1, opacity: 1 }}
                              exit={{ scale: 0.8, opacity: 0 }}
                              transition={{ duration: 0.2 }}
                            >
                              <Badge
                                variant="outline"
                                className={`${statusCfg.bg} ${statusCfg.color} border-0 text-xs gap-1`}
                              >
                                <StatusIcon className={`size-3 ${item.status === 'PRINTING' ? 'animate-spin' : ''}`} />
                                {item.status}
                              </Badge>
                            </motion.div>
                          </AnimatePresence>
                        </TableCell>
                        <TableCell className="text-sm">
                          <div>{item.order.guestName || 'N/A'}</div>
                          <div className="text-xs text-muted-foreground">{item.order.guestPhone || ''}</div>
                        </TableCell>
                        <TableCell className="text-sm font-medium">
                          ৳{item.order.totalAmount.toLocaleString('en-BD', { minimumFractionDigits: 0 })}
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground">
                          {new Date(item.createdAt).toLocaleString('en-GB', {
                            day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit'
                          })}
                        </TableCell>
                        <TableCell>
                          {previewUrl ? (
                            <Button
                              variant="ghost"
                              size="icon"
                              className="size-7 hover:bg-sky-50"
                              onClick={() => window.open(previewUrl, '_blank')}
                              title="Preview document"
                            >
                              <ExternalLink className="size-3.5 text-sky-600" />
                            </Button>
                          ) : (
                            <span className="text-xs text-muted-foreground">—</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            {item.status === 'PENDING' && (
                              <Button
                                variant="ghost"
                                size="icon"
                                className="size-7 hover:bg-emerald-50"
                                onClick={() => updateItemStatus(item.id, 'PRINTING')}
                                title="Start printing"
                              >
                                <Printer className="size-3.5 text-emerald-600" />
                              </Button>
                            )}
                            {item.status === 'PRINTING' && (
                              <Button
                                variant="ghost"
                                size="icon"
                                className="size-7 hover:bg-emerald-50"
                                onClick={() => updateItemStatus(item.id, 'PRINTED')}
                                title="Mark as printed"
                              >
                                <CheckCircle className="size-3.5 text-emerald-600" />
                              </Button>
                            )}
                            {item.status === 'FAILED' && (
                              <Button
                                variant="ghost"
                                size="icon"
                                className="size-7 hover:bg-orange-50"
                                onClick={() => updateItemStatus(item.id, 'PENDING')}
                                title="Retry"
                              >
                                <RotateCcw className="size-3.5 text-orange-600" />
                              </Button>
                            )}
                            <Button
                              variant="ghost"
                              size="icon"
                              className="size-7 hover:bg-red-50"
                              onClick={() => deleteItem(item.id)}
                              title="Remove from queue"
                            >
                              <Trash2 className="size-3.5 text-red-600" />
                            </Button>
                          </div>
                        </TableCell>
                      </motion.tr>
                    )
                  })}
                </AnimatePresence>
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            Page {page} of {totalPages}
          </p>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              disabled={page <= 1}
              onClick={() => setPage(page - 1)}
            >
              <ChevronLeft className="size-4" />
              Previous
            </Button>
            <Button
              variant="outline"
              size="sm"
              disabled={page >= totalPages}
              onClick={() => setPage(page + 1)}
            >
              Next
              <ChevronRight className="size-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Auto Print Workflow Info */}
      <Card className="bg-gradient-to-r from-emerald-50 to-teal-50 border-emerald-200">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-emerald-800 flex items-center gap-2">
            <Printer className="size-4" />
            Auto Print Workflow
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-3 text-xs text-emerald-700 flex-wrap">
            <span className="px-2 py-1 bg-emerald-100 rounded font-mono">New Order</span>
            <span className="text-emerald-400">→</span>
            <span className="px-2 py-1 bg-emerald-100 rounded font-mono">Generate PDFs</span>
            <span className="text-emerald-400">→</span>
            <span className="px-2 py-1 bg-emerald-100 rounded font-mono">Add to Queue</span>
            <span className="text-emerald-400">→</span>
            <span className="px-2 py-1 bg-emerald-100 rounded font-mono">Print</span>
            <span className="text-emerald-400">→</span>
            <span className="px-2 py-1 bg-emerald-100 rounded font-mono">Mark Printed</span>
          </div>
          <p className="text-xs text-emerald-600 mt-2">
            Documents are automatically generated and queued when orders are placed.
            Use the actions above to manage the print workflow. Enable auto-refresh for real-time monitoring.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
