'use client'

import React, { useEffect, useState, useCallback } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Checkbox } from '@/components/ui/checkbox'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Skeleton } from '@/components/ui/skeleton'
import { Separator } from '@/components/ui/separator'
import { toast } from 'sonner'
import { extractItems } from '@/lib/api'
import { useAppStore } from '@/lib/store'
import {
  ShoppingCart, Eye, Truck, Printer, Package,
  QrCode,
  X, Loader2, ArrowUpDown, CheckCircle2, ListChecks,
} from 'lucide-react'
import OrderPrintMenu from '@/components/shared/OrderPrintMenu'
import BulkPrintDialog from '@/components/shared/BulkPrintDialog'
import QRCodeDialog from '@/components/shared/QRCodeDialog'
import OrderTimeline from '@/components/shared/OrderTimeline'
import OrderPrintPanel from '@/components/shared/OrderPrintPanel'
import {
  ORDER_STATUS,
  PRODUCTION_FLOW,
  TERMINAL_STATUSES,
  ALL_STATUSES,
  getStatusMeta,
  getStatusLabel,
  getStatusBadgeClass,
  getNextStatus,
  isTerminal,
  getFlowProgress,
} from '@/lib/order-status'

interface OrderItem {
  id: string
  productId: string
  productName: string
  quantity: number
  unit: string
  price: number
  total: number
  image?: string
}

interface Order {
  id: string
  orderNumber: string
  userId: string
  customerName?: string
  customerEmail?: string
  customerPhone?: string
  items: OrderItem[]
  subtotal: number
  deliveryCharge: number
  discount: number
  total: number
  status: string
  paymentMethod: string
  paymentStatus: string
  shippingAddress?: string
  note?: string
  createdAt: string
  updatedAt: string
}

// ─── Status config comes from the shared `@/lib/order-status` module ─────────
// (single source of truth — reused by AdminOrdersPage, OrderTimeline,
// OrderDetailPage, OrderTrackingPage). Local aliases keep call sites terse.

const statusColors = (s: string) => getStatusBadgeClass(s)
const statusFlow = ALL_STATUSES.map((s) => s as string)
const statusLabels = (s: string) => getStatusLabel(s)

export default function AdminOrdersPage() {
  const { navigate } = useAppStore()
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [statusFilter, setStatusFilter] = useState('all')
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)
  const [detailOpen, setDetailOpen] = useState(false)
  const [updating, setUpdating] = useState(false)

  // ─── Multi-select state ──────────────────────────────────────────────────
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set())
  const [bulkPrintOpen, setBulkPrintOpen] = useState(false)
  const [qrDialogOpen, setQrDialogOpen] = useState(false)
  const [qrOrderId, setQrOrderId] = useState<string>('')
  const [qrOrderNumber, setQrOrderNumber] = useState<string>('')

  // ─── Detail dialog print state ───────────────────────────────────────────
  // (Print loading state now lives inside the shared <OrderPrintPanel />.)

  const fetchOrders = useCallback(async () => {
    try {
      const params = new URLSearchParams()
      if (statusFilter !== 'all') params.set('status', statusFilter)
      params.set('limit', '50')
      const res = await fetch(`/api/orders?${params.toString()}`)
      if (res.ok) {
        const data = await res.json()
        setOrders(extractItems(data))
      }
    } catch {
      toast.error('Failed to fetch orders')
    } finally {
      setLoading(false)
    }
  }, [statusFilter])

  useEffect(() => { fetchOrders() }, [fetchOrders])

  // ─── Selection helpers ────────────────────────────────────────────────────

  const allSelected = orders.length > 0 && selectedIds.size === orders.length
  const someSelected = selectedIds.size > 0 && !allSelected

  function toggleSelectAll() {
    if (allSelected) {
      setSelectedIds(new Set())
    } else {
      setSelectedIds(new Set(orders.map((o) => o.id)))
    }
  }

  function toggleSelect(orderId: string) {
    setSelectedIds((prev) => {
      const next = new Set(prev)
      if (next.has(orderId)) {
        next.delete(orderId)
      } else {
        next.add(orderId)
      }
      return next
    })
  }

  function clearSelection() {
    setSelectedIds(new Set())
  }

  // ─── Open detail ─────────────────────────────────────────────────────────

  function openDetail(order: Order) {
    setSelectedOrder(order)
    setDetailOpen(true)
  }

  // ─── Update status ───────────────────────────────────────────────────────

  async function updateStatus(orderId: string, status: string) {
    setUpdating(true)
    try {
      const res = await fetch(`/api/orders/${orderId}/status-history`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, note: `Status updated to ${status}` }),
      })
      if (!res.ok) {
        const data = await res.json()
        throw new Error(data.error || 'Failed to update status')
      }
      toast.success(`Order status updated to ${statusLabels(status) || status}`)
      fetchOrders()
      if (selectedOrder?.id === orderId) {
        setSelectedOrder((prev) => prev ? { ...prev, status } : null)
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Failed to update order status')
    } finally {
      setUpdating(false)
    }
  }

  // ─── Bulk status update ──────────────────────────────────────────────────

  async function bulkUpdateStatus(newStatus: string) {
    if (selectedIds.size === 0) return
    setUpdating(true)
    let successCount = 0
    for (const orderId of selectedIds) {
      try {
        const res = await fetch(`/api/orders/${orderId}/status-history`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ status: newStatus, note: `Bulk status update to ${newStatus}` }),
        })
        if (res.ok) successCount++
      } catch {
        // continue
      }
    }
    toast.success(`${successCount} order${successCount !== 1 ? 's' : ''} updated to ${statusLabels(newStatus) || newStatus}`)
    clearSelection()
    fetchOrders()
    setUpdating(false)
  }

  // ─── Detail dialog print helpers ─────────────────────────────────────────
  // (Print logic now lives in the shared <OrderPrintPanel /> component,
  //  which reuses the existing print API endpoints. No duplicate logic here.)

  function openQRForOrder(orderId: string, orderNumber: string) {
    setQrOrderId(orderId)
    setQrOrderNumber(orderNumber)
    setQrDialogOpen(true)
  }

  // ─── Status counts ───────────────────────────────────────────────────────

  const countFor = (key: string) =>
    orders.filter((o) => o.status === key || o.status === key.toUpperCase()).length

  const counts = {
    all: orders.length,
    [ORDER_STATUS.PENDING]: countFor(ORDER_STATUS.PENDING),
    [ORDER_STATUS.CONFIRMED]: countFor(ORDER_STATUS.CONFIRMED),
    [ORDER_STATUS.PROCESSING]: countFor(ORDER_STATUS.PROCESSING),
    [ORDER_STATUS.PACKED]: countFor(ORDER_STATUS.PACKED),
    [ORDER_STATUS.READY_TO_SHIP]: countFor(ORDER_STATUS.READY_TO_SHIP),
    [ORDER_STATUS.SHIPPED]: countFor(ORDER_STATUS.SHIPPED),
    [ORDER_STATUS.DELIVERED]: countFor(ORDER_STATUS.DELIVERED),
    [ORDER_STATUS.CANCELLED]: countFor(ORDER_STATUS.CANCELLED),
    [ORDER_STATUS.RETURNED]: countFor(ORDER_STATUS.RETURNED),
  }

  return (
    <div className="space-y-4">
      {/* ─── Header with Print Queue Link ──────────────────────────────────── */}
      <div className="flex items-center justify-between">
        <div />
        <Button
          variant="outline"
          size="sm"
          className="gap-1.5 rounded-xl border-emerald-200 text-emerald-700 hover:bg-emerald-50"
          onClick={() => navigate('admin-print-queue')}
        >
          <ListChecks className="size-3.5" />
          Print Queue Monitor
        </Button>
      </div>

      {/* ─── Status Tabs ──────────────────────────────────────────────────── */}
      <Tabs value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setLoading(true) }}>
        <TabsList className="flex-wrap h-auto">
          <TabsTrigger value="all">All ({counts.all})</TabsTrigger>
          {PRODUCTION_FLOW.map((s) => (
            <TabsTrigger key={s} value={s}>
              {getStatusLabel(s)} ({counts[s]})
            </TabsTrigger>
          ))}
          {TERMINAL_STATUSES.map((s) => (
            <TabsTrigger key={s} value={s}>
              {getStatusLabel(s)} ({counts[s]})
            </TabsTrigger>
          ))}
        </TabsList>
      </Tabs>

      {/* ─── Bulk Actions Bar ─────────────────────────────────────────────── */}
      {selectedIds.size > 0 && (
        <div className="flex items-center gap-3 p-3 rounded-xl bg-emerald-50 border border-emerald-200 animate-in fade-in slide-in-from-top-2">
          <Badge variant="secondary" className="bg-emerald-100 text-emerald-800 border-emerald-200 font-semibold">
            {selectedIds.size} order{selectedIds.size !== 1 ? 's' : ''} selected
          </Badge>

          <Button
            size="sm"
            onClick={() => setBulkPrintOpen(true)}
            className="gap-1.5 bg-emerald-600 hover:bg-emerald-700 rounded-xl"
          >
            <Printer className="size-3.5" />
            Bulk Print
          </Button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="gap-1.5 rounded-xl border-amber-200 text-amber-700 hover:bg-amber-50">
                <ArrowUpDown className="size-3.5" />
                Update Status
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              {statusFlow.map((s) => (
                <DropdownMenuItem
                  key={s}
                  onClick={() => bulkUpdateStatus(s)}
                  disabled={updating}
                  className="cursor-pointer"
                >
                  <Badge variant="secondary" className={`text-[10px] mr-2 ${statusColors(s)}`}>
                    {s}
                  </Badge>
                  Set to {s}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          <div className="flex-1" />

          <Button
            variant="ghost"
            size="sm"
            onClick={clearSelection}
            className="gap-1.5 text-gray-500 hover:text-gray-700 rounded-xl"
          >
            <X className="size-3.5" />
            Clear
          </Button>
        </div>
      )}

      {/* ─── Orders Table ─────────────────────────────────────────────────── */}
      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-6 space-y-3">{[...Array(5)].map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}</div>
          ) : orders.length === 0 ? (
            <div className="text-center py-12">
              <ShoppingCart className="mx-auto size-10 text-muted-foreground mb-2" />
              <p className="text-muted-foreground">No orders found</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-10">
                    <Checkbox
                      checked={allSelected}
                      ref={(el) => {
                        if (el) {
                          (el as unknown as HTMLButtonElement).dataset.state = someSelected ? 'indeterminate' : allSelected ? 'checked' : 'unchecked'
                        }
                      }}
                      onCheckedChange={toggleSelectAll}
                      className="data-[state=checked]:bg-emerald-600 data-[state=checked]:border-emerald-600"
                    />
                  </TableHead>
                  <TableHead>Order #</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Items</TableHead>
                  <TableHead>Total</TableHead>
                  <TableHead>Payment</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead className="w-24 text-center">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {orders.map((order) => (
                  <TableRow
                    key={order.id}
                    className={selectedIds.has(order.id) ? 'bg-emerald-50/50' : ''}
                  >
                    <TableCell>
                      <Checkbox
                        checked={selectedIds.has(order.id)}
                        onCheckedChange={() => toggleSelect(order.id)}
                        className="data-[state=checked]:bg-emerald-600 data-[state=checked]:border-emerald-600"
                      />
                    </TableCell>
                    <TableCell className="font-medium text-sm">{order.orderNumber}</TableCell>
                    <TableCell>
                      <div>
                        <p className="text-sm">{order.customerName ?? 'N/A'}</p>
                        <p className="text-xs text-muted-foreground">{order.customerPhone ?? ''}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="text-xs">{order.items?.length ?? 0} items</Badge>
                    </TableCell>
                    <TableCell className="font-medium">৳{order.total.toLocaleString()}</TableCell>
                    <TableCell>
                      <div>
                        <Badge variant={order.paymentStatus === 'PAID' ? 'default' : 'secondary'} className="text-xs">
                          {order.paymentStatus}
                        </Badge>
                        <p className="text-xs text-muted-foreground mt-0.5">{order.paymentMethod}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1.5">
                        <Badge variant="secondary" className={statusColors(order.status)}>
                          {statusLabels(order.status) || order.status}
                        </Badge>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="size-6 hover:bg-emerald-50 hover:text-emerald-700"
                              disabled={updating}
                            >
                              <ArrowUpDown className="size-3" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            {statusFlow.map((s) => (
                              <DropdownMenuItem
                                key={s}
                                onClick={() => updateStatus(order.id, s)}
                                disabled={updating || order.status === s}
                                className="cursor-pointer"
                              >
                                <Badge variant="secondary" className={`text-[10px] mr-2 ${statusColors(s)}`}>
                                  {statusLabels(s) || s}
                                </Badge>
                                Set to {statusLabels(s) || s}
                              </DropdownMenuItem>
                            ))}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {new Date(order.createdAt).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center justify-center gap-0.5">
                        <Button variant="ghost" size="icon" className="size-7" onClick={() => openDetail(order)}>
                          <Eye className="size-3" />
                        </Button>
                        <OrderPrintMenu
                          orderId={order.id}
                          orderNumber={order.orderNumber}
                          onQRCode={() => openQRForOrder(order.id, order.orderNumber)}
                        />
                        <Button
                          variant="ghost"
                          size="icon"
                          className="size-7 hover:bg-amber-50 hover:text-amber-700"
                          onClick={() => openQRForOrder(order.id, order.orderNumber)}
                        >
                          <QrCode className="size-3" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* ─── Bulk Print Dialog ─────────────────────────────────────────────── */}
      <BulkPrintDialog
        selectedOrderIds={Array.from(selectedIds)}
        open={bulkPrintOpen}
        onOpenChange={setBulkPrintOpen}
        onComplete={() => {
          clearSelection()
          fetchOrders()
        }}
      />

      {/* ─── QR Code Dialog ────────────────────────────────────────────────── */}
      <QRCodeDialog
        orderId={qrOrderId}
        orderNumber={qrOrderNumber}
        open={qrDialogOpen}
        onOpenChange={setQrDialogOpen}
      />

      {/* ─── Order Detail Dialog ───────────────────────────────────────────── */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Package className="size-5" /> Order {selectedOrder?.orderNumber}
            </DialogTitle>
          </DialogHeader>
          {selectedOrder && (
            <div className="space-y-6">
              {/* ─── Status Summary + Flow ─────────────────────────────────── */}
              <div className="space-y-3">
                <div className="flex flex-wrap items-center gap-3">
                  <Badge variant="secondary" className={statusColors(selectedOrder.status)}>
                    {statusLabels(selectedOrder.status) || selectedOrder.status}
                  </Badge>
                  {isTerminal(selectedOrder.status) && (
                    <Badge variant="outline" className="text-xs text-muted-foreground border-gray-300">
                      Terminal state
                    </Badge>
                  )}
                  {updating && <Loader2 className="size-4 animate-spin text-emerald-600" />}
                </div>

                {/* Production flow progress bar */}
                {!isTerminal(selectedOrder.status) && (
                  <div className="rounded-xl border bg-gray-50/50 p-3">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-semibold text-gray-600">Production Flow</span>
                      <span className="text-xs text-muted-foreground">
                        {getFlowProgress(selectedOrder.status)}% complete
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      {PRODUCTION_FLOW.map((s, i) => {
                        const meta = getStatusMeta(s)
                        const Icon = meta.icon
                        const currentIdx = PRODUCTION_FLOW.indexOf(selectedOrder.status as never)
                        const isDone = i <= currentIdx
                        const isCurrent = s === selectedOrder.status
                        return (
                          <div key={s} className="flex items-center flex-1 last:flex-none">
                            <div
                              className={`flex flex-col items-center gap-1 ${isCurrent ? 'scale-110' : ''} transition-transform`}
                              title={meta.label}
                            >
                              <div
                                className={`h-7 w-7 rounded-full flex items-center justify-center text-[10px] font-bold ${
                                  isDone
                                    ? `${meta.dotClass} text-white`
                                    : 'bg-gray-200 text-gray-400'
                                } ${isCurrent ? 'ring-2 ring-offset-1 ring-emerald-400' : ''}`}
                              >
                                <Icon className="size-3.5" />
                              </div>
                              <span className={`text-[9px] ${isDone ? 'text-gray-700 font-medium' : 'text-gray-400'}`}>
                                {meta.shortLabel}
                              </span>
                            </div>
                            {i < PRODUCTION_FLOW.length - 1 && (
                              <div className={`flex-1 h-0.5 mx-1 ${i < currentIdx ? 'bg-emerald-400' : 'bg-gray-200'}`} />
                            )}
                          </div>
                        )
                      })}
                    </div>
                  </div>
                )}

                {/* Status actions: quick advance + full selector */}
                <div className="flex flex-wrap items-center gap-2">
                  {!isTerminal(selectedOrder.status) && getNextStatus(selectedOrder.status) && (
                    <Button
                      size="sm"
                      className="gap-1.5 bg-emerald-600 hover:bg-emerald-700 rounded-xl"
                      disabled={updating}
                      onClick={() => updateStatus(selectedOrder.id, getNextStatus(selectedOrder.status)!)}
                    >
                      <CheckCircle2 className="size-3.5" />
                      Advance to {getStatusLabel(getNextStatus(selectedOrder.status)!)}
                    </Button>
                  )}
                  <Select
                    value={selectedOrder.status}
                    onValueChange={(v) => updateStatus(selectedOrder.id, v)}
                    disabled={updating}
                  >
                    <SelectTrigger className="w-48 h-9">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <span className="text-[10px] text-muted-foreground uppercase tracking-wide px-2 py-1 block">
                        Production Flow
                      </span>
                      {PRODUCTION_FLOW.map((s) => (
                        <SelectItem key={s} value={s}>{getStatusLabel(s)}</SelectItem>
                      ))}
                      <span className="text-[10px] text-muted-foreground uppercase tracking-wide px-2 py-1 block">
                        Terminal
                      </span>
                      {TERMINAL_STATUSES.map((s) => (
                        <SelectItem key={s} value={s}>{getStatusLabel(s)}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* ─── Status Visibility: Payment / Delivery / Print ─────────── */}
              <div className="grid grid-cols-3 gap-3">
                <div className="rounded-xl border p-3 text-center">
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1">Payment</p>
                  <Badge
                    variant="secondary"
                    className={`text-[11px] ${
                      selectedOrder.paymentStatus === 'paid'
                        ? 'bg-emerald-100 text-emerald-800'
                        : selectedOrder.paymentStatus === 'pending'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-gray-100 text-gray-800'
                    }`}
                  >
                    {selectedOrder.paymentStatus || '—'}
                  </Badge>
                  <p className="text-[10px] text-muted-foreground mt-1">{selectedOrder.paymentMethod || '—'}</p>
                </div>
                <div className="rounded-xl border p-3 text-center">
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1">Delivery</p>
                  <Badge variant="secondary" className={`text-[11px] ${statusColors(selectedOrder.status)}`}>
                    {statusLabels(selectedOrder.status) || '—'}
                  </Badge>
                  <p className="text-[10px] text-muted-foreground mt-1">
                    {isTerminal(selectedOrder.status) ? 'Closed' : 'In progress'}
                  </p>
                </div>
                <div className="rounded-xl border p-3 text-center">
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1">Print</p>
                  <Badge variant="secondary" className="text-[11px] bg-emerald-100 text-emerald-800">
                    Ready
                  </Badge>
                  <p className="text-[10px] text-muted-foreground mt-1">5 document types</p>
                </div>
              </div>

              {/* ─── Print Panel (unified, reuses existing print APIs) ─────── */}
              <OrderPrintPanel orderId={selectedOrder.id} orderNumber={selectedOrder.orderNumber} />

              {/* Customer Info */}
              <div className="grid gap-4 sm:grid-cols-2">
                <Card>
                  <CardContent className="p-4">
                    <h4 className="text-sm font-semibold mb-2">Customer Info</h4>
                    <p className="text-sm">{selectedOrder.customerName ?? 'N/A'}</p>
                    <p className="text-sm text-muted-foreground">{selectedOrder.customerEmail ?? ''}</p>
                    <p className="text-sm text-muted-foreground">{selectedOrder.customerPhone ?? ''}</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <h4 className="text-sm font-semibold mb-2">Shipping Address</h4>
                    <p className="text-sm">{selectedOrder.shippingAddress ?? 'N/A'}</p>
                  </CardContent>
                </Card>
              </div>

              {/* Items */}
              <div>
                <h4 className="text-sm font-semibold mb-2">Order Items</h4>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Product</TableHead>
                      <TableHead>Price</TableHead>
                      <TableHead>Qty</TableHead>
                      <TableHead>Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {(selectedOrder.items ?? []).map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="text-sm">{item.productName}</TableCell>
                        <TableCell className="text-sm">৳{item.price}</TableCell>
                        <TableCell className="text-sm">{item.quantity} {item.unit}</TableCell>
                        <TableCell className="text-sm font-medium">৳{item.total}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {/* Totals */}
              <div className="border-t pt-4 space-y-1 text-sm">
                <div className="flex justify-between"><span>Subtotal</span><span>৳{selectedOrder.subtotal.toLocaleString()}</span></div>
                <div className="flex justify-between"><span>Delivery Charge</span><span>৳{selectedOrder.deliveryCharge.toLocaleString()}</span></div>
                {selectedOrder.discount > 0 && (
                  <div className="flex justify-between text-green-600"><span>Discount</span><span>-৳{selectedOrder.discount.toLocaleString()}</span></div>
                )}
                <div className="flex justify-between font-bold text-base pt-2 border-t"><span>Total</span><span>৳{selectedOrder.total.toLocaleString()}</span></div>
              </div>

              {selectedOrder.note && (
                <div>
                  <h4 className="text-sm font-semibold mb-1">Order Note</h4>
                  <p className="text-sm text-muted-foreground">{selectedOrder.note}</p>
                </div>
              )}

              {/* Status Timeline */}
              <OrderTimeline orderId={selectedOrder.id} />

              <div className="text-xs text-muted-foreground">
                <p>Order Date: {new Date(selectedOrder.createdAt).toLocaleString()}</p>
                <p>Last Updated: {new Date(selectedOrder.updatedAt).toLocaleString()}</p>
                <p>Payment: {selectedOrder.paymentMethod} - {selectedOrder.paymentStatus}</p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
