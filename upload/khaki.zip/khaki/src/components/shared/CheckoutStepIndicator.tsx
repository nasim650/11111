'use client'

import { motion } from 'framer-motion'
import { CheckCircle2, ShoppingBag, MapPin, CreditCard } from 'lucide-react'

// ─── Checkout Step Indicator ────────────────────────────────────────────────
// Shared progress indicator for the multi-step checkout flow.
// Reused across all 4 checkout steps. Purely presentational — no logic.

export interface CheckoutStep {
  id: number
  label: string
  description: string
  icon: typeof ShoppingBag
}

export const CHECKOUT_STEPS: CheckoutStep[] = [
  { id: 1, label: 'Cart', description: 'Review items', icon: ShoppingBag },
  { id: 2, label: 'Shipping', description: 'Delivery info', icon: MapPin },
  { id: 3, label: 'Payment', description: 'Choose payment', icon: CreditCard },
  { id: 4, label: 'Confirmation', description: 'Place order', icon: CheckCircle2 },
]

interface CheckoutStepIndicatorProps {
  currentStep: number
  onStepClick?: (step: number) => void
  maxReachedStep?: number
}

export default function CheckoutStepIndicator({
  currentStep,
  onStepClick,
  maxReachedStep = 1,
}: CheckoutStepIndicatorProps) {
  return (
    <div className="bg-white border-b shadow-sm">
      <div className="container mx-auto px-4 py-5 sm:py-6">
        <div className="flex items-center justify-between max-w-2xl mx-auto">
          {CHECKOUT_STEPS.map((step, idx) => {
            const StepIcon = step.icon
            const isCompleted = currentStep > step.id
            const isCurrent = currentStep === step.id
            const isClickable = onStepClick && step.id <= maxReachedStep

            return (
              <div key={step.id} className="flex items-center flex-1 last:flex-none">
                <button
                  type="button"
                  onClick={() => isClickable && onStepClick?.(step.id)}
                  disabled={!isClickable}
                  className={`flex flex-col items-center group ${isClickable ? 'cursor-pointer' : 'cursor-default'}`}
                >
                  <motion.div
                    animate={isCurrent ? { scale: [1, 1.08, 1] } : {}}
                    transition={{ duration: 2, repeat: Infinity, repeatType: 'loop' }}
                    className={`h-11 w-11 sm:h-12 sm:w-12 rounded-full flex items-center justify-center text-sm font-bold transition-all duration-500 relative ${
                      isCompleted
                        ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-200'
                        : isCurrent
                        ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-200 ring-4 ring-emerald-600/20'
                        : 'bg-gray-100 text-gray-400 border-2 border-gray-200'
                    }`}
                  >
                    {isCompleted ? (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ type: 'spring', stiffness: 300, damping: 20 }}
                      >
                        <CheckCircle2 className="h-5 w-5" />
                      </motion.div>
                    ) : isCurrent ? (
                      <StepIcon className="h-5 w-5" />
                    ) : (
                      <StepIcon className="h-4 w-4" />
                    )}
                  </motion.div>
                  <span className={`text-[11px] sm:text-xs mt-2 font-semibold transition-colors ${
                    isCompleted || isCurrent ? 'text-emerald-700' : 'text-gray-400'
                  }`}>
                    {step.label}
                  </span>
                  <span className={`text-[9px] sm:text-[10px] hidden sm:block mt-0.5 ${
                    isCompleted || isCurrent ? 'text-emerald-500' : 'text-gray-300'
                  }`}>
                    {step.description}
                  </span>
                </button>
                {idx < CHECKOUT_STEPS.length - 1 && (
                  <div className="relative mx-2 sm:mx-4 flex-1 h-0.5 mt-[-20px] sm:mt-[-22px]">
                    <div className="absolute inset-0 bg-gray-200 rounded-full" />
                    <motion.div
                      initial={{ width: '0%' }}
                      animate={{ width: isCompleted ? '100%' : isCurrent ? '50%' : '0%' }}
                      transition={{ duration: 0.5, ease: 'easeInOut' }}
                      className="absolute top-0 left-0 h-full bg-emerald-500 rounded-full"
                    />
                  </div>
                )}
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
