'use client'

import { useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Printer,
  FileText,
  Package,
  Tag,
  Receipt,
  Truck,
  Loader2,
  ChevronDown,
} from 'lucide-react'
import { toast } from 'sonner'

// ─── Order Print Panel ──────────────────────────────────────────────────────
// A clean, unified panel showing all print document types for an order in one
// place. Reuses the EXISTING print API endpoints — no new printing logic.
//
// Documents shown together:
//   • Invoice (PDF)
//   • Packing Slip (PDF)
//   • Delivery Label (PDF / HTML)
//   • Thermal Receipt (58mm / 80mm)
//   • Courier Label (Pathao / Steadfast / RedX / Paperfly)

interface OrderPrintPanelProps {
  orderId: string
  orderNumber: string
}

type LoadingKey =
  | 'invoice'
  | 'packing-slip'
  | 'delivery-label'
  | 'receipt-58'
  | 'receipt-80'
  | 'courier-pathao'
  | 'courier-steadfast'
  | 'courier-redx'
  | 'courier-paperfly'
  | null

const COURIERS = [
  { key: 'pathao', name: 'Pathao' },
  { key: 'steadfast', name: 'Steadfast' },
  { key: 'redx', name: 'RedX' },
  { key: 'paperfly', name: 'Paperfly' },
] as const

export default function OrderPrintPanel({ orderId, orderNumber }: OrderPrintPanelProps) {
  const [loading, setLoading] = useState<LoadingKey>(null)

  async function downloadPdf(url: string, filename: string, key: LoadingKey) {
    setLoading(key)
    try {
      const res = await fetch(url)
      if (!res.ok) throw new Error('Download failed')
      const blob = await res.blob()
      const link = window.document.createElement('a')
      link.href = URL.createObjectURL(blob)
      link.download = filename
      window.document.body.appendChild(link)
      link.click()
      window.document.body.removeChild(link)
      URL.revokeObjectURL(link.href)
      toast.success(`${filename} downloaded`)
    } catch {
      toast.error(`Failed to download ${filename}`)
    } finally {
      setLoading(null)
    }
  }

  async function openPrintWindow(url: string, key: LoadingKey) {
    setLoading(key)
    try {
      const res = await fetch(url)
      if (!res.ok) throw new Error('Failed to load')
      const html = await res.text()
      const w = window.open('', '_blank')
      if (w) {
        w.document.write(html)
        w.document.close()
        setTimeout(() => w.print(), 500)
      }
    } catch {
      toast.error('Failed to open print view')
    } finally {
      setLoading(null)
    }
  }

  const isLoading = (key: LoadingKey) => loading === key
  const anyLoading = loading !== null

  return (
    <Card className="border-dashed border-emerald-200 bg-emerald-50/30">
      <CardContent className="p-4">
        <h4 className="text-sm font-bold text-emerald-800 mb-3 flex items-center gap-2">
          <Printer className="size-4" />
          Print &amp; Download Documents
        </h4>

        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {/* Invoice */}
          <Button
            variant="outline"
            size="sm"
            className="gap-1.5 rounded-xl border-emerald-200 text-emerald-700 hover:bg-emerald-50 justify-start"
            disabled={anyLoading}
            onClick={() =>
              downloadPdf(
                `/api/orders/${orderId}/invoice?format=pdf`,
                `invoice-${orderNumber}.pdf`,
                'invoice'
              )
            }
          >
            {isLoading('invoice') ? (
              <Loader2 className="size-3.5 animate-spin" />
            ) : (
              <FileText className="size-3.5" />
            )}
            <span className="flex-1 text-left">Invoice (PDF)</span>
          </Button>

          {/* Packing Slip */}
          <Button
            variant="outline"
            size="sm"
            className="gap-1.5 rounded-xl border-emerald-200 text-emerald-700 hover:bg-emerald-50 justify-start"
            disabled={anyLoading}
            onClick={() =>
              downloadPdf(
                `/api/orders/${orderId}/packing-slip?format=pdf`,
                `packing-slip-${orderNumber}.pdf`,
                'packing-slip'
              )
            }
          >
            {isLoading('packing-slip') ? (
              <Loader2 className="size-3.5 animate-spin" />
            ) : (
              <Package className="size-3.5" />
            )}
            <span className="flex-1 text-left">Packing Slip</span>
          </Button>

          {/* Delivery Label */}
          <Button
            variant="outline"
            size="sm"
            className="gap-1.5 rounded-xl border-amber-200 text-amber-700 hover:bg-amber-50 justify-start"
            disabled={anyLoading}
            onClick={() =>
              downloadPdf(
                `/api/orders/${orderId}/delivery-label?format=pdf`,
                `delivery-label-${orderNumber}.pdf`,
                'delivery-label'
              )
            }
          >
            {isLoading('delivery-label') ? (
              <Loader2 className="size-3.5 animate-spin" />
            ) : (
              <Tag className="size-3.5" />
            )}
            <span className="flex-1 text-left">Delivery Label</span>
          </Button>

          {/* Thermal Receipt (dropdown) */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                className="gap-1.5 rounded-xl justify-start"
                disabled={anyLoading}
              >
                {loading?.startsWith('receipt') ? (
                  <Loader2 className="size-3.5 animate-spin" />
                ) : (
                  <Receipt className="size-3.5" />
                )}
                <span className="flex-1 text-left">Thermal Receipt</span>
                <ChevronDown className="size-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuItem
                onClick={() =>
                  openPrintWindow(
                    `/api/orders/${orderId}/thermal-receipt?width=58`,
                    'receipt-58'
                  )
                }
                disabled={anyLoading}
                className="cursor-pointer gap-3 py-2"
              >
                <Receipt className="size-4 text-emerald-600" />
                <span>58mm Receipt</span>
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() =>
                  openPrintWindow(
                    `/api/orders/${orderId}/thermal-receipt?width=80`,
                    'receipt-80'
                  )
                }
                disabled={anyLoading}
                className="cursor-pointer gap-3 py-2"
              >
                <Receipt className="size-4 text-emerald-600" />
                <span>80mm Receipt</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Courier Label (dropdown) */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                className="gap-1.5 rounded-xl border-orange-200 text-orange-700 hover:bg-orange-50 justify-start"
                disabled={anyLoading}
              >
                {loading?.startsWith('courier') ? (
                  <Loader2 className="size-3.5 animate-spin" />
                ) : (
                  <Truck className="size-3.5" />
                )}
                <span className="flex-1 text-left">Courier Label</span>
                <ChevronDown className="size-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              {COURIERS.map((c) => {
                const key = `courier-${c.key}` as LoadingKey
                return (
                  <DropdownMenuItem
                    key={c.key}
                    onClick={() =>
                      openPrintWindow(
                        `/api/orders/${orderId}/courier-label?courier=${c.key}`,
                        key
                      )
                    }
                    disabled={anyLoading}
                    className="cursor-pointer gap-3 py-2"
                  >
                    {isLoading(key) ? (
                      <Loader2 className="size-4 animate-spin text-orange-600" />
                    ) : (
                      <Truck className="size-4 text-orange-600" />
                    )}
                    <span>{c.name}</span>
                  </DropdownMenuItem>
                )
              })}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        <p className="text-[11px] text-muted-foreground mt-3">
          All documents are generated from the existing print system. Reused endpoints — no new logic.
        </p>
      </CardContent>
    </Card>
  )
}
