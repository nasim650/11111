'use client'

import { useState, useMemo, useCallback, useRef } from 'react'
import { Clock, X, ChevronRight, ArrowRight } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { useAppStore } from '@/lib/store'
import ProductCard from '@/components/shared/ProductCard'

// ── Types ──
interface Product {
  id: string
  name: string
  slug: string
  price: number
  discountPrice?: number | null
  unit: string
  stock: number
  shortDescription?: string
  images?: Array<{ url: string; alt?: string }>
  category?: { name: string; slug: string }
  isFeatured?: boolean
  isBestSeller?: boolean
  isNewArrival?: boolean
  averageRating?: number
  reviewCount?: number
}

interface RecentlyViewedProps {
  /** Exclude a specific product ID (e.g. current product on detail page) */
  excludeProductId?: string
  /** Max number of items to show */
  maxItems?: number
}

export default function RecentlyViewed({ excludeProductId, maxItems = 10 }: RecentlyViewedProps) {
  const { recentlyViewed, clearRecentlyViewed, navigate } = useAppStore()
  const [products, setProducts] = useState<Product[]>([])
  const loadingRef = useRef(false)
  const [, forceUpdate] = useState(0)
  const prevIdsKeyRef = useRef<string>('')

  // Compute the IDs to fetch (derived from store state)
  const idsToFetch = useMemo(() =>
    recentlyViewed
      .filter((id) => id !== excludeProductId)
      .slice(0, maxItems),
    [recentlyViewed, excludeProductId, maxItems]
  )

  // Create a stable key from the IDs for comparison
  const idsKey = idsToFetch.join(',')

  const fetchProducts = useCallback(async (ids: string[]) => {
    if (ids.length === 0) {
      setProducts([])
      return
    }

    loadingRef.current = true
    forceUpdate((n) => n + 1)

    try {
      const results = await Promise.all(
        ids.map((id) =>
          fetch(`/api/products/${id}`)
            .then((r) => r.json())
            .then((d) => d?.data || d)
            .catch(() => null)
        )
      )
      const valid = results.filter(Boolean) as Product[]
      // Preserve the order from recentlyViewed (most recent first)
      const ordered = ids
        .map((id) => valid.find((p) => p.id === id))
        .filter(Boolean) as Product[]
      setProducts(ordered)
    } catch {
      setProducts([])
    } finally {
      loadingRef.current = false
      forceUpdate((n) => n + 1)
    }
  }, [])

  // Trigger fetch when IDs change
  if (idsKey !== prevIdsKeyRef.current) {
    prevIdsKeyRef.current = idsKey
    // Schedule the fetch - avoids synchronous setState in effect
    queueMicrotask(() => fetchProducts(idsToFetch))
  }

  const loading = loadingRef.current

  // Don't render if no recently viewed or no products to show
  if (recentlyViewed.length === 0) return null
  if (!loading && products.length === 0) return null

  return (
    <section className="py-10 md:py-14">
      <div className="container mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="flex items-center justify-between mb-6"
        >
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-emerald-100 to-teal-50 flex items-center justify-center ring-1 ring-emerald-200/50">
              <Clock className="h-5 w-5 text-emerald-600" />
            </div>
            <div>
              <h2 className="text-xl md:text-2xl font-bold">Recently Viewed</h2>
              <p className="text-xs text-muted-foreground mt-0.5">
                {products.length} product{products.length !== 1 ? 's' : ''} you&apos;ve checked out
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              className="text-muted-foreground hover:text-red-500 gap-1.5 text-xs"
              onClick={clearRecentlyViewed}
            >
              <X className="h-3.5 w-3.5" />
              Clear All
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="gap-1.5 text-xs hidden sm:inline-flex"
              onClick={() => navigate('products')}
            >
              Browse More
              <ChevronRight className="h-3.5 w-3.5" />
            </Button>
          </div>
        </motion.div>

        {/* Loading Skeleton */}
        {loading && (
          <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
            {Array.from({ length: 4 }).map((_, i) => (
              <div
                key={`skeleton-${i}`}
                className="min-w-[180px] md:min-w-[220px] animate-pulse"
              >
                <div className="aspect-square rounded-xl bg-muted/50 mb-3" />
                <div className="h-4 w-3/4 rounded bg-muted/50 mb-2" />
                <div className="h-4 w-1/2 rounded bg-muted/50" />
              </div>
            ))}
          </div>
        )}

        {/* Product Cards - Horizontal Scroll */}
        {!loading && products.length > 0 && (
          <div className="relative group/scroll">
            <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide scroll-smooth snap-x snap-mandatory">
              <AnimatePresence mode="popLayout">
                {products.map((product, idx) => (
                  <motion.div
                    key={product.id}
                    className="min-w-[180px] md:min-w-[220px] snap-start"
                    initial={{ opacity: 0, x: 30, scale: 0.95 }}
                    animate={{ opacity: 1, x: 0, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9, x: -20 }}
                    transition={{
                      delay: idx * 0.06,
                      duration: 0.4,
                      ease: 'easeOut',
                    }}
                    layout
                  >
                    <ProductCard product={product} />
                  </motion.div>
                ))}
              </AnimatePresence>

              {/* Browse More Card at the end */}
              <motion.div
                className="min-w-[140px] md:min-w-[160px] snap-start flex items-center justify-center"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: products.length * 0.06 }}
              >
                <button
                  onClick={() => navigate('products')}
                  className="h-full min-h-[280px] w-full rounded-xl border-2 border-dashed border-emerald-200 hover:border-emerald-400 bg-emerald-50/30 hover:bg-emerald-50/60 flex flex-col items-center justify-center gap-3 transition-all duration-300 group/browse p-4"
                >
                  <div className="h-12 w-12 rounded-full bg-emerald-100 flex items-center justify-center group-hover/browse:scale-110 transition-transform">
                    <ArrowRight className="h-5 w-5 text-emerald-600" />
                  </div>
                  <span className="text-sm font-medium text-emerald-700 text-center">
                    Browse All Products
                  </span>
                </button>
              </motion.div>
            </div>
          </div>
        )}
      </div>
    </section>
  )
}
