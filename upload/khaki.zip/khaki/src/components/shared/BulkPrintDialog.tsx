'use client'

import { useState } from 'react'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Label } from '@/components/ui/label'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { Printer, Loader2, FileText, Package, Tag, CheckCircle2 } from 'lucide-react'
import { toast } from 'sonner'

type DocumentType = 'invoice' | 'packing-slip' | 'delivery-label'

interface BulkPrintDialogProps {
  selectedOrderIds: string[]
  open: boolean
  onOpenChange: (open: boolean) => void
  onComplete: () => void
}

const docTypeConfig: Record<DocumentType, { label: string; icon: React.ElementType; emoji: string }> = {
  invoice: { label: 'Invoice', icon: FileText, emoji: '📄' },
  'packing-slip': { label: 'Packing Slip', icon: Package, emoji: '📦' },
  'delivery-label': { label: 'Delivery Label', icon: Tag, emoji: '🏷️' },
}

export default function BulkPrintDialog({
  selectedOrderIds,
  open,
  onOpenChange,
  onComplete,
}: BulkPrintDialogProps) {
  const [docType, setDocType] = useState<DocumentType>('invoice')
  const [printing, setPrinting] = useState(false)
  const [progress, setProgress] = useState(0)
  const [completed, setCompleted] = useState(false)

  async function handlePrint() {
    if (selectedOrderIds.length === 0) return

    setPrinting(true)
    setProgress(0)
    setCompleted(false)

    try {
      // Simulate progress for better UX
      const progressInterval = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 90) {
            clearInterval(progressInterval)
            return 90
          }
          return prev + Math.random() * 15
        })
      }, 300)

      const res = await fetch('/api/orders/bulk-print', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderIds: selectedOrderIds,
          documentType: docType,
        }),
      })

      clearInterval(progressInterval)

      if (!res.ok) throw new Error('Bulk print failed')

      setProgress(100)

      // Try to download the PDF
      const blob = await res.blob()
      if (blob.size > 0 && blob.type === 'application/pdf') {
        const link = window.document.createElement('a')
        link.href = URL.createObjectURL(blob)
        link.download = `bulk-${docType}-${Date.now()}.pdf`
        window.document.body.appendChild(link)
        link.click()
        window.document.body.removeChild(link)
        URL.revokeObjectURL(link.href)
      }

      setCompleted(true)
      toast.success(`Successfully printed ${selectedOrderIds.length} ${docTypeConfig[docType].label.toLowerCase()}s`)
      setTimeout(() => {
        onComplete()
        onOpenChange(false)
        setCompleted(false)
        setProgress(0)
      }, 1500)
    } catch {
      toast.error('Failed to bulk print orders')
      setProgress(0)
    } finally {
      setPrinting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Printer className="size-5 text-emerald-600" />
            Bulk Print
          </DialogTitle>
          <DialogDescription>
            Print documents for {selectedOrderIds.length} selected order{selectedOrderIds.length !== 1 ? 's' : ''}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-5 py-2">
          {/* Selected count badge */}
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="bg-emerald-50 text-emerald-700 border-emerald-200">
              {selectedOrderIds.length} order{selectedOrderIds.length !== 1 ? 's' : ''} selected
            </Badge>
          </div>

          {/* Document type selection */}
          <RadioGroup
            value={docType}
            onValueChange={(v) => setDocType(v as DocumentType)}
            className="space-y-2"
          >
            {(Object.keys(docTypeConfig) as DocumentType[]).map((type) => {
              const config = docTypeConfig[type]
              const Icon = config.icon
              return (
                <Label
                  key={type}
                  htmlFor={`bulk-print-${type}`}
                  className={`flex items-center gap-3 rounded-xl border p-3.5 cursor-pointer transition-all ${
                    docType === type
                      ? 'border-emerald-300 bg-emerald-50/60 shadow-sm'
                      : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  <RadioGroupItem value={type} id={`bulk-print-${type}`} className="sr-only" />
                  <div
                    className={`flex h-8 w-8 items-center justify-center rounded-lg ${
                      docType === type
                        ? 'bg-emerald-100 text-emerald-700'
                        : 'bg-gray-100 text-gray-500'
                    }`}
                  >
                    <Icon className="size-4" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-sm">{config.label}</p>
                    <p className="text-xs text-muted-foreground">
                      {type === 'invoice' && 'Full invoice with pricing details'}
                      {type === 'packing-slip' && 'Items list for warehouse packing'}
                      {type === 'delivery-label' && 'Shipping label with address'}
                    </p>
                  </div>
                  <span className="text-sm">{config.emoji}</span>
                </Label>
              )
            })}
          </RadioGroup>

          {/* Progress indicator */}
          {printing && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span>Generating {docTypeConfig[docType].label.toLowerCase()}s…</span>
                <span>{Math.round(progress)}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          )}

          {/* Completed state */}
          {completed && (
            <div className="flex items-center justify-center gap-2 py-2 text-emerald-600">
              <CheckCircle2 className="size-5" />
              <span className="font-medium text-sm">All documents generated successfully!</span>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={printing}
            className="rounded-xl"
          >
            Cancel
          </Button>
          <Button
            onClick={handlePrint}
            disabled={printing || selectedOrderIds.length === 0}
            className="bg-emerald-600 hover:bg-emerald-700 rounded-xl gap-2 min-w-[120px]"
          >
            {printing ? (
              <>
                <Loader2 className="size-4 animate-spin" />
                Printing…
              </>
            ) : (
              <>
                <Printer className="size-4" />
                Print
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
