'use client'

import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Star, Award, TrendingUp, Gift, Clock, Sparkles,
  ArrowUpRight, Zap, Crown, Shield, ChevronRight,
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'

// ─── Tier definitions ────────────────────────────────────────────────────────

const TIERS = [
  { name: 'Bronze', min: 0, max: 499, color: 'from-amber-600 to-amber-700', bg: 'bg-amber-50', text: 'text-amber-700', border: 'border-amber-200', icon: Shield },
  { name: 'Silver', min: 500, max: 1499, color: 'from-gray-400 to-gray-500', bg: 'bg-gray-50', text: 'text-gray-600', border: 'border-gray-200', icon: Award },
  { name: 'Gold', min: 1500, max: 2999, color: 'from-yellow-500 to-amber-500', bg: 'bg-yellow-50', text: 'text-yellow-700', border: 'border-yellow-200', icon: Crown },
  { name: 'Platinum', min: 3000, max: Infinity, color: 'from-emerald-500 to-teal-500', bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-200', icon: Sparkles },
] as const

function getTier(balance: number) {
  return TIERS.find(t => balance >= t.min && balance <= t.max) || TIERS[0]
}

function getNextTier(balance: number) {
  const currentIdx = TIERS.findIndex(t => balance >= t.min && balance <= t.max)
  if (currentIdx < TIERS.length - 1) return TIERS[currentIdx + 1]
  return null
}

function getTierProgress(balance: number) {
  const tier = getTier(balance)
  if (tier.max === Infinity) return 100
  const range = tier.max - tier.min
  const progress = balance - tier.min
  return Math.min(Math.round((progress / range) * 100), 100)
}

// ─── Transaction type helpers ────────────────────────────────────────────────

interface LoyaltyTransaction {
  id: string
  points: number
  balance: number
  type: string
  description: string
  orderId?: string | null
  createdAt: string
}

function getTypeIcon(type: string) {
  switch (type) {
    case 'earn': return <TrendingUp className="h-3.5 w-3.5" />
    case 'redeem': return <Gift className="h-3.5 w-3.5" />
    case 'bonus': return <Sparkles className="h-3.5 w-3.5" />
    case 'expire': return <Clock className="h-3.5 w-3.5" />
    default: return <Star className="h-3.5 w-3.5" />
  }
}

function getTypeColor(type: string) {
  switch (type) {
    case 'earn': return 'text-emerald-600 bg-emerald-50 border-emerald-200'
    case 'redeem': return 'text-orange-600 bg-orange-50 border-orange-200'
    case 'bonus': return 'text-amber-600 bg-amber-50 border-amber-200'
    case 'expire': return 'text-gray-500 bg-gray-50 border-gray-200'
    default: return 'text-gray-600 bg-gray-50 border-gray-200'
  }
}

function timeAgo(dateStr: string) {
  const diff = Date.now() - new Date(dateStr).getTime()
  const mins = Math.floor(diff / 60000)
  if (mins < 1) return 'Just now'
  if (mins < 60) return `${mins}m ago`
  const hours = Math.floor(mins / 60)
  if (hours < 24) return `${hours}h ago`
  const days = Math.floor(hours / 24)
  if (days < 30) return `${days}d ago`
  return new Date(dateStr).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
}

// ─── Component ───────────────────────────────────────────────────────────────

interface LoyaltyPointsProps {
  userId: string
}

export default function LoyaltyPoints({ userId }: LoyaltyPointsProps) {
  const [balance, setBalance] = useState(0)
  const [totalEarned, setTotalEarned] = useState(0)
  const [totalRedeemed, setTotalRedeemed] = useState(0)
  const [transactions, setTransactions] = useState<LoyaltyTransaction[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!userId) return
    fetch('/api/loyalty')
      .then(r => r.json())
      .then(data => {
        if (data.success) {
          setBalance(data.data.balance)
          setTotalEarned(data.data.totalEarned)
          setTotalRedeemed(data.data.totalRedeemed)
          setTransactions(data.data.transactions || [])
        }
        setLoading(false)
      })
      .catch(() => {
        setLoading(false)
      })
  }, [userId])

  const tier = getTier(balance)
  const nextTier = getNextTier(balance)
  const progress = getTierProgress(balance)
  const TierIcon = tier.icon

  if (loading) {
    return (
      <Card className="rounded-2xl shadow-sm border-0 ring-1 ring-gray-100 overflow-hidden">
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-8 w-32 bg-gray-200 rounded-lg" />
            <div className="h-16 w-16 bg-gray-200 rounded-full mx-auto" />
            <div className="h-4 w-full bg-gray-200 rounded" />
            <div className="h-4 w-3/4 bg-gray-200 rounded" />
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: 'easeOut' }}
    >
      <Card className="rounded-2xl shadow-sm border-0 ring-1 ring-gray-100 overflow-hidden">
        {/* Header with gradient */}
        <div className={`bg-gradient-to-r ${tier.color} px-6 py-5 relative overflow-hidden`}>
          <div className="absolute top-0 right-0 w-32 h-32 rounded-full bg-white/5 -translate-y-1/2 translate-x-1/2" />
          <div className="absolute bottom-0 left-8 w-20 h-20 rounded-full bg-white/5 translate-y-1/2" />
          <div className="relative z-10">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl bg-white/20 flex items-center justify-center backdrop-blur-sm">
                  <Star className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h3 className="text-white font-bold text-lg">Loyalty Points</h3>
                  <p className="text-white/70 text-xs">Earn points with every order</p>
                </div>
              </div>
              <Badge className="bg-white/20 text-white border-0 backdrop-blur-sm text-xs font-bold px-3 py-1">
                <TierIcon className="h-3.5 w-3.5 mr-1" />
                {tier.name}
              </Badge>
            </div>
          </div>
        </div>

        <CardContent className="p-6 space-y-5">
          {/* Balance display */}
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.1, type: 'spring', stiffness: 200 }}
            className="text-center"
          >
            <div className={`h-20 w-20 rounded-full bg-gradient-to-br ${tier.color} flex items-center justify-center mx-auto shadow-lg`}>
              <span className="text-white font-extrabold text-2xl">{balance}</span>
            </div>
            <p className="text-sm text-gray-500 mt-3 font-medium">Available Points</p>
            <p className="text-lg font-bold text-gray-900">
              Worth <span className="text-emerald-600">৳{balance.toLocaleString()}</span>
            </p>
          </motion.div>

          {/* Tier progress */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5">
                <TierIcon className={`h-3.5 w-3.5 ${tier.text}`} />
                <span className={`font-bold ${tier.text}`}>{tier.name}</span>
              </div>
              {nextTier ? (
                <div className="flex items-center gap-1">
                  <span className="text-gray-500 font-medium">{nextTier.name} at {nextTier.min} pts</span>
                  <ArrowUpRight className="h-3 w-3 text-gray-400" />
                </div>
              ) : (
                <span className="text-emerald-600 font-bold flex items-center gap-1">
                  <Crown className="h-3.5 w-3.5" /> Max Tier!
                </span>
              )}
            </div>
            <div className="relative">
              <Progress
                value={progress}
                className={`h-3 ${tier.bg} [&>div]:bg-gradient-to-r [&>div]:${tier.color}`}
              />
              <span className="absolute right-0 -top-4 text-[10px] font-bold text-gray-500">
                {progress}%
              </span>
            </div>
            {nextTier && (
              <p className="text-[11px] text-gray-400 text-center">
                <Zap className="h-3 w-3 inline mr-0.5" />
                {nextTier.min - balance} more points to {nextTier.name}
              </p>
            )}
          </div>

          <Separator />

          {/* Stats row */}
          <div className="grid grid-cols-2 gap-3">
            <motion.div
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-gradient-to-br from-emerald-50 to-teal-50 rounded-xl p-3 text-center border border-emerald-100"
            >
              <p className="text-lg font-bold text-emerald-700">{totalEarned}</p>
              <p className="text-[11px] text-emerald-600 font-medium">Total Earned</p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-gradient-to-br from-orange-50 to-amber-50 rounded-xl p-3 text-center border border-orange-100"
            >
              <p className="text-lg font-bold text-orange-700">{totalRedeemed}</p>
              <p className="text-[11px] text-orange-600 font-medium">Total Redeemed</p>
            </motion.div>
          </div>

          <Separator />

          {/* Recent transactions */}
          <div>
            <h4 className="text-sm font-bold text-gray-700 mb-3 flex items-center gap-2">
              <Clock className="h-4 w-4 text-gray-400" />
              Recent Activity
            </h4>
            {transactions.length === 0 ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-8 bg-gray-50 rounded-xl"
              >
                <Star className="h-8 w-8 text-gray-300 mx-auto mb-2" />
                <p className="text-sm text-gray-500 font-medium">No activity yet</p>
                <p className="text-xs text-gray-400 mt-1">Place an order to start earning points!</p>
              </motion.div>
            ) : (
              <ScrollArea className="max-h-72">
                <div className="space-y-2">
                  <AnimatePresence>
                    {transactions.slice(0, 5).map((tx, idx) => (
                      <motion.div
                        key={tx.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        transition={{ delay: idx * 0.05 }}
                        className="flex items-center gap-3 p-3 rounded-xl hover:bg-gray-50 transition-colors group"
                      >
                        <div className={`h-8 w-8 rounded-lg border flex items-center justify-center flex-shrink-0 ${getTypeColor(tx.type)}`}>
                          {getTypeIcon(tx.type)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-medium text-gray-800 truncate">
                            {tx.description}
                          </p>
                          <p className="text-[10px] text-gray-400 mt-0.5">
                            {timeAgo(tx.createdAt)} · Balance: {tx.balance}
                          </p>
                        </div>
                        <div className="text-right flex-shrink-0">
                          <span className={`text-sm font-bold ${tx.points > 0 ? 'text-emerald-600' : 'text-orange-600'}`}>
                            {tx.points > 0 ? '+' : ''}{tx.points}
                          </span>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              </ScrollArea>
            )}

            {transactions.length > 5 && (
              <div className="text-center mt-2">
                <button className="text-xs text-emerald-600 font-medium hover:text-emerald-700 flex items-center gap-1 mx-auto">
                  View all transactions
                  <ChevronRight className="h-3 w-3" />
                </button>
              </div>
            )}
          </div>

          {/* Info note */}
          <div className="bg-gradient-to-r from-gray-50 to-slate-50 rounded-xl p-3 border border-gray-100">
            <p className="text-[11px] text-gray-500 leading-relaxed">
              <Zap className="h-3 w-3 inline mr-1 text-amber-500" />
              Earn <span className="font-bold text-gray-700">1 point per ৳100</span> spent on delivered orders.
              Redeem points at checkout — <span className="font-bold text-gray-700">1 point = ৳1</span> (max 20% of subtotal).
              New members get a <span className="font-bold text-emerald-600">50 point welcome bonus!</span>
            </p>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}
