'use client'

import { useEffect, useState } from 'react'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { QrCode, Download, Copy, Printer, Loader2 } from 'lucide-react'
import { toast } from 'sonner'
import { motion, AnimatePresence } from 'framer-motion'

interface QRCodeDialogProps {
  orderId: string
  orderNumber: string
  open: boolean
  onOpenChange: (open: boolean) => void
}

export default function QRCodeDialog({
  orderId,
  orderNumber,
  open,
  onOpenChange,
}: QRCodeDialogProps) {
  const [qrCodeUrl, setQrCodeUrl] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(false)

  useEffect(() => {
    if (!open) {
      setQrCodeUrl(null)
      setError(false)
      return
    }

    async function fetchQR() {
      setLoading(true)
      setError(false)
      try {
        const res = await fetch(`/api/orders/${orderId}/qr-code`)
        if (!res.ok) throw new Error('Failed to fetch QR code')
        const data = await res.json()
        // API may return { data: { qrCode: "data:image/png;base64,..." } } or { qrCode: "..." }
        const qr = data?.data?.qrCode || data?.qrCode || data?.data?.url || data?.url
        if (qr) {
          setQrCodeUrl(qr)
        } else {
          setError(true)
        }
      } catch {
        setError(true)
      } finally {
        setLoading(false)
      }
    }

    fetchQR()
  }, [open, orderId])

  function handleDownload() {
    if (!qrCodeUrl) return
    const link = window.document.createElement('a')
    link.href = qrCodeUrl
    link.download = `qr-${orderNumber}.png`
    window.document.body.appendChild(link)
    link.click()
    window.document.body.removeChild(link)
    toast.success('QR Code downloaded')
  }

  function handleCopyLink() {
    const trackingUrl = `${window.location.origin}?track=${orderNumber}`
    navigator.clipboard.writeText(trackingUrl).then(
      () => toast.success('Tracking link copied to clipboard'),
      () => toast.error('Failed to copy link')
    )
  }

  function handlePrint() {
    if (!qrCodeUrl) return
    const w = window.open('', '_blank')
    if (w) {
      w.document.write(`
        <html>
          <head>
            <title>QR Code — ${orderNumber}</title>
            <style>
              body { display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 100vh; margin: 0; font-family: sans-serif; }
              img { max-width: 300px; max-height: 300px; }
              h2 { margin: 16px 0 4px; font-size: 18px; }
              p { color: #666; margin: 0; font-size: 14px; }
              @media print { body { -webkit-print-color-adjust: exact; print-color-adjust: exact; } }
            </style>
          </head>
          <body>
            <img src="${qrCodeUrl}" alt="QR Code for Order ${orderNumber}" />
            <h2>Order #${orderNumber}</h2>
            <p>KHATI KHADYO</p>
          </body>
        </html>
      `)
      w.document.close()
      setTimeout(() => w.print(), 500)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <QrCode className="size-5 text-emerald-600" />
            QR Code
          </DialogTitle>
          <DialogDescription>
            Scan to track order {orderNumber}
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col items-center py-4">
          <AnimatePresence mode="wait">
            {loading ? (
              <motion.div
                key="loading"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="flex flex-col items-center justify-center h-56 w-56"
              >
                <Loader2 className="size-10 animate-spin text-emerald-500" />
                <p className="text-sm text-muted-foreground mt-3">Generating QR code…</p>
              </motion.div>
            ) : error ? (
              <motion.div
                key="error"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="flex flex-col items-center justify-center h-56 w-56 rounded-2xl bg-red-50"
              >
                <QrCode className="size-12 text-red-300 mb-2" />
                <p className="text-sm text-red-500">Failed to load QR code</p>
              </motion.div>
            ) : (
              <motion.div
                key="qrcode"
                initial={{ opacity: 0, scale: 0.85 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ type: 'spring', stiffness: 200, damping: 20 }}
                className="flex flex-col items-center"
              >
                {qrCodeUrl && (
                  <div className="rounded-2xl border-2 border-emerald-100 p-4 bg-white shadow-lg shadow-emerald-100/50">
                    <img
                      src={qrCodeUrl}
                      alt={`QR Code for Order ${orderNumber}`}
                      className="h-48 w-48 object-contain"
                    />
                  </div>
                )}
                <div className="mt-4 text-center">
                  <p className="font-bold text-gray-900 text-lg">#{orderNumber}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">KHATI KHADYO Order</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Action buttons */}
        {!loading && !error && qrCodeUrl && (
          <div className="flex flex-wrap gap-2 mt-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleDownload}
              className="flex-1 rounded-xl gap-1.5 border-emerald-200 text-emerald-700 hover:bg-emerald-50"
            >
              <Download className="size-3.5" />
              Download
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleCopyLink}
              className="flex-1 rounded-xl gap-1.5 border-amber-200 text-amber-700 hover:bg-amber-50"
            >
              <Copy className="size-3.5" />
              Copy Link
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handlePrint}
              className="flex-1 rounded-xl gap-1.5"
            >
              <Printer className="size-3.5" />
              Print
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
