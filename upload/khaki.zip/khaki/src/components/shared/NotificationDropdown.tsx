'use client'

import { useEffect, useRef, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Bell,
  CheckCheck,
  ShoppingCart,
  Tag,
  AlertCircle,
  TrendingDown,
  Package,
  ArrowRight,
  BellOff,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { useAppStore, type NotificationType, type NotificationItem } from '@/lib/store'
import { toast } from 'sonner'

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getNotificationIcon(type: NotificationType) {
  switch (type) {
    case 'order_update':
      return <ShoppingCart className="size-4 text-emerald-600" />
    case 'promo':
      return <Tag className="size-4 text-amber-600" />
    case 'restock':
      return <Package className="size-4 text-sky-600" />
    case 'price_drop':
      return <TrendingDown className="size-4 text-red-500" />
    default:
      return <Bell className="size-4 text-muted-foreground" />
  }
}

function getNotificationBg(type: NotificationType) {
  switch (type) {
    case 'order_update':
      return 'bg-emerald-100 dark:bg-emerald-900/30'
    case 'promo':
      return 'bg-amber-100 dark:bg-amber-900/30'
    case 'restock':
      return 'bg-sky-100 dark:bg-sky-900/30'
    case 'price_drop':
      return 'bg-red-100 dark:bg-red-900/30'
    default:
      return 'bg-muted'
  }
}

function getNotificationAccent(type: NotificationType) {
  switch (type) {
    case 'order_update':
      return 'border-l-emerald-500'
    case 'promo':
      return 'border-l-amber-500'
    case 'restock':
      return 'border-l-sky-500'
    case 'price_drop':
      return 'border-l-red-500'
    default:
      return 'border-l-muted-foreground'
  }
}

function timeAgo(dateStr: string): string {
  const date = new Date(dateStr)
  const now = new Date()
  const diff = Math.floor((now.getTime() - date.getTime()) / 1000)

  if (diff < 60) return 'Just now'
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`
  if (diff < 604800) return `${Math.floor(diff / 86400)}d ago`
  return date.toLocaleDateString()
}

// ─── Animation Variants ───────────────────────────────────────────────────────

const itemVariants = {
  hidden: { opacity: 0, x: -12 },
  visible: (i: number) => ({
    opacity: 1,
    x: 0,
    transition: { delay: i * 0.05, duration: 0.2 },
  }),
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function NotificationDropdown() {
  const {
    notifications,
    unreadCount,
    markAsRead,
    markAllAsRead,
    clearNotifications,
    initDemoNotifications,
    navigate,
  } = useAppStore()

  const [open, setOpen] = useState(false)
  const panelRef = useRef<HTMLDivElement>(null)
  const bellRef = useRef<HTMLButtonElement>(null)

  const count = unreadCount()

  // Initialize demo notifications on first load
  useEffect(() => {
    initDemoNotifications()
  }, [initDemoNotifications])

  // Click outside to close
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (
        panelRef.current &&
        !panelRef.current.contains(e.target as Node) &&
        bellRef.current &&
        !bellRef.current.contains(e.target as Node)
      ) {
        setOpen(false)
      }
    }
    if (open) {
      document.addEventListener('mousedown', handleClickOutside)
      return () => document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [open])

  // Escape key to close
  useEffect(() => {
    function handleEscape(e: KeyboardEvent) {
      if (e.key === 'Escape') setOpen(false)
    }
    if (open) {
      document.addEventListener('keydown', handleEscape)
      return () => document.removeEventListener('keydown', handleEscape)
    }
  }, [open])

  const handleMarkAllRead = () => {
    markAllAsRead()
    toast.success('All notifications marked as read')
  }

  const handleNotificationClick = (notification: NotificationItem) => {
    if (!notification.isRead) {
      markAsRead(notification.id)
    }
    if (notification.link) {
      setOpen(false)
      navigate(notification.link as 'orders' | 'offers' | 'products')
    }
  }

  const handleClearAll = () => {
    clearNotifications()
    toast.success('All notifications cleared')
  }

  const handleViewAll = () => {
    setOpen(false)
    // Navigate to a notifications view (just mark all as read for now)
    toast.info('Notification center coming soon!')
  }

  return (
    <div className="relative">
      {/* Bell Button */}
      <Button
        ref={bellRef}
        variant="ghost"
        size="icon"
        className="size-9 relative hover:bg-emerald-50 dark:hover:bg-emerald-900/20 transition-colors"
        onClick={() => setOpen(!open)}
        aria-label={`Notifications (${count} unread)`}
      >
        <motion.div
          animate={count > 0 ? { rotate: [0, -15, 15, -10, 10, 0] } : {}}
          transition={{ duration: 0.5 }}
          key={count}
        >
          <Bell className="size-[18px] text-foreground/80" />
        </motion.div>
        <AnimatePresence>
          {count > 0 && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0 }}
              transition={{ type: 'spring', stiffness: 500, damping: 25 }}
            >
              <Badge className="absolute -top-1 -right-1 min-w-[18px] h-[18px] p-0 flex items-center justify-center text-[10px] bg-red-500 text-white border-0 shadow-sm">
                {count > 9 ? '9+' : count}
              </Badge>
            </motion.div>
          )}
        </AnimatePresence>
      </Button>

      {/* Dropdown Panel */}
      <AnimatePresence>
        {open && (
          <motion.div
            ref={panelRef}
            initial={{ opacity: 0, y: -8, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.96 }}
            transition={{ duration: 0.2 }}
            className="absolute right-0 top-full mt-2 w-80 sm:w-[380px] bg-background border border-border/80 rounded-xl shadow-2xl z-50 overflow-hidden"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b bg-gradient-to-r from-emerald-50/80 to-amber-50/50 dark:from-emerald-900/20 dark:to-amber-900/10">
              <div className="flex items-center gap-2">
                <Bell className="size-4 text-emerald-600" />
                <h3 className="font-semibold text-sm">Notifications</h3>
                {count > 0 && (
                  <Badge className="bg-emerald-600 text-white text-[10px] px-1.5 py-0 border-0">
                    {count} new
                  </Badge>
                )}
              </div>
              <div className="flex items-center gap-1">
                {count > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-7 text-xs gap-1 text-emerald-700 hover:text-emerald-800 hover:bg-emerald-100/50 dark:text-emerald-400"
                    onClick={handleMarkAllRead}
                  >
                    <CheckCheck className="size-3.5" />
                    <span className="hidden sm:inline">Mark all read</span>
                  </Button>
                )}
              </div>
            </div>

            {/* Notifications List */}
            <div className="max-h-[400px] overflow-y-auto custom-scrollbar">
              {notifications.length === 0 ? (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-8 text-center"
                >
                  <motion.div
                    animate={{ y: [0, -5, 0] }}
                    transition={{ repeat: Infinity, duration: 2, ease: 'easeInOut' }}
                  >
                    <BellOff className="size-12 text-muted-foreground/20 mx-auto mb-3" />
                  </motion.div>
                  <p className="font-medium text-sm text-muted-foreground">No notifications yet</p>
                  <p className="text-xs text-muted-foreground/60 mt-1 max-w-[200px] mx-auto">
                    We&apos;ll notify you about orders, offers, restocks, and price drops
                  </p>
                  <div className="mt-4 flex flex-wrap gap-2 justify-center">
                    {(['order_update', 'promo', 'restock', 'price_drop'] as NotificationType[]).map((type) => (
                      <div
                        key={type}
                        className={`size-8 rounded-full flex items-center justify-center ${getNotificationBg(type)}`}
                      >
                        {getNotificationIcon(type)}
                      </div>
                    ))}
                  </div>
                </motion.div>
              ) : (
                <div>
                  {notifications.map((notification, index) => (
                    <motion.div
                      key={notification.id}
                      custom={index}
                      variants={itemVariants}
                      initial="hidden"
                      animate="visible"
                      onClick={() => handleNotificationClick(notification)}
                      className={`group cursor-pointer border-l-[3px] ${getNotificationAccent(notification.type)} ${
                        !notification.isRead ? 'bg-emerald-50/40 dark:bg-emerald-900/10' : ''
                      } hover:bg-muted/40 transition-colors`}
                    >
                      <div className="p-3.5">
                        <div className="flex gap-3">
                          {/* Icon */}
                          <div className={`shrink-0 size-9 rounded-full flex items-center justify-center ${getNotificationBg(notification.type)}`}>
                            {getNotificationIcon(notification.type)}
                          </div>

                          {/* Content */}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between gap-2">
                              <p className={`text-sm leading-tight ${!notification.isRead ? 'font-semibold' : 'font-medium'} line-clamp-1`}>
                                {notification.title}
                              </p>
                              <span className="text-[10px] text-muted-foreground shrink-0 mt-0.5">
                                {timeAgo(notification.timestamp)}
                              </span>
                            </div>
                            <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5 leading-relaxed">
                              {notification.description}
                            </p>
                          </div>

                          {/* Unread dot */}
                          {!notification.isRead && (
                            <div className="size-2 rounded-full bg-emerald-500 shrink-0 mt-2 ring-2 ring-emerald-500/20" />
                          )}
                        </div>
                      </div>
                      {index < notifications.length - 1 && <Separator className="mx-4" />}
                    </motion.div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer */}
            {notifications.length > 0 && (
              <div className="p-3 border-t bg-muted/20">
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1 h-8 text-xs gap-1 border-emerald-200 dark:border-emerald-800 text-emerald-700 hover:bg-emerald-50 dark:text-emerald-400 dark:hover:bg-emerald-900/30"
                    onClick={handleViewAll}
                  >
                    View All
                    <ArrowRight className="size-3" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 text-xs text-muted-foreground hover:text-destructive"
                    onClick={handleClearAll}
                  >
                    Clear All
                  </Button>
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
