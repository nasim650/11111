'use client'

import { useState } from 'react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Button } from '@/components/ui/button'
import {
  Printer,
  FileText,
  Package,
  Tag,
  Receipt,
  QrCode,
  Loader2,
  Barcode,
  Truck,
} from 'lucide-react'
import { toast } from 'sonner'

interface OrderPrintMenuProps {
  orderId: string
  orderNumber: string
  onQRCode?: () => void
}

type LoadingKey = 'invoice' | 'packing-slip' | 'delivery-label' | 'receipt-58' | 'receipt-80' | 'qr-code' | 'barcode' | 'courier-pathao' | 'courier-steadfast' | 'courier-redx' | 'courier-paperfly' | null

const COURIER_NAMES = {
  pathao: 'Pathao',
  steadfast: 'Steadfast',
  redx: 'RedX',
  paperfly: 'Paperfly',
} as const

export default function OrderPrintMenu({ orderId, orderNumber, onQRCode }: OrderPrintMenuProps) {
  const [loading, setLoading] = useState<LoadingKey>(null)

  async function downloadPdf(url: string, filename: string, key: LoadingKey) {
    setLoading(key)
    try {
      const res = await fetch(url)
      if (!res.ok) throw new Error('Download failed')
      const blob = await res.blob()
      const link = window.document.createElement('a')
      link.href = URL.createObjectURL(blob)
      link.download = filename
      window.document.body.appendChild(link)
      link.click()
      window.document.body.removeChild(link)
      URL.revokeObjectURL(link.href)
      toast.success(`${filename} downloaded`)
    } catch {
      toast.error(`Failed to download ${filename}`)
    } finally {
      setLoading(null)
    }
  }

  async function openPrintWindow(url: string, key: LoadingKey) {
    setLoading(key)
    try {
      const res = await fetch(url)
      if (!res.ok) throw new Error('Failed to load')
      const html = await res.text()
      const w = window.open('', '_blank')
      if (w) {
        w.document.write(html)
        w.document.close()
        setTimeout(() => w.print(), 500)
      }
    } catch {
      toast.error('Failed to open print view')
    } finally {
      setLoading(null)
    }
  }

  async function viewBarcodeImage(url: string, key: LoadingKey) {
    setLoading(key)
    try {
      const res = await fetch(url)
      if (!res.ok) throw new Error('Failed to load')
      const blob = await res.blob()
      const imageUrl = URL.createObjectURL(blob)
      const w = window.open('', '_blank')
      if (w) {
        w.document.write(`<html><head><title>Barcode - ${orderNumber}</title><style>body{display:flex;justify-content:center;align-items:center;min-height:100vh;margin:0;background:#f5f5f5;}img{max-width:90%;}</style></head><body><img src="${imageUrl}" alt="Barcode" /></body></html>`)
        w.document.close()
      }
    } catch {
      toast.error('Failed to load barcode')
    } finally {
      setLoading(null)
    }
  }

  const items: {
    key: LoadingKey
    label: string
    icon: React.ElementType
    action: () => void
  }[] = [
    {
      key: 'invoice',
      label: 'Download Invoice (PDF)',
      icon: FileText,
      action: () =>
        downloadPdf(
          `/api/orders/${orderId}/invoice?format=pdf`,
          `invoice-${orderNumber}.pdf`,
          'invoice'
        ),
    },
    {
      key: 'packing-slip',
      label: 'Download Packing Slip',
      icon: Package,
      action: () =>
        downloadPdf(
          `/api/orders/${orderId}/packing-slip?format=pdf`,
          `packing-slip-${orderNumber}.pdf`,
          'packing-slip'
        ),
    },
    {
      key: 'delivery-label',
      label: 'Print Delivery Label',
      icon: Tag,
      action: () =>
        downloadPdf(
          `/api/orders/${orderId}/delivery-label?format=pdf`,
          `delivery-label-${orderNumber}.pdf`,
          'delivery-label'
        ),
    },
    {
      key: 'receipt-58',
      label: 'Print Receipt (58mm)',
      icon: Receipt,
      action: () =>
        openPrintWindow(`/api/orders/${orderId}/thermal-receipt?width=58`, 'receipt-58'),
    },
    {
      key: 'receipt-80',
      label: 'Print Receipt (80mm)',
      icon: Receipt,
      action: () =>
        openPrintWindow(`/api/orders/${orderId}/thermal-receipt?width=80`, 'receipt-80'),
    },
    {
      key: 'barcode',
      label: 'View Barcode (CODE128)',
      icon: Barcode,
      action: () =>
        viewBarcodeImage(`/api/orders/${orderId}/barcode`, 'barcode'),
    },
    {
      key: 'qr-code',
      label: 'QR Code',
      icon: QrCode,
      action: () => {
        if (onQRCode) {
          onQRCode()
        } else {
          toast.info('QR Code dialog not available')
        }
      },
    },
  ]

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="size-8 hover:bg-emerald-50 hover:text-emerald-700">
          {loading ? (
            <Loader2 className="size-4 animate-spin" />
          ) : (
            <Printer className="size-4" />
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-60">
        <DropdownMenuLabel className="text-xs text-muted-foreground">
          Print Options — {orderNumber}
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        {items.map((item) => {
          const Icon = item.icon
          return (
            <DropdownMenuItem
              key={item.key}
              onClick={item.action}
              disabled={loading !== null}
              className="cursor-pointer gap-3 py-2.5"
            >
              {loading === item.key ? (
                <Loader2 className="size-4 animate-spin text-emerald-600" />
              ) : (
                <Icon className="size-4 text-emerald-600" />
              )}
              <span className="flex-1">{item.label}</span>
            </DropdownMenuItem>
          )
        })}
        <DropdownMenuSeparator />
        <DropdownMenuSub>
          <DropdownMenuSubTrigger className="cursor-pointer gap-3 py-2.5" disabled={loading !== null}>
            <Truck className="size-4 text-orange-600" />
            <span>Courier Labels</span>
          </DropdownMenuSubTrigger>
          <DropdownMenuSubContent className="w-52">
            {Object.entries(COURIER_NAMES).map(([key, name]) => {
              const loadingKey = `courier-${key}` as LoadingKey
              return (
                <DropdownMenuItem
                  key={key}
                  onClick={() =>
                    openPrintWindow(
                      `/api/orders/${orderId}/courier-label?courier=${key}`,
                      loadingKey
                    )
                  }
                  disabled={loading !== null}
                  className="cursor-pointer gap-3 py-2"
                >
                  {loading === loadingKey ? (
                    <Loader2 className="size-4 animate-spin text-orange-600" />
                  ) : (
                    <Truck className="size-4 text-orange-600" />
                  )}
                  <span>{name}</span>
                </DropdownMenuItem>
              )
            })}
            <DropdownMenuSeparator />
            <DropdownMenuItem
              onClick={() =>
                downloadPdf(
                  `/api/orders/${orderId}/courier-label?courier=pathao&format=pdf`,
                  `courier-label-${orderNumber}.pdf`,
                  'courier-pathao'
                )
              }
              disabled={loading !== null}
              className="cursor-pointer gap-3 py-2"
            >
              <FileText className="size-4 text-orange-600" />
              <span>Download PDF</span>
            </DropdownMenuItem>
          </DropdownMenuSubContent>
        </DropdownMenuSub>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
