'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { Printer, Download, Loader2, Leaf } from 'lucide-react'
import { toast } from 'sonner'

// ─── Invoice Data Types ────────────────────────────────────────────────────────

export interface InvoiceItem {
  id: string
  productName: string
  quantity: number
  unit: string
  price: number
  total: number
}

export interface InvoiceData {
  orderNumber: string
  orderDate: string
  customerName: string
  customerEmail?: string
  customerPhone: string
  shippingAddress: string
  items: InvoiceItem[]
  subtotal: number
  deliveryCharge: number
  discount: number
  total: number
  paymentMethod: string
  paymentStatus: string
  note?: string
}

interface InvoiceViewProps {
  orderData: InvoiceData
}

export default function InvoiceView({ orderData }: InvoiceViewProps) {
  const [downloading, setDownloading] = useState(false)

  function handlePrint() {
    window.print()
  }

  async function handleDownloadPDF() {
    setDownloading(true)
    try {
      const res = await fetch(`/api/orders/${orderData.orderNumber}/invoice?format=pdf`)
      if (!res.ok) throw new Error('Failed to download')
      const blob = await res.blob()
      const link = window.document.createElement('a')
      link.href = URL.createObjectURL(blob)
      link.download = `invoice-${orderData.orderNumber}.pdf`
      window.document.body.appendChild(link)
      link.click()
      window.document.body.removeChild(link)
      URL.revokeObjectURL(link.href)
      toast.success('Invoice PDF downloaded')
    } catch {
      toast.error('Failed to download invoice PDF')
    } finally {
      setDownloading(false)
    }
  }

  const formattedDate = new Date(orderData.orderDate).toLocaleDateString('en-BD', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  })

  return (
    <>
      {/* Screen-only action bar */}
      <div className="print:hidden sticky top-0 z-10 bg-white/80 backdrop-blur-md border-b py-3 px-4 mb-6">
        <div className="container mx-auto max-w-4xl flex items-center justify-between">
          <h2 className="font-bold text-lg text-gray-900">Invoice Preview</h2>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handlePrint}
              className="gap-1.5 rounded-xl border-emerald-200 text-emerald-700 hover:bg-emerald-50"
            >
              <Printer className="size-3.5" />
              Print
            </Button>
            <Button
              size="sm"
              onClick={handleDownloadPDF}
              disabled={downloading}
              className="gap-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700"
            >
              {downloading ? (
                <Loader2 className="size-3.5 animate-spin" />
              ) : (
                <Download className="size-3.5" />
              )}
              Download PDF
            </Button>
          </div>
        </div>
      </div>

      {/* Invoice content - A4 optimized */}
      <div className="container mx-auto max-w-4xl bg-white shadow-xl print:shadow-none print:max-w-none">
        <div className="p-8 sm:p-12 print:p-8">
          {/* ─── Company Header ─────────────────────────────────────────── */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-700 flex items-center justify-center shadow-md shadow-emerald-200">
                <Leaf className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-black text-gray-900 tracking-tight">
                  KHATI KHADYO
                </h1>
                <p className="text-xs text-emerald-600 font-medium">খাঁটি খাদ্য — Pure & Authentic</p>
              </div>
            </div>
            <div className="text-right text-xs text-gray-500 space-y-0.5">
              <p>House 12, Road 5, Dhanmondi</p>
              <p>Dhaka 1205, Bangladesh</p>
              <p>info@khatikhadyo.com</p>
              <p>+880 1700-000000</p>
            </div>
          </div>

          <Separator className="mb-8 bg-emerald-100" />

          {/* ─── Invoice Title & Meta ────────────────────────────────────── */}
          <div className="flex flex-col sm:flex-row justify-between gap-4 mb-8">
            <div>
              <h2 className="text-xl font-bold text-gray-900 mb-1">INVOICE</h2>
              <p className="text-sm text-emerald-600 font-semibold">#{orderData.orderNumber}</p>
            </div>
            <div className="text-sm text-right space-y-1">
              <div className="flex items-center justify-end gap-2">
                <span className="text-gray-500">Date:</span>
                <span className="font-medium text-gray-900">{formattedDate}</span>
              </div>
              <div className="flex items-center justify-end gap-2">
                <span className="text-gray-500">Payment:</span>
                <span className="font-medium text-gray-900">{orderData.paymentMethod}</span>
              </div>
              <div className="flex items-center justify-end gap-2">
                <span className="text-gray-500">Status:</span>
                <span
                  className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-bold ${
                    orderData.paymentStatus === 'PAID' || orderData.paymentStatus === 'paid'
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {orderData.paymentStatus}
                </span>
              </div>
            </div>
          </div>

          {/* ─── Customer Info ───────────────────────────────────────────── */}
          <div className="grid sm:grid-cols-2 gap-6 mb-8">
            <div className="rounded-xl border border-gray-200 p-4">
              <h3 className="text-xs font-bold text-emerald-700 uppercase tracking-wider mb-2">
                Bill To
              </h3>
              <p className="font-semibold text-gray-900">{orderData.customerName}</p>
              {orderData.customerEmail && (
                <p className="text-sm text-gray-600 mt-0.5">{orderData.customerEmail}</p>
              )}
              <p className="text-sm text-gray-600 mt-0.5">{orderData.customerPhone}</p>
            </div>
            <div className="rounded-xl border border-gray-200 p-4">
              <h3 className="text-xs font-bold text-emerald-700 uppercase tracking-wider mb-2">
                Ship To
              </h3>
              <p className="text-sm text-gray-700 leading-relaxed">{orderData.shippingAddress}</p>
            </div>
          </div>

          {/* ─── Items Table ─────────────────────────────────────────────── */}
          <div className="rounded-xl border border-gray-200 overflow-hidden mb-8">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gradient-to-r from-emerald-600 to-emerald-700 text-white">
                  <th className="text-left py-3 px-4 font-semibold">#</th>
                  <th className="text-left py-3 px-4 font-semibold">Product</th>
                  <th className="text-right py-3 px-4 font-semibold">Price</th>
                  <th className="text-center py-3 px-4 font-semibold">Qty</th>
                  <th className="text-right py-3 px-4 font-semibold">Total</th>
                </tr>
              </thead>
              <tbody>
                {orderData.items.map((item, idx) => (
                  <tr
                    key={item.id}
                    className={`border-b border-gray-100 ${idx % 2 === 1 ? 'bg-gray-50/50' : ''}`}
                  >
                    <td className="py-3 px-4 text-gray-400">{idx + 1}</td>
                    <td className="py-3 px-4 font-medium text-gray-900">{item.productName}</td>
                    <td className="py-3 px-4 text-right text-gray-700">
                      ৳{item.price.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-center text-gray-700">
                      {item.quantity} {item.unit}
                    </td>
                    <td className="py-3 px-4 text-right font-semibold text-gray-900">
                      ৳{item.total.toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* ─── Totals ──────────────────────────────────────────────────── */}
          <div className="flex justify-end mb-8">
            <div className="w-full sm:w-72 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Subtotal</span>
                <span className="text-gray-900 font-medium">৳{orderData.subtotal.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Delivery Charge</span>
                <span className="text-gray-900 font-medium">
                  {orderData.deliveryCharge === 0 ? (
                    <span className="text-emerald-600 font-bold">FREE</span>
                  ) : (
                    `৳${orderData.deliveryCharge.toLocaleString()}`
                  )}
                </span>
              </div>
              {orderData.discount > 0 && (
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Discount</span>
                  <span className="text-emerald-600 font-bold">
                    -৳{orderData.discount.toLocaleString()}
                  </span>
                </div>
              )}
              <Separator />
              <div className="flex justify-between font-bold text-lg">
                <span className="text-gray-900">Total</span>
                <span className="text-emerald-700">৳{orderData.total.toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* ─── Note ────────────────────────────────────────────────────── */}
          {orderData.note && (
            <div className="rounded-xl bg-amber-50 border border-amber-200 p-4 mb-8">
              <p className="text-xs font-bold text-amber-700 uppercase tracking-wider mb-1">Note</p>
              <p className="text-sm text-amber-800">{orderData.note}</p>
            </div>
          )}

          {/* ─── Footer ──────────────────────────────────────────────────── */}
          <div className="text-center pt-6 border-t border-gray-100">
            <p className="text-xs text-gray-400">
              Thank you for shopping with KHATI KHADYO!
            </p>
            <p className="text-xs text-gray-400 mt-1">
              This is a computer-generated invoice and does not require a signature.
            </p>
          </div>
        </div>
      </div>
    </>
  )
}
