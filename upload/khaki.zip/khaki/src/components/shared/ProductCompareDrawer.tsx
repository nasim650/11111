'use client'

import { useEffect, useState } from 'react'
import Image from 'next/image'
import { motion, AnimatePresence } from 'framer-motion'
import {
  X,
  GitCompareArrows,
  Package,
  Star,
  MapPin,
  Scale,
  CircleDot,
  CheckCircle2,
  XCircle,
  Trash2,
  ChevronUp,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { useAppStore } from '@/lib/store'

// ─── Types ────────────────────────────────────────────────────────────────────

interface CompareProduct {
  id: string
  name: string
  slug: string
  price: number
  discountPrice?: number | null
  unit: string
  stock: number
  origin?: string
  weight?: string
  features?: string[]
  averageRating?: number
  reviewCount?: number
  images?: Array<{ url: string; alt?: string }>
  category?: { name: string; slug: string }
  shortDescription?: string
}

// ─── Animation Variants ───────────────────────────────────────────────────────



// ─── Compare Row Component ────────────────────────────────────────────────────

function CompareRow({ label, icon, children }: { label: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="flex border-b border-border/50 last:border-b-0">
      <div className="w-28 sm:w-36 shrink-0 p-3 bg-muted/30 flex items-center gap-2 text-xs font-medium text-muted-foreground">
        {icon}
        {label}
      </div>
      <div className="flex-1 flex">
        {children}
      </div>
    </div>
  )
}

function CompareCell({ children, highlight }: { children: React.ReactNode; highlight?: boolean }) {
  return (
    <div className={`flex-1 p-3 text-sm text-center min-w-[140px] ${highlight ? 'bg-emerald-50/50 dark:bg-emerald-900/10' : ''}`}>
      {children}
    </div>
  )
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function ProductCompareDrawer() {
  const {
    compareProducts,
    removeFromCompare,
    clearCompare,
    navigate,
  } = useAppStore()

  const [products, setProducts] = useState<CompareProduct[]>([])
  const [isDrawerOpen, setIsDrawerOpen] = useState(false)
  const [loading, setLoading] = useState(false)

  const shouldShow = compareProducts.length >= 1

  // Fetch product details when compare list changes
  useEffect(() => {
    if (compareProducts.length === 0) {
      setProducts([])
      return
    }

    let cancelled = false

    const fetchProducts = async () => {
      setLoading(true)
      try {
        const results = await Promise.all(
          compareProducts.map(async (id) => {
            try {
              const res = await fetch(`/api/products/${id}`)
              if (res.ok) {
                const data = await res.json()
                return (data.data || data) as CompareProduct
              }
              return null
            } catch {
              return null
            }
          })
        )
        if (!cancelled) {
          setProducts(results.filter((p): p is CompareProduct => p !== null && p.id !== undefined))
        }
      } catch {
        if (!cancelled) {
          setProducts([])
        }
      } finally {
        if (!cancelled) setLoading(false)
      }
    }

    fetchProducts()

    return () => {
      cancelled = true
    }
  }, [compareProducts])

  if (!shouldShow) return null

  const findBestPrice = () => {
    if (products.length === 0) return -1
    let bestIdx = 0
    let bestPrice = Infinity
    products.forEach((p, i) => {
      const price = p.discountPrice != null ? p.discountPrice : p.price
      if (price < bestPrice) {
        bestPrice = price
        bestIdx = i
      }
    })
    return bestIdx
  }

  const bestPriceIdx = findBestPrice()

  return (
    <>
      {/* Floating Compare Bar */}
      <AnimatePresence>
        {!isDrawerOpen && shouldShow && (
          <motion.div
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 100, opacity: 0 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="fixed bottom-0 left-0 right-0 z-40"
          >
            <div className="absolute inset-x-0 -top-8 h-8 bg-gradient-to-t from-black/10 to-transparent pointer-events-none" />
            <div className="bg-background/95 backdrop-blur-md border-t border-border shadow-2xl">
              <div className="container mx-auto px-4 py-3">
                <div className="flex items-center gap-3">
                  {/* Compare label */}
                  <div className="hidden sm:flex items-center gap-2 shrink-0">
                    <div className="size-8 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center">
                      <GitCompareArrows className="size-4 text-emerald-600" />
                    </div>
                    <span className="text-sm font-semibold">Compare</span>
                    <Badge className="bg-emerald-600 text-white text-[10px] border-0">
                      {compareProducts.length}/4
                    </Badge>
                  </div>

                  {/* Product thumbnails */}
                  <div
                    className="flex-1 flex items-center gap-2 overflow-x-auto py-1"
                    style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
                  >
                    {products.map((product) => {
                      const imageUrl = product.images?.[0]?.url
                      return (
                        <div
                          key={product.id}
                          className="flex-shrink-0 flex items-center gap-2 bg-muted/50 rounded-lg px-2 py-1.5 group hover:bg-muted transition-colors"
                        >
                          <div className="relative size-10 rounded-md overflow-hidden bg-muted/30 flex-shrink-0">
                            {imageUrl ? (
                              <Image
                                src={imageUrl}
                                alt={product.name}
                                width={40}
                                height={40}
                                className="object-cover w-full h-full"
                              />
                            ) : (
                              <div className="flex items-center justify-center h-full">
                                <Package className="size-4 text-muted-foreground/50" />
                              </div>
                            )}
                          </div>
                          <span className="text-xs font-medium line-clamp-1 max-w-[80px] sm:max-w-[120px]">
                            {product.name}
                          </span>
                          <button
                            onClick={(e) => {
                              e.stopPropagation()
                              removeFromCompare(product.id)
                            }}
                            className="size-5 rounded-full flex items-center justify-center text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors flex-shrink-0"
                            aria-label={`Remove ${product.name} from comparison`}
                          >
                            <X className="size-3.5" />
                          </button>
                        </div>
                      )
                    })}
                    {/* Add more slot */}
                    {compareProducts.length < 4 && (
                      <button
                        onClick={() => navigate('products')}
                        className="flex-shrink-0 flex items-center justify-center size-10 rounded-lg border-2 border-dashed border-muted-foreground/20 text-muted-foreground/40 hover:border-emerald-400 hover:text-emerald-600 transition-colors"
                        aria-label="Add more products to compare"
                      >
                        <span className="text-lg leading-none">+</span>
                      </button>
                    )}
                  </div>

                  {/* Action buttons */}
                  <div className="flex items-center gap-2 shrink-0">
                    <Button
                      size="sm"
                      className="h-9 gap-1.5 bg-emerald-600 hover:bg-emerald-700"
                      onClick={() => setIsDrawerOpen(true)}
                      disabled={compareProducts.length < 2}
                    >
                      <GitCompareArrows className="size-4" />
                      <span className="hidden sm:inline">Compare Now</span>
                      <span className="sm:hidden">Compare</span>
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-9 text-muted-foreground hover:text-destructive"
                      onClick={clearCompare}
                    >
                      <Trash2 className="size-4 sm:mr-1" />
                      <span className="hidden sm:inline">Clear</span>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Comparison Drawer Overlay */}
      <AnimatePresence>
        {isDrawerOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="fixed inset-0 bg-black/50 z-50 backdrop-blur-sm"
              onClick={() => setIsDrawerOpen(false)}
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 30, stiffness: 300 }}
              className="fixed bottom-0 left-0 right-0 z-50 bg-background rounded-t-2xl shadow-2xl max-h-[85vh] flex flex-col"
            >
              {/* Drawer Header */}
              <div className="flex items-center justify-between p-4 border-b bg-gradient-to-r from-emerald-50/80 to-amber-50/50 dark:from-emerald-900/20 dark:to-amber-900/10 rounded-t-2xl">
                <div className="flex items-center gap-3">
                  <div className="size-9 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center">
                    <GitCompareArrows className="size-4 text-emerald-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-base">Product Comparison</h3>
                    <p className="text-xs text-muted-foreground">
                      Comparing {products.length} product{products.length !== 1 ? 's' : ''}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-destructive hover:text-destructive gap-1"
                    onClick={() => {
                      clearCompare()
                      setIsDrawerOpen(false)
                    }}
                  >
                    <Trash2 className="size-3.5" />
                    Clear All
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="size-8"
                    onClick={() => setIsDrawerOpen(false)}
                    aria-label="Close comparison"
                  >
                    <ChevronUp className="size-5" />
                  </Button>
                </div>
              </div>

              {/* Comparison Table */}
              <div className="flex-1 overflow-auto custom-scrollbar">
                {loading ? (
                  <div className="p-12 text-center">
                    <div className="size-8 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto" />
                    <p className="text-sm text-muted-foreground mt-3">Loading products...</p>
                  </div>
                ) : products.length < 2 ? (
                  <div className="p-12 text-center">
                    <GitCompareArrows className="size-12 text-muted-foreground/20 mx-auto mb-3" />
                    <p className="font-medium text-muted-foreground">Add at least 2 products to compare</p>
                    <Button
                      variant="outline"
                      size="sm"
                      className="mt-4 gap-1"
                      onClick={() => {
                        setIsDrawerOpen(false)
                        navigate('products')
                      }}
                    >
                      Browse Products
                    </Button>
                  </div>
                ) : (
                  <div className="min-w-max">
                    {/* Product Headers */}
                    <div className="flex border-b border-border">
                      <div className="w-28 sm:w-36 shrink-0 p-3 bg-muted/30" />
                      {products.map((product) => {
                        const imageUrl = product.images?.[0]?.url
                        return (
                          <div key={product.id} className="flex-1 p-4 text-center min-w-[160px] relative group">
                            <button
                              onClick={() => removeFromCompare(product.id)}
                              className="absolute top-2 right-2 size-6 rounded-full bg-muted/80 flex items-center justify-center text-muted-foreground hover:text-destructive hover:bg-destructive/10 opacity-0 group-hover:opacity-100 transition-all"
                              aria-label={`Remove ${product.name}`}
                            >
                              <X className="size-3" />
                            </button>
                            <div className="relative size-20 mx-auto rounded-lg overflow-hidden bg-muted/30 mb-2">
                              {imageUrl ? (
                                <Image
                                  src={imageUrl}
                                  alt={product.name}
                                  fill
                                  className="object-cover"
                                />
                              ) : (
                                <div className="flex items-center justify-center h-full">
                                  <Package className="size-8 text-muted-foreground/30" />
                                </div>
                              )}
                            </div>
                            <p className="font-semibold text-sm line-clamp-2">{product.name}</p>
                            {product.category && (
                              <p className="text-[10px] text-muted-foreground mt-0.5">{product.category.name}</p>
                            )}
                          </div>
                        )
                      })}
                    </div>

                    {/* Price Row */}
                    <CompareRow label="Price" icon={<span className="text-emerald-600">৳</span>}>
                      {products.map((product, idx) => {
                        const effectivePrice = product.discountPrice != null ? product.discountPrice : product.price
                        const hasDiscount = product.discountPrice != null && product.discountPrice < product.price
                        return (
                          <CompareCell key={product.id} highlight={idx === bestPriceIdx}>
                            <span className={`font-bold text-lg ${idx === bestPriceIdx ? 'text-emerald-600' : ''}`}>
                              ৳{effectivePrice.toLocaleString()}
                            </span>
                            {hasDiscount && (
                              <>
                                <br />
                                <span className="text-xs text-muted-foreground line-through">
                                  ৳{product.price.toLocaleString()}
                                </span>
                                <Badge className="ml-1 bg-red-500 text-white text-[9px] border-0 px-1">
                                  -{Math.round(((product.price - product.discountPrice!) / product.price) * 100)}%
                                </Badge>
                              </>
                            )}
                            {idx === bestPriceIdx && products.length > 1 && (
                              <div className="mt-1">
                                <Badge className="bg-emerald-100 text-emerald-700 text-[10px] border-0 dark:bg-emerald-900/30 dark:text-emerald-400">
                                  Best Price
                                </Badge>
                              </div>
                            )}
                            <span className="text-xs text-muted-foreground">/{product.unit}</span>
                          </CompareCell>
                        )
                      })}
                    </CompareRow>

                    {/* Rating Row */}
                    <CompareRow label="Rating" icon={<Star className="size-3 text-amber-500" />}>
                      {products.map((product) => (
                        <CompareCell key={product.id}>
                          {product.averageRating != null && product.averageRating > 0 ? (
                            <div className="flex flex-col items-center">
                              <div className="flex items-center gap-1">
                                <Star className="size-4 fill-amber-400 text-amber-400" />
                                <span className="font-bold text-sm">{product.averageRating.toFixed(1)}</span>
                              </div>
                              {product.reviewCount != null && (
                                <span className="text-[10px] text-muted-foreground">
                                  ({product.reviewCount} reviews)
                                </span>
                              )}
                            </div>
                          ) : (
                            <span className="text-xs text-muted-foreground">No reviews</span>
                          )}
                        </CompareCell>
                      ))}
                    </CompareRow>

                    {/* Origin Row */}
                    <CompareRow label="Origin" icon={<MapPin className="size-3 text-emerald-500" />}>
                      {products.map((product) => (
                        <CompareCell key={product.id}>
                          <span className="text-sm">
                            {product.origin || 'Bangladesh'}
                          </span>
                        </CompareCell>
                      ))}
                    </CompareRow>

                    {/* Weight/Unit Row */}
                    <CompareRow label="Weight" icon={<Scale className="size-3 text-sky-500" />}>
                      {products.map((product) => (
                        <CompareCell key={product.id}>
                          <span className="text-sm">
                            {product.weight || product.unit}
                          </span>
                        </CompareCell>
                      ))}
                    </CompareRow>

                    {/* Stock Row */}
                    <CompareRow label="Availability" icon={<CircleDot className="size-3 text-emerald-500" />}>
                      {products.map((product) => {
                        const inStock = product.stock > 0
                        const lowStock = product.stock > 0 && product.stock <= 5
                        return (
                          <CompareCell key={product.id} highlight={inStock && !lowStock}>
                            {inStock ? (
                              <div className="flex items-center justify-center gap-1">
                                <CheckCircle2 className={`size-4 ${lowStock ? 'text-amber-500' : 'text-emerald-500'}`} />
                                <span className={`text-sm font-medium ${lowStock ? 'text-amber-600' : 'text-emerald-600'}`}>
                                  {lowStock ? `Only ${product.stock} left` : 'In Stock'}
                                </span>
                              </div>
                            ) : (
                              <div className="flex items-center justify-center gap-1">
                                <XCircle className="size-4 text-red-500" />
                                <span className="text-sm font-medium text-red-500">Out of Stock</span>
                              </div>
                            )}
                          </CompareCell>
                        )
                      })}
                    </CompareRow>

                    {/* Description Row */}
                    <CompareRow label="Description" icon={<span className="text-xs">📝</span>}>
                      {products.map((product) => (
                        <CompareCell key={product.id}>
                          <p className="text-xs text-muted-foreground text-left line-clamp-3">
                            {product.shortDescription || 'No description available'}
                          </p>
                        </CompareCell>
                      ))}
                    </CompareRow>

                    {/* Action Row */}
                    <CompareRow label="Action" icon={<span className="text-xs">🛒</span>}>
                      {products.map((product) => (
                        <CompareCell key={product.id}>
                          <Button
                            size="sm"
                            className="bg-emerald-600 hover:bg-emerald-700 text-xs"
                            disabled={product.stock <= 0}
                            onClick={() => {
                              setIsDrawerOpen(false)
                              navigate('product-detail', { id: product.id })
                            }}
                          >
                            View Details
                          </Button>
                        </CompareCell>
                      ))}
                    </CompareRow>
                  </div>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  )
}
