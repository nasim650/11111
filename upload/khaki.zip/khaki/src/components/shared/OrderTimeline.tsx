'use client'

import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import {
  Clock,
  CheckCircle2,
  Package,
  Box,
  Send,
  Truck,
  Home,
  XCircle,
  RotateCcw,
  ShieldCheck,
  CircleDot,
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'

// ─── Types ────────────────────────────────────────────────────────────────────

interface StatusHistoryEntry {
  id: string
  orderId: string
  status: string
  note: string | null
  changedBy: string | null
  createdAt: string
}

interface OrderTimelineProps {
  orderId: string
}

// ─── Status Configuration ────────────────────────────────────────────────────

const statusConfig: Record<string, {
  label: string
  icon: React.ComponentType<{ className?: string }>
  badgeClass: string
  dotClass: string
  lineClass: string
}> = {
  pending: {
    label: 'Pending',
    icon: Clock,
    badgeClass: 'bg-amber-100 text-amber-800 border-amber-200',
    dotClass: 'bg-amber-500 shadow-amber-200',
    lineClass: 'bg-amber-200',
  },
  confirmed: {
    label: 'Confirmed',
    icon: CheckCircle2,
    badgeClass: 'bg-teal-100 text-teal-800 border-teal-200',
    dotClass: 'bg-teal-500 shadow-teal-200',
    lineClass: 'bg-teal-200',
  },
  processing: {
    label: 'Processing',
    icon: Package,
    badgeClass: 'bg-purple-100 text-purple-800 border-purple-200',
    dotClass: 'bg-purple-500 shadow-purple-200',
    lineClass: 'bg-purple-200',
  },
  packed: {
    label: 'Packed',
    icon: Box,
    badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200',
    dotClass: 'bg-indigo-500 shadow-indigo-200',
    lineClass: 'bg-indigo-200',
  },
  ready_to_ship: {
    label: 'Ready to Ship',
    icon: Send,
    badgeClass: 'bg-cyan-100 text-cyan-800 border-cyan-200',
    dotClass: 'bg-cyan-500 shadow-cyan-200',
    lineClass: 'bg-cyan-200',
  },
  shipped: {
    label: 'Shipped',
    icon: Truck,
    badgeClass: 'bg-orange-100 text-orange-800 border-orange-200',
    dotClass: 'bg-orange-500 shadow-orange-200',
    lineClass: 'bg-orange-200',
  },
  delivered: {
    label: 'Delivered',
    icon: Home,
    badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-200',
    dotClass: 'bg-emerald-500 shadow-emerald-200',
    lineClass: 'bg-emerald-200',
  },
  cancelled: {
    label: 'Cancelled',
    icon: XCircle,
    badgeClass: 'bg-red-100 text-red-800 border-red-200',
    dotClass: 'bg-red-500 shadow-red-200',
    lineClass: 'bg-red-200',
  },
  returned: {
    label: 'Returned',
    icon: RotateCcw,
    badgeClass: 'bg-gray-100 text-gray-800 border-gray-200',
    dotClass: 'bg-gray-500 shadow-gray-200',
    lineClass: 'bg-gray-200',
  },
  refunded: {
    label: 'Refunded',
    icon: RotateCcw,
    badgeClass: 'bg-gray-100 text-gray-800 border-gray-200',
    dotClass: 'bg-gray-500 shadow-gray-200',
    lineClass: 'bg-gray-200',
  },
}

const defaultConfig = {
  label: 'Unknown',
  icon: CircleDot,
  badgeClass: 'bg-gray-100 text-gray-800 border-gray-200',
  dotClass: 'bg-gray-400 shadow-gray-200',
  lineClass: 'bg-gray-200',
}

// ─── Helper ──────────────────────────────────────────────────────────────────

function formatRelativeTime(dateStr: string): string {
  const date = new Date(dateStr)
  const now = new Date()
  const diffMs = now.getTime() - date.getTime()
  const diffMins = Math.floor(diffMs / 60000)
  const diffHours = Math.floor(diffMs / 3600000)
  const diffDays = Math.floor(diffMs / 86400000)

  if (diffMins < 1) return 'Just now'
  if (diffMins < 60) return `${diffMins}m ago`
  if (diffHours < 24) return `${diffHours}h ago`
  if (diffDays < 7) return `${diffDays}d ago`

  return date.toLocaleDateString('en-BD', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
}

function formatFullDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString('en-BD', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function OrderTimeline({ orderId }: OrderTimelineProps) {
  const [history, setHistory] = useState<StatusHistoryEntry[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!orderId) return

    async function fetchHistory() {
      try {
        const res = await fetch(`/api/orders/${orderId}/status-history`)
        if (!res.ok) throw new Error('Failed to fetch status history')
        const data = await res.json()
        setHistory(data.data || [])
      } catch {
        setError('Could not load status history')
      } finally {
        setLoading(false)
      }
    }

    fetchHistory()
  }, [orderId])

  if (loading) {
    return (
      <Card className="border-0 shadow-lg overflow-hidden">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-emerald-100 flex items-center justify-center">
              <Clock className="h-4 w-4 text-emerald-600" />
            </div>
            Order Timeline
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6 pt-0">
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-start gap-4">
                <Skeleton className="h-10 w-10 rounded-full flex-shrink-0" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-32" />
                  <Skeleton className="h-3 w-48" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }

  if (error || history.length === 0) {
    return null
  }

  // History is sorted by createdAt desc from API, reverse for chronological display
  const chronologicalHistory = [...history].reverse()

  return (
    <Card className="border-0 shadow-lg overflow-hidden">
      <div className="bg-gradient-to-r from-emerald-600 to-teal-600 px-6 py-4">
        <CardTitle className="text-white font-bold flex items-center gap-2">
          <div className="h-8 w-8 rounded-lg bg-white/20 flex items-center justify-center">
            <Clock className="h-4 w-4 text-white" />
          </div>
          Order Timeline
        </CardTitle>
      </div>
      <CardContent className="p-6">
        <div className="relative pl-8">
          {/* Vertical line */}
          <div className="absolute left-[15px] top-2 bottom-2 w-0.5 bg-gradient-to-b from-gray-200 via-gray-200 to-gray-100" />

          {chronologicalHistory.map((entry, idx) => {
            const config = statusConfig[entry.status] || defaultConfig
            const Icon = config.icon
            const isLatest = idx === chronologicalHistory.length - 1

            return (
              <motion.div
                key={entry.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.08, duration: 0.3 }}
                className="relative flex items-start gap-4 pb-6 last:pb-0"
              >
                {/* Timeline dot */}
                <div
                  className={`absolute left-[-21px] h-8 w-8 rounded-full flex items-center justify-center z-10 shadow-md ${
                    isLatest
                      ? `${config.dotClass} ring-4 ring-white`
                      : 'bg-white border-2 border-gray-200 text-gray-400'
                  }`}
                >
                  {isLatest ? (
                    <Icon className="h-4 w-4 text-white" />
                  ) : (
                    <Icon className="h-3.5 w-3.5" />
                  )}
                </div>

                {/* Content */}
                <div className="flex-1 ml-2 min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge
                      className={`text-xs border font-semibold ${config.badgeClass}`}
                    >
                      {config.label}
                    </Badge>
                    {isLatest && (
                      <Badge className="bg-emerald-100 text-emerald-700 border-0 text-[10px] h-5 px-2 font-semibold">
                        Current
                      </Badge>
                    )}
                  </div>

                  {/* Note */}
                  {entry.note && (
                    <p className="text-xs text-gray-500 mt-1 leading-relaxed">
                      {entry.note}
                    </p>
                  )}

                  {/* Timestamp */}
                  <div className="flex items-center gap-2 mt-1.5">
                    <span className="text-[11px] text-gray-400" title={formatFullDate(entry.createdAt)}>
                      {formatRelativeTime(entry.createdAt)}
                    </span>
                    <span className="text-[11px] text-gray-300">•</span>
                    <span className="text-[11px] text-gray-400">
                      {formatFullDate(entry.createdAt)}
                    </span>
                  </div>
                </div>
              </motion.div>
            )
          })}
        </div>

        {/* Timeline summary */}
        <div className="mt-5 pt-4 border-t flex items-center gap-3 bg-gray-50/50 rounded-xl p-4">
          <div className="h-10 w-10 rounded-xl bg-emerald-100 flex items-center justify-center flex-shrink-0">
            <ShieldCheck className="h-5 w-5 text-emerald-600" />
          </div>
          <div>
            <p className="text-xs text-gray-500">Total status changes</p>
            <span className="font-bold text-gray-900 text-sm">
              {history.length} update{history.length !== 1 ? 's' : ''}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
