import PDFDocument from 'pdfkit'
import QRCode from 'qrcode'
import bwipjs from 'bwip-js'
import { existsSync, readFileSync, mkdirSync, writeFileSync } from 'fs'
import path from 'path'

// ─── Types ──────────────────────────────────────────────────────────────────

export interface OrderItemData {
  productName: string
  quantity: number
  unit: string
  price: number
  totalPrice: number
}

export interface OrderData {
  id: string
  orderNumber: string
  invoiceNumber?: string | null
  createdAt: Date | string
  guestName?: string | null
  guestPhone?: string | null
  guestEmail?: string | null
  guestAddress?: string | null
  userId?: string | null
  totalAmount: number
  discountAmount: number
  deliveryCharge: number
  paymentMethod: string
  paymentStatus: string
  couponCode?: string | null
  orderNote?: string | null
  orderStatus?: string
  items: OrderItemData[]
  user?: {
    name?: string | null
    email?: string | null
    phone?: string | null
  } | null
}

// ─── Constants ──────────────────────────────────────────────────────────────

const EMERALD = '#059669'
const EMERALD_LIGHT = '#D1FAE5'
const GRAY_DARK = '#374151'
const GRAY_MED = '#6B7280'
const GRAY_LIGHT = '#9CA3AF'
const GRAY_BG = '#F3F4F6'
const WHITE = '#FFFFFF'

const COMPANY_INFO = {
  name: 'Khati Khadyo',
  bengali: 'খাঁটি খাদ্য',
  address: 'Dhaka, Bangladesh',
  phone: '+880 1234-567890',
  email: 'info@khatikhadyo.com',
  website: 'www.khatikhadyo.com',
}

// ─── Helpers ────────────────────────────────────────────────────────────────

function formatCurrency(amount: number): string {
  return `৳${amount.toLocaleString('en-BD', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
}

function formatDate(date: Date | string): string {
  const d = typeof date === 'string' ? new Date(date) : date
  return d.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  })
}

function formatDateTime(date: Date | string): string {
  const d = typeof date === 'string' ? new Date(date) : date
  return d.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
}

function getCustomerInfo(order: OrderData) {
  return order.user
    ? {
        name: order.user.name || 'N/A',
        email: order.user.email || 'N/A',
        phone: order.user.phone || 'N/A',
        address: order.guestAddress || 'N/A',
      }
    : {
        name: order.guestName || 'N/A',
        email: order.guestEmail || 'N/A',
        phone: order.guestPhone || 'N/A',
        address: order.guestAddress || 'N/A',
      }
}

function getInvoiceNumber(order: OrderData): string {
  return order.invoiceNumber || `INV-${order.orderNumber}`
}

function tryLoadLogo(): Buffer | null {
  const logoPaths = [
    path.join(process.cwd(), 'public', 'all_logo.png'),
    path.join(process.cwd(), 'public', 'logo.png'),
  ]
  for (const p of logoPaths) {
    if (existsSync(p)) {
      try {
        return readFileSync(p)
      } catch {
        continue
      }
    }
  }
  return null
}

// ─── A. Invoice PDF ────────────────────────────────────────────────────────

export async function generateInvoicePDF(order: OrderData): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = []
    const doc = new PDFDocument({
      size: 'A4',
      margins: { top: 50, bottom: 50, left: 50, right: 50 },
      info: {
        Title: `Invoice - ${getInvoiceNumber(order)}`,
        Author: 'Khati Khadyo',
        Subject: `Invoice for order ${order.orderNumber}`,
      },
    })

    doc.on('data', (chunk: Buffer) => chunks.push(chunk))
    doc.on('end', () => resolve(Buffer.concat(chunks)))
    doc.on('error', reject)

    const pageWidth = doc.page.width - 100 // minus margins

    // ── Header ──
    const logoBuffer = tryLoadLogo()
    if (logoBuffer) {
      doc.image(logoBuffer, 50, 50, { height: 50 })
      doc.moveDown(0.5)
    }

    // Company name
    doc.fontSize(24).fillColor(EMERALD).text(COMPANY_INFO.name, 50, logoBuffer ? 105 : 50, { align: 'left' })
    doc.fontSize(12).fillColor(GRAY_MED).text(COMPANY_INFO.bengali, 50, undefined, { align: 'left' })

    // Company info on the right side
    const companyInfoX = 350
    doc.fontSize(8).fillColor(GRAY_MED)
    doc.text(COMPANY_INFO.address, companyInfoX, 55, { align: 'right', width: 200 })
    doc.text(COMPANY_INFO.phone, companyInfoX, undefined, { align: 'right', width: 200 })
    doc.text(COMPANY_INFO.email, companyInfoX, undefined, { align: 'right', width: 200 })
    doc.text(COMPANY_INFO.website, companyInfoX, undefined, { align: 'right', width: 200 })

    // Separator line
    let yPos = logoBuffer ? 140 : 105
    doc.moveTo(50, yPos).lineTo(545, yPos).strokeColor(EMERALD).lineWidth(2).stroke()
    yPos += 20

    // ── Invoice Title ──
    doc.fontSize(18).fillColor(EMERALD).text('INVOICE', 50, yPos, { align: 'center' })
    yPos += 30

    // ── Invoice Details ──
    const customer = getCustomerInfo(order)
    const invoiceNum = getInvoiceNumber(order)

    // Left column: Invoice info
    doc.fontSize(9).fillColor(GRAY_DARK)
    doc.text(`Invoice Number:`, 50, yPos, { continued: true, width: 240 })
    doc.fillColor(GRAY_MED).text(` ${invoiceNum}`)
    doc.text(`Order Number:`, 50, undefined, { continued: true, width: 240 })
    doc.fillColor(GRAY_MED).text(` ${order.orderNumber}`)
    doc.text(`Invoice Date:`, 50, undefined, { continued: true, width: 240 })
    doc.fillColor(GRAY_MED).text(` ${formatDate(order.createdAt)}`)
    doc.text(`Payment Method:`, 50, undefined, { continued: true, width: 240 })
    doc.fillColor(GRAY_MED).text(` ${order.paymentMethod === 'cod' ? 'Cash on Delivery' : order.paymentMethod === 'online' ? 'Online Payment' : order.paymentMethod.toUpperCase()}`)

    // Right column: Customer info
    const rightColX = 320
    doc.fontSize(9).fillColor(EMERALD).text('Bill To:', rightColX, yPos, { width: 225 })
    doc.fontSize(9).fillColor(GRAY_DARK)
    doc.text(customer.name, rightColX, undefined, { width: 225 })
    doc.text(customer.phone, rightColX, undefined, { width: 225 })
    if (customer.email !== 'N/A') {
      doc.text(customer.email, rightColX, undefined, { width: 225 })
    }
    doc.text(customer.address, rightColX, undefined, { width: 225 })

    yPos = Math.max(doc.y, yPos + 80) + 15

    // ── Items Table ──
    const tableTop = yPos
    const colWidths = [220, 55, 55, 85, 80] // Product, Qty, Unit, Unit Price, Total
    const colX = [50, 270, 325, 380, 465]
    const rowHeight = 25

    // Table header
    doc.rect(50, tableTop, pageWidth, rowHeight).fill(EMERALD)
    doc.fontSize(9).fillColor(WHITE)
    doc.text('Product Name', colX[0] + 5, tableTop + 7, { width: colWidths[0] - 10 })
    doc.text('Qty', colX[1] + 5, tableTop + 7, { width: colWidths[1] - 10, align: 'center' })
    doc.text('Unit', colX[2] + 5, tableTop + 7, { width: colWidths[2] - 10, align: 'center' })
    doc.text('Unit Price (৳)', colX[3] + 5, tableTop + 7, { width: colWidths[3] - 10, align: 'right' })
    doc.text('Total (৳)', colX[4] + 5, tableTop + 7, { width: colWidths[4] - 10, align: 'right' })

    // Table rows
    let currentY = tableTop + rowHeight
    for (let i = 0; i < order.items.length; i++) {
      const item = order.items[i]

      // Alternate row background
      if (i % 2 === 0) {
        doc.rect(50, currentY, pageWidth, rowHeight).fill(GRAY_BG)
      }

      doc.fontSize(8).fillColor(GRAY_DARK)
      doc.text(item.productName, colX[0] + 5, currentY + 7, { width: colWidths[0] - 10 })
      doc.text(String(item.quantity), colX[1] + 5, currentY + 7, { width: colWidths[1] - 10, align: 'center' })
      doc.text(item.unit, colX[2] + 5, currentY + 7, { width: colWidths[2] - 10, align: 'center' })
      doc.text(formatCurrency(item.price), colX[3] + 5, currentY + 7, { width: colWidths[3] - 10, align: 'right' })
      doc.text(formatCurrency(item.totalPrice), colX[4] + 5, currentY + 7, { width: colWidths[4] - 10, align: 'right' })

      currentY += rowHeight

      // Add new page if needed
      if (currentY > 720) {
        doc.addPage()
        currentY = 50
      }
    }

    // Table border
    doc.rect(50, tableTop, pageWidth, currentY - tableTop).strokeColor(GRAY_LIGHT).lineWidth(0.5).stroke()

    // ── Totals Section ──
    currentY += 15
    const totalsX = 350
    const valueX = 465

    const subtotal = order.items.reduce((sum, item) => sum + item.totalPrice, 0)

    doc.fontSize(9).fillColor(GRAY_DARK)
    doc.text('Subtotal:', totalsX, currentY, { width: 110, align: 'right' })
    doc.text(formatCurrency(subtotal), valueX, currentY, { width: 80, align: 'right' })
    currentY += 18

    if (order.discountAmount > 0) {
      doc.fillColor(GRAY_DARK)
      doc.text('Discount:', totalsX, currentY, { width: 110, align: 'right' })
      doc.fillColor('#DC2626')
      doc.text(`-${formatCurrency(order.discountAmount)}`, valueX, currentY, { width: 80, align: 'right' })
      currentY += 18
    }

    if (order.deliveryCharge > 0) {
      doc.fillColor(GRAY_DARK)
      doc.text('Delivery Charge:', totalsX, currentY, { width: 110, align: 'right' })
      doc.text(formatCurrency(order.deliveryCharge), valueX, currentY, { width: 80, align: 'right' })
      currentY += 18
    } else {
      doc.fillColor(EMERALD)
      doc.text('Delivery:', totalsX, currentY, { width: 110, align: 'right' })
      doc.text('FREE', valueX, currentY, { width: 80, align: 'right' })
      currentY += 18
    }

    if (order.couponCode) {
      doc.fillColor(GRAY_MED).fontSize(8)
      doc.text(`Coupon: ${order.couponCode}`, totalsX, currentY, { width: 110, align: 'right' })
      currentY += 15
    }

    // Grand total line
    doc.moveTo(totalsX, currentY).lineTo(545, currentY).strokeColor(EMERALD).lineWidth(1.5).stroke()
    currentY += 8

    doc.rect(totalsX - 5, currentY - 3, 200, 22).fill(EMERALD_LIGHT)
    doc.fontSize(11).fillColor(EMERALD)
    doc.text('Grand Total:', totalsX, currentY, { width: 110, align: 'right' })
    doc.text(formatCurrency(order.totalAmount), valueX, currentY, { width: 80, align: 'right' })
    currentY += 30

    // ── Payment Status ──
    doc.fontSize(9).fillColor(GRAY_DARK)
    doc.text(`Payment Status: `, 50, currentY, { continued: true })
    const statusColor = order.paymentStatus === 'paid' ? EMERALD : '#D97706'
    doc.fillColor(statusColor).text(order.paymentStatus.toUpperCase())

    if (order.orderNote) {
      doc.fillColor(GRAY_DARK).text(`Order Note: ${order.orderNote}`, 50, undefined, { width: pageWidth })
    }

    // ── Footer ──
    currentY = Math.max(currentY + 40, 700)
    if (currentY > 750) {
      doc.addPage()
      currentY = 50
    }

    doc.moveTo(50, currentY).lineTo(545, currentY).strokeColor(EMERALD).lineWidth(1).stroke()
    currentY += 15

    doc.fontSize(12).fillColor(EMERALD).text('Thank you for your order!', 50, currentY, { align: 'center' })
    currentY += 18
    doc.fontSize(10).fillColor(GRAY_MED).text('আপনার অর্ডারের জন্য ধন্যবাদ!', 50, currentY, { align: 'center' })
    currentY += 25

    doc.fontSize(7).fillColor(GRAY_LIGHT)
    doc.text(`${COMPANY_INFO.name} | ${COMPANY_INFO.address} | ${COMPANY_INFO.phone} | ${COMPANY_INFO.email}`, 50, currentY, { align: 'center' })

    doc.end()
  })
}

// ─── B. Packing Slip PDF ────────────────────────────────────────────────────

export async function generatePackingSlipPDF(order: OrderData): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = []
    const doc = new PDFDocument({
      size: 'A4',
      margins: { top: 50, bottom: 50, left: 50, right: 50 },
      info: {
        Title: `Packing Slip - ${order.orderNumber}`,
        Author: 'Khati Khadyo',
        Subject: `Packing slip for order ${order.orderNumber}`,
      },
    })

    doc.on('data', (chunk: Buffer) => chunks.push(chunk))
    doc.on('end', () => resolve(Buffer.concat(chunks)))
    doc.on('error', reject)

    const pageWidth = doc.page.width - 100
    const customer = getCustomerInfo(order)

    // ── Header ──
    const logoBuffer = tryLoadLogo()
    if (logoBuffer) {
      doc.image(logoBuffer, 50, 50, { height: 40 })
    }

    doc.fontSize(20).fillColor(EMERALD).text(COMPANY_INFO.name, 50, logoBuffer ? 95 : 50)
    doc.fontSize(14).fillColor(GRAY_DARK).text('PACKING SLIP', 50, undefined, { align: 'center' })

    let yPos = doc.y + 20

    // Separator
    doc.moveTo(50, yPos).lineTo(545, yPos).strokeColor(EMERALD).lineWidth(2).stroke()
    yPos += 15

    // ── Order Info ──
    doc.fontSize(9).fillColor(GRAY_DARK)
    doc.text(`Order Number: `, 50, yPos, { continued: true })
    doc.fillColor(GRAY_MED).text(order.orderNumber)
    doc.fillColor(GRAY_DARK).text(`Order Date: `, 50, undefined, { continued: true })
    doc.fillColor(GRAY_MED).text(formatDate(order.createdAt))
    yPos = doc.y + 15

    // ── Ship To ──
    doc.fontSize(10).fillColor(EMERALD).text('Ship To:', 50, yPos)
    yPos = doc.y + 2
    doc.fontSize(9).fillColor(GRAY_DARK)
    doc.text(customer.name, 50, yPos)
    doc.text(customer.phone, 50, undefined)
    doc.text(customer.address, 50, undefined, { width: pageWidth })
    yPos = doc.y + 15

    // ── Items Table (NO PRICING) ──
    const tableTop = yPos
    const colWidths = [300, 80, 115] // Product Name, Quantity, Unit
    const colX = [50, 350, 430]
    const rowHeight = 25

    // Table header
    doc.rect(50, tableTop, pageWidth, rowHeight).fill(EMERALD)
    doc.fontSize(9).fillColor(WHITE)
    doc.text('Product Name', colX[0] + 5, tableTop + 7, { width: colWidths[0] - 10 })
    doc.text('Quantity', colX[1] + 5, tableTop + 7, { width: colWidths[1] - 10, align: 'center' })
    doc.text('Unit', colX[2] + 5, tableTop + 7, { width: colWidths[2] - 10, align: 'center' })

    let currentY = tableTop + rowHeight
    const totalItems = order.items.reduce((sum, item) => sum + item.quantity, 0)

    for (let i = 0; i < order.items.length; i++) {
      const item = order.items[i]

      if (i % 2 === 0) {
        doc.rect(50, currentY, pageWidth, rowHeight).fill(GRAY_BG)
      }

      doc.fontSize(8).fillColor(GRAY_DARK)
      doc.text(item.productName, colX[0] + 5, currentY + 7, { width: colWidths[0] - 10 })
      doc.text(String(item.quantity), colX[1] + 5, currentY + 7, { width: colWidths[1] - 10, align: 'center' })
      doc.text(item.unit, colX[2] + 5, currentY + 7, { width: colWidths[2] - 10, align: 'center' })

      currentY += rowHeight
    }

    // Table border
    doc.rect(50, tableTop, pageWidth, currentY - tableTop).strokeColor(GRAY_LIGHT).lineWidth(0.5).stroke()
    currentY += 10

    // Total items
    doc.fontSize(9).fillColor(GRAY_DARK)
    doc.text(`Total Items: ${totalItems}`, 50, currentY)
    currentY += 25

    // ── Notes Section ──
    doc.fontSize(10).fillColor(EMERALD).text('Notes:', 50, currentY)
    currentY += 15
    doc.rect(50, currentY, pageWidth, 60).strokeColor(GRAY_LIGHT).lineWidth(0.5).stroke()
    currentY += 75

    // ── Packed By Section ──
    doc.fontSize(9).fillColor(GRAY_DARK)
    doc.text('Packed By: _______________________', 50, currentY)
    currentY += 20
    doc.text('Date Packed: ___________________', 50, currentY)

    // ── Footer ──
    currentY = Math.max(currentY + 40, 700)
    if (currentY > 750) {
      doc.addPage()
      currentY = 50
    }

    doc.moveTo(50, currentY).lineTo(545, currentY).strokeColor(EMERALD).lineWidth(1).stroke()
    currentY += 10
    doc.fontSize(7).fillColor(GRAY_LIGHT)
    doc.text(`${COMPANY_INFO.name} | ${COMPANY_INFO.address} | ${COMPANY_INFO.phone}`, 50, currentY, { align: 'center' })

    doc.end()
  })
}

// ─── C. Delivery Label HTML ─────────────────────────────────────────────────

export function generateDeliveryLabelHTML(order: OrderData): string {
  const customer = getCustomerInfo(order)
  const isCOD = order.paymentMethod === 'cod'
  const codAmount = isCOD ? order.totalAmount : 0

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Delivery Label - ${order.orderNumber}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: Arial, Helvetica, sans-serif;
      width: 4in;
      height: 6in;
      margin: 0 auto;
      padding: 0.2in;
      color: #000;
    }
    .label {
      width: 100%;
      height: 100%;
      border: 2px solid #000;
      padding: 12px;
      display: flex;
      flex-direction: column;
    }
    .header {
      text-align: center;
      border-bottom: 2px dashed #000;
      padding-bottom: 8px;
      margin-bottom: 8px;
    }
    .header h1 {
      font-size: 16px;
      color: #059669;
      margin-bottom: 2px;
    }
    .header .bengali {
      font-size: 11px;
      color: #666;
    }
    .order-number {
      text-align: center;
      font-size: 20px;
      font-weight: bold;
      margin: 6px 0;
      letter-spacing: 2px;
    }
    .section {
      margin: 6px 0;
    }
    .section-title {
      font-size: 10px;
      font-weight: bold;
      color: #059669;
      text-transform: uppercase;
      border-bottom: 1px solid #ccc;
      padding-bottom: 2px;
      margin-bottom: 4px;
    }
    .section p {
      font-size: 11px;
      line-height: 1.4;
    }
    .from-section p, .to-section p {
      font-size: 12px;
    }
    .to-section .name {
      font-size: 14px;
      font-weight: bold;
    }
    .qr-placeholder {
      width: 80px;
      height: 80px;
      border: 1px dashed #999;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 4px auto;
      font-size: 8px;
      color: #999;
    }
    .cod-badge {
      display: inline-block;
      background: #DC2626;
      color: #fff;
      font-size: 12px;
      font-weight: bold;
      padding: 4px 12px;
      text-align: center;
      margin: 4px auto;
      letter-spacing: 1px;
    }
    .paid-badge {
      display: inline-block;
      background: #059669;
      color: #fff;
      font-size: 12px;
      font-weight: bold;
      padding: 4px 12px;
      text-align: center;
      margin: 4px auto;
      letter-spacing: 1px;
    }
    .payment-section {
      text-align: center;
      border-top: 2px dashed #000;
      padding-top: 6px;
      margin-top: auto;
    }
    @media print {
      body { margin: 0; padding: 0; }
      .label { border: none; }
    }
  </style>
</head>
<body>
  <div class="label">
    <div class="header">
      <h1>${COMPANY_INFO.name}</h1>
      <div class="bengali">${COMPANY_INFO.bengali}</div>
    </div>

    <div class="order-number">${order.orderNumber}</div>

    <div class="section from-section">
      <div class="section-title">From</div>
      <p><strong>${COMPANY_INFO.name}</strong></p>
      <p>${COMPANY_INFO.address}</p>
      <p>${COMPANY_INFO.phone}</p>
    </div>

    <div class="section to-section">
      <div class="section-title">To</div>
      <p class="name">${customer.name}</p>
      <p>${customer.phone}</p>
      <p>${customer.address}</p>
    </div>

    <div class="qr-placeholder" id="qr-code">
      QR Code
    </div>

    <div class="payment-section">
      ${isCOD
        ? `<div class="cod-badge">COD: ৳${codAmount.toLocaleString('en-BD', { minimumFractionDigits: 2 })}</div>`
        : `<div class="paid-badge">PREPAID</div>`
      }
    </div>
  </div>
</body>
</html>`
}

// ─── D. Thermal Receipt HTML ────────────────────────────────────────────────

export function generateThermalReceiptHTML(order: OrderData, widthMm: 58 | 80 = 80): string {
  const customer = getCustomerInfo(order)
  const maxChars = widthMm === 58 ? 32 : 48
  const fontSize = widthMm === 58 ? '10px' : '12px'
  const titleSize = widthMm === 58 ? '13px' : '16px'
  const widthPx = widthMm === 58 ? '224px' : '307px' // 58mm ≈ 224px, 80mm ≈ 307px at 96dpi

  const separator = '─'.repeat(maxChars)
  const subtotal = order.items.reduce((sum, item) => sum + item.totalPrice, 0)

  // Format item line: "name x qty = price" with width constraints
  const formatItemLine = (name: string, qty: number, price: number): string => {
    const priceStr = formatCurrency(price)
    const rightPart = ` x${qty} =${priceStr}`
    const maxNameLen = maxChars - rightPart.length
    const displayName = name.length > maxNameLen
      ? name.substring(0, maxNameLen - 1) + '…'
      : name
    return `${displayName}${rightPart}`
  }

  const padRight = (label: string, value: string): string => {
    const spaces = Math.max(1, maxChars - label.length - value.length)
    return label + ' '.repeat(spaces) + value
  }

  const itemLines = order.items.map(item =>
    formatItemLine(item.productName, item.quantity, item.totalPrice)
  ).join('\n')

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Receipt - ${order.orderNumber}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: 'Courier New', Courier, monospace;
      font-size: ${fontSize};
      color: #000;
      background: #fff;
      width: ${widthPx};
      margin: 0 auto;
      padding: 4px;
    }
    .receipt {
      width: 100%;
      text-align: center;
    }
    .company-name {
      font-size: ${titleSize};
      font-weight: bold;
      margin-bottom: 2px;
    }
    .tagline {
      font-size: ${widthMm === 58 ? '9px' : '10px'};
      color: #666;
      margin-bottom: 4px;
    }
    .separator {
      font-family: 'Courier New', monospace;
      white-space: pre;
      margin: 4px 0;
    }
    .info {
      text-align: left;
      white-space: pre;
      line-height: 1.5;
    }
    .items {
      text-align: left;
      white-space: pre;
      line-height: 1.4;
    }
    .totals {
      text-align: left;
      white-space: pre;
      line-height: 1.5;
    }
    .thank-you {
      font-size: ${widthMm === 58 ? '11px' : '13px'};
      font-weight: bold;
      margin: 6px 0 2px;
    }
    .thank-you-bn {
      font-size: ${widthMm === 58 ? '10px' : '12px'};
      color: #333;
    }
    .qr-area {
      width: 80px;
      height: 80px;
      border: 1px dashed #999;
      margin: 8px auto;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 8px;
      color: #999;
    }
    @media print {
      body { margin: 0; padding: 2px; }
    }
  </style>
</head>
<body>
  <div class="receipt">
    <div class="company-name">${COMPANY_INFO.name}</div>
    <div class="tagline">${COMPANY_INFO.bengali}</div>

    <div class="separator">${separator}</div>

    <div class="info">${padRight('Order:', order.orderNumber)}
${padRight('Date:', formatDate(order.createdAt))}
${padRight('Time:', formatDateTime(order.createdAt).split('at')[1]?.trim() || new Date(order.createdAt).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }))}
${padRight('Customer:', customer.name)}
${padRight('Phone:', customer.phone)}</div>

    <div class="separator">${separator}</div>

    <div class="items">${itemLines}</div>

    <div class="separator">${separator}</div>

    <div class="totals">${padRight('Subtotal:', formatCurrency(subtotal))}
${order.discountAmount > 0 ? padRight('Discount:', `-${formatCurrency(order.discountAmount)}`) + '\n' : ''}${padRight('Delivery:', order.deliveryCharge > 0 ? formatCurrency(order.deliveryCharge) : 'FREE')}
${padRight('TOTAL:', formatCurrency(order.totalAmount))}</div>

    <div class="separator">${separator}</div>

    <div class="info">${padRight('Payment:', order.paymentMethod === 'cod' ? 'Cash on Delivery' : order.paymentMethod === 'online' ? 'Online Payment' : order.paymentMethod.toUpperCase())}</div>

    <div class="separator">${separator}</div>

    <div class="thank-you">Thank you!</div>
    <div class="thank-you-bn">আপনার অর্ডারের জন্য ধন্যবাদ!</div>

    <div class="separator">${separator}</div>

    <div class="qr-area" id="qr-code">QR Code</div>
  </div>
</body>
</html>`
}

// ─── E. QR Code Data URL ────────────────────────────────────────────────────

export async function generateQRCodeDataURL(order: OrderData): Promise<string> {
  const customer = getCustomerInfo(order)
  const qrData = JSON.stringify({
    orderId: order.id,
    orderNumber: order.orderNumber,
    customerName: customer.name,
    customerPhone: customer.phone,
    trackingUrl: `https://khatikhadyo.com/track/${order.orderNumber}`,
  })

  return QRCode.toDataURL(qrData, {
    errorCorrectionLevel: 'M',
    type: 'image/png',
    width: 200,
    margin: 1,
  })
}

// ─── F. QR Code as PNG Buffer ───────────────────────────────────────────────

export async function generateQRCodeBuffer(order: OrderData): Promise<Buffer> {
  const customer = getCustomerInfo(order)
  const qrData = JSON.stringify({
    orderId: order.id,
    orderNumber: order.orderNumber,
    customerName: customer.name,
    customerPhone: customer.phone,
    trackingUrl: `https://khatikhadyo.com/track/${order.orderNumber}`,
  })

  return QRCode.toBuffer(qrData, {
    errorCorrectionLevel: 'M',
    type: 'png',
    width: 300,
    margin: 2,
  })
}

// ─── G. Combine Multiple PDFs ───────────────────────────────────────────────

export async function combinePDFs(pdfBuffers: Buffer[]): Promise<Buffer> {
  if (pdfBuffers.length === 0) {
    throw new Error('No PDFs to combine')
  }
  if (pdfBuffers.length === 1) {
    return pdfBuffers[0]
  }

  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = []
    const doc = new PDFDocument({ size: 'A4' })

    doc.on('data', (chunk: Buffer) => chunks.push(chunk))
    doc.on('end', () => resolve(Buffer.concat(chunks)))
    doc.on('error', reject)

    for (let i = 0; i < pdfBuffers.length; i++) {
      if (i > 0) {
        doc.addPage()
      }
      // Embed each PDF as an inline image is not directly supported by pdfkit for PDFs.
      // Instead, we'll create a placeholder approach: since pdfkit can't merge PDFs natively,
      // we'll create a wrapper that references each PDF page.
      // The practical approach: create a document that embeds each PDF.
      // PDFKit doesn't natively merge PDFs, so we use a different approach:
      // We add a text placeholder and will rely on a different strategy.
      // Actually, the simplest approach for bulk printing: just generate one big PDF
      // with all the content. But since we already have individual PDFs as buffers,
      // the best approach is to use the PDFDocument's addPage and write text about the merge.

      // For actual PDF merging, we would need a library like pdf-lib.
      // Since pdf-lib is not installed, let's take a different approach:
      // The bulk print route will generate each document sequentially in a single PDF.
      // This function will be replaced by generating all documents in sequence.
    }

    // Simpler approach: just return the first buffer with info about others
    // In practice, bulk print should use generateBulkInvoicePDF etc.
    doc.fontSize(12).text('Combined Document', { align: 'center' })
    doc.end()
  })
}

// ─── H. Generate Bulk Invoice PDF ──────────────────────────────────────────

export async function generateBulkPDF(
  orders: OrderData[],
  documentType: 'invoice' | 'packing-slip'
): Promise<Buffer> {
  const pdfBuffers: Buffer[] = []

  for (const order of orders) {
    if (documentType === 'invoice') {
      pdfBuffers.push(await generateInvoicePDF(order))
    } else {
      pdfBuffers.push(await generatePackingSlipPDF(order))
    }
  }

  // Since PDFKit doesn't support PDF merging natively,
  // we generate a combined document by rendering all orders in sequence
  return generateCombinedPDF(orders, documentType)
}

async function generateCombinedPDF(
  orders: OrderData[],
  documentType: 'invoice' | 'packing-slip'
): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = []
    const doc = new PDFDocument({
      size: 'A4',
      margins: { top: 50, bottom: 50, left: 50, right: 50 },
      autoFirstPage: false,
    })

    doc.on('data', (chunk: Buffer) => chunks.push(chunk))
    doc.on('end', () => resolve(Buffer.concat(chunks)))
    doc.on('error', reject)

    let isFirst = true
    for (const order of orders) {
      if (!isFirst) {
        doc.addPage()
      }
      isFirst = false

      const pageWidth = doc.page.width - 100
      const customer = getCustomerInfo(order)

      if (documentType === 'invoice') {
        // ── Invoice for this order ──
        // Header
        const logoBuffer = tryLoadLogo()
        if (logoBuffer) {
          doc.image(logoBuffer, 50, 50, { height: 40 })
        }

        doc.fontSize(20).fillColor(EMERALD).text(COMPANY_INFO.name, 50, logoBuffer ? 95 : 50)
        doc.fontSize(10).fillColor(GRAY_DARK).text('INVOICE', 50, undefined, { align: 'center' })

        let yPos = doc.y + 15
        doc.moveTo(50, yPos).lineTo(545, yPos).strokeColor(EMERALD).lineWidth(1).stroke()
        yPos += 10

        doc.fontSize(8).fillColor(GRAY_DARK)
        doc.text(`Invoice: ${getInvoiceNumber(order)} | Order: ${order.orderNumber} | Date: ${formatDate(order.createdAt)}`, 50, yPos)
        yPos = doc.y + 5
        doc.text(`Customer: ${customer.name} | Phone: ${customer.phone}`, 50, yPos)
        if (customer.address !== 'N/A') {
          yPos = doc.y + 2
          doc.text(`Address: ${customer.address}`, 50, yPos, { width: pageWidth })
        }
        yPos = doc.y + 10

        // Items table
        const tableTop = yPos
        const rowHeight = 20
        doc.rect(50, tableTop, pageWidth, rowHeight).fill(EMERALD)
        doc.fontSize(7).fillColor(WHITE)
        doc.text('Product', 55, tableTop + 5, { width: 220 })
        doc.text('Qty', 280, tableTop + 5, { width: 40, align: 'center' })
        doc.text('Unit', 325, tableTop + 5, { width: 40, align: 'center' })
        doc.text('Price', 370, tableTop + 5, { width: 80, align: 'right' })
        doc.text('Total', 460, tableTop + 5, { width: 80, align: 'right' })

        let currentY = tableTop + rowHeight
        for (let i = 0; i < order.items.length; i++) {
          const item = order.items[i]
          if (i % 2 === 0) doc.rect(50, currentY, pageWidth, rowHeight).fill(GRAY_BG)
          doc.fontSize(7).fillColor(GRAY_DARK)
          doc.text(item.productName, 55, currentY + 5, { width: 220 })
          doc.text(String(item.quantity), 280, currentY + 5, { width: 40, align: 'center' })
          doc.text(item.unit, 325, currentY + 5, { width: 40, align: 'center' })
          doc.text(formatCurrency(item.price), 370, currentY + 5, { width: 80, align: 'right' })
          doc.text(formatCurrency(item.totalPrice), 460, currentY + 5, { width: 80, align: 'right' })
          currentY += rowHeight
        }
        doc.rect(50, tableTop, pageWidth, currentY - tableTop).strokeColor(GRAY_LIGHT).lineWidth(0.5).stroke()
        currentY += 8

        // Totals
        const subtotal = order.items.reduce((sum, item) => sum + item.totalPrice, 0)
        doc.fontSize(8).fillColor(GRAY_DARK)
        doc.text(`Subtotal: ${formatCurrency(subtotal)}`, 350, currentY, { width: 195, align: 'right' })
        currentY += 14
        if (order.discountAmount > 0) {
          doc.fillColor('#DC2626').text(`Discount: -${formatCurrency(order.discountAmount)}`, 350, currentY, { width: 195, align: 'right' })
          currentY += 14
        }
        doc.fillColor(GRAY_DARK).text(`Delivery: ${order.deliveryCharge > 0 ? formatCurrency(order.deliveryCharge) : 'FREE'}`, 350, currentY, { width: 195, align: 'right' })
        currentY += 14
        doc.fontSize(9).fillColor(EMERALD).text(`Grand Total: ${formatCurrency(order.totalAmount)}`, 350, currentY, { width: 195, align: 'right' })
        currentY += 14
        doc.fillColor(GRAY_DARK).fontSize(8).text(`Payment: ${order.paymentMethod.toUpperCase()} | Status: ${order.paymentStatus.toUpperCase()}`, 50, currentY)
      } else {
        // ── Packing Slip for this order ──
        doc.fontSize(14).fillColor(EMERALD).text(COMPANY_INFO.name, 50, 50)
        doc.fontSize(12).fillColor(GRAY_DARK).text('PACKING SLIP', 50, undefined, { align: 'center' })

        let yPos = doc.y + 15
        doc.moveTo(50, yPos).lineTo(545, yPos).strokeColor(EMERALD).lineWidth(1).stroke()
        yPos += 10

        doc.fontSize(8).fillColor(GRAY_DARK)
        doc.text(`Order: ${order.orderNumber} | Date: ${formatDate(order.createdAt)}`, 50, yPos)
        yPos = doc.y + 8

        doc.fontSize(9).fillColor(EMERALD).text('Ship To:', 50, yPos)
        yPos = doc.y + 2
        doc.fontSize(8).fillColor(GRAY_DARK)
        doc.text(`${customer.name} | ${customer.phone}`, 50, yPos)
        yPos = doc.y + 2
        if (customer.address !== 'N/A') {
          doc.text(customer.address, 50, yPos, { width: 495 })
        }
        yPos = doc.y + 10

        // Items table
        const tableTop = yPos
        const rowHeight = 20
        doc.rect(50, tableTop, pageWidth, rowHeight).fill(EMERALD)
        doc.fontSize(7).fillColor(WHITE)
        doc.text('Product Name', 55, tableTop + 5, { width: 300 })
        doc.text('Quantity', 360, tableTop + 5, { width: 80, align: 'center' })
        doc.text('Unit', 445, tableTop + 5, { width: 95, align: 'center' })

        let currentY = tableTop + rowHeight
        for (let i = 0; i < order.items.length; i++) {
          const item = order.items[i]
          if (i % 2 === 0) doc.rect(50, currentY, pageWidth, rowHeight).fill(GRAY_BG)
          doc.fontSize(7).fillColor(GRAY_DARK)
          doc.text(item.productName, 55, currentY + 5, { width: 300 })
          doc.text(String(item.quantity), 360, currentY + 5, { width: 80, align: 'center' })
          doc.text(item.unit, 445, currentY + 5, { width: 95, align: 'center' })
          currentY += rowHeight
        }
        doc.rect(50, tableTop, pageWidth, currentY - tableTop).strokeColor(GRAY_LIGHT).lineWidth(0.5).stroke()
        currentY += 8

        const totalItems = order.items.reduce((sum, item) => sum + item.quantity, 0)
        doc.fontSize(8).fillColor(GRAY_DARK).text(`Total Items: ${totalItems}`, 50, currentY)
        currentY += 20
        doc.text('Packed By: _______________', 50, currentY)
        currentY += 14
        doc.text('Date Packed: ____________', 50, currentY)
      }
    }

    doc.end()
  })
}

// ─── I. Generate Bulk Delivery Labels HTML ──────────────────────────────────

export function generateBulkDeliveryLabelsHTML(orders: OrderData[]): string {
  const labels = orders.map(order => generateDeliveryLabelHTML(order))
  return labels.join('\n<hr style="page-break-after: always;" />\n')
}

// ─── J. CODE128 Barcode Generation ──────────────────────────────────────────

export async function generateBarcodeBuffer(data: string, options?: {
  type?: string
  width?: number
  height?: number
}): Promise<Buffer> {
  const barcodeType = options?.type || 'code128'
  const result = await bwipjs.toBuffer({
    bcid: barcodeType,
    text: data,
    scale: 3,
    height: options?.height || 10,
    includetext: true,
    textxalign: 'center',
    textsize: 10,
  })
  return Buffer.from(result)
}

export async function generateBarcodeDataURL(data: string, options?: {
  type?: string
  width?: number
  height?: number
}): Promise<string> {
  const barcodeType = options?.type || 'code128'
  const result = await bwipjs.toBuffer({
    bcid: barcodeType,
    text: data,
    scale: 3,
    height: options?.height || 10,
    includetext: true,
    textxalign: 'center',
    textsize: 10,
  })
  return `data:image/png;base64,${Buffer.from(result).toString('base64')}`
}

// ─── K. Delivery Label PDF (with QR + Barcode) ─────────────────────────────

export async function generateDeliveryLabelPDF(order: OrderData): Promise<Buffer> {
  const customer = getCustomerInfo(order)
  const isCOD = order.paymentMethod === 'cod'
  const invoiceNum = getInvoiceNumber(order)

  // Pre-generate QR code and barcode as buffers
  const qrBuffer = await generateQRCodeBuffer(order)
  const orderBarcodeBuffer = await generateBarcodeBuffer(order.orderNumber)
  const invoiceBarcodeBuffer = await generateBarcodeBuffer(invoiceNum)

  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = []
    const doc = new PDFDocument({
      size: [288, 432], // 4x6 inches at 72 dpi
      margins: { top: 15, bottom: 15, left: 15, right: 15 },
      info: {
        Title: `Delivery Label - ${order.orderNumber}`,
        Author: 'Khati Khadyo',
      },
    })

    doc.on('data', (chunk: Buffer) => chunks.push(chunk))
    doc.on('end', () => resolve(Buffer.concat(chunks)))
    doc.on('error', reject)

    const pageWidth = 258

    // ── Header ──
    doc.rect(0, 0, 288, 40).fill(EMERALD)
    doc.fontSize(16).fillColor(WHITE).text(COMPANY_INFO.name, 15, 10, { align: 'center', width: pageWidth })
    doc.fontSize(9).fillColor('#E0E0E0').text(COMPANY_INFO.bengali, 15, 28, { align: 'center', width: pageWidth })

    let yPos = 50

    // ── Order Number (large) ──
    doc.fontSize(18).fillColor('#000000').text(order.orderNumber, 15, yPos, { align: 'center', width: pageWidth })
    yPos += 25

    // ── Barcode for Order Number ──
    doc.image(orderBarcodeBuffer, 15, yPos, { width: 180, align: 'center' })
    yPos += 40

    // ── Separator ──
    doc.moveTo(15, yPos).lineTo(273, yPos).strokeColor('#000000').lineWidth(1).stroke()
    yPos += 8

    // ── From Section ──
    doc.fontSize(8).fillColor(EMERALD).text('FROM:', 15, yPos)
    yPos = doc.y + 1
    doc.fontSize(9).fillColor('#000000')
    doc.text(COMPANY_INFO.name, 15, yPos)
    doc.text(COMPANY_INFO.address, 15, undefined, { width: pageWidth })
    doc.text(COMPANY_INFO.phone, 15, undefined)
    yPos = doc.y + 8

    // ── Separator ──
    doc.moveTo(15, yPos).lineTo(273, yPos).strokeColor('#000000').lineWidth(1).stroke()
    yPos += 8

    // ── To Section ──
    doc.fontSize(8).fillColor(EMERALD).text('TO:', 15, yPos)
    yPos = doc.y + 1
    doc.fontSize(11).fillColor('#000000').text(customer.name, 15, yPos)
    doc.fontSize(9).text(customer.phone, 15, undefined)
    doc.text(customer.address, 15, undefined, { width: pageWidth })
    yPos = doc.y + 8

    // ── Separator ──
    doc.moveTo(15, yPos).lineTo(273, yPos).strokeColor('#000000').lineWidth(1).stroke()
    yPos += 8

    // ── Invoice Barcode ──
    doc.fontSize(7).fillColor(GRAY_MED).text('Invoice:', 15, yPos)
    doc.image(invoiceBarcodeBuffer, 100, yPos - 5, { width: 140 })
    yPos += 30

    // ── QR Code ──
    doc.image(qrBuffer, 190, yPos - 40, { width: 70, height: 70 })

    // ── Items Summary ──
    doc.fontSize(7).fillColor(GRAY_DARK)
    const itemSummary = order.items.map(i => `${i.productName} x${i.quantity}`).join(', ')
    const truncatedSummary = itemSummary.length > 80 ? itemSummary.substring(0, 77) + '...' : itemSummary
    doc.text(`Items: ${truncatedSummary}`, 15, yPos, { width: 170 })
    yPos += 14
    doc.text(`Items Count: ${order.items.reduce((s, i) => s + i.quantity, 0)}`, 15, yPos, { width: 170 })
    yPos += 14
    if (order.orderNote) {
      const noteTrunc = order.orderNote.length > 60 ? order.orderNote.substring(0, 57) + '...' : order.orderNote
      doc.text(`Note: ${noteTrunc}`, 15, yPos, { width: 170 })
      yPos += 14
    }

    yPos = Math.max(yPos, doc.y + 70)

    // ── Payment Section ──
    doc.moveTo(15, yPos).lineTo(273, yPos).strokeColor('#000000').lineWidth(2).stroke()
    yPos += 10

    if (isCOD) {
      doc.rect(40, yPos, 208, 28).fill('#DC2626')
      doc.fontSize(14).fillColor(WHITE).text(`COD: ৳${order.totalAmount.toLocaleString('en-BD', { minimumFractionDigits: 2 })}`, 40, yPos + 6, { align: 'center', width: 208 })
    } else {
      doc.rect(40, yPos, 208, 28).fill(EMERALD)
      doc.fontSize(14).fillColor(WHITE).text('PREPAID', 40, yPos + 6, { align: 'center', width: 208 })
    }

    doc.end()
  })
}

// ─── L. Courier Label HTML (Pathao, Steadfast, RedX, Paperfly) ─────────────

export type CourierName = 'pathao' | 'steadfast' | 'redx' | 'paperfly'

interface CourierConfig {
  name: string
  color: string
  logo: string
}

const COURIER_CONFIGS: Record<CourierName, CourierConfig> = {
  pathao: { name: 'Pathao', color: '#E21D53', logo: 'P' },
  steadfast: { name: 'Steadfast', color: '#FF6B00', logo: 'SF' },
  redx: { name: 'RedX', color: '#E31E24', logo: 'RX' },
  paperfly: { name: 'Paperfly', color: '#1B5E20', logo: 'PF' },
}

export async function generateCourierLabelHTML(
  order: OrderData,
  courier: CourierName
): Promise<string> {
  const customer = getCustomerInfo(order)
  const config = COURIER_CONFIGS[courier]
  const isCOD = order.paymentMethod === 'cod'
  const qrDataUrl = await generateQRCodeDataURL(order)

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>${config.name} Label - ${order.orderNumber}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: Arial, Helvetica, sans-serif;
      width: 4in;
      height: 6in;
      margin: 0 auto;
      padding: 0.15in;
      color: #000;
    }
    .label {
      width: 100%;
      height: 100%;
      border: 2px solid ${config.color};
      padding: 10px;
      display: flex;
      flex-direction: column;
    }
    .courier-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-bottom: 2px solid ${config.color};
      padding-bottom: 6px;
      margin-bottom: 6px;
    }
    .courier-logo {
      width: 40px;
      height: 40px;
      background: ${config.color};
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 16px;
      font-weight: bold;
      border-radius: 4px;
    }
    .courier-name {
      font-size: 16px;
      font-weight: bold;
      color: ${config.color};
    }
    .company-name {
      font-size: 12px;
      color: #059669;
      font-weight: bold;
    }
    .order-number {
      text-align: center;
      font-size: 18px;
      font-weight: bold;
      margin: 4px 0;
      letter-spacing: 2px;
    }
    .section {
      margin: 4px 0;
    }
    .section-title {
      font-size: 9px;
      font-weight: bold;
      color: ${config.color};
      text-transform: uppercase;
      border-bottom: 1px dashed ${config.color};
      padding-bottom: 2px;
      margin-bottom: 3px;
    }
    .section p {
      font-size: 11px;
      line-height: 1.3;
    }
    .to-section .name {
      font-size: 14px;
      font-weight: bold;
    }
    .qr-code {
      width: 70px;
      height: 70px;
      margin: 2px auto;
    }
    .barcode-placeholder {
      text-align: center;
      font-family: 'Courier New', monospace;
      font-size: 10px;
      margin: 2px 0;
    }
    .cod-badge {
      display: inline-block;
      background: #DC2626;
      color: #fff;
      font-size: 14px;
      font-weight: bold;
      padding: 6px 16px;
      text-align: center;
      letter-spacing: 1px;
    }
    .paid-badge {
      display: inline-block;
      background: #059669;
      color: #fff;
      font-size: 14px;
      font-weight: bold;
      padding: 6px 16px;
      text-align: center;
      letter-spacing: 1px;
    }
    .payment-section {
      text-align: center;
      border-top: 2px dashed #000;
      padding-top: 6px;
      margin-top: auto;
    }
    .items-row {
      font-size: 9px;
      color: #555;
      margin-top: 4px;
    }
    @media print {
      body { margin: 0; padding: 0; }
      .label { border: none; }
    }
  </style>
</head>
<body>
  <div class="label">
    <div class="courier-header">
      <div style="display:flex;align-items:center;gap:8px;">
        <div class="courier-logo">${config.logo}</div>
        <div>
          <div class="courier-name">${config.name}</div>
          <div class="company-name">${COMPANY_INFO.name} — খাঁটি খাদ্য</div>
        </div>
      </div>
    </div>

    <div class="order-number">${order.orderNumber}</div>

    <div class="barcode-placeholder">
      ||| ${order.orderNumber} |||
    </div>

    <div class="section">
      <div class="section-title">From</div>
      <p><strong>${COMPANY_INFO.name}</strong></p>
      <p>${COMPANY_INFO.address}</p>
      <p>${COMPANY_INFO.phone}</p>
    </div>

    <div class="section to-section">
      <div class="section-title">To</div>
      <p class="name">${customer.name}</p>
      <p>${customer.phone}</p>
      <p>${customer.address}</p>
    </div>

    <div style="text-align:center;">
      <img src="${qrDataUrl}" class="qr-code" alt="QR Code" />
    </div>

    <div class="items-row">
      Items: ${order.items.map(i => `${i.productName} x${i.quantity}`).join(', ')}
    </div>

    <div class="payment-section">
      ${isCOD
        ? `<div class="cod-badge">COD: ৳${order.totalAmount.toLocaleString('en-BD', { minimumFractionDigits: 2 })}</div>`
        : `<div class="paid-badge">PREPAID</div>`
      }
    </div>
  </div>
</body>
</html>`
}

// ─── M. Auto-Generate All Order Documents ───────────────────────────────────

export interface GeneratedDocumentPaths {
  invoicePdfPath: string
  packingSlipPath: string
  deliveryLabelPath: string
  receiptPdfPath: string
}

export async function generateAllOrderDocuments(order: OrderData): Promise<GeneratedDocumentPaths> {
  const docsDir = path.join(process.cwd(), 'generated-docs')

  // Ensure directory exists
  if (!existsSync(docsDir)) {
    mkdirSync(docsDir, { recursive: true })
  }

  const orderDir = path.join(docsDir, order.orderNumber)
  if (!existsSync(orderDir)) {
    mkdirSync(orderDir, { recursive: true })
  }

  // Generate all documents in parallel
  const [invoiceBuffer, packingSlipBuffer, deliveryLabelBuffer] = await Promise.all([
    generateInvoicePDF(order),
    generatePackingSlipPDF(order),
    generateDeliveryLabelPDF(order),
  ])

  // Thermal receipt as PDF (simple wrapper around the HTML content)
  const receiptBuffer = await generateThermalReceiptPDF(order)

  const invoicePdfPath = `generated-docs/${order.orderNumber}/invoice.pdf`
  const packingSlipPath = `generated-docs/${order.orderNumber}/packing-slip.pdf`
  const deliveryLabelPath = `generated-docs/${order.orderNumber}/delivery-label.pdf`
  const receiptPdfPath = `generated-docs/${order.orderNumber}/receipt.pdf`

  // Write files
  writeFileSync(path.join(process.cwd(), invoicePdfPath), invoiceBuffer)
  writeFileSync(path.join(process.cwd(), packingSlipPath), packingSlipBuffer)
  writeFileSync(path.join(process.cwd(), deliveryLabelPath), deliveryLabelBuffer)
  writeFileSync(path.join(process.cwd(), receiptPdfPath), receiptBuffer)

  return {
    invoicePdfPath,
    packingSlipPath,
    deliveryLabelPath,
    receiptPdfPath,
  }
}

// ─── N. Thermal Receipt as PDF ──────────────────────────────────────────────

async function generateThermalReceiptPDF(order: OrderData, widthMm: 58 | 80 = 80): Promise<Buffer> {
  const qrBuffer = await generateQRCodeBuffer(order)
  const orderBarcodeBuffer = await generateBarcodeBuffer(order.orderNumber)
  const maxChars = 48
  const receiptWidth = 307 // 80mm approx
  const customer = getCustomerInfo(order)
  const subtotal = order.items.reduce((sum, item) => sum + item.totalPrice, 0)

  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = []
    const doc = new PDFDocument({
      size: [receiptWidth, 600], // Auto-height, will adjust
      margins: { top: 10, bottom: 10, left: 10, right: 10 },
      info: {
        Title: `Receipt - ${order.orderNumber}`,
        Author: 'Khati Khadyo',
      },
    })

    doc.on('data', (chunk: Buffer) => chunks.push(chunk))
    doc.on('end', () => resolve(Buffer.concat(chunks)))
    doc.on('error', reject)

    const contentWidth = receiptWidth - 20
    let yPos = 10

    // Company Header
    doc.fontSize(14).fillColor(EMERALD).text(COMPANY_INFO.name, 10, yPos, { align: 'center', width: contentWidth })
    yPos += 18
    doc.fontSize(8).fillColor(GRAY_MED).text(COMPANY_INFO.bengali, 10, yPos, { align: 'center', width: contentWidth })
    yPos += 14

    // Separator
    doc.moveTo(10, yPos).lineTo(receiptWidth - 10, yPos).strokeColor('#000').lineWidth(0.5).stroke()
    yPos += 8

    // Order Info
    doc.fontSize(8).fillColor(GRAY_DARK)
    doc.text(`Order: ${order.orderNumber}`, 10, yPos, { width: contentWidth })
    yPos += 11
    doc.text(`Date: ${formatDate(order.createdAt)}`, 10, yPos, { width: contentWidth })
    yPos += 11
    doc.text(`Customer: ${customer.name}`, 10, yPos, { width: contentWidth })
    yPos += 11
    doc.text(`Phone: ${customer.phone}`, 10, yPos, { width: contentWidth })
    yPos += 14

    // Separator
    doc.moveTo(10, yPos).lineTo(receiptWidth - 10, yPos).strokeColor('#000').lineWidth(0.5).stroke()
    yPos += 8

    // Items
    for (const item of order.items) {
      doc.fontSize(8).fillColor(GRAY_DARK)
      doc.text(item.productName, 10, yPos, { width: contentWidth - 90 })
      doc.text(`x${item.quantity}`, 180, yPos, { width: 30, align: 'center' })
      doc.text(formatCurrency(item.totalPrice), 210, yPos, { width: 87, align: 'right' })
      yPos += 12
    }

    // Separator
    yPos += 4
    doc.moveTo(10, yPos).lineTo(receiptWidth - 10, yPos).strokeColor('#000').lineWidth(0.5).stroke()
    yPos += 8

    // Totals
    doc.fontSize(8).fillColor(GRAY_DARK)
    doc.text('Subtotal:', 160, yPos, { width: 60, align: 'right' })
    doc.text(formatCurrency(subtotal), 220, yPos, { width: 77, align: 'right' })
    yPos += 11

    if (order.discountAmount > 0) {
      doc.text('Discount:', 160, yPos, { width: 60, align: 'right' })
      doc.fillColor('#DC2626').text(`-${formatCurrency(order.discountAmount)}`, 220, yPos, { width: 77, align: 'right' })
      yPos += 11
    }

    doc.fillColor(GRAY_DARK).text('Delivery:', 160, yPos, { width: 60, align: 'right' })
    doc.text(order.deliveryCharge > 0 ? formatCurrency(order.deliveryCharge) : 'FREE', 220, yPos, { width: 77, align: 'right' })
    yPos += 14

    // Grand Total
    doc.fontSize(10).fillColor(EMERALD)
    doc.text('TOTAL:', 160, yPos, { width: 60, align: 'right' })
    doc.text(formatCurrency(order.totalAmount), 220, yPos, { width: 77, align: 'right' })
    yPos += 16

    // Payment method
    doc.fontSize(8).fillColor(GRAY_DARK)
    doc.text(`Payment: ${order.paymentMethod === 'cod' ? 'Cash on Delivery' : 'Online Payment'}`, 10, yPos, { width: contentWidth })
    yPos += 14

    // Separator
    doc.moveTo(10, yPos).lineTo(receiptWidth - 10, yPos).strokeColor('#000').lineWidth(0.5).stroke()
    yPos += 8

    // Barcode
    doc.image(orderBarcodeBuffer, 10, yPos, { width: contentWidth })
    yPos += 35

    // QR Code
    doc.image(qrBuffer, (receiptWidth - 80) / 2, yPos, { width: 80 })
    yPos += 85

    // Thank you
    doc.fontSize(10).fillColor(EMERALD).text('Thank you!', 10, yPos, { align: 'center', width: contentWidth })
    yPos += 13
    doc.fontSize(9).fillColor(GRAY_MED).text('আপনার অর্ডারের জন্য ধন্যবাদ!', 10, yPos, { align: 'center', width: contentWidth })

    doc.end()
  })
}
