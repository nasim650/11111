import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserRoleFromRequest, isAdmin } from '@/lib/utils'
import { generateBulkPDF, generateBulkDeliveryLabelsHTML } from '@/lib/print-utils'
import type { OrderData } from '@/lib/print-utils'

export async function POST(request: NextRequest) {
  try {
    const role = await getUserRoleFromRequest(request)

    // Admin-only access
    if (!isAdmin(role)) {
      return NextResponse.json(
        { success: false, error: 'Forbidden: Admin access required' },
        { status: 403 }
      )
    }

    const body = await request.json()
    const { orderIds, documentType } = body as {
      orderIds: string[]
      documentType: 'invoice' | 'packing-slip' | 'delivery-label'
    }

    if (!orderIds || !Array.isArray(orderIds) || orderIds.length === 0) {
      return NextResponse.json(
        { success: false, error: 'orderIds must be a non-empty array' },
        { status: 400 }
      )
    }

    if (!['invoice', 'packing-slip', 'delivery-label'].includes(documentType)) {
      return NextResponse.json(
        { success: false, error: 'documentType must be invoice, packing-slip, or delivery-label' },
        { status: 400 }
      )
    }

    // Fetch all orders
    const orders = await db.order.findMany({
      where: { id: { in: orderIds } },
      include: {
        items: true,
        payment: true,
        user: { select: { id: true, name: true, email: true, phone: true } },
      },
      orderBy: { createdAt: 'desc' },
    })

    if (orders.length === 0) {
      return NextResponse.json(
        { success: false, error: 'No orders found with the given IDs' },
        { status: 404 }
      )
    }

    // Convert to OrderData format
    const orderDataList: OrderData[] = orders.map((order) => ({
      id: order.id,
      orderNumber: order.orderNumber,
      invoiceNumber: order.invoiceNumber,
      createdAt: order.createdAt,
      guestName: order.guestName,
      guestPhone: order.guestPhone,
      guestEmail: order.guestEmail,
      guestAddress: order.guestAddress,
      userId: order.userId,
      totalAmount: order.totalAmount,
      discountAmount: order.discountAmount,
      deliveryCharge: order.deliveryCharge,
      paymentMethod: order.paymentMethod,
      paymentStatus: order.paymentStatus,
      couponCode: order.couponCode,
      orderNote: order.orderNote,
      orderStatus: order.orderStatus,
      items: order.items.map((item) => ({
        productName: item.productName,
        quantity: item.quantity,
        unit: item.unit,
        price: item.price,
        totalPrice: Math.round(item.price * item.quantity * 100) / 100,
      })),
      user: order.user
        ? {
            name: order.user.name,
            email: order.user.email,
            phone: order.user.phone,
          }
        : null,
    }))

    // Generate document based on type
    if (documentType === 'delivery-label') {
      // Return HTML for delivery labels
      const html = generateBulkDeliveryLabelsHTML(orderDataList)
      return new NextResponse(html, {
        status: 200,
        headers: {
          'Content-Type': 'text/html; charset=utf-8',
        },
      })
    }

    // Generate combined PDF for invoices and packing slips
    const pdfBuffer = await generateBulkPDF(orderDataList, documentType as 'invoice' | 'packing-slip')

    const filename = documentType === 'invoice'
      ? 'bulk-invoices.pdf'
      : 'bulk-packing-slips.pdf'

    return new NextResponse(new Uint8Array(pdfBuffer), {
      status: 200,
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="${filename}"`,
        'Content-Length': String(pdfBuffer.length),
      },
    })
  } catch (error) {
    console.error('Bulk print error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
