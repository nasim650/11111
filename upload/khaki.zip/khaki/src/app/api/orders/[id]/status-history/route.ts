import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserRoleFromRequest, getUserIdFromRequest, isAdmin } from '@/lib/utils'

const VALID_STATUSES = ['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled', 'refunded']

// GET /api/orders/[id]/status-history — Return all status history entries for an order
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const role = await getUserRoleFromRequest(request)
    const userId = await getUserIdFromRequest(request)

    // Verify order exists and user has access
    const order = await db.order.findUnique({
      where: { id },
      select: { id: true, userId: true },
    })

    if (!order) {
      return NextResponse.json(
        { success: false, error: 'Order not found' },
        { status: 404 }
      )
    }

    // Non-admin users can only see their own order history
    if (!isAdmin(role) && order.userId !== userId) {
      return NextResponse.json(
        { success: false, error: 'Forbidden' },
        { status: 403 }
      )
    }

    const history = await db.orderStatusHistory.findMany({
      where: { orderId: id },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json({
      success: true,
      data: history,
    })
  } catch (error) {
    console.error('Get status history error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// POST /api/orders/[id]/status-history — Add a new status history entry
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const role = await getUserRoleFromRequest(request)

    if (!isAdmin(role)) {
      return NextResponse.json(
        { success: false, error: 'Forbidden: Admin access required' },
        { status: 403 }
      )
    }

    const body = await request.json()
    const { status, note } = body

    if (!status || !VALID_STATUSES.includes(status)) {
      return NextResponse.json(
        { success: false, error: `Invalid status. Must be one of: ${VALID_STATUSES.join(', ')}` },
        { status: 400 }
      )
    }

    // Verify order exists
    const order = await db.order.findUnique({
      where: { id },
      select: { id: true, orderStatus: true },
    })

    if (!order) {
      return NextResponse.json(
        { success: false, error: 'Order not found' },
        { status: 404 }
      )
    }

    const userId = await getUserIdFromRequest(request)

    // Create status history entry and update order status in a transaction
    const [historyEntry] = await db.$transaction([
      db.orderStatusHistory.create({
        data: {
          orderId: id,
          status,
          note: note || null,
          changedBy: userId || null,
        },
      }),
      db.order.update({
        where: { id },
        data: { orderStatus: status },
      }),
    ])

    return NextResponse.json({
      success: true,
      data: historyEntry,
    }, { status: 201 })
  } catch (error) {
    console.error('Create status history error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
