import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserRoleFromRequest, isAdmin } from '@/lib/utils'
import { generatePackingSlipPDF } from '@/lib/print-utils'
import type { OrderData } from '@/lib/print-utils'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const role = await getUserRoleFromRequest(request)

    // Admin-only access
    if (!isAdmin(role)) {
      return NextResponse.json(
        { success: false, error: 'Forbidden: Admin access required' },
        { status: 403 }
      )
    }

    const order = await db.order.findUnique({
      where: { id },
      include: {
        items: true,
        payment: true,
        user: { select: { id: true, name: true, email: true, phone: true } },
      },
    })

    if (!order) {
      return NextResponse.json(
        { success: false, error: 'Order not found' },
        { status: 404 }
      )
    }

    const url = new URL(request.url)
    const format = url.searchParams.get('format')

    // Build packing slip data
    const customerInfo = order.user
      ? {
          name: order.user.name || 'N/A',
          email: order.user.email || 'N/A',
          phone: order.user.phone || 'N/A',
          address: order.guestAddress || 'N/A',
        }
      : {
          name: order.guestName || 'N/A',
          email: order.guestEmail || 'N/A',
          phone: order.guestPhone || 'N/A',
          address: order.guestAddress || 'N/A',
        }

    const totalItems = order.items.reduce((sum, item) => sum + item.quantity, 0)

    if (format === 'pdf') {
      const orderData: OrderData = {
        id: order.id,
        orderNumber: order.orderNumber,
        invoiceNumber: order.invoiceNumber,
        createdAt: order.createdAt,
        guestName: order.guestName,
        guestPhone: order.guestPhone,
        guestEmail: order.guestEmail,
        guestAddress: order.guestAddress,
        userId: order.userId,
        totalAmount: order.totalAmount,
        discountAmount: order.discountAmount,
        deliveryCharge: order.deliveryCharge,
        paymentMethod: order.paymentMethod,
        paymentStatus: order.paymentStatus,
        couponCode: order.couponCode,
        orderNote: order.orderNote,
        orderStatus: order.orderStatus,
        items: order.items.map((item) => ({
          productName: item.productName,
          quantity: item.quantity,
          unit: item.unit,
          price: item.price,
          totalPrice: Math.round(item.price * item.quantity * 100) / 100,
        })),
        user: order.user
          ? {
              name: order.user.name,
              email: order.user.email,
              phone: order.user.phone,
            }
          : null,
      }

      const pdfBuffer = await generatePackingSlipPDF(orderData)

      return new NextResponse(new Uint8Array(pdfBuffer), {
        status: 200,
        headers: {
          'Content-Type': 'application/pdf',
          'Content-Disposition': `attachment; filename="packing-slip-${order.orderNumber}.pdf"`,
          'Content-Length': String(pdfBuffer.length),
        },
      })
    }

    // Default: return JSON
    const packingSlip = {
      orderNumber: order.orderNumber,
      orderDate: order.createdAt,
      orderStatus: order.orderStatus,
      shipTo: customerInfo,
      items: order.items.map((item) => ({
        productName: item.productName,
        quantity: item.quantity,
        unit: item.unit,
      })),
      totalItems,
      orderNote: order.orderNote || null,
    }

    return NextResponse.json({
      success: true,
      data: packingSlip,
    })
  } catch (error) {
    console.error('Get packing slip error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
