import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserIdFromRequest, getUserRoleFromRequest, isAdmin } from '@/lib/utils'
import { generateBarcodeBuffer } from '@/lib/print-utils'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const userId = await getUserIdFromRequest(request)
    const role = await getUserRoleFromRequest(request)

    const order = await db.order.findUnique({
      where: { id },
      select: { id: true, orderNumber: true, invoiceNumber: true, userId: true },
    })

    if (!order) {
      return NextResponse.json(
        { success: false, error: 'Order not found' },
        { status: 404 }
      )
    }

    // Non-admin users can only view their own barcodes
    if (!isAdmin(role) && order.userId !== userId) {
      return NextResponse.json(
        { success: false, error: 'Forbidden' },
        { status: 403 }
      )
    }

    const url = new URL(request.url)
    const data = url.searchParams.get('data') || order.orderNumber
    const barcodeType = url.searchParams.get('type') || 'code128'

    // Validate data for CODE128 - must be ASCII
    const sanitizedData = data.replace(/[^\x20-\x7E]/g, '')

    const barcodeBuffer = await generateBarcodeBuffer(sanitizedData, {
      type: barcodeType,
      height: 10,
    })

    return new NextResponse(new Uint8Array(barcodeBuffer), {
      status: 200,
      headers: {
        'Content-Type': 'image/png',
        'Content-Disposition': `inline; filename="barcode-${sanitizedData}.png"`,
        'Content-Length': String(barcodeBuffer.length),
        'Cache-Control': 'public, max-age=3600',
      },
    })
  } catch (error) {
    console.error('Get barcode error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
