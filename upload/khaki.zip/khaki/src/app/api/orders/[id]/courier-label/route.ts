import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserRoleFromRequest, isAdmin } from '@/lib/utils'
import { generateCourierLabelHTML, generateDeliveryLabelPDF } from '@/lib/print-utils'
import type { OrderData, CourierName } from '@/lib/print-utils'

const VALID_COURIERS: CourierName[] = ['pathao', 'steadfast', 'redx', 'paperfly']

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const role = await getUserRoleFromRequest(request)

    // Admin-only access
    if (!isAdmin(role)) {
      return NextResponse.json(
        { success: false, error: 'Forbidden: Admin access required' },
        { status: 403 }
      )
    }

    const order = await db.order.findUnique({
      where: { id },
      include: {
        items: true,
        payment: true,
        user: { select: { id: true, name: true, email: true, phone: true } },
      },
    })

    if (!order) {
      return NextResponse.json(
        { success: false, error: 'Order not found' },
        { status: 404 }
      )
    }

    const url = new URL(request.url)
    const courier = (url.searchParams.get('courier') || 'pathao') as CourierName
    const format = url.searchParams.get('format')

    if (!VALID_COURIERS.includes(courier)) {
      return NextResponse.json(
        { success: false, error: `Invalid courier. Must be one of: ${VALID_COURIERS.join(', ')}` },
        { status: 400 }
      )
    }

    const orderData: OrderData = {
      id: order.id,
      orderNumber: order.orderNumber,
      invoiceNumber: order.invoiceNumber,
      createdAt: order.createdAt,
      guestName: order.guestName,
      guestPhone: order.guestPhone,
      guestEmail: order.guestEmail,
      guestAddress: order.guestAddress,
      userId: order.userId,
      totalAmount: order.totalAmount,
      discountAmount: order.discountAmount,
      deliveryCharge: order.deliveryCharge,
      paymentMethod: order.paymentMethod,
      paymentStatus: order.paymentStatus,
      couponCode: order.couponCode,
      orderNote: order.orderNote,
      orderStatus: order.orderStatus,
      items: order.items.map((item) => ({
        productName: item.productName,
        quantity: item.quantity,
        unit: item.unit,
        price: item.price,
        totalPrice: Math.round(item.price * item.quantity * 100) / 100,
      })),
      user: order.user
        ? {
            name: order.user.name,
            email: order.user.email,
            phone: order.user.phone,
          }
        : null,
    }

    if (format === 'pdf') {
      // Use the delivery label PDF with barcode for PDF format
      const pdfBuffer = await generateDeliveryLabelPDF(orderData)

      return new NextResponse(new Uint8Array(pdfBuffer), {
        status: 200,
        headers: {
          'Content-Type': 'application/pdf',
          'Content-Disposition': `attachment; filename="${courier}-label-${order.orderNumber}.pdf"`,
          'Content-Length': String(pdfBuffer.length),
        },
      })
    }

    // Default: return HTML for print dialog
    const html = await generateCourierLabelHTML(orderData, courier)

    return new NextResponse(html, {
      status: 200,
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
      },
    })
  } catch (error) {
    console.error('Get courier label error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
