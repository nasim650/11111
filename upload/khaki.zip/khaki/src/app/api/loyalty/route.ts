import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserIdFromRequest } from '@/lib/utils'

// GET: Get current user's loyalty point balance and recent transactions
export async function GET(request: NextRequest) {
  try {
    const userId = await getUserIdFromRequest(request)
    if (!userId) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      )
    }

    const user = await db.user.findUnique({
      where: { id: userId },
      select: { loyaltyBalance: true },
    })

    if (!user) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      )
    }

    const [transactions, totalEarned, totalRedeemed] = await Promise.all([
      db.loyaltyPoint.findMany({
        where: { userId },
        orderBy: { createdAt: 'desc' },
        take: 20,
      }),
      db.loyaltyPoint.aggregate({
        where: { userId, points: { gt: 0 } },
        _sum: { points: true },
      }),
      db.loyaltyPoint.aggregate({
        where: { userId, points: { lt: 0 } },
        _sum: { points: true },
      }),
    ])

    return NextResponse.json({
      success: true,
      data: {
        balance: user.loyaltyBalance,
        totalEarned: totalEarned._sum.points || 0,
        totalRedeemed: Math.abs(totalRedeemed._sum.points || 0),
        transactions,
      },
    })
  } catch (error) {
    console.error('Get loyalty points error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// POST: Redeem points
export async function POST(request: NextRequest) {
  try {
    const userId = await getUserIdFromRequest(request)
    if (!userId) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      )
    }

    const body = await request.json()
    const { points, orderId } = body

    if (!points || points <= 0) {
      return NextResponse.json(
        { success: false, error: 'Points must be a positive number' },
        { status: 400 }
      )
    }

    const user = await db.user.findUnique({
      where: { id: userId },
      select: { loyaltyBalance: true },
    })

    if (!user) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      )
    }

    if (user.loyaltyBalance < points) {
      return NextResponse.json(
        { success: false, error: `Insufficient points. You have ${user.loyaltyBalance} points.` },
        { status: 400 }
      )
    }

    const newBalance = user.loyaltyBalance - points

    const loyaltyPoint = await db.$transaction(async (tx) => {
      const lp = await tx.loyaltyPoint.create({
        data: {
          userId,
          points: -points,
          balance: newBalance,
          type: 'redeem',
          description: `Redeemed ${points} points${orderId ? ` for order` : ''}`,
          orderId: orderId || null,
        },
      })

      await tx.user.update({
        where: { id: userId },
        data: { loyaltyBalance: newBalance },
      })

      return lp
    })

    return NextResponse.json({
      success: true,
      data: {
        pointsRedeemed: points,
        newBalance,
        transaction: loyaltyPoint,
      },
    })
  } catch (error) {
    console.error('Redeem loyalty points error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
