import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserRoleFromRequest, isAdmin, getPaginationParams, paginatedResponse } from '@/lib/utils'

// ─── GET: List Print Queue ───────────────────────────────────────────────────

export async function GET(request: NextRequest) {
  try {
    const role = await getUserRoleFromRequest(request)

    if (!isAdmin(role)) {
      return NextResponse.json(
        { success: false, error: 'Forbidden: Admin access required' },
        { status: 403 }
      )
    }

    const url = new URL(request.url)
    const { page, limit, skip } = getPaginationParams(url)

    const status = url.searchParams.get('status')
    const documentType = url.searchParams.get('documentType')

    const where: Record<string, unknown> = {}
    if (status) where.status = status
    if (documentType) where.documentType = documentType

    const [items, total] = await Promise.all([
      db.printQueue.findMany({
        where,
        include: {
          order: {
            select: {
              id: true,
              orderNumber: true,
              orderStatus: true,
              guestName: true,
              guestPhone: true,
              totalAmount: true,
              paymentMethod: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      db.printQueue.count({ where }),
    ])

    // Queue statistics
    const [pendingCount, printingCount, printedCount, failedCount] = await Promise.all([
      db.printQueue.count({ where: { status: 'PENDING' } }),
      db.printQueue.count({ where: { status: 'PRINTING' } }),
      db.printQueue.count({ where: { status: 'PRINTED' } }),
      db.printQueue.count({ where: { status: 'FAILED' } }),
    ])

    return NextResponse.json({
      success: true,
      data: paginatedResponse(items, total, page, limit),
      stats: {
        pending: pendingCount,
        printing: printingCount,
        printed: printedCount,
        failed: failedCount,
        total: pendingCount + printingCount + printedCount + failedCount,
      },
    })
  } catch (error) {
    console.error('Get print queue error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// ─── POST: Add to Print Queue ────────────────────────────────────────────────

export async function POST(request: NextRequest) {
  try {
    const role = await getUserRoleFromRequest(request)

    if (!isAdmin(role)) {
      return NextResponse.json(
        { success: false, error: 'Forbidden: Admin access required' },
        { status: 403 }
      )
    }

    const body = await request.json()
    const { orderId, documentType } = body as {
      orderId: string
      documentType: string
    }

    if (!orderId || !documentType) {
      return NextResponse.json(
        { success: false, error: 'orderId and documentType are required' },
        { status: 400 }
      )
    }

    const validDocTypes = ['invoice', 'packing-slip', 'delivery-label', 'thermal-receipt', 'courier-label']
    if (!validDocTypes.includes(documentType)) {
      return NextResponse.json(
        { success: false, error: `documentType must be one of: ${validDocTypes.join(', ')}` },
        { status: 400 }
      )
    }

    // Check order exists
    const order = await db.order.findUnique({ where: { id: orderId } })
    if (!order) {
      return NextResponse.json(
        { success: false, error: 'Order not found' },
        { status: 404 }
      )
    }

    const queueItem = await db.printQueue.create({
      data: {
        orderId,
        documentType,
        status: 'PENDING',
        filePath: null,
      },
    })

    return NextResponse.json({ success: true, data: queueItem }, { status: 201 })
  } catch (error) {
    console.error('Create print queue item error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// ─── PATCH: Bulk Update Print Queue ──────────────────────────────────────────

export async function PATCH(request: NextRequest) {
  try {
    const role = await getUserRoleFromRequest(request)

    if (!isAdmin(role)) {
      return NextResponse.json(
        { success: false, error: 'Forbidden: Admin access required' },
        { status: 403 }
      )
    }

    const body = await request.json()
    const { action } = body as { action: string }

    if (action === 'mark-all-printed') {
      // Mark all PENDING items as PRINTED
      const result = await db.printQueue.updateMany({
        where: { status: 'PENDING' },
        data: { status: 'PRINTED', printedAt: new Date() },
      })

      return NextResponse.json({
        success: true,
        message: `Marked ${result.count} items as PRINTED`,
      })
    }

    if (action === 'retry-failed') {
      // Reset all FAILED items to PENDING
      const result = await db.printQueue.updateMany({
        where: { status: 'FAILED' },
        data: { status: 'PENDING', error: null },
      })

      return NextResponse.json({
        success: true,
        message: `Reset ${result.count} FAILED items to PENDING`,
      })
    }

    if (action === 'clear-printed') {
      // Delete all PRINTED items
      const result = await db.printQueue.deleteMany({
        where: { status: 'PRINTED' },
      })

      return NextResponse.json({
        success: true,
        message: `Cleared ${result.count} PRINTED items`,
      })
    }

    return NextResponse.json(
      { success: false, error: 'Invalid action. Use: mark-all-printed, retry-failed, or clear-printed' },
      { status: 400 }
    )
  } catch (error) {
    console.error('Bulk update print queue error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
