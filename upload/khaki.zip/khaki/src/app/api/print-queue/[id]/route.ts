import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserRoleFromRequest, isAdmin } from '@/lib/utils'

// ─── GET: Single Print Queue Item ────────────────────────────────────────────

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const role = await getUserRoleFromRequest(request)

    if (!isAdmin(role)) {
      return NextResponse.json(
        { success: false, error: 'Forbidden: Admin access required' },
        { status: 403 }
      )
    }

    const item = await db.printQueue.findUnique({
      where: { id },
      include: {
        order: {
          select: {
            id: true,
            orderNumber: true,
            orderStatus: true,
            guestName: true,
            guestPhone: true,
            totalAmount: true,
            paymentMethod: true,
          },
        },
      },
    })

    if (!item) {
      return NextResponse.json(
        { success: false, error: 'Print queue item not found' },
        { status: 404 }
      )
    }

    return NextResponse.json({ success: true, data: item })
  } catch (error) {
    console.error('Get print queue item error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// ─── PATCH: Update Print Queue Item Status ───────────────────────────────────

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const role = await getUserRoleFromRequest(request)

    if (!isAdmin(role)) {
      return NextResponse.json(
        { success: false, error: 'Forbidden: Admin access required' },
        { status: 403 }
      )
    }

    const body = await request.json()
    const { status, filePath, error: errorMessage } = body as {
      status?: string
      filePath?: string
      error?: string
    }

    const validStatuses = ['PENDING', 'PRINTING', 'PRINTED', 'FAILED']
    if (status && !validStatuses.includes(status)) {
      return NextResponse.json(
        { success: false, error: `Status must be one of: ${validStatuses.join(', ')}` },
        { status: 400 }
      )
    }

    const existing = await db.printQueue.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json(
        { success: false, error: 'Print queue item not found' },
        { status: 404 }
      )
    }

    const updateData: Record<string, unknown> = {}
    if (status) {
      updateData.status = status
      if (status === 'PRINTED') {
        updateData.printedAt = new Date()
      }
    }
    if (filePath !== undefined) updateData.filePath = filePath
    if (errorMessage !== undefined) updateData.error = errorMessage

    const updated = await db.printQueue.update({
      where: { id },
      data: updateData,
    })

    return NextResponse.json({ success: true, data: updated })
  } catch (error) {
    console.error('Update print queue item error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// ─── DELETE: Remove Print Queue Item ─────────────────────────────────────────

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const role = await getUserRoleFromRequest(request)

    if (!isAdmin(role)) {
      return NextResponse.json(
        { success: false, error: 'Forbidden: Admin access required' },
        { status: 403 }
      )
    }

    const existing = await db.printQueue.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json(
        { success: false, error: 'Print queue item not found' },
        { status: 404 }
      )
    }

    await db.printQueue.delete({ where: { id } })

    return NextResponse.json({
      success: true,
      message: 'Print queue item deleted',
    })
  } catch (error) {
    console.error('Delete print queue item error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
