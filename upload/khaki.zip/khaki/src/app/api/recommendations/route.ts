import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// Enhanced recommendations endpoint - supports categoryId and excludeProductId params
export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const productId = url.searchParams.get('productId')
    const categoryId = url.searchParams.get('categoryId')
    const excludeProductId = url.searchParams.get('excludeProductId')
    const limitParam = url.searchParams.get('limit')
    const limit = Math.min(8, Math.max(1, parseInt(limitParam || '8')))

    // IDs to exclude from results
    const excludeIds: string[] = []
    if (productId) excludeIds.push(productId)
    if (excludeProductId && !excludeIds.includes(excludeProductId)) {
      excludeIds.push(excludeProductId)
    }

    // Determine the source category
    let sourceCategoryId: string | null = null

    if (categoryId) {
      // Use the explicitly provided categoryId
      const cat = await db.category.findFirst({
        where: {
          OR: [
            { id: categoryId },
            { slug: categoryId },
          ],
        },
        select: { id: true },
      })
      sourceCategoryId = cat?.id || null
    } else if (productId) {
      // Derive category from the source product
      const sourceProduct = await db.product.findUnique({
        where: { id: productId },
        include: {
          images: { where: { isFeatured: true }, take: 1 },
          category: { select: { id: true, name: true } },
        },
      })

      if (!sourceProduct) {
        return NextResponse.json(
          { success: false, error: 'Product not found' },
          { status: 404 }
        )
      }

      sourceCategoryId = sourceProduct.categoryId
    }

    const seenIds = new Set<string>(excludeIds)
    const combined: FormattedProduct[] = []

    // ── Strategy 1: Products from same category ──
    if (sourceCategoryId) {
      const sameCategory = await db.product.findMany({
        where: {
          categoryId: sourceCategoryId,
          id: { notIn: excludeIds.length > 0 ? excludeIds : undefined },
          status: 'active',
          stock: { gt: 0 },
        },
        include: {
          images: { where: { isFeatured: true }, take: 1 },
          category: { select: { id: true, name: true, slug: true } },
        },
        take: limit,
        orderBy: [
          { isBestSeller: 'desc' },
          { createdAt: 'desc' },
        ],
      })

      for (const p of sameCategory) {
        if (!seenIds.has(p.id) && combined.length < limit) {
          seenIds.add(p.id)
          combined.push(formatProduct(p))
        }
      }

      if (combined.length >= limit) {
        return NextResponse.json({ success: true, data: combined })
      }
    }

    // ── Strategy 2: Best-selling products as fallback ──
    const bestSellers = await db.product.findMany({
      where: {
        id: { notIn: Array.from(seenIds).length > 0 ? Array.from(seenIds) : undefined },
        status: 'active',
        stock: { gt: 0 },
        isBestSeller: true,
      },
      include: {
        images: { where: { isFeatured: true }, take: 1 },
        category: { select: { id: true, name: true, slug: true } },
      },
      take: limit - combined.length,
      orderBy: { createdAt: 'desc' },
    })

    for (const p of bestSellers) {
      if (!seenIds.has(p.id) && combined.length < limit) {
        seenIds.add(p.id)
        combined.push(formatProduct(p))
      }
    }

    if (combined.length >= limit) {
      return NextResponse.json({ success: true, data: combined })
    }

    // ── Strategy 3: New arrivals as additional fallback ──
    const newArrivals = await db.product.findMany({
      where: {
        id: { notIn: Array.from(seenIds).length > 0 ? Array.from(seenIds) : undefined },
        status: 'active',
        stock: { gt: 0 },
        isNewArrival: true,
      },
      include: {
        images: { where: { isFeatured: true }, take: 1 },
        category: { select: { id: true, name: true, slug: true } },
      },
      take: limit - combined.length,
      orderBy: { createdAt: 'desc' },
    })

    for (const p of newArrivals) {
      if (!seenIds.has(p.id) && combined.length < limit) {
        seenIds.add(p.id)
        combined.push(formatProduct(p))
      }
    }

    if (combined.length >= limit) {
      return NextResponse.json({ success: true, data: combined })
    }

    // ── Strategy 4: Any active products as final fallback ──
    const moreProducts = await db.product.findMany({
      where: {
        id: { notIn: Array.from(seenIds).length > 0 ? Array.from(seenIds) : undefined },
        status: 'active',
        stock: { gt: 0 },
      },
      include: {
        images: { where: { isFeatured: true }, take: 1 },
        category: { select: { id: true, name: true, slug: true } },
      },
      take: limit - combined.length,
      orderBy: { createdAt: 'desc' },
    })

    for (const p of moreProducts) {
      if (!seenIds.has(p.id) && combined.length < limit) {
        seenIds.add(p.id)
        combined.push(formatProduct(p))
      }
    }

    return NextResponse.json({ success: true, data: combined })
  } catch (error) {
    console.error('Get recommendations error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// ── Type for formatted product ──
interface FormattedProduct {
  id: string
  name: string
  slug: string
  shortDescription: string | null
  price: number
  discountPrice: number | null
  unit: string
  stock: number
  isFeatured: boolean
  isBestSeller: boolean
  isNewArrival: boolean
  image: string | null
  imageAlt: string
  category: { id: string; name: string; slug: string }
}

function formatProduct(product: {
  id: string
  name: string
  slug: string
  shortDescription: string | null
  price: number
  discountPrice: number | null
  unit: string
  stock: number
  isFeatured: boolean
  isBestSeller: boolean
  isNewArrival: boolean
  images: { url: string; alt: string | null }[]
  category: { id: string; name: string; slug: string }
}): FormattedProduct {
  return {
    id: product.id,
    name: product.name,
    slug: product.slug,
    shortDescription: product.shortDescription,
    price: product.price,
    discountPrice: product.discountPrice,
    unit: product.unit,
    stock: product.stock,
    isFeatured: product.isFeatured,
    isBestSeller: product.isBestSeller,
    isNewArrival: product.isNewArrival,
    image: product.images[0]?.url || null,
    imageAlt: product.images[0]?.alt || product.name,
    category: product.category,
  }
}
