# MIGRATION_PLAN.md

> Production migration plan for **Khati Khadyo** — moving from the current
> dev/sandbox state to a production deployment on PostgreSQL (Neon) +
> Cloudinary + real SSLCommerz credentials.
>
> This is a **documentation-only** plan. No implementation code. Derived from
> the project's current architecture (see `PROJECT_CONTEXT.md`, `TASKS.md`,
> `NEXT_TASK.md`).

---

## 1. Current Database Architecture

| Aspect | Current state |
|--------|--------------|
| Provider | `sqlite` (Prisma 6) |
| Canonical DB file | `prisma/dev.db` |
| Stale duplicate | `db/custom.db` (to be deleted — `BUG-3`) |
| Schema file | `prisma/schema.prisma` (30+ models) |
| Migrations | `prisma/migrations/` (used in dev via `db:push` / `db:migrate`) |
| Datasource URL | `DATABASE_URL` env (currently `file:/home/z/my-project/prisma/dev.db`) |
| Client | `src/lib/db.ts` — Prisma client singleton (no per-route instantiation) |
| Schema limitations | No native arrays → `tags`, `specifications`, `deliveryZones`, `content` stored as comma/JSON strings |
| Known issues | `OrderStatusHistory` / `PrintQueue` writes can be lost under dev-container OOM (`BUG-1`, `BUG-2`); SQLite is not safe for concurrent writes |

**Models in scope for migration:** `User`, `Address`, `Category`, `Subcategory`,
`Product`, `ProductImage`, `ProductVideo`, `Banner`, `HomepageSection`,
`MenuItem`, `CartItem`, `Order`, `OrderItem`, `Payment`, `DeliveryLabel`,
`Review`, `Wishlist`, `Coupon`, `ContactMessage`, `PolicyPage`,
`Notification`, `NewsletterSubscriber`, `MediaFile`, `AuditLog`,
`Testimonial`, `FAQItem`, `TeamMember`, `StockNotification`, `Partner`,
`OrderStatusHistory`, `PrintQueue`, `LoyaltyPoint`, `SiteConfig`.

---

## 2. Planned PostgreSQL Migration

### 2.1 Target
- **Provider swap:** `sqlite` → `postgresql` in `prisma/schema.prisma`.
- **Host:** Neon (serverless Postgres) — see §3.
- **Connection string:** `postgresql://USER:PASSWORD@HOST/DB?sslmode=require`.

### 2.2 Schema adjustments required
These are the only schema-level changes needed (no model redesign):

| Change | Reason |
|--------|--------|
| `datasource db { provider = "postgresql" }` | Provider swap |
| Add `@db.Text` to long string columns (`description`, `content`, `message`, `bio`) | Avoid default `VARCHAR(256)` truncation on Postgres |
| Convert comma/JSON string columns to native arrays or `Json` where beneficial (`tags`, `specifications`, `deliveryZones`) | Optional optimisation; keep as-is for v1 if risky |
| Verify `@default(now())` and `@updatedAt` behave identically on Postgres | They do — no change expected |

### 2.3 Migration procedure
1. **Snapshot** the current SQLite data (`prisma/dev.db`) for reference.
2. Update `prisma/schema.prisma` provider to `postgresql`.
3. Run `bun run db:generate` (regenerate Prisma client for Postgres).
4. Create the Neon database (§3) and set `DATABASE_URL` to the Neon connection string.
5. Run `bun run db:migrate dev --name init_postgres` to create the baseline migration.
6. **Seed** production from `prisma/seed.ts` (site config, categories, homepage sections, policy pages, etc.).
7. **Backfill** real data (products, orders, users) from the SQLite snapshot via a one-off ETL script (write it when executing the migration — not in this doc).

### 2.4 Data integrity checks
- Row counts per table match between SQLite source and Postgres target.
- Foreign-key relationships intact (Prisma enforces; verify with `PRISMA_VALIDATE_FOREIGN_KEYS`).
- `cuid()` primary keys preserve their string values (no re-generation).
- `Order.orderNumber` format `KK-YYYYMMDD-NNNNN` preserved.

---

## 3. Planned Neon Deployment

[Neon](https://neon.tech) is the target serverless Postgres host.

| Item | Plan |
|------|------|
| Project name | `khati-khadyo-prod` |
| Region | AWS AP-Southeast-1 (Singapore — closest to Bangladesh) |
| Postgres version | 16 (Neon default) |
| Compute | Neon autoscaling (min 0.25 CU, max 2 CU) |
| Branching | `main` = production; `staging` branch for pre-prod testing |
| Point-in-time restore | Enabled (default 7 days; extend to 30 for prod) |
| Connection pooling | Neon pooled connection string (`-pooler` endpoint) for the app; direct connection for migrations |
| SSL | `sslmode=require` enforced in connection string |
| Backups | Neon automated backups + PITR (see §7) |

**Connection-string strategy:**
- `DATABASE_URL` (app runtime) → Neon **pooled** endpoint (`...-pooler.neon.tech`).
- `DIRECT_URL` (migrations) → Neon **direct** endpoint.

---

## 4. Planned Cloudinary Migration

| Aspect | Current | Target |
|--------|---------|--------|
| Module | `src/lib/cloudinary.ts` (present, unconfigured) | Configured with real credentials |
| Storage of product/banner/category images | URLs stored on `ProductImage.url`, `Banner.desktopImage`, etc. | Same — Cloudinary returns the URL |
| `MediaFile` table | Currently unused (uploads go straight to Cloudinary) | Populate on upload for a DB-backed media library, or drop the table (decision deferred) |
| Upload mode | Server-side signed upload from API routes | Same |
| Transformations | Cloudinary on-the-fly URL params (`f_auto,q_auto,w_…`) | Same |

**Migration steps:**
1. Create a Cloudinary account and a cloud named `khati-khadyo`.
2. Set `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET` in production env.
3. Verify `src/lib/cloudinary.ts` uses these env vars (it already does).
4. Upload existing seed images (logos, category SVGs, banner images) to the Cloudinary cloud.
5. Update `SiteConfig.logo` / banner `desktopImage` / category `image` to the Cloudinary URLs.
6. Confirm `/api/uploads` returns Cloudinary-hosted URLs.

---

## 5. Environment Variables Required

See **`ENVIRONMENT_VARIABLES.md`** for the full, canonical list. Summary:

- `DATABASE_URL` — Neon pooled connection string
- `DIRECT_URL` — Neon direct connection string (migrations)
- `JWT_SECRET` — 32+ char random string (auth throws without it in production)
- `SSLCOMMERZ_STORE_ID`, `SSLCOMMERZ_STORE_PASSWD`, `SSLCOMMERZ_STORE_NAME`
- `SSLCOMMERZ_IPN_URL` — public HTTPS URL
- `SSLCOMMERZ_SANDBOX` — `"true"` for staging, `"false"` for production
- `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET`
- `ZAI_API_KEY` — for the AI chat widget (`/api/chat`)
- `NEXT_PUBLIC_SITE_URL` — canonical public URL
- `NEXT_PUBLIC_CURRENCY`, `NEXT_PUBLIC_CURRENCY_SYMBOL`
- Cookie / CORS / NODE_ENV settings

---

## 6. Rollback Strategy

### 6.1 Rollback triggers
- Failed deployment that breaks checkout, payment, or auth.
- Data corruption detected in Postgres.
- SSLCommerz IPN storms or payment reconciliation failure.

### 6.2 Rollback levels

| Level | Action |
|-------|--------|
| **App rollback** | Re-deploy the previous Docker image / standalone build. Next.js standalone output makes this a single `server.js` swap. |
| **Migration rollback** | If a Prisma migration introduced a breaking change, run `prisma migrate resolve --rolled-back <migration_name>` and redeploy the prior image. **Never** run `prisma migrate reset` in production — it drops data. |
| **Database rollback** | Neon PITR — restore the database to a timestamp before the incident. App must be redeployed to a compatible version first. |
| **Config rollback** | Revert environment variables in the hosting platform. No code redeploy needed for env-only changes. |

### 6.3 Rollback sequence
1. Flip the load balancer / Caddy to return 503 (maintenance page).
2. Re-deploy the last known-good app image.
3. If data issue: restore Neon from PITR to a pre-incident timestamp.
4. Re-enable traffic.
5. Post-rollback QA: auth + checkout + payment smoke tests.

---

## 7. Backup Strategy

| Asset | Mechanism | Frequency | Retention |
|-------|-----------|-----------|-----------|
| Postgres database | Neon automated backups + PITR | Continuous (WAL streaming) | 30 days PITR |
| Postgres (off-cloud) | `pg_dump` to object storage | Nightly | 14 days rolling |
| Media (Cloudinary) | Cloudinary keeps originals; no separate backup needed for served URLs | — | — |
| App code | Git (main branch tagged on each release) | Per-release | Indefinite |
| Environment variables | Stored in the hosting platform's secret manager; exported to an encrypted vault | Per-change | Indefinite |
| `data/homepage-sections.json` (if still JSON-file based) | Git-tracked + nightly copy to object storage | Nightly | 14 days |
| Print artefacts (generated PDFs) | Regenerable from order data — no persistent backup required | — | — |

**Restore drill:** quarterly, restore the Neon backup to a staging branch and
verify the app boots and serves a sample order end-to-end.

---

## 8. Migration Order

Executed as a sequence of gated steps — each gate must pass before the next.

```
1. Delete stale db/custom.db                         (BUG-3)
2. Fix OrderStatusHistory / PrintQueue persistence   (BUG-1, BUG-2)
3. Create Neon project + staging branch
4. Update prisma/schema.prisma provider → postgresql
5. Regenerate Prisma client (bun run db:generate)
6. Run db:migrate against Neon staging branch
7. Seed staging from prisma/seed.ts
8. Run QA-1…QA-6 against staging                     ← GATE
9. Configure Cloudinary + upload seed media
10. Configure SSLCommerz sandbox credentials
11. Set JWT_SECRET + all env vars in staging
12. Full staging QA (auth, checkout, payment, print) ← GATE
13. ETL: backfill real data from SQLite → Neon prod
14. Cut DATABASE_URL to Neon production branch
15. Switch SSLCommerz to live credentials
16. Switch SSLCommerz SANDBOX=false
17. Smoke-test production                            ← GATE
18. Enable monitoring + alerts
19. Enable nightly pg_dump backup
```

---

## 9. Verification Checklist

After migration, verify **all** of the following before declaring production
live. (See also `PRODUCTION_CHECKLIST.md` for the full launch checklist.)

- [ ] `prisma/schema.prisma` provider is `postgresql`.
- [ ] `DATABASE_URL` points to the Neon pooled endpoint with `sslmode=require`.
- [ ] `DIRECT_URL` points to the Neon direct endpoint.
- [ ] `bun run db:generate` succeeds with zero errors.
- [ ] `bun run db:migrate deploy` succeeds with zero errors.
- [ ] All 30+ tables exist in Postgres with correct row counts vs. SQLite source.
- [ ] `User`, `Order`, `Product` counts match the pre-migration snapshot.
- [ ] Auth: register → login → session restore → address CRUD (QA-1).
- [ ] Order flow: create → stock decrement → delivery label → invoice (QA-2).
- [ ] All 17 admin modules render and CRUD works (QA-3).
- [ ] SSLCommerz success/fail/cancel/IPN round-trip with live credentials (QA-4).
- [ ] Print artefacts generate and download (QA-5).
- [ ] Responsive + sticky-footer on mobile + desktop (QA-6).
- [ ] Cloudinary uploads return hosted URLs.
- [ ] `JWT_SECRET` is set and ≥ 32 characters.
- [ ] CSP / HSTS / X-Frame-Options headers present (middleware).
- [ ] Neon PITR is enabled with 30-day retention.
- [ ] Nightly `pg_dump` backup is scheduled.
- [ ] Monitoring + alerts are live.
- [ ] Maintenance page (503) is configured for rollback.
