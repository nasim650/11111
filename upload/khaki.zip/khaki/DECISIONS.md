# DECISIONS.md

> Key engineering & architectural decisions for **Khati Khadyo**, with rationale
> and trade-offs. Inferred from source analysis of `v2.zip`.

Format: `ADR-style` — Decision · Context · Rationale · Consequences.

---

## D-1. Single-route SPA instead of Next.js file-based routing

**Decision.** The entire customer + admin UI is rendered from one route (`/`)
via a `currentPage` state machine in a Zustand store; there are no
`app/<segment>/page.tsx` files beyond `/` and `/api/*`.

**Context.** The storefront and admin share a great deal of state (cart,
auth, notifications, quick-view modal, compare drawer) and benefit from
instant in-app navigation with persistent overlays.

**Rationale.**
- Avoids full page reloads and re-hydration of shared overlays on every nav.
- Lets the cart sidebar, AI chat widget, and back-to-top button stay mounted
  across "pages".
- `React.lazy` + `Suspense` still gives code-splitting per page.

**Consequences.**
- ⚠️ Loses native Next.js URL deep-linking (`/products/123` doesn't work;
  navigation is in-memory). SEO for inner pages is weaker.
- ⚠️ Browser back/forward and shareable URLs require manual handling.
- ⚠️ Admin guard is client-side only (mitigated by server-side API guards).
- ✅ Simplest mental model for a tightly-coupled storefront+admin SPA.

---

## D-2. SQLite as the database (for now)

**Decision.** Use Prisma with the `sqlite` provider and a single file
`prisma/dev.db`.

**Context.** Project started as a self-contained demo/POC in a sandboxed
container.

**Rationale.** Zero-ops, file-based, perfect for development and
single-instance demos. Prisma abstracts the provider, so a later swap to
PostgreSQL is a schema-provider change + migration rather than a rewrite.

**Consequences.**
- ⚠️ Not safe for concurrent writes at production scale.
- ⚠️ No advanced types (arrays → stored as comma/JSON strings: `tags`,
  `specifications`, `deliveryZones`).
- ✅ Trivial local setup; `db:push` is the only migration step needed in dev.
- 🔁 Migration to PostgreSQL is an explicit roadmap item (`PROD-1`).

---

## D-3. JWT (jose, HS256) + bcrypt — no NextAuth

**Decision.** Hand-rolled auth: bcryptjs password hashing + jose-signed JWT
(HS256, 7-day expiry), transported as `Authorization: Bearer` + httpOnly
cookie. No NextAuth.js despite it being available.

**Context.** The team wanted full control over the token shape, role claims,
and the dual transport (cookie for SSR-ish flows + bearer for API clients).

**Rationale.** Fewer moving parts than NextAuth for a JWT-only model; direct
control of expiry and verification in route handlers via `getUserFromRequest`.

**Consequences.**
- ⚠️ No refresh-token / rotation mechanism (7-day hard expiry).
- ⚠️ Must enforce `JWT_SECRET` in production (auth throws otherwise).
- ✅ Small, auditable surface area; easy to reason about per-handler.
- 🔁 Add refresh tokens (`PROD-2`) before high-traffic launch.

---

## D-4. Client-side admin guard, server-side API enforcement

**Decision.** Admin *pages* are gated only by a Zustand `user.role === 'admin'`
check in `src/app/page.tsx`. Admin *API endpoints* are enforced server-side
via `isAdmin(role)`.

**Context.** Because routing is client-side (D-1), there is no middleware-level
route protection for virtual admin pages.

**Rationale.** Defense-in-depth at the API layer is sufficient for data
confidentiality; the client guard is just UX (hide admin nav / redirect).
All sensitive mutations go through server-protected handlers.

**Consequences.**
- ⚠️ An attacker could *view* the admin shell markup, but cannot read or mutate
  any data without a valid admin JWT.
- 🔁 Optional hardening: add a middleware/`proxy.ts` guard for `?page=admin-*`
  or move admin to a real protected route (`TD-5`/`BUG-6`).

---

## D-5. Persisted Zustand store as the single client truth

**Decision.** One large Zustand store (`src/lib/store.ts`, ~1000 lines) with
`persist` middleware to `localStorage`. It owns navigation, auth, cart,
wishlist, UI, notifications, compare, recently-viewed, and modals.

**Context.** The SPA model (D-1) needs cross-"page" state to survive
in-app navigation.

**Rationale.** Zustand is minimal, has no provider tree, and `persist` gives
free session restoration. Cart/wishlist are *also* synced server-side for
logged-in users (and by `kk_session_id` for guests).

**Consequences.**
- ⚠️ Single ~1000-line file is hard to navigate → slice it (`TD-2`).
- ⚠️ Persisted auth token in localStorage is an XSS-recoverable secret; the
  httpOnly cookie copy is the secure transport.
- ✅ Predictable, single source of truth; no React Context boilerplate.

---

## D-6. REST Route Handlers with a uniform `{ success, data }` envelope

**Decision.** All 60+ API endpoints are Next.js Route Handlers returning
`{ success: boolean, data?: …, error?: string }`. Lists are paginated via
`paginatedResponse`. No GraphQL, no tRPC.

**Context.** The frontend talks to the API with a thin `fetch` wrapper
(`src/lib/api.ts`).

**Rationale.** Maximally transparent; easy to test with `curl`; trivial to
document; no extra build step.

**Consequences.**
- ⚠️ No automatic type safety between client and server (mitigated by shared
  zod schemas in `src/lib/validation.ts`).
- ⚠️ Manual cache invalidation (no TanStack Query yet).
- ✅ Zero magic; onboarding is fast.

---

## D-7. SSLCommerz + COD for Bangladesh payments

**Decision.** Integrate **SSLCommerz** as the online gateway and support
**Cash-on-Delivery**. Implement the full success/fail/cancel/IPN callback set.

**Context.** Target market is Bangladesh; SSLCommerz is the dominant
omni-channel aggregator; COD is the majority preference.

**Rationale.** Covers the two payment modes Bangladeshi shoppers actually use;
`payment-sync.ts` reconciles async IPN with order state.

**Consequences.**
- ⚠️ Requires production store credentials + a public IPN URL.
- ⚠️ Redirect-based flow means the SPA must handle `?payment=…` returns.
- ✅ Native fit for the market.

---

## D-8. Print/document generation as an async post-order pipeline

**Decision.** After order creation, `generateAllOrderDocuments` produces
invoice PDF, packing slip, delivery label, thermal receipt, courier label,
QR, and CODE128 barcode, enqueuing each into a `PrintQueue` table.

**Context.** The fulfilment team needs printable, courier-ready documents per
order without manual steps.

**Rationale.** Decoupling generation from the order-creation request keeps the
checkout snappy; the queue gives the admin visibility + retry.

**Consequences.**
- ⚠️ Async generation is vulnerable to container OOM in dev (rows sometimes
  don't commit) — production is unaffected.
- 🔁 Real-time queue monitoring via socket.io is a roadmap item (`FEAT-2`).

---

## D-9. Cloudinary for media, `MediaFile` table currently unused

**Decision.** Product/banner/category images are uploaded directly to
Cloudinary (`src/lib/cloudinary.ts`); the `MediaFile` Prisma model exists but
is not populated.

**Context.** Cloudinary handles transforms/CDN; storing URLs on
`ProductImage.url` / `Banner.desktopImage` etc. is sufficient.

**Rationale.** Avoid duplicate source-of-truth; Cloudinary is the asset store.

**Consequences.**
- ⚠️ Admin "Media Library" has no DB-backed index of uploaded files.
- 🔁 Either populate `MediaFile` on upload or drop the model (`BUG-5`).

---

## D-10. Security headers via `middleware.ts` (Caddy in front)

**Decision.** Set CSP, X-Frame-Options, X-Content-Type-Options, Referrer-Policy,
Permissions-Policy, and HSTS (HTTPS-only) in `middleware.ts`. A Caddy gateway
on `:81` reverse-proxies to the Next.js dev server on `:3000`.

**Context.** Single externally-exposed port constraint in the sandbox.

**Rationale.** Defense-in-depth at the framework edge; Caddy handles TLS and
port multiplexing (`?XTransformPort=` for mini-services).

**Consequences.**
- ⚠️ CSP currently allows `'unsafe-eval'` in `script-src` — tighten before
  launch (`PROD-8`).
- ⚠️ `middleware.ts` is deprecated in Next.js 16 in favour of `proxy.ts`
  (`BUG-4`) — cosmetic only.
- ✅ Solid baseline header posture.

---

## D-11. House styling: shadcn/ui New York, emerald/teal accent, no indigo/blue

**Decision.** Use the shadcn/ui New York variant with a food/freshness emerald
+ teal palette; deliberately avoid indigo/blue.

**Context.** Brand identity for a Bangladeshi *food* store should feel fresh
and organic, not corporate-tech.

**Rationale.** Visual differentiation + thematic fit (green = fresh/organic).

**Consequences.**
- ✅ Consistent, professional look out of the box.
- 🔁 Keep verifying the "no indigo/blue" rule as new components land.

---

## D-12. Dual source-tree (root `app/`+`components/` AND `src/`)

**Decision (legacy).** The repo contains both a root-level `app/`/`components/`/
`lib/` tree **and** a `src/` tree. The `src/` tree is canonical (per
`tsconfig.json` `@/*` alias and the dev script).

**Context.** Likely an artifact of migrating a scaffold into `src/` without
deleting the originals.

**Rationale.** N/A — unintentional.

**Consequences.**
- ⚠️ Confusion about which files are live; risk of editing dead copies.
- 🔁 Delete the root-level duplicates (`TD-1`).

---

## D-13. z-ai-web-dev-sdk for the AI chat widget (backend-only)

**Decision.** The customer-support chat widget (`AIChatWidget.tsx`) calls
`POST /api/chat`, which uses `z-ai-web-dev-sdk` server-side with a
Khati-Khadyo-specific system prompt and per-session memory.

**Context.** House AI SDK available; must never run in the browser.

**Rationale.** Keeps API keys server-side; gives a branded, policy-aware
assistant (delivery info, return policy, payment methods).

**Consequences.**
- ✅ No client-side secret exposure.
- ⚠️ Rate-limited (20/min/IP) to bound cost — added in Phase 17.
- 🔁 Could extend to product recommendations (`FEAT-7`).
