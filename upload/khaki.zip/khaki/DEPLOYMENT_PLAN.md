# DEPLOYMENT_PLAN.md

> Deployment pipeline for **Khati Khadyo** — from development through testing,
> staging, and production.
>
> Documentation only. No deployment scripts.

---

## 1. Pipeline Overview

```
Development  →  Testing  →  Staging  →  Production
   (local)      (CI gate)   (Neon staging branch)   (Neon prod + live traffic)
```

Each stage is a hard gate. No code advances to the next stage until the
current stage's acceptance criteria pass.

---

## 2. Stage 1 — Development

| Item | Configuration |
|------|--------------|
| **Server** | Local dev server via `bun run dev` (Next.js 16 Turbopack, port 3000) |
| **Caddy** | Local Caddy on `:81` reverse-proxying to `:3000`; `?XTransformPort=` for mini-services |
| **Node/Bun** | Bun runtime (project uses `bun.lock`); Node ≥ 20 for tooling |
| **PostgreSQL** | SQLite (`prisma/dev.db`) for local dev — Postgres not required locally |
| **SSL** | None (HTTP localhost) |
| **Cloudinary** | Optional — unset; uploads fall back to local `/public` paths |
| **SSLCommerz** | Sandbox mode (`SSLCOMMERZ_SANDBOX=true`) or unset |
| **Monitoring** | `console.*` + `tee dev.log` |
| **Backup** | Git commits; `prisma/dev.db` is disposable |

**Exit criteria:** `bun run lint` passes; `bun run dev` serves `GET /` 200;
manual smoke of the feature under development.

---

## 3. Stage 2 — Testing (CI Gate)

| Item | Configuration |
|------|--------------|
| **Server** | CI runner (GitHub Actions / equivalent) — ephemeral |
| **Caddy** | Not used; tests hit `:3000` directly |
| **Node/Bun** | Bun in CI |
| **PostgreSQL** | Ephemeral SQLite or a throwaway Neon preview branch |
| **SSL** | None |
| **Cloudinary** | Unset (mock or skip upload tests) |
| **SSLCommerz** | Unset (skip live payment tests) |
| **Monitoring** | CI logs + test reporter |
| **Backup** | None (ephemeral) |

**Checks performed:**
- `bun run lint` (ESLint, zero errors in `src/`)
- `npx tsc --noEmit` (TypeScript strict, zero errors)
- `bun run db:generate` (Prisma client builds)
- Auth unit tests (register / login / session / ownership)
- Order-flow test (create → stock decrement → delivery label)
- API contract tests (`{ success, data }` envelope on all 60+ endpoints)

**Exit criteria:** all checks green; branch is mergeable.

---

## 4. Stage 3 — Staging

| Item | Configuration |
|------|--------------|
| **Server** | Production-class host (VPS / container) running the Next.js standalone build (`bun .next/standalone/server.js`) |
| **Caddy** | Caddy on `:81` (or `:443` via auto-HTTPS) reverse-proxying to the standalone server on `:3000`; same `?XTransformPort=` gateway pattern as dev |
| **Node/Bun** | Bun runtime in production mode (`NODE_ENV=production`) |
| **PostgreSQL** | **Neon staging branch** — a forked copy of production data, auto-synced |
| **SSL** | Caddy auto-HTTPS via Let's Encrypt for the staging domain (e.g. `staging.khatikhadyo.com`) |
| **Cloudinary** | Real credentials against a staging cloud (or the same cloud with a `staging/` folder prefix) |
| **SSLCommerz** | Sandbox credentials (`SSLCOMMERZ_SANDBOX=true`); IPN URL = `https://staging.khatikhadyo.com/api/payments/sslcommerz/ipn` |
| **Monitoring** | Structured logging (pino/winston) → log aggregator; error monitoring (Sentry) in staging mode |
| **Backup** | Neon PITR on the staging branch (7-day retention) |

**Exit criteria:** QA-1…QA-6 all pass against staging; SSLCommerz sandbox
round-trip succeeds; print artefacts generate; admin CMS fully functional.

---

## 5. Stage 4 — Production

| Item | Configuration |
|------|--------------|
| **Server** | Production VPS / container running the Next.js standalone build (`bun .next/standalone/server.js`) on `:3000`; process manager (systemd / PM2 / Docker restart policy) to auto-restart on crash |
| **Caddy** | Caddy on `:443` (auto-HTTPS via Let's Encrypt) reverse-proxying to `:3000`; `?XTransformPort=` for any mini-services; HTTP→HTTPS redirect enforced; security headers (CSP, HSTS, X-Frame-Options, X-Content-Type-Options, Referrer-Policy, Permissions-Policy) applied by Caddy and/or the Next.js `middleware.ts` |
| **Node/Bun** | Bun in production mode; `NODE_ENV=production`; memory limit tuned to avoid OOM (`--max-old-space-size=512` or container memory limit) |
| **PostgreSQL** | **Neon production branch** — serverless Postgres; pooled connection for the app (`DATABASE_URL`), direct connection for migrations (`DIRECT_URL`); `sslmode=require`; 30-day PITR |
| **SSL** | Caddy auto-HTTPS (Let's Encrypt) for `khatikhadyo.com` + `www.khatikhadyo.com`; HSTS with `max-age=31536000; includeSubDomains` |
| **Cloudinary** | Production cloud (`khati-khadyo`); real `CLOUDINARY_CLOUD_NAME` / `CLOUDINARY_API_KEY` / `CLOUDINARY_API_SECRET`; `f_auto,q_auto` transformations on all served URLs |
| **SSLCommerz** | Live store credentials (`SSLCOMMERZ_SANDBOX=false`); public IPN URL = `https://khatikhadyo.com/api/payments/sslcommerz/ipn`; success/fail/cancel routes on HTTPS |
| **Monitoring** | Structured logging → log aggregator; Sentry (or equivalent) for client + server error monitoring; uptime monitor on `GET /` and `GET /api/site-config`; Neon compute/connections dashboard |
| **Backup** | Neon automated backups + 30-day PITR; nightly `pg_dump` to object storage (14-day rolling); Git tags on every release; env vars stored in the hosting platform's secret manager + encrypted vault |

---

## 6. Per-Service Detail

### 6.1 Server (Next.js standalone)
- Build: `bun run build` produces `.next/standalone/server.js` + `.next/static/` + `public/`.
- Run: `NODE_ENV=production bun .next/standalone/server.js` (the `start` script).
- Port: `3000` (internal); Caddy fronts `443`.
- Restart policy: process manager or Docker `restart: always`.
- Health check: `GET /` returns 200; `GET /api/site-config` returns 200.

### 6.2 Caddy (gateway / TLS)
- Listens on `:80` (redirect to `:443`) and `:443`.
- Reverse-proxies to `localhost:3000`.
- `?XTransformPort=<port>` reverse-proxy rule preserved for mini-services.
- Auto-HTTPS via Let's Encrypt; HSTS header on HTTPS responses.
- The existing `Caddyfile` pattern is reused — only the domain and TLS settings change.

### 6.3 Node / Bun
- Runtime: Bun (matches `bun.lock`).
- `NODE_ENV=production`.
- Memory: container/process limit ≥ 512 MB to avoid the OOM kills observed in the dev sandbox (`PROD-5`).

### 6.4 PostgreSQL (Neon)
- Pooled connection for the app (`DATABASE_URL`).
- Direct connection for migrations (`DIRECT_URL`).
- `sslmode=require`.
- Region: AP-Southeast-1 (Singapore).
- 30-day PITR enabled.

### 6.5 SSL (TLS)
- Caddy auto-HTTPS via Let's Encrypt.
- Domains: `khatikhadyo.com`, `www.khatikhadyo.com`, `staging.khatikhadyo.com`.
- HSTS: `max-age=31536000; includeSubDomains`.
- HTTP→HTTPS redirect enforced at Caddy.

### 6.6 Cloudinary
- Cloud: `khati-khadyo`.
- All uploads server-side signed (`src/lib/cloudinary.ts`).
- Served URLs use `f_auto,q_auto` for format/quality optimisation.
- No local media storage in production.

### 6.7 SSLCommerz
- Live store: `SSLCOMMERZ_STORE_ID` + `SSLCOMMERZ_STORE_PASSWD` + `SSLCOMMERZ_STORE_NAME`.
- `SSLCOMMERZ_SANDBOX=false`.
- IPN URL: `https://khatikhadyo.com/api/payments/sslcommerz/ipn` (must be publicly reachable).
- Success / fail / cancel routes return HTTPS redirects.
- `payment-sync.ts` reconciles IPN callbacks with order state.

### 6.8 Monitoring
- **Logs:** structured JSON (pino or winston) → log aggregator (Loki / Datadog / CloudWatch).
- **Errors:** Sentry (or equivalent) for both client and server.
- **Uptime:** external uptime monitor on `GET /` and `GET /api/site-config`.
- **DB:** Neon dashboard (compute, connections, storage).
- **Payments:** alert on any `Payment.status = pending` older than 30 minutes.

### 6.9 Backup
- **Neon:** automated backups + 30-day PITR.
- **Off-cloud:** nightly `pg_dump` → object storage (14-day rolling).
- **Code:** Git, tagged per release.
- **Env:** hosting platform secret manager + encrypted vault.
- **Restore drill:** quarterly on staging.

---

## 7. Release Sequence (per deployment)

1. Merge feature branch → `main` (after CI green).
2. Tag the release (`git tag v0.x.y`).
3. Build the standalone image: `bun run build`.
4. Deploy to **staging**; run QA-1…QA-6.
5. If staging green: deploy to **production**.
6. Smoke-test production (auth + checkout + payment + print).
7. Enable monitoring alerts for the new release.
8. If any smoke test fails: execute the rollback strategy (see `MIGRATION_PLAN.md` §6).

---

## 8. Rollback (summary)

See `MIGRATION_PLAN.md` §6 for the full rollback strategy. In brief:
- **App:** redeploy previous image.
- **DB:** Neon PITR to pre-incident timestamp.
- **Config:** revert env vars.
- Never run `prisma migrate reset` in production.
