# NEXT_TASK.md

> Governance handoff file for the **Khati Khadyo** project.
> Defines the single next actionable objective and the guardrails for the next agent.

---

## Current Objective

Continue development of the **Khati Khadyo** e-commerce platform following the
established product-first philosophy. The immediate objective is to advance
the **actual pending work** listed in `TASKS.md` — prioritising stability and
production hardening over speculative features.

The next concrete step is to address the highest-priority open items:
- Resolve the dual-database confusion (`prisma/dev.db` canonical vs stale
  `db/custom.db`).
- Add transactional safety to `OrderStatusHistory` and `PrintQueue` writes so
  they persist reliably.
- Prepare for the planned **PostgreSQL migration** (provider swap in
  `prisma/schema.prisma`).

No UI redesign, no architecture redesign, no package installs/removals.

---

## Current Architecture Status

- **Framework**: Next.js 16 (App Router), single client-rendered route `/`
  driven by a persisted Zustand store (`src/lib/store.ts`).
- **API**: ~60 REST Route Handlers under `src/app/api/*` with a uniform
  `{ success, data }` envelope; server-side auth via jose JWT + bcrypt.
- **Database**: Prisma 6 + SQLite (`prisma/dev.db` canonical).
  **PostgreSQL migration is planned** but not yet executed.
- **Payments**: SSLCommerz + COD, with success/fail/cancel/IPN callbacks.
- **Media**: Cloudinary integration present; production credentials
  **planned** but not yet configured.
- **Print/fulfilment**: async PDF/barcode/QR pipeline writing to `PrintQueue`.
- **Admin CMS**: 17 modules functional.
- **Stability**: dev-server OOM kills observed in the sandbox container;
  code paths are correct but async post-transaction work can be lost.
- **Production-readiness** (per Phase 19): 8.5/10 (Grade A), no launch blockers.

---

## Current Constraints

- **Do NOT** redesign the architecture.
- **Do NOT** modify the UI or visual design.
- **Do NOT** modify the database schema unless the change is the explicitly
  planned PostgreSQL provider swap.
- **Do NOT** modify existing API contracts or response envelopes.
- **Do NOT** install or remove packages.
- **Do NOT** rename files or folders.
- **Do NOT** refactor code unless explicitly instructed.
- **Do NOT** enter review mode, iteration mode, or autonomous
  optimisation/planning.
- **Do NOT** scan the entire project more than once.
- **MUST** keep token usage low and perform only the requested task.

---

## Files Allowed To Edit

- `NEXT_TASK.md` (this file)
- `PROJECT_CONTEXT.md`
- `TASKS.md`
- `CHANGELOG.md`
- `DECISIONS.md`
- `worklog.md`

(When a concrete code task is later authorised, only the specific files
required for that task may be touched — not the broader tree.)

---

## Files Forbidden To Edit

- Any file under `src/app/**` (pages, layouts, API route handlers)
- Any file under `src/components/**` (UI, pages, shared, layout)
- Any file under `src/lib/**` (store, auth, db, sslcommerz, print-utils, etc.)
- Any file under `src/hooks/**`
- `src/middleware.ts` / root `middleware.ts`
- `prisma/schema.prisma` (unless executing the planned PG provider swap)
- `prisma/seed.ts`
- `package.json`, `bun.lock`, `package-lock.json`
- `tsconfig.json`, `eslint.config.mjs`, `postcss.config.mjs`,
  `tailwind.config.ts`, `next.config.ts`, `components.json`
- `Caddyfile`
- `.env`, `.gitignore`, `.vscode/**`, `.zscripts/**`
- `examples/**`, `mini-services/**`, `public/**`, `agent-ctx/**`

---

## Acceptance Criteria

The next agent's work is considered complete when **all** of the following hold:

1. The single highest-priority item from `TASKS.md` (Section A or B) is fully
   addressed, or — if it cannot be — a clear, minimal blocker note is appended
   to `worklog.md` instead of partial work.
2. No file outside the **Files Allowed To Edit** list is modified.
3. No packages are installed or removed (`package.json` / lockfiles unchanged).
4. No database schema change is made (unless it is the explicitly planned
   PostgreSQL provider swap, performed as its own isolated step).
5. No UI or visual design change is made.
6. `bun run lint` passes with no new errors.
7. `worklog.md` is appended (not overwritten) with a `---`-prefixed section
   containing: Task ID, Agent, Task, Work Log, Stage Summary.
8. `TASKS.md` remains free of speculative/AI-assumed items — only real pending
   work may remain.

---

## Notes For Next Agent

- **Read `PROJECT_CONTEXT.md` first** for the product overview and the
  "Project Development Rules" section before doing anything.
- **Read `worklog.md`** for the actual project progress (Phases A → 19) and
  the known non-blocking issues.
- **Canonical database is `prisma/dev.db`** — ignore the stale
  `db/custom.db`.
- The homepage is **product-first and admin-controlled** via the
  `HomepageSection` model + `/api/homepage-sections`; do not hard-code
  storefront sections.
- Checkout is **multi-step** (cart → address → payment → confirmation);
  preserve this flow in any change.
- UI language is **English** (Bangla toggle is a UI affordance only, not a
  content-translation requirement).
- Follow the **modular development workflow**: one focused task per round,
  minimal scope, append-only documentation updates.
- The architecture is **production-first**: design choices must be valid for
  production (Postgres, real Cloudinary creds, real SSLCommerz creds), not
  just the dev sandbox.
- After completing a task, update `worklog.md` and `TASKS.md` (mark items
  done / add new real items only) and add a `CHANGELOG.md` entry describing
  the change.
