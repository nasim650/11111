/**
 * API response extraction helpers
 *
 * API returns two formats:
 * 1. Paginated: { success: true, data: { data: [...], pagination: {...} } }
 * 2. Non-paginated: { success: true, data: [...] } or { success: true, data: <object> }
 */

/**
 * Extract items array from API response
 * Handles both paginated and non-paginated response formats
 */
export function extractItems<T>(response: unknown): T[] {
  if (Array.isArray(response)) return response
  if (!response || typeof response !== 'object') return []

  const obj = response as Record<string, unknown>

  // Check for { success: true, data: { data: [...], pagination: {...} } }
  if (obj.data) {
    if (Array.isArray(obj.data)) return obj.data as T[]

    const dataObj = obj.data as Record<string, unknown>
    // Paginated response: data.data is the items array
    if (dataObj.data && Array.isArray(dataObj.data)) return dataObj.data as T[]
    // Fallback: data.items
    if (dataObj.items && Array.isArray(dataObj.items)) return dataObj.items as T[]
  }

  // Direct items property
  if (obj.items && Array.isArray(obj.items)) return obj.items as T[]

  return []
}

/**
 * Extract pagination info from API response
 */
export function extractPagination(response: unknown): {
  page: number
  limit: number
  total: number
  totalPages: number
} {
  const defaultPagination = { page: 1, limit: 10, total: 0, totalPages: 0 }

  if (!response || typeof response !== 'object') return defaultPagination

  const obj = response as Record<string, unknown>

  // Check for { success: true, data: { pagination: {...} } }
  if (obj.data && typeof obj.data === 'object') {
    const dataObj = obj.data as Record<string, unknown>
    if (dataObj.pagination && typeof dataObj.pagination === 'object') {
      return dataObj.pagination as typeof defaultPagination
    }
  }

  // Direct pagination property
  if (obj.pagination && typeof obj.pagination === 'object') {
    return obj.pagination as typeof defaultPagination
  }

  return defaultPagination
}
