# ENVIRONMENT_VARIABLES.md

> Every environment variable required for **Khati Khadyo** production.
>
> This document **describes** variables only. It does **not** contain real
> values. Never commit actual secrets to Git — store them in the hosting
> platform's secret manager.

---

## 1. Database

### `DATABASE_URL`
- **Purpose:** Primary Prisma connection string used by the running application.
- **Production value:** Neon **pooled** connection string
  (`postgresql://USER:PASSWORD@HOST-pooler.neon.tech/DB?sslmode=require`).
- **Required:** Yes (app will not start without it).
- **Notes:** The pooled endpoint (`-pooler`) is mandatory for the app to
  avoid exhausting Postgres connections under load. Must include
  `sslmode=require`.

### `DIRECT_URL`
- **Purpose:** Direct (non-pooled) Prisma connection string used only for
  running migrations (`prisma migrate deploy`).
- **Production value:** Neon **direct** connection string
  (`postgresql://USER:PASSWORD@HOST.neon.tech/DB?sslmode=require`).
- **Required:** Yes (migrations will fail without it).
- **Notes:** Migrations must use the direct endpoint, not the pooled one.

---

## 2. Authentication

### `JWT_SECRET`
- **Purpose:** Secret key used to sign and verify JWT auth tokens (HS256,
  via `jose`).
- **Production value:** A cryptographically random string ≥ 32 characters.
- **Required:** Yes — **the app throws on startup in production if unset**
  (see `src/lib/auth.ts`).
- **Notes:** Generate with `openssl rand -base64 48`. Never commit. Rotate
  only if a token compromise is suspected (rotation invalidates all active
  sessions). A refresh-token mechanism is a known follow-up, not yet
  implemented.

---

## 3. Payment (SSLCommerz)

### `SSLCOMMERZ_STORE_ID`
- **Purpose:** SSLCommerz store identifier.
- **Production value:** The live store ID issued by SSLCommerz.
- **Required:** Yes for online payments.

### `SSLCOMMERZ_STORE_PASSWD`
- **Purpose:** SSLCommerz store password / API secret.
- **Production value:** The live store password issued by SSLCommerz.
- **Required:** Yes for online payments.
- **Notes:** Never commit. Store in the secret manager.

### `SSLCOMMERZ_STORE_NAME`
- **Purpose:** Human-readable store name sent to the SSLCommerz session
  initiation API.
- **Production value:** e.g. `Khati Khadyo`.
- **Required:** Yes.

### `SSLCOMMERZ_IPN_URL`
- **Purpose:** Public HTTPS URL that SSLCommerz calls to deliver Instant
  Payment Notifications.
- **Production value:** `https://khatikhadyo.com/api/payments/sslcommerz/ipn`.
- **Required:** Yes — payment reconciliation will not work without it.
- **Notes:** Must be reachable from the public internet (not localhost).

### `SSLCOMMERZ_SANDBOX`
- **Purpose:** Toggles between SSLCommerz sandbox and live gateway.
- **Production value:** `false`.
- **Staging value:** `true`.
- **Required:** Yes.

---

## 4. Images (Cloudinary)

### `CLOUDINARY_CLOUD_NAME`
- **Purpose:** Cloudinary cloud name.
- **Production value:** e.g. `khati-khadyo`.
- **Required:** Yes for media uploads.
- **Notes:** Configured in `src/lib/cloudinary.ts`.

### `CLOUDINARY_API_KEY`
- **Purpose:** Cloudinary API key.
- **Production value:** Numeric API key from the Cloudinary console.
- **Required:** Yes for media uploads.
- **Notes:** Never commit.

### `CLOUDINARY_API_SECRET`
- **Purpose:** Cloudinary API secret.
- **Production value:** The API secret from the Cloudinary console.
- **Required:** Yes for server-side signed uploads.
- **Notes:** Never commit. Store in the secret manager.

---

## 5. AI API Key

### `ZAI_API_KEY`
- **Purpose:** API key for the z-ai-web-dev-sdk, used by the AI chat widget
  (`/api/chat`).
- **Production value:** A valid Z.ai API key.
- **Required:** Yes for the AI chat support widget.
- **Notes:** The SDK must run server-side only — never expose this key in
  client code. Rate limiting (20/min/IP) is enforced on `/api/chat`.

---

## 6. Site URL

### `NEXT_PUBLIC_SITE_URL`
- **Purpose:** Canonical public URL of the site. Used for Open Graph tags,
  sitemap generation, and absolute URL construction.
- **Production value:** `https://khatikhadyo.com`.
- **Staging value:** `https://staging.khatikhadyo.com`.
- **Required:** Yes.
- **Notes:** `NEXT_PUBLIC_*` vars are inlined at build time — set before
  `bun run build`.

### `NEXT_PUBLIC_CURRENCY`
- **Purpose:** ISO currency code displayed in the UI.
- **Production value:** `BDT`.
- **Required:** Yes.

### `NEXT_PUBLIC_CURRENCY_SYMBOL`
- **Purpose:** Currency symbol shown to customers.
- **Production value:** `৳`.
- **Required:** Yes.

---

## 7. CORS

Cross-Origin Resource Sharing is governed by the Next.js `middleware.ts`
and the API route handlers. No dedicated `CORS_*` env var exists in the
current codebase, but production should enforce:

- **Allowed origins:** only `https://khatikhadyo.com` and
  `https://www.khatikhadyo.com` (plus `https://staging.khatikhadyo.com`
  for the staging environment).
- **Allowed methods:** `GET, POST, PUT, DELETE, OPTIONS`.
- **Allowed headers:** `Content-Type, Authorization`.
- **Credentials:** allowed (cookies + Bearer tokens).

If a future task introduces a `CORS_ALLOWED_ORIGINS` env var, document it
here. Currently CORS is implicit (same-origin API calls from the SPA).

---

## 8. Cookie Settings

Auth tokens are transported as:
1. `Authorization: Bearer <jwt>` header (primary).
2. An **httpOnly** cookie (for SSR / middleware reads).

Production cookie requirements:
- `httpOnly: true` — JavaScript cannot read the cookie.
- `secure: true` — cookie only sent over HTTPS.
- `sameSite: 'lax'` — protects against CSRF while allowing top-level
  navigation GETs.
- `path: '/'`.
- `maxAge`: 7 days (matches the JWT expiry).

If a dedicated `COOKIE_DOMAIN` or `COOKIE_SECURE` env var is introduced
later, document it here. Currently these are hardcoded in `src/lib/auth.ts`
and should be reviewed before launch.

---

## 9. Runtime / Build

### `NODE_ENV`
- **Purpose:** Node/Bun runtime mode.
- **Production value:** `production`.
- **Required:** Yes.
- **Notes:** When `production`, `src/lib/auth.ts` throws if `JWT_SECRET` is
  unset. Also enables Next.js production optimisations.

---

## 10. Summary Table

| Variable | Required | Purpose | Secret? |
|----------|----------|---------|---------|
| `DATABASE_URL` | Yes | Neon pooled Postgres connection | Yes |
| `DIRECT_URL` | Yes | Neon direct Postgres connection (migrations) | Yes |
| `JWT_SECRET` | Yes | JWT signing/verification (HS256) | Yes |
| `SSLCOMMERZ_STORE_ID` | Yes (online payments) | SSLCommerz store ID | No |
| `SSLCOMMERZ_STORE_PASSWD` | Yes (online payments) | SSLCommerz store password | Yes |
| `SSLCOMMERZ_STORE_NAME` | Yes (online payments) | SSLCommerz store name | No |
| `SSLCOMMERZ_IPN_URL` | Yes (online payments) | Public IPN endpoint | No |
| `SSLCOMMERZ_SANDBOX` | Yes | Sandbox toggle (`true`/`false`) | No |
| `CLOUDINARY_CLOUD_NAME` | Yes (media) | Cloudinary cloud name | No |
| `CLOUDINARY_API_KEY` | Yes (media) | Cloudinary API key | Yes |
| `CLOUDINARY_API_SECRET` | Yes (media) | Cloudinary API secret | Yes |
| `ZAI_API_KEY` | Yes (AI chat) | Z.ai SDK API key | Yes |
| `NEXT_PUBLIC_SITE_URL` | Yes | Canonical site URL | No |
| `NEXT_PUBLIC_CURRENCY` | Yes | Currency code (`BDT`) | No |
| `NEXT_PUBLIC_CURRENCY_SYMBOL` | Yes | Currency symbol (`৳`) | No |
| `NODE_ENV` | Yes | Runtime mode (`production`) | No |

---

## 11. Notes

- **Never commit** any variable marked "Secret? Yes" to Git or `.env`.
- **`NEXT_PUBLIC_*`** variables are inlined at build time — set them before
  running `bun run build`. Changing them requires a rebuild.
- **All other variables** are read at runtime and can be changed without a
  rebuild (just restart the process).
- **Secret rotation:** rotate `JWT_SECRET`, `SSLCOMMERZ_STORE_PASSWD`,
  `CLOUDINARY_API_SECRET`, and `ZAI_API_KEY` on a regular schedule (e.g.
  quarterly) or immediately on suspected compromise.
- **Staging vs. production:** use separate Neon projects, separate
  Cloudinary clouds (or folder prefixes), and separate SSLCommerz
  sandbox/live credentials. Never share production secrets with staging.
